-- Copyright (C) 2025  Altera Corporation. All rights reserved.
-- Your use of Altera Corporation's design tools, logic functions 
-- and other software and tools, and any partner logic 
-- functions, and any output files from any of the foregoing 
-- (including device programming or simulation files), and any 
-- associated documentation or information are expressly subject 
-- to the terms and conditions of the Altera Program License 
-- Subscription Agreement, the Altera Quartus Prime License Agreement,
-- the Altera IP License Agreement, or other applicable license
-- agreement, including, without limitation, that your use is for
-- the sole purpose of programming logic devices manufactured by
-- Altera and sold by Altera or its authorized distributors.  Please
-- refer to the Altera Software License Subscription Agreements 
-- on the Quartus Prime software download page.

-- VENDOR "Altera"
-- PROGRAM "Quartus Prime"
-- VERSION "Version 25.1std.0 Build 1129 10/21/2025 SC Lite Edition"

-- DATE "11/15/2026 22:11:01"

-- 
-- Device: Altera 5CSXFC6D6F31C6 Package FBGA896
-- 

-- 
-- This VHDL file should be used for Questa Altera FPGA (VHDL) only
-- 

LIBRARY ALTERA;
LIBRARY ALTERA_LNSIM;
LIBRARY CYCLONEV;
LIBRARY IEEE;
USE ALTERA.ALTERA_PRIMITIVES_COMPONENTS.ALL;
USE ALTERA_LNSIM.ALTERA_LNSIM_COMPONENTS.ALL;
USE CYCLONEV.CYCLONEV_COMPONENTS.ALL;
USE IEEE.STD_LOGIC_1164.ALL;

ENTITY 	timer_peripheral IS
    PORT (
	CLOCK : IN std_logic;
	RESETN : IN std_logic;
	IO_ADDR : IN std_logic_vector(10 DOWNTO 0);
	IO_READ : IN std_logic;
	IO_WRITE : IN std_logic;
	IO_DATA : INOUT std_logic_vector(15 DOWNTO 0)
	);
END timer_peripheral;

-- Design Ports Information
-- IO_DATA[0]	=>  Location: PIN_J7,	 I/O Standard: 3.3-V LVTTL,	 Current Strength: 16mA
-- IO_DATA[1]	=>  Location: PIN_F13,	 I/O Standard: 3.3-V LVTTL,	 Current Strength: 16mA
-- IO_DATA[2]	=>  Location: PIN_H8,	 I/O Standard: 3.3-V LVTTL,	 Current Strength: 16mA
-- IO_DATA[3]	=>  Location: PIN_D6,	 I/O Standard: 3.3-V LVTTL,	 Current Strength: 16mA
-- IO_DATA[4]	=>  Location: PIN_G13,	 I/O Standard: 3.3-V LVTTL,	 Current Strength: 16mA
-- IO_DATA[5]	=>  Location: PIN_F11,	 I/O Standard: 3.3-V LVTTL,	 Current Strength: 16mA
-- IO_DATA[6]	=>  Location: PIN_B1,	 I/O Standard: 3.3-V LVTTL,	 Current Strength: 16mA
-- IO_DATA[7]	=>  Location: PIN_D12,	 I/O Standard: 3.3-V LVTTL,	 Current Strength: 16mA
-- IO_DATA[8]	=>  Location: PIN_B2,	 I/O Standard: 3.3-V LVTTL,	 Current Strength: 16mA
-- IO_DATA[9]	=>  Location: PIN_H7,	 I/O Standard: 3.3-V LVTTL,	 Current Strength: 16mA
-- IO_DATA[10]	=>  Location: PIN_D7,	 I/O Standard: 3.3-V LVTTL,	 Current Strength: 16mA
-- IO_DATA[11]	=>  Location: PIN_E8,	 I/O Standard: 3.3-V LVTTL,	 Current Strength: 16mA
-- IO_DATA[12]	=>  Location: PIN_C10,	 I/O Standard: 3.3-V LVTTL,	 Current Strength: 16mA
-- IO_DATA[13]	=>  Location: PIN_A4,	 I/O Standard: 3.3-V LVTTL,	 Current Strength: 16mA
-- IO_DATA[14]	=>  Location: PIN_A6,	 I/O Standard: 3.3-V LVTTL,	 Current Strength: 16mA
-- IO_DATA[15]	=>  Location: PIN_E12,	 I/O Standard: 3.3-V LVTTL,	 Current Strength: 16mA
-- IO_ADDR[0]	=>  Location: PIN_H13,	 I/O Standard: 3.3-V LVTTL,	 Current Strength: Default
-- IO_ADDR[1]	=>  Location: PIN_E13,	 I/O Standard: 3.3-V LVTTL,	 Current Strength: Default
-- IO_ADDR[2]	=>  Location: PIN_G8,	 I/O Standard: 3.3-V LVTTL,	 Current Strength: Default
-- IO_ADDR[3]	=>  Location: PIN_A5,	 I/O Standard: 3.3-V LVTTL,	 Current Strength: Default
-- IO_READ	=>  Location: PIN_B5,	 I/O Standard: 3.3-V LVTTL,	 Current Strength: Default
-- IO_ADDR[10]	=>  Location: PIN_A3,	 I/O Standard: 3.3-V LVTTL,	 Current Strength: Default
-- IO_ADDR[4]	=>  Location: PIN_C4,	 I/O Standard: 3.3-V LVTTL,	 Current Strength: Default
-- IO_ADDR[5]	=>  Location: PIN_E11,	 I/O Standard: 3.3-V LVTTL,	 Current Strength: Default
-- IO_ADDR[6]	=>  Location: PIN_D5,	 I/O Standard: 3.3-V LVTTL,	 Current Strength: Default
-- IO_ADDR[7]	=>  Location: PIN_C5,	 I/O Standard: 3.3-V LVTTL,	 Current Strength: Default
-- IO_ADDR[8]	=>  Location: PIN_C2,	 I/O Standard: 3.3-V LVTTL,	 Current Strength: Default
-- IO_ADDR[9]	=>  Location: PIN_H14,	 I/O Standard: 3.3-V LVTTL,	 Current Strength: Default
-- CLOCK	=>  Location: PIN_Y27,	 I/O Standard: 3.3-V LVTTL,	 Current Strength: Default
-- RESETN	=>  Location: PIN_AB27,	 I/O Standard: 3.3-V LVTTL,	 Current Strength: Default
-- IO_WRITE	=>  Location: PIN_H12,	 I/O Standard: 3.3-V LVTTL,	 Current Strength: Default


ARCHITECTURE structure OF timer_peripheral IS
SIGNAL gnd : std_logic := '0';
SIGNAL vcc : std_logic := '1';
SIGNAL unknown : std_logic := 'X';
SIGNAL devoe : std_logic := '1';
SIGNAL devclrn : std_logic := '1';
SIGNAL devpor : std_logic := '1';
SIGNAL ww_devoe : std_logic;
SIGNAL ww_devclrn : std_logic;
SIGNAL ww_devpor : std_logic;
SIGNAL ww_CLOCK : std_logic;
SIGNAL ww_RESETN : std_logic;
SIGNAL ww_IO_ADDR : std_logic_vector(10 DOWNTO 0);
SIGNAL ww_IO_READ : std_logic;
SIGNAL ww_IO_WRITE : std_logic;
SIGNAL \~QUARTUS_CREATED_GND~I_combout\ : std_logic;
SIGNAL \IO_ADDR[3]~input_o\ : std_logic;
SIGNAL \IO_ADDR[2]~input_o\ : std_logic;
SIGNAL \IO_ADDR[0]~input_o\ : std_logic;
SIGNAL \IO_ADDR[1]~input_o\ : std_logic;
SIGNAL \read_value[0]~0_combout\ : std_logic;
SIGNAL \read_value[0]~1_combout\ : std_logic;
SIGNAL \CLOCK~input_o\ : std_logic;
SIGNAL \CLOCK~inputCLKENA0_outclk\ : std_logic;
SIGNAL \timers:3:channel|Add2~1_sumout\ : std_logic;
SIGNAL \IO_DATA[0]~input_o\ : std_logic;
SIGNAL \timers:3:channel|duration_r[0]~0_combout\ : std_logic;
SIGNAL \RESETN~input_o\ : std_logic;
SIGNAL \RESETN~inputCLKENA0_outclk\ : std_logic;
SIGNAL \IO_DATA[5]~input_o\ : std_logic;
SIGNAL \IO_DATA[6]~input_o\ : std_logic;
SIGNAL \IO_DATA[7]~input_o\ : std_logic;
SIGNAL \IO_DATA[4]~input_o\ : std_logic;
SIGNAL \IO_DATA[8]~input_o\ : std_logic;
SIGNAL \IO_DATA[9]~input_o\ : std_logic;
SIGNAL \timers:0:channel|Equal1~0_combout\ : std_logic;
SIGNAL \IO_DATA[10]~input_o\ : std_logic;
SIGNAL \IO_DATA[2]~input_o\ : std_logic;
SIGNAL \IO_DATA[3]~input_o\ : std_logic;
SIGNAL \IO_DATA[1]~input_o\ : std_logic;
SIGNAL \timers:0:channel|Equal1~2_combout\ : std_logic;
SIGNAL \IO_DATA[15]~input_o\ : std_logic;
SIGNAL \IO_DATA[11]~input_o\ : std_logic;
SIGNAL \IO_DATA[14]~input_o\ : std_logic;
SIGNAL \IO_DATA[12]~input_o\ : std_logic;
SIGNAL \IO_DATA[13]~input_o\ : std_logic;
SIGNAL \timers:0:channel|Equal1~1_combout\ : std_logic;
SIGNAL \timers:0:channel|process_0~1_combout\ : std_logic;
SIGNAL \IO_ADDR[10]~input_o\ : std_logic;
SIGNAL \Equal11~3_combout\ : std_logic;
SIGNAL \IO_WRITE~input_o\ : std_logic;
SIGNAL \IO_ADDR[5]~input_o\ : std_logic;
SIGNAL \IO_ADDR[6]~input_o\ : std_logic;
SIGNAL \IO_ADDR[7]~input_o\ : std_logic;
SIGNAL \IO_ADDR[4]~input_o\ : std_logic;
SIGNAL \IO_ADDR[9]~input_o\ : std_logic;
SIGNAL \IO_ADDR[8]~input_o\ : std_logic;
SIGNAL \Equal0~0_combout\ : std_logic;
SIGNAL \timers:3:channel|process_0~0_combout\ : std_logic;
SIGNAL \timers:3:channel|duration_r[0]~_wirecell_combout\ : std_logic;
SIGNAL \timers:0:channel|process_0~0_combout\ : std_logic;
SIGNAL \timers:3:channel|process_0~1_combout\ : std_logic;
SIGNAL \timers:0:channel|periods_r~0_combout\ : std_logic;
SIGNAL \timers:0:channel|Mux33~0_combout\ : std_logic;
SIGNAL \Equal11~4_combout\ : std_logic;
SIGNAL \timers:3:channel|mode_r[0]~0_combout\ : std_logic;
SIGNAL \timers:3:channel|process_0~2_combout\ : std_logic;
SIGNAL \timers:3:channel|clear_prescale~0_combout\ : std_logic;
SIGNAL \timers:3:channel|clear_prescale~q\ : std_logic;
SIGNAL \timers:3:channel|prescaler|cycle_count~4_combout\ : std_logic;
SIGNAL \timers:3:channel|prescaler|cycle_count[0]~1_combout\ : std_logic;
SIGNAL \timers:3:channel|prescaler|cycle_count~3_combout\ : std_logic;
SIGNAL \timers:3:channel|prescaler|cycle_count~2_combout\ : std_logic;
SIGNAL \timers:3:channel|prescaler|cycle_count~0_combout\ : std_logic;
SIGNAL \timers:3:channel|prescaler|LessThan0~0_combout\ : std_logic;
SIGNAL \timers:3:channel|prescaler|ms_count[4]~1_combout\ : std_logic;
SIGNAL \timers:3:channel|prescaler|Add1~49_sumout\ : std_logic;
SIGNAL \timers:3:channel|prescaler|Add1~50\ : std_logic;
SIGNAL \timers:3:channel|prescaler|Add1~45_sumout\ : std_logic;
SIGNAL \timers:3:channel|prescaler|Add1~46\ : std_logic;
SIGNAL \timers:3:channel|prescaler|Add1~41_sumout\ : std_logic;
SIGNAL \timers:3:channel|prescaler|Add1~42\ : std_logic;
SIGNAL \timers:3:channel|prescaler|Add1~37_sumout\ : std_logic;
SIGNAL \timers:3:channel|prescaler|Add1~38\ : std_logic;
SIGNAL \timers:3:channel|prescaler|Add1~33_sumout\ : std_logic;
SIGNAL \timers:3:channel|prescaler|Add1~34\ : std_logic;
SIGNAL \timers:3:channel|prescaler|Add1~61_sumout\ : std_logic;
SIGNAL \timers:3:channel|prescaler|Add1~62\ : std_logic;
SIGNAL \timers:3:channel|prescaler|Add1~57_sumout\ : std_logic;
SIGNAL \timers:3:channel|prescaler|Add1~58\ : std_logic;
SIGNAL \timers:3:channel|prescaler|Add1~53_sumout\ : std_logic;
SIGNAL \timers:3:channel|prescaler|Add1~54\ : std_logic;
SIGNAL \timers:3:channel|prescaler|Add1~25_sumout\ : std_logic;
SIGNAL \timers:3:channel|prescaler|Add1~26\ : std_logic;
SIGNAL \timers:3:channel|prescaler|Add1~29_sumout\ : std_logic;
SIGNAL \timers:3:channel|prescaler|Add1~30\ : std_logic;
SIGNAL \timers:3:channel|prescaler|Add1~21_sumout\ : std_logic;
SIGNAL \timers:3:channel|process_0~3_combout\ : std_logic;
SIGNAL \timers:3:channel|prescaler|Add1~22\ : std_logic;
SIGNAL \timers:3:channel|prescaler|Add1~5_sumout\ : std_logic;
SIGNAL \timers:3:channel|prescaler|Add1~6\ : std_logic;
SIGNAL \timers:3:channel|prescaler|Add1~17_sumout\ : std_logic;
SIGNAL \timers:3:channel|prescaler|Add1~18\ : std_logic;
SIGNAL \timers:3:channel|prescaler|Add1~13_sumout\ : std_logic;
SIGNAL \timers:3:channel|prescaler|Add1~14\ : std_logic;
SIGNAL \timers:3:channel|prescaler|Add1~9_sumout\ : std_logic;
SIGNAL \timers:3:channel|prescaler|LessThan1~0_combout\ : std_logic;
SIGNAL \timers:3:channel|prescaler|LessThan1~1_combout\ : std_logic;
SIGNAL \timers:3:channel|prescaler|LessThan1~2_combout\ : std_logic;
SIGNAL \timers:3:channel|timescale_r[9]~1_combout\ : std_logic;
SIGNAL \timers:3:channel|prescaler|LessThan1~4_combout\ : std_logic;
SIGNAL \timers:3:channel|timescale_r[8]~0_combout\ : std_logic;
SIGNAL \timers:3:channel|prescaler|LessThan1~14_combout\ : std_logic;
SIGNAL \timers:3:channel|prescaler|LessThan1~3_combout\ : std_logic;
SIGNAL \timers:3:channel|prescaler|LessThan1~15_combout\ : std_logic;
SIGNAL \timers:3:channel|prescaler|LessThan1~5_combout\ : std_logic;
SIGNAL \timers:3:channel|prescaler|LessThan1~6_combout\ : std_logic;
SIGNAL \timers:3:channel|timescale_r[2]~feeder_combout\ : std_logic;
SIGNAL \timers:3:channel|prescaler|LessThan1~8_combout\ : std_logic;
SIGNAL \timers:3:channel|timescale_r[3]~2_combout\ : std_logic;
SIGNAL \timers:3:channel|prescaler|LessThan1~7_combout\ : std_logic;
SIGNAL \timers:3:channel|prescaler|LessThan1~9_combout\ : std_logic;
SIGNAL \timers:3:channel|timescale_r[7]~3_combout\ : std_logic;
SIGNAL \timers:3:channel|timescale_r[6]~4_combout\ : std_logic;
SIGNAL \timers:3:channel|timescale_r[5]~5_combout\ : std_logic;
SIGNAL \timers:3:channel|prescaler|LessThan1~11_combout\ : std_logic;
SIGNAL \timers:3:channel|prescaler|LessThan1~10_combout\ : std_logic;
SIGNAL \timers:3:channel|prescaler|LessThan1~12_combout\ : std_logic;
SIGNAL \timers:3:channel|prescaler|LessThan1~13_combout\ : std_logic;
SIGNAL \timers:3:channel|prescaler|ms_count[4]~0_combout\ : std_logic;
SIGNAL \timers:3:channel|prescaler|Add1~10\ : std_logic;
SIGNAL \timers:3:channel|prescaler|Add1~1_sumout\ : std_logic;
SIGNAL \timers:3:channel|prescaler|TICK~0_combout\ : std_logic;
SIGNAL \timers:3:channel|prescaler|TICK~1_combout\ : std_logic;
SIGNAL \timers:3:channel|prescaler|TICK~q\ : std_logic;
SIGNAL \timers:3:channel|running_r~0_combout\ : std_logic;
SIGNAL \timers:3:channel|Add0~50\ : std_logic;
SIGNAL \timers:3:channel|Add0~46\ : std_logic;
SIGNAL \timers:3:channel|Add0~42\ : std_logic;
SIGNAL \timers:3:channel|Add0~38\ : std_logic;
SIGNAL \timers:3:channel|Add0~34\ : std_logic;
SIGNAL \timers:3:channel|Add0~62\ : std_logic;
SIGNAL \timers:3:channel|Add0~58\ : std_logic;
SIGNAL \timers:3:channel|Add0~54\ : std_logic;
SIGNAL \timers:3:channel|Add0~30\ : std_logic;
SIGNAL \timers:3:channel|Add0~26\ : std_logic;
SIGNAL \timers:3:channel|Add0~22\ : std_logic;
SIGNAL \timers:3:channel|Add0~18\ : std_logic;
SIGNAL \timers:3:channel|Add0~14\ : std_logic;
SIGNAL \timers:3:channel|Add0~10\ : std_logic;
SIGNAL \timers:3:channel|Add0~6\ : std_logic;
SIGNAL \timers:3:channel|Add0~1_sumout\ : std_logic;
SIGNAL \timers:3:channel|Add2~2\ : std_logic;
SIGNAL \timers:3:channel|Add2~5_sumout\ : std_logic;
SIGNAL \timers:3:channel|Add0~21_sumout\ : std_logic;
SIGNAL \timers:3:channel|Add0~17_sumout\ : std_logic;
SIGNAL \timers:3:channel|Add0~13_sumout\ : std_logic;
SIGNAL \timers:3:channel|Add0~9_sumout\ : std_logic;
SIGNAL \timers:3:channel|Add0~5_sumout\ : std_logic;
SIGNAL \timers:3:channel|LessThan0~0_combout\ : std_logic;
SIGNAL \timers:3:channel|LessThan0~5_combout\ : std_logic;
SIGNAL \timers:3:channel|LessThan0~6_combout\ : std_logic;
SIGNAL \timers:3:channel|Add0~25_sumout\ : std_logic;
SIGNAL \timers:3:channel|LessThan0~2_combout\ : std_logic;
SIGNAL \timers:3:channel|LessThan0~1_combout\ : std_logic;
SIGNAL \timers:3:channel|Add0~29_sumout\ : std_logic;
SIGNAL \timers:3:channel|LessThan0~14_combout\ : std_logic;
SIGNAL \timers:3:channel|LessThan0~15_combout\ : std_logic;
SIGNAL \timers:3:channel|LessThan0~7_combout\ : std_logic;
SIGNAL \timers:3:channel|LessThan0~3_combout\ : std_logic;
SIGNAL \timers:3:channel|Add0~49_sumout\ : std_logic;
SIGNAL \timers:3:channel|Add0~41_sumout\ : std_logic;
SIGNAL \timers:3:channel|Add0~45_sumout\ : std_logic;
SIGNAL \timers:3:channel|LessThan0~9_combout\ : std_logic;
SIGNAL \timers:3:channel|Add0~57_sumout\ : std_logic;
SIGNAL \timers:3:channel|Add0~53_sumout\ : std_logic;
SIGNAL \timers:3:channel|Add0~61_sumout\ : std_logic;
SIGNAL \timers:3:channel|LessThan0~11_combout\ : std_logic;
SIGNAL \timers:3:channel|Add0~37_sumout\ : std_logic;
SIGNAL \timers:3:channel|Add0~33_sumout\ : std_logic;
SIGNAL \timers:3:channel|LessThan0~8_combout\ : std_logic;
SIGNAL \timers:3:channel|LessThan0~12_combout\ : std_logic;
SIGNAL \timers:3:channel|LessThan0~10_combout\ : std_logic;
SIGNAL \timers:3:channel|LessThan0~17_combout\ : std_logic;
SIGNAL \timers:3:channel|LessThan0~18_combout\ : std_logic;
SIGNAL \timers:3:channel|elapsed_r[9]~1_combout\ : std_logic;
SIGNAL \timers:0:channel|periods_r~1_combout\ : std_logic;
SIGNAL \timers:3:channel|elapsed_r[9]~2_combout\ : std_logic;
SIGNAL \timers:3:channel|elapsed_r[9]~3_combout\ : std_logic;
SIGNAL \timers:3:channel|Add2~6\ : std_logic;
SIGNAL \timers:3:channel|Add2~9_sumout\ : std_logic;
SIGNAL \timers:3:channel|Add2~10\ : std_logic;
SIGNAL \timers:3:channel|Add2~13_sumout\ : std_logic;
SIGNAL \timers:3:channel|Add2~14\ : std_logic;
SIGNAL \timers:3:channel|Add2~17_sumout\ : std_logic;
SIGNAL \timers:3:channel|Add2~18\ : std_logic;
SIGNAL \timers:3:channel|Add2~21_sumout\ : std_logic;
SIGNAL \timers:3:channel|Add2~22\ : std_logic;
SIGNAL \timers:3:channel|Add2~25_sumout\ : std_logic;
SIGNAL \timers:3:channel|Add2~26\ : std_logic;
SIGNAL \timers:3:channel|Add2~29_sumout\ : std_logic;
SIGNAL \timers:3:channel|Add2~30\ : std_logic;
SIGNAL \timers:3:channel|Add2~33_sumout\ : std_logic;
SIGNAL \timers:3:channel|Add2~34\ : std_logic;
SIGNAL \timers:3:channel|Add2~37_sumout\ : std_logic;
SIGNAL \timers:3:channel|Add2~38\ : std_logic;
SIGNAL \timers:3:channel|Add2~41_sumout\ : std_logic;
SIGNAL \timers:3:channel|Add2~42\ : std_logic;
SIGNAL \timers:3:channel|Add2~45_sumout\ : std_logic;
SIGNAL \timers:3:channel|Add2~46\ : std_logic;
SIGNAL \timers:3:channel|Add2~49_sumout\ : std_logic;
SIGNAL \timers:3:channel|Add2~50\ : std_logic;
SIGNAL \timers:3:channel|Add2~53_sumout\ : std_logic;
SIGNAL \timers:3:channel|Add2~54\ : std_logic;
SIGNAL \timers:3:channel|Add2~57_sumout\ : std_logic;
SIGNAL \timers:3:channel|Add2~58\ : std_logic;
SIGNAL \timers:3:channel|Add2~61_sumout\ : std_logic;
SIGNAL \timers:3:channel|LessThan0~13_combout\ : std_logic;
SIGNAL \timers:3:channel|LessThan0~4_combout\ : std_logic;
SIGNAL \timers:3:channel|LessThan0~16_combout\ : std_logic;
SIGNAL \timers:3:channel|Mux33~0_combout\ : std_logic;
SIGNAL \timers:3:channel|running_r~q\ : std_logic;
SIGNAL \timers:3:channel|elapsed_r[9]~0_combout\ : std_logic;
SIGNAL \timers:2:channel|Add2~1_sumout\ : std_logic;
SIGNAL \timers:2:channel|duration_r[0]~0_combout\ : std_logic;
SIGNAL \Equal11~0_combout\ : std_logic;
SIGNAL \timers:2:channel|process_0~1_combout\ : std_logic;
SIGNAL \timers:2:channel|duration_r[0]~_wirecell_combout\ : std_logic;
SIGNAL \timers:2:channel|mode_r[0]~0_combout\ : std_logic;
SIGNAL \timers:2:channel|process_0~0_combout\ : std_logic;
SIGNAL \Equal11~1_combout\ : std_logic;
SIGNAL \timers:2:channel|clear_prescale~0_combout\ : std_logic;
SIGNAL \timers:2:channel|clear_prescale~q\ : std_logic;
SIGNAL \timers:2:channel|prescaler|cycle_count[3]~1_combout\ : std_logic;
SIGNAL \timers:2:channel|prescaler|cycle_count~4_combout\ : std_logic;
SIGNAL \timers:2:channel|prescaler|cycle_count[0]~DUPLICATE_q\ : std_logic;
SIGNAL \timers:2:channel|prescaler|cycle_count~3_combout\ : std_logic;
SIGNAL \timers:2:channel|prescaler|cycle_count~2_combout\ : std_logic;
SIGNAL \timers:2:channel|prescaler|cycle_count~0_combout\ : std_logic;
SIGNAL \timers:2:channel|prescaler|LessThan0~0_combout\ : std_logic;
SIGNAL \timers:2:channel|prescaler|TICK~0_combout\ : std_logic;
SIGNAL \timers:2:channel|timescale_r[8]~0_combout\ : std_logic;
SIGNAL \timers:2:channel|process_0~2_combout\ : std_logic;
SIGNAL \timers:2:channel|prescaler|ms_count[1]~1_combout\ : std_logic;
SIGNAL \timers:2:channel|prescaler|Add1~49_sumout\ : std_logic;
SIGNAL \timers:2:channel|prescaler|Add1~50\ : std_logic;
SIGNAL \timers:2:channel|prescaler|Add1~45_sumout\ : std_logic;
SIGNAL \timers:2:channel|prescaler|Add1~46\ : std_logic;
SIGNAL \timers:2:channel|prescaler|Add1~41_sumout\ : std_logic;
SIGNAL \timers:2:channel|prescaler|Add1~42\ : std_logic;
SIGNAL \timers:2:channel|prescaler|Add1~37_sumout\ : std_logic;
SIGNAL \timers:2:channel|prescaler|Add1~38\ : std_logic;
SIGNAL \timers:2:channel|prescaler|Add1~33_sumout\ : std_logic;
SIGNAL \timers:2:channel|prescaler|Add1~34\ : std_logic;
SIGNAL \timers:2:channel|prescaler|Add1~61_sumout\ : std_logic;
SIGNAL \timers:2:channel|prescaler|Add1~62\ : std_logic;
SIGNAL \timers:2:channel|prescaler|Add1~57_sumout\ : std_logic;
SIGNAL \timers:2:channel|prescaler|Add1~58\ : std_logic;
SIGNAL \timers:2:channel|prescaler|Add1~53_sumout\ : std_logic;
SIGNAL \timers:2:channel|prescaler|Add1~54\ : std_logic;
SIGNAL \timers:2:channel|prescaler|Add1~26\ : std_logic;
SIGNAL \timers:2:channel|prescaler|Add1~29_sumout\ : std_logic;
SIGNAL \timers:2:channel|prescaler|Add1~30\ : std_logic;
SIGNAL \timers:2:channel|prescaler|Add1~21_sumout\ : std_logic;
SIGNAL \timers:2:channel|prescaler|Add1~22\ : std_logic;
SIGNAL \timers:2:channel|prescaler|Add1~5_sumout\ : std_logic;
SIGNAL \timers:2:channel|prescaler|Add1~6\ : std_logic;
SIGNAL \timers:2:channel|prescaler|Add1~17_sumout\ : std_logic;
SIGNAL \timers:2:channel|prescaler|Add1~18\ : std_logic;
SIGNAL \timers:2:channel|prescaler|Add1~13_sumout\ : std_logic;
SIGNAL \timers:2:channel|prescaler|Add1~14\ : std_logic;
SIGNAL \timers:2:channel|prescaler|Add1~9_sumout\ : std_logic;
SIGNAL \timers:2:channel|prescaler|Add1~10\ : std_logic;
SIGNAL \timers:2:channel|prescaler|Add1~1_sumout\ : std_logic;
SIGNAL \timers:2:channel|timescale_r[9]~1_combout\ : std_logic;
SIGNAL \timers:2:channel|prescaler|LessThan1~14_combout\ : std_logic;
SIGNAL \timers:2:channel|prescaler|LessThan1~4_combout\ : std_logic;
SIGNAL \timers:2:channel|prescaler|LessThan1~3_combout\ : std_logic;
SIGNAL \timers:2:channel|timescale_r[12]~feeder_combout\ : std_logic;
SIGNAL \timers:2:channel|prescaler|LessThan1~0_combout\ : std_logic;
SIGNAL \timers:2:channel|prescaler|LessThan1~15_combout\ : std_logic;
SIGNAL \timers:2:channel|prescaler|LessThan1~1_combout\ : std_logic;
SIGNAL \timers:2:channel|prescaler|LessThan1~2_combout\ : std_logic;
SIGNAL \timers:2:channel|prescaler|ms_count[1]~0_combout\ : std_logic;
SIGNAL \timers:2:channel|prescaler|Add1~25_sumout\ : std_logic;
SIGNAL \timers:2:channel|prescaler|LessThan1~5_combout\ : std_logic;
SIGNAL \timers:2:channel|prescaler|LessThan1~6_combout\ : std_logic;
SIGNAL \timers:2:channel|timescale_r[3]~2_combout\ : std_logic;
SIGNAL \timers:2:channel|prescaler|LessThan1~9_combout\ : std_logic;
SIGNAL \timers:2:channel|prescaler|LessThan1~8_combout\ : std_logic;
SIGNAL \timers:2:channel|timescale_r[7]~3_combout\ : std_logic;
SIGNAL \timers:2:channel|timescale_r[5]~5_combout\ : std_logic;
SIGNAL \timers:2:channel|timescale_r[6]~4_combout\ : std_logic;
SIGNAL \timers:2:channel|prescaler|LessThan1~11_combout\ : std_logic;
SIGNAL \timers:2:channel|prescaler|LessThan1~7_combout\ : std_logic;
SIGNAL \timers:2:channel|prescaler|LessThan1~10_combout\ : std_logic;
SIGNAL \timers:2:channel|prescaler|LessThan1~12_combout\ : std_logic;
SIGNAL \timers:2:channel|prescaler|LessThan1~13_combout\ : std_logic;
SIGNAL \timers:2:channel|prescaler|TICK~1_combout\ : std_logic;
SIGNAL \timers:2:channel|prescaler|TICK~DUPLICATE_q\ : std_logic;
SIGNAL \timers:2:channel|running_r~0_combout\ : std_logic;
SIGNAL \timers:2:channel|Add2~2\ : std_logic;
SIGNAL \timers:2:channel|Add2~5_sumout\ : std_logic;
SIGNAL \timers:2:channel|Add0~50\ : std_logic;
SIGNAL \timers:2:channel|Add0~46\ : std_logic;
SIGNAL \timers:2:channel|Add0~42\ : std_logic;
SIGNAL \timers:2:channel|Add0~38\ : std_logic;
SIGNAL \timers:2:channel|Add0~34\ : std_logic;
SIGNAL \timers:2:channel|Add0~62\ : std_logic;
SIGNAL \timers:2:channel|Add0~58\ : std_logic;
SIGNAL \timers:2:channel|Add0~54\ : std_logic;
SIGNAL \timers:2:channel|Add0~30\ : std_logic;
SIGNAL \timers:2:channel|Add0~26\ : std_logic;
SIGNAL \timers:2:channel|Add0~22\ : std_logic;
SIGNAL \timers:2:channel|Add0~18\ : std_logic;
SIGNAL \timers:2:channel|Add0~14\ : std_logic;
SIGNAL \timers:2:channel|Add0~10\ : std_logic;
SIGNAL \timers:2:channel|Add0~6\ : std_logic;
SIGNAL \timers:2:channel|Add0~1_sumout\ : std_logic;
SIGNAL \timers:2:channel|Add2~42\ : std_logic;
SIGNAL \timers:2:channel|Add2~45_sumout\ : std_logic;
SIGNAL \timers:2:channel|elapsed_r[6]~3_combout\ : std_logic;
SIGNAL \timers:2:channel|elapsed_r[6]~4_combout\ : std_logic;
SIGNAL \timers:2:channel|Add2~46\ : std_logic;
SIGNAL \timers:2:channel|Add2~49_sumout\ : std_logic;
SIGNAL \timers:2:channel|Add2~50\ : std_logic;
SIGNAL \timers:2:channel|Add2~53_sumout\ : std_logic;
SIGNAL \timers:2:channel|Add2~54\ : std_logic;
SIGNAL \timers:2:channel|Add2~57_sumout\ : std_logic;
SIGNAL \timers:2:channel|Add2~58\ : std_logic;
SIGNAL \timers:2:channel|Add2~61_sumout\ : std_logic;
SIGNAL \timers:2:channel|Add0~25_sumout\ : std_logic;
SIGNAL \timers:2:channel|Add0~21_sumout\ : std_logic;
SIGNAL \timers:2:channel|LessThan0~2_combout\ : std_logic;
SIGNAL \timers:2:channel|Add0~17_sumout\ : std_logic;
SIGNAL \timers:2:channel|LessThan0~1_combout\ : std_logic;
SIGNAL \timers:2:channel|Add0~29_sumout\ : std_logic;
SIGNAL \timers:2:channel|LessThan0~14_combout\ : std_logic;
SIGNAL \timers:2:channel|Add0~13_sumout\ : std_logic;
SIGNAL \timers:2:channel|Add0~9_sumout\ : std_logic;
SIGNAL \timers:2:channel|Add0~5_sumout\ : std_logic;
SIGNAL \timers:2:channel|LessThan0~0_combout\ : std_logic;
SIGNAL \timers:2:channel|LessThan0~15_combout\ : std_logic;
SIGNAL \timers:2:channel|LessThan0~7_combout\ : std_logic;
SIGNAL \timers:2:channel|LessThan0~3_combout\ : std_logic;
SIGNAL \timers:2:channel|Add0~41_sumout\ : std_logic;
SIGNAL \timers:2:channel|Add0~37_sumout\ : std_logic;
SIGNAL \timers:2:channel|Add0~33_sumout\ : std_logic;
SIGNAL \timers:2:channel|LessThan0~10_combout\ : std_logic;
SIGNAL \timers:2:channel|Add0~49_sumout\ : std_logic;
SIGNAL \timers:2:channel|Add0~45_sumout\ : std_logic;
SIGNAL \timers:2:channel|LessThan0~9_combout\ : std_logic;
SIGNAL \timers:2:channel|Add0~53_sumout\ : std_logic;
SIGNAL \timers:2:channel|Add0~57_sumout\ : std_logic;
SIGNAL \timers:2:channel|Add0~61_sumout\ : std_logic;
SIGNAL \timers:2:channel|LessThan0~11_combout\ : std_logic;
SIGNAL \timers:2:channel|LessThan0~8_combout\ : std_logic;
SIGNAL \timers:2:channel|LessThan0~12_combout\ : std_logic;
SIGNAL \timers:2:channel|LessThan0~17_combout\ : std_logic;
SIGNAL \timers:2:channel|LessThan0~18_combout\ : std_logic;
SIGNAL \timers:2:channel|elapsed_r[6]~2_combout\ : std_logic;
SIGNAL \timers:2:channel|Add2~6\ : std_logic;
SIGNAL \timers:2:channel|Add2~9_sumout\ : std_logic;
SIGNAL \timers:2:channel|Add2~10\ : std_logic;
SIGNAL \timers:2:channel|Add2~13_sumout\ : std_logic;
SIGNAL \timers:2:channel|Add2~14\ : std_logic;
SIGNAL \timers:2:channel|Add2~17_sumout\ : std_logic;
SIGNAL \timers:2:channel|Add2~18\ : std_logic;
SIGNAL \timers:2:channel|Add2~21_sumout\ : std_logic;
SIGNAL \timers:2:channel|Add2~22\ : std_logic;
SIGNAL \timers:2:channel|Add2~25_sumout\ : std_logic;
SIGNAL \timers:2:channel|Add2~26\ : std_logic;
SIGNAL \timers:2:channel|Add2~29_sumout\ : std_logic;
SIGNAL \timers:2:channel|Add2~30\ : std_logic;
SIGNAL \timers:2:channel|Add2~33_sumout\ : std_logic;
SIGNAL \timers:2:channel|Add2~34\ : std_logic;
SIGNAL \timers:2:channel|Add2~37_sumout\ : std_logic;
SIGNAL \timers:2:channel|Add2~38\ : std_logic;
SIGNAL \timers:2:channel|Add2~41_sumout\ : std_logic;
SIGNAL \timers:2:channel|LessThan0~5_combout\ : std_logic;
SIGNAL \timers:2:channel|LessThan0~6_combout\ : std_logic;
SIGNAL \timers:2:channel|LessThan0~4_combout\ : std_logic;
SIGNAL \timers:2:channel|LessThan0~13_combout\ : std_logic;
SIGNAL \timers:2:channel|LessThan0~16_combout\ : std_logic;
SIGNAL \timers:2:channel|Mux33~0_combout\ : std_logic;
SIGNAL \timers:2:channel|running_r~q\ : std_logic;
SIGNAL \timers:2:channel|elapsed_r[6]~1_combout\ : std_logic;
SIGNAL \timers:1:channel|Add2~1_sumout\ : std_logic;
SIGNAL \timers:1:channel|duration_r[0]~0_combout\ : std_logic;
SIGNAL \timers:1:channel|process_0~0_combout\ : std_logic;
SIGNAL \timers:1:channel|duration_r[0]~_wirecell_combout\ : std_logic;
SIGNAL \Equal11~2_combout\ : std_logic;
SIGNAL \timers:1:channel|process_0~1_combout\ : std_logic;
SIGNAL \timers:1:channel|mode_r[0]~0_combout\ : std_logic;
SIGNAL \timers:1:channel|process_0~2_combout\ : std_logic;
SIGNAL \timers:1:channel|clear_prescale~0_combout\ : std_logic;
SIGNAL \timers:1:channel|clear_prescale~q\ : std_logic;
SIGNAL \timers:1:channel|prescaler|cycle_count~4_combout\ : std_logic;
SIGNAL \timers:1:channel|prescaler|cycle_count[2]~1_combout\ : std_logic;
SIGNAL \timers:1:channel|prescaler|cycle_count~3_combout\ : std_logic;
SIGNAL \timers:1:channel|prescaler|cycle_count~0_combout\ : std_logic;
SIGNAL \timers:1:channel|prescaler|cycle_count~2_combout\ : std_logic;
SIGNAL \timers:1:channel|prescaler|cycle_count[1]~DUPLICATE_q\ : std_logic;
SIGNAL \timers:1:channel|prescaler|LessThan0~0_combout\ : std_logic;
SIGNAL \timers:1:channel|prescaler|TICK~0_combout\ : std_logic;
SIGNAL \timers:1:channel|timescale_r[8]~0_combout\ : std_logic;
SIGNAL \timers:1:channel|prescaler|ms_count[7]~1_combout\ : std_logic;
SIGNAL \timers:1:channel|prescaler|Add1~49_sumout\ : std_logic;
SIGNAL \timers:1:channel|prescaler|Add1~50\ : std_logic;
SIGNAL \timers:1:channel|prescaler|Add1~45_sumout\ : std_logic;
SIGNAL \timers:1:channel|prescaler|Add1~46\ : std_logic;
SIGNAL \timers:1:channel|prescaler|Add1~41_sumout\ : std_logic;
SIGNAL \timers:1:channel|prescaler|Add1~42\ : std_logic;
SIGNAL \timers:1:channel|prescaler|Add1~37_sumout\ : std_logic;
SIGNAL \timers:1:channel|prescaler|Add1~38\ : std_logic;
SIGNAL \timers:1:channel|prescaler|Add1~33_sumout\ : std_logic;
SIGNAL \timers:1:channel|prescaler|Add1~34\ : std_logic;
SIGNAL \timers:1:channel|prescaler|Add1~61_sumout\ : std_logic;
SIGNAL \timers:1:channel|prescaler|Add1~62\ : std_logic;
SIGNAL \timers:1:channel|prescaler|Add1~57_sumout\ : std_logic;
SIGNAL \timers:1:channel|prescaler|Add1~58\ : std_logic;
SIGNAL \timers:1:channel|prescaler|Add1~53_sumout\ : std_logic;
SIGNAL \timers:1:channel|prescaler|Add1~54\ : std_logic;
SIGNAL \timers:1:channel|prescaler|Add1~25_sumout\ : std_logic;
SIGNAL \timers:1:channel|prescaler|LessThan1~14_combout\ : std_logic;
SIGNAL \timers:1:channel|prescaler|Add1~26\ : std_logic;
SIGNAL \timers:1:channel|prescaler|Add1~29_sumout\ : std_logic;
SIGNAL \timers:1:channel|timescale_r[9]~1_combout\ : std_logic;
SIGNAL \timers:1:channel|prescaler|Add1~30\ : std_logic;
SIGNAL \timers:1:channel|prescaler|Add1~21_sumout\ : std_logic;
SIGNAL \timers:1:channel|prescaler|LessThan1~4_combout\ : std_logic;
SIGNAL \timers:1:channel|prescaler|Add1~22\ : std_logic;
SIGNAL \timers:1:channel|prescaler|Add1~5_sumout\ : std_logic;
SIGNAL \timers:1:channel|prescaler|Add1~6\ : std_logic;
SIGNAL \timers:1:channel|prescaler|Add1~17_sumout\ : std_logic;
SIGNAL \timers:1:channel|prescaler|Add1~18\ : std_logic;
SIGNAL \timers:1:channel|prescaler|Add1~13_sumout\ : std_logic;
SIGNAL \timers:1:channel|prescaler|Add1~14\ : std_logic;
SIGNAL \timers:1:channel|prescaler|Add1~9_sumout\ : std_logic;
SIGNAL \timers:1:channel|prescaler|LessThan1~0_combout\ : std_logic;
SIGNAL \timers:1:channel|prescaler|LessThan1~3_combout\ : std_logic;
SIGNAL \timers:1:channel|prescaler|LessThan1~15_combout\ : std_logic;
SIGNAL \timers:1:channel|prescaler|LessThan1~6_combout\ : std_logic;
SIGNAL \timers:1:channel|prescaler|LessThan1~5_combout\ : std_logic;
SIGNAL \timers:1:channel|timescale_r[3]~2_combout\ : std_logic;
SIGNAL \timers:1:channel|prescaler|LessThan1~9_combout\ : std_logic;
SIGNAL \timers:1:channel|prescaler|LessThan1~8_combout\ : std_logic;
SIGNAL \timers:1:channel|prescaler|LessThan1~7_combout\ : std_logic;
SIGNAL \timers:1:channel|timescale_r[6]~4_combout\ : std_logic;
SIGNAL \timers:1:channel|timescale_r[5]~5_combout\ : std_logic;
SIGNAL \timers:1:channel|timescale_r[7]~3_combout\ : std_logic;
SIGNAL \timers:1:channel|prescaler|LessThan1~11_combout\ : std_logic;
SIGNAL \timers:1:channel|prescaler|LessThan1~10_combout\ : std_logic;
SIGNAL \timers:1:channel|prescaler|LessThan1~12_combout\ : std_logic;
SIGNAL \timers:1:channel|prescaler|LessThan1~13_combout\ : std_logic;
SIGNAL \timers:1:channel|prescaler|LessThan1~1_combout\ : std_logic;
SIGNAL \timers:1:channel|prescaler|LessThan1~2_combout\ : std_logic;
SIGNAL \timers:1:channel|prescaler|ms_count[7]~0_combout\ : std_logic;
SIGNAL \timers:1:channel|prescaler|Add1~10\ : std_logic;
SIGNAL \timers:1:channel|prescaler|Add1~1_sumout\ : std_logic;
SIGNAL \timers:1:channel|prescaler|TICK~1_combout\ : std_logic;
SIGNAL \timers:1:channel|prescaler|TICK~q\ : std_logic;
SIGNAL \timers:1:channel|running_r~0_combout\ : std_logic;
SIGNAL \timers:1:channel|Add2~2\ : std_logic;
SIGNAL \timers:1:channel|Add2~5_sumout\ : std_logic;
SIGNAL \timers:1:channel|Add2~30\ : std_logic;
SIGNAL \timers:1:channel|Add2~33_sumout\ : std_logic;
SIGNAL \timers:1:channel|elapsed_r[14]~2_combout\ : std_logic;
SIGNAL \timers:1:channel|elapsed_r[14]~3_combout\ : std_logic;
SIGNAL \timers:1:channel|Add2~34\ : std_logic;
SIGNAL \timers:1:channel|Add2~37_sumout\ : std_logic;
SIGNAL \timers:1:channel|Add2~38\ : std_logic;
SIGNAL \timers:1:channel|Add2~41_sumout\ : std_logic;
SIGNAL \timers:1:channel|Add2~42\ : std_logic;
SIGNAL \timers:1:channel|Add2~45_sumout\ : std_logic;
SIGNAL \timers:1:channel|Add2~46\ : std_logic;
SIGNAL \timers:1:channel|Add2~49_sumout\ : std_logic;
SIGNAL \timers:1:channel|Add2~50\ : std_logic;
SIGNAL \timers:1:channel|Add2~53_sumout\ : std_logic;
SIGNAL \timers:1:channel|Add2~54\ : std_logic;
SIGNAL \timers:1:channel|Add2~57_sumout\ : std_logic;
SIGNAL \timers:1:channel|Add2~58\ : std_logic;
SIGNAL \timers:1:channel|Add2~61_sumout\ : std_logic;
SIGNAL \timers:1:channel|Add0~50\ : std_logic;
SIGNAL \timers:1:channel|Add0~46\ : std_logic;
SIGNAL \timers:1:channel|Add0~42\ : std_logic;
SIGNAL \timers:1:channel|Add0~38\ : std_logic;
SIGNAL \timers:1:channel|Add0~34\ : std_logic;
SIGNAL \timers:1:channel|Add0~62\ : std_logic;
SIGNAL \timers:1:channel|Add0~58\ : std_logic;
SIGNAL \timers:1:channel|Add0~54\ : std_logic;
SIGNAL \timers:1:channel|Add0~30\ : std_logic;
SIGNAL \timers:1:channel|Add0~26\ : std_logic;
SIGNAL \timers:1:channel|Add0~21_sumout\ : std_logic;
SIGNAL \timers:1:channel|Add0~22\ : std_logic;
SIGNAL \timers:1:channel|Add0~18\ : std_logic;
SIGNAL \timers:1:channel|Add0~13_sumout\ : std_logic;
SIGNAL \timers:1:channel|Add0~14\ : std_logic;
SIGNAL \timers:1:channel|Add0~10\ : std_logic;
SIGNAL \timers:1:channel|Add0~5_sumout\ : std_logic;
SIGNAL \timers:1:channel|Add0~9_sumout\ : std_logic;
SIGNAL \timers:1:channel|LessThan0~0_combout\ : std_logic;
SIGNAL \timers:1:channel|Add0~17_sumout\ : std_logic;
SIGNAL \timers:1:channel|LessThan0~5_combout\ : std_logic;
SIGNAL \timers:1:channel|LessThan0~6_combout\ : std_logic;
SIGNAL \timers:1:channel|Add0~6\ : std_logic;
SIGNAL \timers:1:channel|Add0~1_sumout\ : std_logic;
SIGNAL \timers:1:channel|LessThan0~2_combout\ : std_logic;
SIGNAL \timers:1:channel|Add0~29_sumout\ : std_logic;
SIGNAL \timers:1:channel|LessThan0~7_combout\ : std_logic;
SIGNAL \timers:1:channel|LessThan0~1_combout\ : std_logic;
SIGNAL \timers:1:channel|Add0~25_sumout\ : std_logic;
SIGNAL \timers:1:channel|LessThan0~3_combout\ : std_logic;
SIGNAL \timers:1:channel|Add0~41_sumout\ : std_logic;
SIGNAL \timers:1:channel|Add0~33_sumout\ : std_logic;
SIGNAL \timers:1:channel|Add0~37_sumout\ : std_logic;
SIGNAL \timers:1:channel|LessThan0~10_combout\ : std_logic;
SIGNAL \timers:1:channel|Add0~49_sumout\ : std_logic;
SIGNAL \timers:1:channel|Add0~45_sumout\ : std_logic;
SIGNAL \timers:1:channel|LessThan0~9_combout\ : std_logic;
SIGNAL \timers:1:channel|Add0~57_sumout\ : std_logic;
SIGNAL \timers:1:channel|Add0~53_sumout\ : std_logic;
SIGNAL \timers:1:channel|Add0~61_sumout\ : std_logic;
SIGNAL \timers:1:channel|LessThan0~11_combout\ : std_logic;
SIGNAL \timers:1:channel|LessThan0~8_combout\ : std_logic;
SIGNAL \timers:1:channel|LessThan0~17_combout\ : std_logic;
SIGNAL \timers:1:channel|LessThan0~18_combout\ : std_logic;
SIGNAL \timers:1:channel|LessThan0~14_combout\ : std_logic;
SIGNAL \timers:1:channel|LessThan0~15_combout\ : std_logic;
SIGNAL \timers:1:channel|elapsed_r[14]~1_combout\ : std_logic;
SIGNAL \timers:1:channel|Add2~6\ : std_logic;
SIGNAL \timers:1:channel|Add2~9_sumout\ : std_logic;
SIGNAL \timers:1:channel|Add2~10\ : std_logic;
SIGNAL \timers:1:channel|Add2~13_sumout\ : std_logic;
SIGNAL \timers:1:channel|Add2~14\ : std_logic;
SIGNAL \timers:1:channel|Add2~17_sumout\ : std_logic;
SIGNAL \timers:1:channel|Add2~18\ : std_logic;
SIGNAL \timers:1:channel|Add2~21_sumout\ : std_logic;
SIGNAL \timers:1:channel|Add2~22\ : std_logic;
SIGNAL \timers:1:channel|Add2~25_sumout\ : std_logic;
SIGNAL \timers:1:channel|Add2~26\ : std_logic;
SIGNAL \timers:1:channel|Add2~29_sumout\ : std_logic;
SIGNAL \timers:1:channel|LessThan0~12_combout\ : std_logic;
SIGNAL \timers:1:channel|LessThan0~13_combout\ : std_logic;
SIGNAL \timers:1:channel|LessThan0~4_combout\ : std_logic;
SIGNAL \timers:1:channel|LessThan0~16_combout\ : std_logic;
SIGNAL \timers:1:channel|Mux33~0_combout\ : std_logic;
SIGNAL \timers:1:channel|running_r~q\ : std_logic;
SIGNAL \timers:1:channel|elapsed_r[14]~0_combout\ : std_logic;
SIGNAL \timers:0:channel|Add2~1_sumout\ : std_logic;
SIGNAL \timers:0:channel|duration_r[0]~0_combout\ : std_logic;
SIGNAL \timers:0:channel|process_0~2_combout\ : std_logic;
SIGNAL \timers:0:channel|duration_r[0]~_wirecell_combout\ : std_logic;
SIGNAL \timers:0:channel|process_0~3_combout\ : std_logic;
SIGNAL \timers:0:channel|mode_r[0]~0_combout\ : std_logic;
SIGNAL \timers:0:channel|clear_prescale~0_combout\ : std_logic;
SIGNAL \timers:0:channel|clear_prescale~q\ : std_logic;
SIGNAL \timers:0:channel|process_0~4_combout\ : std_logic;
SIGNAL \timers:0:channel|prescaler|cycle_count[3]~1_combout\ : std_logic;
SIGNAL \timers:0:channel|prescaler|cycle_count~4_combout\ : std_logic;
SIGNAL \timers:0:channel|prescaler|cycle_count[0]~DUPLICATE_q\ : std_logic;
SIGNAL \timers:0:channel|prescaler|cycle_count~3_combout\ : std_logic;
SIGNAL \timers:0:channel|prescaler|cycle_count~0_combout\ : std_logic;
SIGNAL \timers:0:channel|prescaler|cycle_count~2_combout\ : std_logic;
SIGNAL \timers:0:channel|prescaler|LessThan0~0_combout\ : std_logic;
SIGNAL \timers:0:channel|prescaler|ms_count[0]~1_combout\ : std_logic;
SIGNAL \timers:0:channel|prescaler|Add1~49_sumout\ : std_logic;
SIGNAL \timers:0:channel|prescaler|Add1~50\ : std_logic;
SIGNAL \timers:0:channel|prescaler|Add1~45_sumout\ : std_logic;
SIGNAL \timers:0:channel|prescaler|Add1~46\ : std_logic;
SIGNAL \timers:0:channel|prescaler|Add1~41_sumout\ : std_logic;
SIGNAL \timers:0:channel|prescaler|Add1~42\ : std_logic;
SIGNAL \timers:0:channel|prescaler|Add1~37_sumout\ : std_logic;
SIGNAL \timers:0:channel|prescaler|Add1~38\ : std_logic;
SIGNAL \timers:0:channel|prescaler|Add1~33_sumout\ : std_logic;
SIGNAL \timers:0:channel|prescaler|Add1~34\ : std_logic;
SIGNAL \timers:0:channel|prescaler|Add1~61_sumout\ : std_logic;
SIGNAL \timers:0:channel|prescaler|Add1~62\ : std_logic;
SIGNAL \timers:0:channel|prescaler|Add1~57_sumout\ : std_logic;
SIGNAL \timers:0:channel|prescaler|Add1~58\ : std_logic;
SIGNAL \timers:0:channel|prescaler|Add1~53_sumout\ : std_logic;
SIGNAL \timers:0:channel|prescaler|Add1~54\ : std_logic;
SIGNAL \timers:0:channel|prescaler|Add1~25_sumout\ : std_logic;
SIGNAL \timers:0:channel|prescaler|Add1~26\ : std_logic;
SIGNAL \timers:0:channel|prescaler|Add1~29_sumout\ : std_logic;
SIGNAL \timers:0:channel|prescaler|Add1~30\ : std_logic;
SIGNAL \timers:0:channel|prescaler|Add1~21_sumout\ : std_logic;
SIGNAL \timers:0:channel|prescaler|Add1~22\ : std_logic;
SIGNAL \timers:0:channel|prescaler|Add1~5_sumout\ : std_logic;
SIGNAL \timers:0:channel|prescaler|Add1~6\ : std_logic;
SIGNAL \timers:0:channel|prescaler|Add1~17_sumout\ : std_logic;
SIGNAL \timers:0:channel|prescaler|Add1~18\ : std_logic;
SIGNAL \timers:0:channel|prescaler|Add1~13_sumout\ : std_logic;
SIGNAL \timers:0:channel|prescaler|Add1~14\ : std_logic;
SIGNAL \timers:0:channel|prescaler|Add1~9_sumout\ : std_logic;
SIGNAL \timers:0:channel|prescaler|LessThan1~0_combout\ : std_logic;
SIGNAL \timers:0:channel|prescaler|LessThan1~1_combout\ : std_logic;
SIGNAL \timers:0:channel|prescaler|LessThan1~2_combout\ : std_logic;
SIGNAL \timers:0:channel|timescale_r[8]~0_combout\ : std_logic;
SIGNAL \timers:0:channel|prescaler|LessThan1~14_combout\ : std_logic;
SIGNAL \timers:0:channel|timescale_r[9]~1_combout\ : std_logic;
SIGNAL \timers:0:channel|prescaler|LessThan1~4_combout\ : std_logic;
SIGNAL \timers:0:channel|prescaler|LessThan1~3_combout\ : std_logic;
SIGNAL \timers:0:channel|prescaler|LessThan1~15_combout\ : std_logic;
SIGNAL \timers:0:channel|prescaler|LessThan1~5_combout\ : std_logic;
SIGNAL \timers:0:channel|prescaler|LessThan1~6_combout\ : std_logic;
SIGNAL \timers:0:channel|timescale_r[0]~feeder_combout\ : std_logic;
SIGNAL \timers:0:channel|prescaler|LessThan1~8_combout\ : std_logic;
SIGNAL \timers:0:channel|timescale_r[3]~2_combout\ : std_logic;
SIGNAL \timers:0:channel|prescaler|LessThan1~7_combout\ : std_logic;
SIGNAL \timers:0:channel|prescaler|LessThan1~9_combout\ : std_logic;
SIGNAL \timers:0:channel|timescale_r[7]~3_combout\ : std_logic;
SIGNAL \timers:0:channel|timescale_r[6]~4_combout\ : std_logic;
SIGNAL \timers:0:channel|timescale_r[5]~5_combout\ : std_logic;
SIGNAL \timers:0:channel|prescaler|LessThan1~10_combout\ : std_logic;
SIGNAL \timers:0:channel|prescaler|LessThan1~11_combout\ : std_logic;
SIGNAL \timers:0:channel|prescaler|LessThan1~12_combout\ : std_logic;
SIGNAL \timers:0:channel|prescaler|LessThan1~13_combout\ : std_logic;
SIGNAL \timers:0:channel|prescaler|ms_count[0]~0_combout\ : std_logic;
SIGNAL \timers:0:channel|prescaler|Add1~10\ : std_logic;
SIGNAL \timers:0:channel|prescaler|Add1~1_sumout\ : std_logic;
SIGNAL \timers:0:channel|prescaler|TICK~0_combout\ : std_logic;
SIGNAL \timers:0:channel|prescaler|TICK~1_combout\ : std_logic;
SIGNAL \timers:0:channel|prescaler|TICK~q\ : std_logic;
SIGNAL \timers:0:channel|running_r~0_combout\ : std_logic;
SIGNAL \timers:0:channel|Add2~2\ : std_logic;
SIGNAL \timers:0:channel|Add2~5_sumout\ : std_logic;
SIGNAL \timers:0:channel|Add0~50\ : std_logic;
SIGNAL \timers:0:channel|Add0~46\ : std_logic;
SIGNAL \timers:0:channel|Add0~42\ : std_logic;
SIGNAL \timers:0:channel|Add0~38\ : std_logic;
SIGNAL \timers:0:channel|Add0~34\ : std_logic;
SIGNAL \timers:0:channel|Add0~62\ : std_logic;
SIGNAL \timers:0:channel|Add0~58\ : std_logic;
SIGNAL \timers:0:channel|Add0~54\ : std_logic;
SIGNAL \timers:0:channel|Add0~30\ : std_logic;
SIGNAL \timers:0:channel|Add0~26\ : std_logic;
SIGNAL \timers:0:channel|Add0~22\ : std_logic;
SIGNAL \timers:0:channel|Add0~18\ : std_logic;
SIGNAL \timers:0:channel|Add0~14\ : std_logic;
SIGNAL \timers:0:channel|Add0~10\ : std_logic;
SIGNAL \timers:0:channel|Add0~6\ : std_logic;
SIGNAL \timers:0:channel|Add0~1_sumout\ : std_logic;
SIGNAL \timers:0:channel|Add0~25_sumout\ : std_logic;
SIGNAL \timers:0:channel|Add0~29_sumout\ : std_logic;
SIGNAL \timers:0:channel|LessThan0~14_combout\ : std_logic;
SIGNAL \timers:0:channel|Add0~21_sumout\ : std_logic;
SIGNAL \timers:0:channel|LessThan0~2_combout\ : std_logic;
SIGNAL \timers:0:channel|Add0~17_sumout\ : std_logic;
SIGNAL \timers:0:channel|LessThan0~1_combout\ : std_logic;
SIGNAL \timers:0:channel|Add0~13_sumout\ : std_logic;
SIGNAL \timers:0:channel|Add0~5_sumout\ : std_logic;
SIGNAL \timers:0:channel|Add0~9_sumout\ : std_logic;
SIGNAL \timers:0:channel|LessThan0~0_combout\ : std_logic;
SIGNAL \timers:0:channel|LessThan0~15_combout\ : std_logic;
SIGNAL \timers:0:channel|LessThan0~7_combout\ : std_logic;
SIGNAL \timers:0:channel|LessThan0~3_combout\ : std_logic;
SIGNAL \timers:0:channel|Add0~41_sumout\ : std_logic;
SIGNAL \timers:0:channel|Add0~33_sumout\ : std_logic;
SIGNAL \timers:0:channel|Add0~37_sumout\ : std_logic;
SIGNAL \timers:0:channel|LessThan0~10_combout\ : std_logic;
SIGNAL \timers:0:channel|LessThan0~8_combout\ : std_logic;
SIGNAL \timers:0:channel|Add0~57_sumout\ : std_logic;
SIGNAL \timers:0:channel|Add0~61_sumout\ : std_logic;
SIGNAL \timers:0:channel|Add0~53_sumout\ : std_logic;
SIGNAL \timers:0:channel|LessThan0~11_combout\ : std_logic;
SIGNAL \timers:0:channel|Add0~49_sumout\ : std_logic;
SIGNAL \timers:0:channel|Add0~45_sumout\ : std_logic;
SIGNAL \timers:0:channel|LessThan0~9_combout\ : std_logic;
SIGNAL \timers:0:channel|LessThan0~12_combout\ : std_logic;
SIGNAL \timers:0:channel|LessThan0~17_combout\ : std_logic;
SIGNAL \timers:0:channel|LessThan0~18_combout\ : std_logic;
SIGNAL \timers:0:channel|LessThan0~5_combout\ : std_logic;
SIGNAL \timers:0:channel|LessThan0~6_combout\ : std_logic;
SIGNAL \timers:0:channel|elapsed_r[2]~1_combout\ : std_logic;
SIGNAL \timers:0:channel|elapsed_r[2]~2_combout\ : std_logic;
SIGNAL \timers:0:channel|elapsed_r[2]~3_combout\ : std_logic;
SIGNAL \timers:0:channel|Add2~6\ : std_logic;
SIGNAL \timers:0:channel|Add2~9_sumout\ : std_logic;
SIGNAL \timers:0:channel|Add2~10\ : std_logic;
SIGNAL \timers:0:channel|Add2~13_sumout\ : std_logic;
SIGNAL \timers:0:channel|Add2~14\ : std_logic;
SIGNAL \timers:0:channel|Add2~17_sumout\ : std_logic;
SIGNAL \timers:0:channel|Add2~18\ : std_logic;
SIGNAL \timers:0:channel|Add2~21_sumout\ : std_logic;
SIGNAL \timers:0:channel|Add2~22\ : std_logic;
SIGNAL \timers:0:channel|Add2~25_sumout\ : std_logic;
SIGNAL \timers:0:channel|Add2~26\ : std_logic;
SIGNAL \timers:0:channel|Add2~29_sumout\ : std_logic;
SIGNAL \timers:0:channel|Add2~30\ : std_logic;
SIGNAL \timers:0:channel|Add2~33_sumout\ : std_logic;
SIGNAL \timers:0:channel|Add2~34\ : std_logic;
SIGNAL \timers:0:channel|Add2~37_sumout\ : std_logic;
SIGNAL \timers:0:channel|Add2~38\ : std_logic;
SIGNAL \timers:0:channel|Add2~41_sumout\ : std_logic;
SIGNAL \timers:0:channel|Add2~42\ : std_logic;
SIGNAL \timers:0:channel|Add2~45_sumout\ : std_logic;
SIGNAL \timers:0:channel|Add2~46\ : std_logic;
SIGNAL \timers:0:channel|Add2~49_sumout\ : std_logic;
SIGNAL \timers:0:channel|Add2~50\ : std_logic;
SIGNAL \timers:0:channel|Add2~53_sumout\ : std_logic;
SIGNAL \timers:0:channel|Add2~54\ : std_logic;
SIGNAL \timers:0:channel|Add2~57_sumout\ : std_logic;
SIGNAL \timers:0:channel|Add2~58\ : std_logic;
SIGNAL \timers:0:channel|Add2~61_sumout\ : std_logic;
SIGNAL \timers:0:channel|LessThan0~13_combout\ : std_logic;
SIGNAL \timers:0:channel|LessThan0~4_combout\ : std_logic;
SIGNAL \timers:0:channel|LessThan0~16_combout\ : std_logic;
SIGNAL \timers:0:channel|Mux33~1_combout\ : std_logic;
SIGNAL \timers:0:channel|running_r~q\ : std_logic;
SIGNAL \timers:0:channel|elapsed_r[2]~0_combout\ : std_logic;
SIGNAL \read_value[0]~2_combout\ : std_logic;
SIGNAL \timers:1:channel|Add1~1_sumout\ : std_logic;
SIGNAL \timers:1:channel|elapsed_r[14]~4_combout\ : std_logic;
SIGNAL \timers:1:channel|periods_r[14]~0_combout\ : std_logic;
SIGNAL \timers:0:channel|Add1~1_sumout\ : std_logic;
SIGNAL \timers:0:channel|elapsed_r[2]~4_combout\ : std_logic;
SIGNAL \timers:0:channel|periods_r[7]~2_combout\ : std_logic;
SIGNAL \timers:3:channel|Add1~1_sumout\ : std_logic;
SIGNAL \timers:3:channel|elapsed_r[9]~4_combout\ : std_logic;
SIGNAL \timers:3:channel|periods_r[13]~0_combout\ : std_logic;
SIGNAL \read_value[0]~3_combout\ : std_logic;
SIGNAL \timers:2:channel|Add1~1_sumout\ : std_logic;
SIGNAL \timers:2:channel|elapsed_r[6]~0_combout\ : std_logic;
SIGNAL \timers:2:channel|prescaler|TICK~q\ : std_logic;
SIGNAL \timers:2:channel|periods_r[5]~0_combout\ : std_logic;
SIGNAL \read_value[0]~4_combout\ : std_logic;
SIGNAL \IO_READ~input_o\ : std_logic;
SIGNAL \drive_en~combout\ : std_logic;
SIGNAL \timers:2:channel|Add1~2\ : std_logic;
SIGNAL \timers:2:channel|Add1~5_sumout\ : std_logic;
SIGNAL \timers:3:channel|Add1~2\ : std_logic;
SIGNAL \timers:3:channel|Add1~5_sumout\ : std_logic;
SIGNAL \timers:1:channel|Add1~2\ : std_logic;
SIGNAL \timers:1:channel|Add1~5_sumout\ : std_logic;
SIGNAL \timers:0:channel|Add1~2\ : std_logic;
SIGNAL \timers:0:channel|Add1~5_sumout\ : std_logic;
SIGNAL \read_value[1]~6_combout\ : std_logic;
SIGNAL \read_value[1]~5_combout\ : std_logic;
SIGNAL \read_value[1]~7_combout\ : std_logic;
SIGNAL \timers:2:channel|Add1~6\ : std_logic;
SIGNAL \timers:2:channel|Add1~9_sumout\ : std_logic;
SIGNAL \timers:1:channel|Add1~6\ : std_logic;
SIGNAL \timers:1:channel|Add1~9_sumout\ : std_logic;
SIGNAL \timers:3:channel|Add1~6\ : std_logic;
SIGNAL \timers:3:channel|Add1~9_sumout\ : std_logic;
SIGNAL \timers:0:channel|Add1~6\ : std_logic;
SIGNAL \timers:0:channel|Add1~9_sumout\ : std_logic;
SIGNAL \read_value[2]~9_combout\ : std_logic;
SIGNAL \read_value[2]~8_combout\ : std_logic;
SIGNAL \read_value[2]~10_combout\ : std_logic;
SIGNAL \timers:2:channel|Add1~10\ : std_logic;
SIGNAL \timers:2:channel|Add1~13_sumout\ : std_logic;
SIGNAL \read_value[3]~11_combout\ : std_logic;
SIGNAL \timers:3:channel|Add1~10\ : std_logic;
SIGNAL \timers:3:channel|Add1~13_sumout\ : std_logic;
SIGNAL \timers:0:channel|Add1~10\ : std_logic;
SIGNAL \timers:0:channel|Add1~13_sumout\ : std_logic;
SIGNAL \timers:1:channel|Add1~10\ : std_logic;
SIGNAL \timers:1:channel|Add1~13_sumout\ : std_logic;
SIGNAL \read_value[3]~12_combout\ : std_logic;
SIGNAL \read_value[3]~13_combout\ : std_logic;
SIGNAL \timers:3:channel|Add1~14\ : std_logic;
SIGNAL \timers:3:channel|Add1~17_sumout\ : std_logic;
SIGNAL \timers:0:channel|Add1~14\ : std_logic;
SIGNAL \timers:0:channel|Add1~17_sumout\ : std_logic;
SIGNAL \timers:1:channel|Add1~14\ : std_logic;
SIGNAL \timers:1:channel|Add1~17_sumout\ : std_logic;
SIGNAL \read_value[4]~15_combout\ : std_logic;
SIGNAL \timers:2:channel|Add1~14\ : std_logic;
SIGNAL \timers:2:channel|Add1~17_sumout\ : std_logic;
SIGNAL \read_value[4]~14_combout\ : std_logic;
SIGNAL \read_value[4]~16_combout\ : std_logic;
SIGNAL \read_value[5]~17_combout\ : std_logic;
SIGNAL \timers:0:channel|Add1~18\ : std_logic;
SIGNAL \timers:0:channel|Add1~21_sumout\ : std_logic;
SIGNAL \timers:1:channel|Add1~18\ : std_logic;
SIGNAL \timers:1:channel|Add1~21_sumout\ : std_logic;
SIGNAL \timers:3:channel|Add1~18\ : std_logic;
SIGNAL \timers:3:channel|Add1~21_sumout\ : std_logic;
SIGNAL \read_value[5]~18_combout\ : std_logic;
SIGNAL \timers:2:channel|Add1~18\ : std_logic;
SIGNAL \timers:2:channel|Add1~21_sumout\ : std_logic;
SIGNAL \read_value[5]~19_combout\ : std_logic;
SIGNAL \timers:0:channel|Add1~22\ : std_logic;
SIGNAL \timers:0:channel|Add1~25_sumout\ : std_logic;
SIGNAL \timers:3:channel|Add1~22\ : std_logic;
SIGNAL \timers:3:channel|Add1~25_sumout\ : std_logic;
SIGNAL \timers:1:channel|Add1~22\ : std_logic;
SIGNAL \timers:1:channel|Add1~25_sumout\ : std_logic;
SIGNAL \read_value[6]~21_combout\ : std_logic;
SIGNAL \timers:2:channel|Add1~22\ : std_logic;
SIGNAL \timers:2:channel|Add1~25_sumout\ : std_logic;
SIGNAL \read_value[6]~20_combout\ : std_logic;
SIGNAL \read_value[6]~22_combout\ : std_logic;
SIGNAL \read_value[7]~23_combout\ : std_logic;
SIGNAL \timers:2:channel|Add1~26\ : std_logic;
SIGNAL \timers:2:channel|Add1~29_sumout\ : std_logic;
SIGNAL \timers:0:channel|Add1~26\ : std_logic;
SIGNAL \timers:0:channel|Add1~29_sumout\ : std_logic;
SIGNAL \timers:3:channel|Add1~26\ : std_logic;
SIGNAL \timers:3:channel|Add1~29_sumout\ : std_logic;
SIGNAL \timers:1:channel|Add1~26\ : std_logic;
SIGNAL \timers:1:channel|Add1~29_sumout\ : std_logic;
SIGNAL \read_value[7]~24_combout\ : std_logic;
SIGNAL \read_value[7]~25_combout\ : std_logic;
SIGNAL \timers:2:channel|Add1~30\ : std_logic;
SIGNAL \timers:2:channel|Add1~33_sumout\ : std_logic;
SIGNAL \timers:3:channel|Add1~30\ : std_logic;
SIGNAL \timers:3:channel|Add1~33_sumout\ : std_logic;
SIGNAL \timers:1:channel|Add1~30\ : std_logic;
SIGNAL \timers:1:channel|Add1~33_sumout\ : std_logic;
SIGNAL \timers:0:channel|Add1~30\ : std_logic;
SIGNAL \timers:0:channel|Add1~33_sumout\ : std_logic;
SIGNAL \read_value[8]~27_combout\ : std_logic;
SIGNAL \read_value[8]~26_combout\ : std_logic;
SIGNAL \read_value[8]~28_combout\ : std_logic;
SIGNAL \read_value[9]~29_combout\ : std_logic;
SIGNAL \timers:2:channel|Add1~34\ : std_logic;
SIGNAL \timers:2:channel|Add1~37_sumout\ : std_logic;
SIGNAL \timers:3:channel|Add1~34\ : std_logic;
SIGNAL \timers:3:channel|Add1~37_sumout\ : std_logic;
SIGNAL \timers:0:channel|Add1~34\ : std_logic;
SIGNAL \timers:0:channel|Add1~37_sumout\ : std_logic;
SIGNAL \timers:1:channel|Add1~34\ : std_logic;
SIGNAL \timers:1:channel|Add1~37_sumout\ : std_logic;
SIGNAL \read_value[9]~30_combout\ : std_logic;
SIGNAL \read_value[9]~31_combout\ : std_logic;
SIGNAL \timers:2:channel|Add1~38\ : std_logic;
SIGNAL \timers:2:channel|Add1~41_sumout\ : std_logic;
SIGNAL \timers:3:channel|Add1~38\ : std_logic;
SIGNAL \timers:3:channel|Add1~41_sumout\ : std_logic;
SIGNAL \timers:0:channel|Add1~38\ : std_logic;
SIGNAL \timers:0:channel|Add1~41_sumout\ : std_logic;
SIGNAL \timers:1:channel|Add1~38\ : std_logic;
SIGNAL \timers:1:channel|Add1~41_sumout\ : std_logic;
SIGNAL \read_value[10]~33_combout\ : std_logic;
SIGNAL \read_value[10]~32_combout\ : std_logic;
SIGNAL \read_value[10]~34_combout\ : std_logic;
SIGNAL \read_value[11]~35_combout\ : std_logic;
SIGNAL \timers:2:channel|Add1~42\ : std_logic;
SIGNAL \timers:2:channel|Add1~45_sumout\ : std_logic;
SIGNAL \timers:0:channel|Add1~42\ : std_logic;
SIGNAL \timers:0:channel|Add1~45_sumout\ : std_logic;
SIGNAL \timers:1:channel|Add1~42\ : std_logic;
SIGNAL \timers:1:channel|Add1~45_sumout\ : std_logic;
SIGNAL \timers:3:channel|Add1~42\ : std_logic;
SIGNAL \timers:3:channel|Add1~45_sumout\ : std_logic;
SIGNAL \read_value[11]~36_combout\ : std_logic;
SIGNAL \read_value[11]~37_combout\ : std_logic;
SIGNAL \timers:2:channel|Add1~46\ : std_logic;
SIGNAL \timers:2:channel|Add1~49_sumout\ : std_logic;
SIGNAL \timers:0:channel|Add1~46\ : std_logic;
SIGNAL \timers:0:channel|Add1~49_sumout\ : std_logic;
SIGNAL \timers:3:channel|Add1~46\ : std_logic;
SIGNAL \timers:3:channel|Add1~49_sumout\ : std_logic;
SIGNAL \timers:1:channel|Add1~46\ : std_logic;
SIGNAL \timers:1:channel|Add1~49_sumout\ : std_logic;
SIGNAL \read_value[12]~39_combout\ : std_logic;
SIGNAL \read_value[12]~38_combout\ : std_logic;
SIGNAL \read_value[12]~40_combout\ : std_logic;
SIGNAL \timers:2:channel|Add1~50\ : std_logic;
SIGNAL \timers:2:channel|Add1~53_sumout\ : std_logic;
SIGNAL \timers:1:channel|Add1~50\ : std_logic;
SIGNAL \timers:1:channel|Add1~53_sumout\ : std_logic;
SIGNAL \timers:3:channel|Add1~50\ : std_logic;
SIGNAL \timers:3:channel|Add1~53_sumout\ : std_logic;
SIGNAL \timers:0:channel|Add1~50\ : std_logic;
SIGNAL \timers:0:channel|Add1~53_sumout\ : std_logic;
SIGNAL \read_value[13]~42_combout\ : std_logic;
SIGNAL \read_value[13]~41_combout\ : std_logic;
SIGNAL \read_value[13]~43_combout\ : std_logic;
SIGNAL \timers:3:channel|Add1~54\ : std_logic;
SIGNAL \timers:3:channel|Add1~57_sumout\ : std_logic;
SIGNAL \timers:0:channel|Add1~54\ : std_logic;
SIGNAL \timers:0:channel|Add1~57_sumout\ : std_logic;
SIGNAL \timers:1:channel|Add1~54\ : std_logic;
SIGNAL \timers:1:channel|Add1~57_sumout\ : std_logic;
SIGNAL \read_value[14]~45_combout\ : std_logic;
SIGNAL \timers:2:channel|Add1~54\ : std_logic;
SIGNAL \timers:2:channel|Add1~57_sumout\ : std_logic;
SIGNAL \read_value[14]~44_combout\ : std_logic;
SIGNAL \read_value[14]~46_combout\ : std_logic;
SIGNAL \timers:2:channel|Add1~58\ : std_logic;
SIGNAL \timers:2:channel|Add1~61_sumout\ : std_logic;
SIGNAL \read_value[15]~47_combout\ : std_logic;
SIGNAL \timers:0:channel|Add1~58\ : std_logic;
SIGNAL \timers:0:channel|Add1~61_sumout\ : std_logic;
SIGNAL \timers:1:channel|Add1~58\ : std_logic;
SIGNAL \timers:1:channel|Add1~61_sumout\ : std_logic;
SIGNAL \timers:3:channel|Add1~58\ : std_logic;
SIGNAL \timers:3:channel|Add1~61_sumout\ : std_logic;
SIGNAL \read_value[15]~48_combout\ : std_logic;
SIGNAL \read_value[15]~49_combout\ : std_logic;
SIGNAL \timers:0:channel|elapsed_r\ : std_logic_vector(15 DOWNTO 0);
SIGNAL \timers:2:channel|periods_r\ : std_logic_vector(15 DOWNTO 0);
SIGNAL \timers:1:channel|elapsed_r\ : std_logic_vector(15 DOWNTO 0);
SIGNAL \timers:0:channel|periods_r\ : std_logic_vector(15 DOWNTO 0);
SIGNAL \timers:2:channel|elapsed_r\ : std_logic_vector(15 DOWNTO 0);
SIGNAL \timers:1:channel|periods_r\ : std_logic_vector(15 DOWNTO 0);
SIGNAL \timers:0:channel|mode_r\ : std_logic_vector(1 DOWNTO 0);
SIGNAL \timers:3:channel|elapsed_r\ : std_logic_vector(15 DOWNTO 0);
SIGNAL \timers:3:channel|periods_r\ : std_logic_vector(15 DOWNTO 0);
SIGNAL \timers:2:channel|prescaler|ms_count\ : std_logic_vector(15 DOWNTO 0);
SIGNAL \timers:0:channel|prescaler|ms_count\ : std_logic_vector(15 DOWNTO 0);
SIGNAL \timers:1:channel|prescaler|ms_count\ : std_logic_vector(15 DOWNTO 0);
SIGNAL \timers:3:channel|prescaler|ms_count\ : std_logic_vector(15 DOWNTO 0);
SIGNAL \timers:2:channel|mode_r\ : std_logic_vector(1 DOWNTO 0);
SIGNAL \timers:0:channel|duration_r\ : std_logic_vector(15 DOWNTO 0);
SIGNAL write_hit : std_logic_vector(3 DOWNTO 0);
SIGNAL \timers:1:channel|duration_r\ : std_logic_vector(15 DOWNTO 0);
SIGNAL \timers:1:channel|mode_r\ : std_logic_vector(1 DOWNTO 0);
SIGNAL \timers:2:channel|duration_r\ : std_logic_vector(15 DOWNTO 0);
SIGNAL \timers:3:channel|duration_r\ : std_logic_vector(15 DOWNTO 0);
SIGNAL \timers:3:channel|mode_r\ : std_logic_vector(1 DOWNTO 0);
SIGNAL \timers:2:channel|timescale_r\ : std_logic_vector(15 DOWNTO 0);
SIGNAL \timers:2:channel|prescaler|cycle_count\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \timers:0:channel|timescale_r\ : std_logic_vector(15 DOWNTO 0);
SIGNAL \timers:0:channel|prescaler|cycle_count\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \timers:1:channel|timescale_r\ : std_logic_vector(15 DOWNTO 0);
SIGNAL \timers:1:channel|prescaler|cycle_count\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \timers:3:channel|timescale_r\ : std_logic_vector(15 DOWNTO 0);
SIGNAL \timers:3:channel|prescaler|cycle_count\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \timers:0:channel|ALT_INV_periods_r\ : std_logic_vector(15 DOWNTO 0);
SIGNAL \timers:1:channel|ALT_INV_periods_r\ : std_logic_vector(15 DOWNTO 0);
SIGNAL \timers:2:channel|ALT_INV_elapsed_r\ : std_logic_vector(15 DOWNTO 0);
SIGNAL \timers:2:channel|ALT_INV_periods_r\ : std_logic_vector(15 DOWNTO 0);
SIGNAL \timers:0:channel|ALT_INV_elapsed_r\ : std_logic_vector(15 DOWNTO 0);
SIGNAL \timers:3:channel|ALT_INV_elapsed_r\ : std_logic_vector(15 DOWNTO 0);
SIGNAL \timers:3:channel|ALT_INV_periods_r\ : std_logic_vector(15 DOWNTO 0);
SIGNAL \timers:1:channel|ALT_INV_elapsed_r\ : std_logic_vector(15 DOWNTO 0);
SIGNAL \timers:0:channel|ALT_INV_Add0~21_sumout\ : std_logic;
SIGNAL \timers:0:channel|ALT_INV_Add0~25_sumout\ : std_logic;
SIGNAL \timers:0:channel|ALT_INV_Add0~29_sumout\ : std_logic;
SIGNAL \timers:0:channel|ALT_INV_Add0~33_sumout\ : std_logic;
SIGNAL \timers:2:channel|ALT_INV_Add0~13_sumout\ : std_logic;
SIGNAL \timers:2:channel|ALT_INV_Add0~29_sumout\ : std_logic;
SIGNAL \timers:2:channel|ALT_INV_Add0~5_sumout\ : std_logic;
SIGNAL \timers:2:channel|ALT_INV_Add0~41_sumout\ : std_logic;
SIGNAL \timers:0:channel|ALT_INV_Add0~45_sumout\ : std_logic;
SIGNAL \timers:0:channel|ALT_INV_Add0~49_sumout\ : std_logic;
SIGNAL \timers:0:channel|ALT_INV_Add0~53_sumout\ : std_logic;
SIGNAL \timers:0:channel|ALT_INV_Add0~37_sumout\ : std_logic;
SIGNAL \timers:0:channel|ALT_INV_Add0~57_sumout\ : std_logic;
SIGNAL \timers:0:channel|ALT_INV_Add0~41_sumout\ : std_logic;
SIGNAL \timers:2:channel|ALT_INV_Add0~1_sumout\ : std_logic;
SIGNAL \timers:2:channel|ALT_INV_Add0~49_sumout\ : std_logic;
SIGNAL \timers:2:channel|ALT_INV_Add0~9_sumout\ : std_logic;
SIGNAL \timers:2:channel|ALT_INV_Add0~61_sumout\ : std_logic;
SIGNAL \timers:2:channel|ALT_INV_Add0~25_sumout\ : std_logic;
SIGNAL \timers:0:channel|ALT_INV_Add0~5_sumout\ : std_logic;
SIGNAL \timers:0:channel|ALT_INV_Add0~9_sumout\ : std_logic;
SIGNAL \timers:2:channel|ALT_INV_Add0~21_sumout\ : std_logic;
SIGNAL \timers:0:channel|ALT_INV_Add0~17_sumout\ : std_logic;
SIGNAL \timers:2:channel|ALT_INV_Add0~33_sumout\ : std_logic;
SIGNAL \timers:2:channel|ALT_INV_Add0~37_sumout\ : std_logic;
SIGNAL \timers:2:channel|ALT_INV_Add0~53_sumout\ : std_logic;
SIGNAL \timers:2:channel|ALT_INV_Add0~45_sumout\ : std_logic;
SIGNAL \timers:0:channel|ALT_INV_Add0~13_sumout\ : std_logic;
SIGNAL \timers:2:channel|ALT_INV_Add0~17_sumout\ : std_logic;
SIGNAL \timers:2:channel|ALT_INV_Add0~57_sumout\ : std_logic;
SIGNAL \timers:0:channel|ALT_INV_Add0~1_sumout\ : std_logic;
SIGNAL \timers:3:channel|ALT_INV_Add0~25_sumout\ : std_logic;
SIGNAL \timers:3:channel|ALT_INV_Add0~17_sumout\ : std_logic;
SIGNAL \timers:1:channel|ALT_INV_Add0~25_sumout\ : std_logic;
SIGNAL \timers:3:channel|ALT_INV_Add0~29_sumout\ : std_logic;
SIGNAL \timers:3:channel|ALT_INV_Add0~37_sumout\ : std_logic;
SIGNAL \timers:3:channel|ALT_INV_Add0~41_sumout\ : std_logic;
SIGNAL \timers:3:channel|ALT_INV_Add0~49_sumout\ : std_logic;
SIGNAL \timers:0:channel|ALT_INV_Add0~61_sumout\ : std_logic;
SIGNAL \timers:1:channel|ALT_INV_Add0~37_sumout\ : std_logic;
SIGNAL \timers:1:channel|ALT_INV_Add0~45_sumout\ : std_logic;
SIGNAL \timers:3:channel|ALT_INV_Add0~33_sumout\ : std_logic;
SIGNAL \timers:3:channel|ALT_INV_Add0~45_sumout\ : std_logic;
SIGNAL \timers:1:channel|ALT_INV_Add0~49_sumout\ : std_logic;
SIGNAL \timers:1:channel|ALT_INV_Add0~13_sumout\ : std_logic;
SIGNAL \timers:1:channel|ALT_INV_Add0~17_sumout\ : std_logic;
SIGNAL \timers:1:channel|ALT_INV_Add0~53_sumout\ : std_logic;
SIGNAL \timers:1:channel|ALT_INV_Add0~1_sumout\ : std_logic;
SIGNAL \timers:1:channel|ALT_INV_Add0~41_sumout\ : std_logic;
SIGNAL \timers:1:channel|ALT_INV_Add0~61_sumout\ : std_logic;
SIGNAL \timers:1:channel|ALT_INV_Add0~9_sumout\ : std_logic;
SIGNAL \timers:1:channel|ALT_INV_Add0~21_sumout\ : std_logic;
SIGNAL \timers:1:channel|ALT_INV_Add0~33_sumout\ : std_logic;
SIGNAL \timers:1:channel|ALT_INV_Add0~5_sumout\ : std_logic;
SIGNAL \timers:3:channel|ALT_INV_Add0~1_sumout\ : std_logic;
SIGNAL \timers:1:channel|ALT_INV_Add0~57_sumout\ : std_logic;
SIGNAL \timers:3:channel|ALT_INV_Add0~9_sumout\ : std_logic;
SIGNAL \timers:3:channel|ALT_INV_Add0~5_sumout\ : std_logic;
SIGNAL \timers:1:channel|ALT_INV_Add0~29_sumout\ : std_logic;
SIGNAL \timers:3:channel|ALT_INV_Add0~13_sumout\ : std_logic;
SIGNAL \timers:3:channel|ALT_INV_Add0~21_sumout\ : std_logic;
SIGNAL \timers:3:channel|ALT_INV_Add0~61_sumout\ : std_logic;
SIGNAL \timers:3:channel|ALT_INV_Add0~53_sumout\ : std_logic;
SIGNAL \timers:3:channel|ALT_INV_Add0~57_sumout\ : std_logic;
SIGNAL \timers:2:channel|prescaler|ALT_INV_Add1~1_sumout\ : std_logic;
SIGNAL \timers:2:channel|prescaler|ALT_INV_Add1~5_sumout\ : std_logic;
SIGNAL \timers:2:channel|prescaler|ALT_INV_Add1~13_sumout\ : std_logic;
SIGNAL \timers:2:channel|prescaler|ALT_INV_Add1~17_sumout\ : std_logic;
SIGNAL \timers:2:channel|prescaler|ALT_INV_Add1~21_sumout\ : std_logic;
SIGNAL \timers:2:channel|prescaler|ALT_INV_Add1~9_sumout\ : std_logic;
SIGNAL \timers:1:channel|prescaler|ALT_INV_Add1~17_sumout\ : std_logic;
SIGNAL \timers:2:channel|prescaler|ALT_INV_Add1~45_sumout\ : std_logic;
SIGNAL \timers:2:channel|prescaler|ALT_INV_Add1~61_sumout\ : std_logic;
SIGNAL \timers:0:channel|prescaler|ALT_INV_Add1~53_sumout\ : std_logic;
SIGNAL \timers:0:channel|prescaler|ALT_INV_Add1~25_sumout\ : std_logic;
SIGNAL \timers:2:channel|prescaler|ALT_INV_Add1~33_sumout\ : std_logic;
SIGNAL \timers:1:channel|prescaler|ALT_INV_Add1~9_sumout\ : std_logic;
SIGNAL \timers:0:channel|prescaler|ALT_INV_Add1~33_sumout\ : std_logic;
SIGNAL \timers:0:channel|prescaler|ALT_INV_Add1~49_sumout\ : std_logic;
SIGNAL \timers:1:channel|prescaler|ALT_INV_Add1~5_sumout\ : std_logic;
SIGNAL \timers:1:channel|prescaler|ALT_INV_Add1~21_sumout\ : std_logic;
SIGNAL \timers:0:channel|prescaler|ALT_INV_Add1~37_sumout\ : std_logic;
SIGNAL \timers:2:channel|prescaler|ALT_INV_Add1~25_sumout\ : std_logic;
SIGNAL \timers:2:channel|prescaler|ALT_INV_Add1~41_sumout\ : std_logic;
SIGNAL \timers:1:channel|prescaler|ALT_INV_Add1~25_sumout\ : std_logic;
SIGNAL \timers:0:channel|prescaler|ALT_INV_Add1~61_sumout\ : std_logic;
SIGNAL \timers:2:channel|prescaler|ALT_INV_Add1~49_sumout\ : std_logic;
SIGNAL \timers:0:channel|prescaler|ALT_INV_Add1~21_sumout\ : std_logic;
SIGNAL \timers:0:channel|prescaler|ALT_INV_Add1~41_sumout\ : std_logic;
SIGNAL \timers:2:channel|prescaler|ALT_INV_Add1~29_sumout\ : std_logic;
SIGNAL \timers:0:channel|prescaler|ALT_INV_Add1~9_sumout\ : std_logic;
SIGNAL \timers:0:channel|prescaler|ALT_INV_Add1~29_sumout\ : std_logic;
SIGNAL \timers:0:channel|prescaler|ALT_INV_Add1~13_sumout\ : std_logic;
SIGNAL \timers:0:channel|prescaler|ALT_INV_Add1~45_sumout\ : std_logic;
SIGNAL \timers:2:channel|prescaler|ALT_INV_Add1~53_sumout\ : std_logic;
SIGNAL \timers:0:channel|prescaler|ALT_INV_Add1~17_sumout\ : std_logic;
SIGNAL \timers:0:channel|prescaler|ALT_INV_Add1~5_sumout\ : std_logic;
SIGNAL \timers:0:channel|prescaler|ALT_INV_Add1~1_sumout\ : std_logic;
SIGNAL \timers:1:channel|prescaler|ALT_INV_Add1~13_sumout\ : std_logic;
SIGNAL \timers:2:channel|prescaler|ALT_INV_Add1~37_sumout\ : std_logic;
SIGNAL \timers:2:channel|prescaler|ALT_INV_Add1~57_sumout\ : std_logic;
SIGNAL \timers:0:channel|prescaler|ALT_INV_Add1~57_sumout\ : std_logic;
SIGNAL \timers:1:channel|prescaler|ALT_INV_Add1~1_sumout\ : std_logic;
SIGNAL \timers:2:channel|prescaler|ALT_INV_ms_count\ : std_logic_vector(15 DOWNTO 0);
SIGNAL \timers:1:channel|prescaler|ALT_INV_Add1~33_sumout\ : std_logic;
SIGNAL \timers:3:channel|prescaler|ALT_INV_Add1~53_sumout\ : std_logic;
SIGNAL \timers:1:channel|prescaler|ALT_INV_Add1~53_sumout\ : std_logic;
SIGNAL \timers:3:channel|prescaler|ALT_INV_Add1~41_sumout\ : std_logic;
SIGNAL \timers:1:channel|prescaler|ALT_INV_Add1~37_sumout\ : std_logic;
SIGNAL \timers:3:channel|prescaler|ALT_INV_Add1~17_sumout\ : std_logic;
SIGNAL \timers:3:channel|prescaler|ALT_INV_Add1~1_sumout\ : std_logic;
SIGNAL \timers:3:channel|prescaler|ALT_INV_Add1~29_sumout\ : std_logic;
SIGNAL \timers:3:channel|prescaler|ALT_INV_Add1~61_sumout\ : std_logic;
SIGNAL \timers:3:channel|prescaler|ALT_INV_Add1~9_sumout\ : std_logic;
SIGNAL \timers:1:channel|prescaler|ALT_INV_Add1~45_sumout\ : std_logic;
SIGNAL \timers:1:channel|prescaler|ALT_INV_Add1~49_sumout\ : std_logic;
SIGNAL \timers:3:channel|prescaler|ALT_INV_Add1~5_sumout\ : std_logic;
SIGNAL \timers:1:channel|prescaler|ALT_INV_Add1~29_sumout\ : std_logic;
SIGNAL \timers:3:channel|prescaler|ALT_INV_Add1~33_sumout\ : std_logic;
SIGNAL \timers:3:channel|prescaler|ALT_INV_Add1~45_sumout\ : std_logic;
SIGNAL \timers:3:channel|prescaler|ALT_INV_Add1~21_sumout\ : std_logic;
SIGNAL \timers:3:channel|prescaler|ALT_INV_Add1~49_sumout\ : std_logic;
SIGNAL \timers:1:channel|prescaler|ALT_INV_Add1~41_sumout\ : std_logic;
SIGNAL \timers:1:channel|prescaler|ALT_INV_Add1~61_sumout\ : std_logic;
SIGNAL \timers:3:channel|prescaler|ALT_INV_Add1~13_sumout\ : std_logic;
SIGNAL \timers:3:channel|prescaler|ALT_INV_Add1~37_sumout\ : std_logic;
SIGNAL \timers:3:channel|prescaler|ALT_INV_Add1~57_sumout\ : std_logic;
SIGNAL \timers:1:channel|prescaler|ALT_INV_Add1~57_sumout\ : std_logic;
SIGNAL \timers:3:channel|prescaler|ALT_INV_Add1~25_sumout\ : std_logic;
SIGNAL \timers:0:channel|prescaler|ALT_INV_ms_count\ : std_logic_vector(15 DOWNTO 0);
SIGNAL \timers:1:channel|prescaler|ALT_INV_ms_count\ : std_logic_vector(15 DOWNTO 0);
SIGNAL \timers:3:channel|prescaler|ALT_INV_ms_count\ : std_logic_vector(15 DOWNTO 0);
SIGNAL \ALT_INV_read_value[0]~1_combout\ : std_logic;
SIGNAL \ALT_INV_read_value[0]~2_combout\ : std_logic;
SIGNAL \ALT_INV_read_value[1]~5_combout\ : std_logic;
SIGNAL \ALT_INV_read_value[1]~6_combout\ : std_logic;
SIGNAL \ALT_INV_read_value[2]~8_combout\ : std_logic;
SIGNAL \ALT_INV_Equal0~0_combout\ : std_logic;
SIGNAL \ALT_INV_read_value[0]~0_combout\ : std_logic;
SIGNAL \ALT_INV_read_value[0]~3_combout\ : std_logic;
SIGNAL \ALT_INV_read_value[13]~42_combout\ : std_logic;
SIGNAL \timers:2:channel|ALT_INV_LessThan0~10_combout\ : std_logic;
SIGNAL \timers:2:channel|ALT_INV_mode_r\ : std_logic_vector(1 DOWNTO 0);
SIGNAL \timers:2:channel|ALT_INV_LessThan0~11_combout\ : std_logic;
SIGNAL \ALT_INV_read_value[7]~23_combout\ : std_logic;
SIGNAL \ALT_INV_read_value[11]~35_combout\ : std_logic;
SIGNAL \ALT_INV_read_value[8]~27_combout\ : std_logic;
SIGNAL \ALT_INV_read_value[12]~39_combout\ : std_logic;
SIGNAL \ALT_INV_read_value[9]~29_combout\ : std_logic;
SIGNAL \ALT_INV_read_value[15]~48_combout\ : std_logic;
SIGNAL \ALT_INV_Equal11~0_combout\ : std_logic;
SIGNAL \timers:2:channel|ALT_INV_LessThan0~2_combout\ : std_logic;
SIGNAL \timers:0:channel|ALT_INV_periods_r~0_combout\ : std_logic;
SIGNAL \timers:2:channel|ALT_INV_LessThan0~9_combout\ : std_logic;
SIGNAL \timers:2:channel|ALT_INV_LessThan0~12_combout\ : std_logic;
SIGNAL \timers:2:channel|ALT_INV_LessThan0~14_combout\ : std_logic;
SIGNAL \ALT_INV_read_value[3]~12_combout\ : std_logic;
SIGNAL \ALT_INV_read_value[8]~26_combout\ : std_logic;
SIGNAL \ALT_INV_read_value[2]~9_combout\ : std_logic;
SIGNAL \ALT_INV_read_value[12]~38_combout\ : std_logic;
SIGNAL \ALT_INV_Equal11~1_combout\ : std_logic;
SIGNAL \timers:2:channel|ALT_INV_LessThan0~3_combout\ : std_logic;
SIGNAL \timers:2:channel|ALT_INV_LessThan0~8_combout\ : std_logic;
SIGNAL \timers:2:channel|ALT_INV_LessThan0~13_combout\ : std_logic;
SIGNAL \ALT_INV_read_value[14]~45_combout\ : std_logic;
SIGNAL \timers:2:channel|ALT_INV_LessThan0~15_combout\ : std_logic;
SIGNAL \timers:2:channel|ALT_INV_LessThan0~5_combout\ : std_logic;
SIGNAL \ALT_INV_read_value[5]~18_combout\ : std_logic;
SIGNAL \ALT_INV_read_value[4]~14_combout\ : std_logic;
SIGNAL \ALT_INV_read_value[7]~24_combout\ : std_logic;
SIGNAL \ALT_INV_read_value[9]~30_combout\ : std_logic;
SIGNAL \ALT_INV_read_value[6]~20_combout\ : std_logic;
SIGNAL \ALT_INV_read_value[5]~17_combout\ : std_logic;
SIGNAL \ALT_INV_read_value[10]~32_combout\ : std_logic;
SIGNAL \ALT_INV_read_value[11]~36_combout\ : std_logic;
SIGNAL \ALT_INV_read_value[13]~41_combout\ : std_logic;
SIGNAL \ALT_INV_read_value[14]~44_combout\ : std_logic;
SIGNAL \ALT_INV_read_value[15]~47_combout\ : std_logic;
SIGNAL \ALT_INV_read_value[4]~15_combout\ : std_logic;
SIGNAL \timers:2:channel|ALT_INV_running_r~q\ : std_logic;
SIGNAL \timers:2:channel|ALT_INV_LessThan0~0_combout\ : std_logic;
SIGNAL \ALT_INV_read_value[3]~11_combout\ : std_logic;
SIGNAL \ALT_INV_read_value[6]~21_combout\ : std_logic;
SIGNAL \ALT_INV_read_value[10]~33_combout\ : std_logic;
SIGNAL \timers:2:channel|ALT_INV_LessThan0~1_combout\ : std_logic;
SIGNAL \timers:2:channel|ALT_INV_LessThan0~4_combout\ : std_logic;
SIGNAL \timers:2:channel|ALT_INV_LessThan0~6_combout\ : std_logic;
SIGNAL \timers:2:channel|ALT_INV_LessThan0~7_combout\ : std_logic;
SIGNAL \timers:0:channel|ALT_INV_LessThan0~15_combout\ : std_logic;
SIGNAL \timers:1:channel|ALT_INV_LessThan0~6_combout\ : std_logic;
SIGNAL \timers:0:channel|ALT_INV_mode_r\ : std_logic_vector(1 DOWNTO 0);
SIGNAL \timers:0:channel|ALT_INV_elapsed_r[2]~2_combout\ : std_logic;
SIGNAL \timers:1:channel|ALT_INV_LessThan0~12_combout\ : std_logic;
SIGNAL \timers:2:channel|ALT_INV_LessThan0~16_combout\ : std_logic;
SIGNAL \timers:0:channel|ALT_INV_LessThan0~6_combout\ : std_logic;
SIGNAL \timers:0:channel|ALT_INV_LessThan0~10_combout\ : std_logic;
SIGNAL \timers:0:channel|ALT_INV_LessThan0~11_combout\ : std_logic;
SIGNAL \timers:1:channel|ALT_INV_mode_r\ : std_logic_vector(1 DOWNTO 0);
SIGNAL \timers:1:channel|ALT_INV_LessThan0~13_combout\ : std_logic;
SIGNAL \timers:2:channel|prescaler|ALT_INV_TICK~q\ : std_logic;
SIGNAL \timers:0:channel|ALT_INV_LessThan0~7_combout\ : std_logic;
SIGNAL \timers:0:channel|ALT_INV_LessThan0~2_combout\ : std_logic;
SIGNAL \timers:0:channel|ALT_INV_LessThan0~14_combout\ : std_logic;
SIGNAL \timers:1:channel|ALT_INV_LessThan0~5_combout\ : std_logic;
SIGNAL \timers:0:channel|ALT_INV_LessThan0~17_combout\ : std_logic;
SIGNAL \timers:0:channel|prescaler|ALT_INV_TICK~q\ : std_logic;
SIGNAL \timers:0:channel|ALT_INV_LessThan0~5_combout\ : std_logic;
SIGNAL \timers:0:channel|ALT_INV_LessThan0~9_combout\ : std_logic;
SIGNAL \timers:0:channel|ALT_INV_LessThan0~4_combout\ : std_logic;
SIGNAL ALT_INV_write_hit : std_logic_vector(0 DOWNTO 0);
SIGNAL \timers:1:channel|ALT_INV_LessThan0~1_combout\ : std_logic;
SIGNAL \timers:0:channel|ALT_INV_LessThan0~3_combout\ : std_logic;
SIGNAL \timers:1:channel|ALT_INV_running_r~q\ : std_logic;
SIGNAL \timers:1:channel|ALT_INV_LessThan0~2_combout\ : std_logic;
SIGNAL \timers:1:channel|ALT_INV_LessThan0~10_combout\ : std_logic;
SIGNAL \timers:0:channel|ALT_INV_LessThan0~13_combout\ : std_logic;
SIGNAL \timers:0:channel|ALT_INV_LessThan0~0_combout\ : std_logic;
SIGNAL \timers:0:channel|ALT_INV_LessThan0~12_combout\ : std_logic;
SIGNAL \timers:1:channel|ALT_INV_duration_r\ : std_logic_vector(15 DOWNTO 0);
SIGNAL \timers:1:channel|ALT_INV_LessThan0~3_combout\ : std_logic;
SIGNAL \timers:1:channel|ALT_INV_LessThan0~4_combout\ : std_logic;
SIGNAL \timers:1:channel|ALT_INV_LessThan0~8_combout\ : std_logic;
SIGNAL \timers:1:channel|ALT_INV_LessThan0~9_combout\ : std_logic;
SIGNAL \timers:0:channel|ALT_INV_LessThan0~8_combout\ : std_logic;
SIGNAL \timers:1:channel|ALT_INV_LessThan0~11_combout\ : std_logic;
SIGNAL \timers:1:channel|ALT_INV_LessThan0~15_combout\ : std_logic;
SIGNAL \timers:1:channel|ALT_INV_LessThan0~16_combout\ : std_logic;
SIGNAL \timers:1:channel|ALT_INV_LessThan0~0_combout\ : std_logic;
SIGNAL \timers:0:channel|ALT_INV_LessThan0~18_combout\ : std_logic;
SIGNAL \timers:0:channel|ALT_INV_duration_r\ : std_logic_vector(15 DOWNTO 0);
SIGNAL \timers:1:channel|ALT_INV_LessThan0~7_combout\ : std_logic;
SIGNAL \timers:1:channel|ALT_INV_LessThan0~14_combout\ : std_logic;
SIGNAL \timers:0:channel|ALT_INV_LessThan0~16_combout\ : std_logic;
SIGNAL \timers:0:channel|ALT_INV_LessThan0~1_combout\ : std_logic;
SIGNAL \ALT_INV_Equal11~2_combout\ : std_logic;
SIGNAL \timers:1:channel|ALT_INV_LessThan0~17_combout\ : std_logic;
SIGNAL \timers:0:channel|ALT_INV_periods_r~1_combout\ : std_logic;
SIGNAL \timers:0:channel|ALT_INV_running_r~q\ : std_logic;
SIGNAL \timers:1:channel|ALT_INV_LessThan0~18_combout\ : std_logic;
SIGNAL \timers:2:channel|ALT_INV_duration_r\ : std_logic_vector(15 DOWNTO 0);
SIGNAL \ALT_INV_Equal11~3_combout\ : std_logic;
SIGNAL \timers:3:channel|ALT_INV_duration_r\ : std_logic_vector(15 DOWNTO 0);
SIGNAL \timers:3:channel|ALT_INV_LessThan0~14_combout\ : std_logic;
SIGNAL \ALT_INV_Equal11~4_combout\ : std_logic;
SIGNAL \timers:3:channel|ALT_INV_LessThan0~15_combout\ : std_logic;
SIGNAL \timers:3:channel|ALT_INV_LessThan0~17_combout\ : std_logic;
SIGNAL \timers:3:channel|ALT_INV_LessThan0~7_combout\ : std_logic;
SIGNAL \timers:3:channel|ALT_INV_mode_r\ : std_logic_vector(1 DOWNTO 0);
SIGNAL \timers:3:channel|ALT_INV_LessThan0~5_combout\ : std_logic;
SIGNAL \timers:3:channel|ALT_INV_LessThan0~4_combout\ : std_logic;
SIGNAL \timers:3:channel|ALT_INV_LessThan0~9_combout\ : std_logic;
SIGNAL \timers:3:channel|ALT_INV_LessThan0~11_combout\ : std_logic;
SIGNAL \timers:3:channel|ALT_INV_LessThan0~13_combout\ : std_logic;
SIGNAL \timers:3:channel|ALT_INV_LessThan0~16_combout\ : std_logic;
SIGNAL \timers:3:channel|ALT_INV_running_r~q\ : std_logic;
SIGNAL \timers:3:channel|ALT_INV_LessThan0~10_combout\ : std_logic;
SIGNAL \timers:3:channel|ALT_INV_LessThan0~18_combout\ : std_logic;
SIGNAL \timers:3:channel|ALT_INV_elapsed_r[9]~2_combout\ : std_logic;
SIGNAL \timers:2:channel|ALT_INV_LessThan0~17_combout\ : std_logic;
SIGNAL \timers:3:channel|ALT_INV_LessThan0~0_combout\ : std_logic;
SIGNAL \timers:3:channel|ALT_INV_LessThan0~1_combout\ : std_logic;
SIGNAL \timers:3:channel|ALT_INV_LessThan0~6_combout\ : std_logic;
SIGNAL \timers:2:channel|ALT_INV_LessThan0~18_combout\ : std_logic;
SIGNAL \timers:3:channel|ALT_INV_LessThan0~12_combout\ : std_logic;
SIGNAL \timers:3:channel|ALT_INV_LessThan0~3_combout\ : std_logic;
SIGNAL \timers:2:channel|ALT_INV_elapsed_r[6]~3_combout\ : std_logic;
SIGNAL \timers:3:channel|ALT_INV_LessThan0~8_combout\ : std_logic;
SIGNAL \timers:3:channel|prescaler|ALT_INV_TICK~q\ : std_logic;
SIGNAL \timers:3:channel|ALT_INV_LessThan0~2_combout\ : std_logic;
SIGNAL \timers:1:channel|prescaler|ALT_INV_TICK~q\ : std_logic;
SIGNAL \timers:1:channel|ALT_INV_elapsed_r[14]~2_combout\ : std_logic;
SIGNAL \timers:2:channel|ALT_INV_timescale_r\ : std_logic_vector(15 DOWNTO 0);
SIGNAL \timers:2:channel|prescaler|ALT_INV_LessThan1~0_combout\ : std_logic;
SIGNAL \timers:2:channel|prescaler|ALT_INV_LessThan1~1_combout\ : std_logic;
SIGNAL \timers:2:channel|prescaler|ALT_INV_LessThan1~2_combout\ : std_logic;
SIGNAL \timers:2:channel|prescaler|ALT_INV_LessThan1~3_combout\ : std_logic;
SIGNAL \timers:2:channel|prescaler|ALT_INV_LessThan1~4_combout\ : std_logic;
SIGNAL \timers:2:channel|ALT_INV_running_r~0_combout\ : std_logic;
SIGNAL \timers:0:channel|ALT_INV_Mux33~0_combout\ : std_logic;
SIGNAL \timers:0:channel|ALT_INV_process_0~0_combout\ : std_logic;
SIGNAL \timers:0:channel|ALT_INV_timescale_r\ : std_logic_vector(15 DOWNTO 0);
SIGNAL \timers:0:channel|ALT_INV_running_r~0_combout\ : std_logic;
SIGNAL \timers:2:channel|prescaler|ALT_INV_TICK~0_combout\ : std_logic;
SIGNAL \timers:2:channel|prescaler|ALT_INV_LessThan1~9_combout\ : std_logic;
SIGNAL \timers:0:channel|ALT_INV_Equal1~1_combout\ : std_logic;
SIGNAL \timers:2:channel|prescaler|ALT_INV_LessThan1~7_combout\ : std_logic;
SIGNAL \timers:2:channel|prescaler|ALT_INV_LessThan1~14_combout\ : std_logic;
SIGNAL \timers:2:channel|prescaler|ALT_INV_LessThan0~0_combout\ : std_logic;
SIGNAL \timers:0:channel|ALT_INV_Equal1~0_combout\ : std_logic;
SIGNAL \timers:0:channel|prescaler|ALT_INV_LessThan1~5_combout\ : std_logic;
SIGNAL \timers:0:channel|prescaler|ALT_INV_LessThan1~7_combout\ : std_logic;
SIGNAL \timers:2:channel|prescaler|ALT_INV_LessThan1~5_combout\ : std_logic;
SIGNAL \timers:2:channel|prescaler|ALT_INV_cycle_count\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \timers:2:channel|prescaler|ALT_INV_LessThan1~8_combout\ : std_logic;
SIGNAL \timers:0:channel|ALT_INV_process_0~1_combout\ : std_logic;
SIGNAL \timers:0:channel|prescaler|ALT_INV_LessThan1~3_combout\ : std_logic;
SIGNAL \timers:0:channel|prescaler|ALT_INV_LessThan1~9_combout\ : std_logic;
SIGNAL \timers:2:channel|prescaler|ALT_INV_LessThan1~12_combout\ : std_logic;
SIGNAL \timers:2:channel|prescaler|ALT_INV_LessThan1~6_combout\ : std_logic;
SIGNAL \timers:0:channel|prescaler|ALT_INV_LessThan1~6_combout\ : std_logic;
SIGNAL \timers:0:channel|ALT_INV_Equal1~2_combout\ : std_logic;
SIGNAL \timers:2:channel|prescaler|ALT_INV_LessThan1~10_combout\ : std_logic;
SIGNAL \timers:2:channel|prescaler|ALT_INV_LessThan1~11_combout\ : std_logic;
SIGNAL \timers:2:channel|prescaler|ALT_INV_LessThan1~15_combout\ : std_logic;
SIGNAL \timers:0:channel|prescaler|ALT_INV_LessThan1~1_combout\ : std_logic;
SIGNAL \timers:2:channel|ALT_INV_clear_prescale~q\ : std_logic;
SIGNAL \timers:0:channel|prescaler|ALT_INV_LessThan1~2_combout\ : std_logic;
SIGNAL \timers:2:channel|prescaler|ALT_INV_LessThan1~13_combout\ : std_logic;
SIGNAL \timers:0:channel|prescaler|ALT_INV_LessThan1~0_combout\ : std_logic;
SIGNAL \timers:0:channel|prescaler|ALT_INV_LessThan1~4_combout\ : std_logic;
SIGNAL \timers:0:channel|prescaler|ALT_INV_LessThan1~8_combout\ : std_logic;
SIGNAL \timers:1:channel|prescaler|ALT_INV_LessThan1~8_combout\ : std_logic;
SIGNAL \timers:1:channel|ALT_INV_timescale_r\ : std_logic_vector(15 DOWNTO 0);
SIGNAL \timers:1:channel|prescaler|ALT_INV_LessThan1~11_combout\ : std_logic;
SIGNAL \timers:1:channel|prescaler|ALT_INV_LessThan1~12_combout\ : std_logic;
SIGNAL \timers:1:channel|prescaler|ALT_INV_LessThan1~13_combout\ : std_logic;
SIGNAL \timers:1:channel|prescaler|ALT_INV_LessThan1~15_combout\ : std_logic;
SIGNAL \timers:0:channel|prescaler|ALT_INV_cycle_count\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \timers:1:channel|prescaler|ALT_INV_LessThan1~6_combout\ : std_logic;
SIGNAL \timers:1:channel|ALT_INV_clear_prescale~q\ : std_logic;
SIGNAL \timers:1:channel|prescaler|ALT_INV_cycle_count\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \timers:0:channel|prescaler|ALT_INV_LessThan1~15_combout\ : std_logic;
SIGNAL \timers:0:channel|prescaler|ALT_INV_LessThan0~0_combout\ : std_logic;
SIGNAL \timers:0:channel|ALT_INV_clear_prescale~q\ : std_logic;
SIGNAL \timers:1:channel|prescaler|ALT_INV_LessThan1~14_combout\ : std_logic;
SIGNAL \timers:1:channel|prescaler|ALT_INV_LessThan0~0_combout\ : std_logic;
SIGNAL \timers:1:channel|prescaler|ALT_INV_TICK~0_combout\ : std_logic;
SIGNAL \timers:3:channel|ALT_INV_running_r~0_combout\ : std_logic;
SIGNAL \timers:1:channel|prescaler|ALT_INV_LessThan1~0_combout\ : std_logic;
SIGNAL \timers:1:channel|prescaler|ALT_INV_LessThan1~2_combout\ : std_logic;
SIGNAL \timers:1:channel|prescaler|ALT_INV_LessThan1~9_combout\ : std_logic;
SIGNAL \timers:1:channel|prescaler|ALT_INV_LessThan1~10_combout\ : std_logic;
SIGNAL \timers:0:channel|prescaler|ALT_INV_LessThan1~10_combout\ : std_logic;
SIGNAL \timers:1:channel|prescaler|ALT_INV_LessThan1~7_combout\ : std_logic;
SIGNAL \timers:0:channel|prescaler|ALT_INV_LessThan1~12_combout\ : std_logic;
SIGNAL \timers:0:channel|prescaler|ALT_INV_TICK~0_combout\ : std_logic;
SIGNAL \timers:1:channel|prescaler|ALT_INV_LessThan1~1_combout\ : std_logic;
SIGNAL \timers:0:channel|prescaler|ALT_INV_LessThan1~11_combout\ : std_logic;
SIGNAL \timers:0:channel|prescaler|ALT_INV_LessThan1~13_combout\ : std_logic;
SIGNAL \timers:1:channel|prescaler|ALT_INV_LessThan1~4_combout\ : std_logic;
SIGNAL \timers:1:channel|prescaler|ALT_INV_LessThan1~5_combout\ : std_logic;
SIGNAL \timers:1:channel|prescaler|ALT_INV_LessThan1~3_combout\ : std_logic;
SIGNAL \timers:1:channel|ALT_INV_running_r~0_combout\ : std_logic;
SIGNAL \timers:0:channel|prescaler|ALT_INV_LessThan1~14_combout\ : std_logic;
SIGNAL \timers:3:channel|prescaler|ALT_INV_LessThan1~10_combout\ : std_logic;
SIGNAL \timers:3:channel|prescaler|ALT_INV_LessThan1~4_combout\ : std_logic;
SIGNAL \timers:3:channel|ALT_INV_timescale_r\ : std_logic_vector(15 DOWNTO 0);
SIGNAL \timers:3:channel|prescaler|ALT_INV_LessThan1~5_combout\ : std_logic;
SIGNAL \timers:3:channel|ALT_INV_clear_prescale~q\ : std_logic;
SIGNAL \timers:3:channel|prescaler|ALT_INV_LessThan1~7_combout\ : std_logic;
SIGNAL \timers:3:channel|prescaler|ALT_INV_cycle_count\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \timers:3:channel|ALT_INV_process_0~2_combout\ : std_logic;
SIGNAL \timers:3:channel|prescaler|ALT_INV_LessThan1~13_combout\ : std_logic;
SIGNAL \timers:3:channel|prescaler|ALT_INV_TICK~0_combout\ : std_logic;
SIGNAL \timers:3:channel|prescaler|ALT_INV_LessThan1~8_combout\ : std_logic;
SIGNAL \timers:3:channel|prescaler|ALT_INV_LessThan1~2_combout\ : std_logic;
SIGNAL \timers:3:channel|prescaler|ALT_INV_LessThan1~6_combout\ : std_logic;
SIGNAL \timers:3:channel|prescaler|ALT_INV_LessThan1~0_combout\ : std_logic;
SIGNAL \timers:3:channel|prescaler|ALT_INV_LessThan1~3_combout\ : std_logic;
SIGNAL \timers:3:channel|prescaler|ALT_INV_LessThan1~14_combout\ : std_logic;
SIGNAL \timers:3:channel|prescaler|ALT_INV_LessThan1~15_combout\ : std_logic;
SIGNAL \timers:3:channel|prescaler|ALT_INV_LessThan1~11_combout\ : std_logic;
SIGNAL \timers:3:channel|prescaler|ALT_INV_LessThan1~9_combout\ : std_logic;
SIGNAL \timers:3:channel|prescaler|ALT_INV_LessThan1~1_combout\ : std_logic;
SIGNAL \timers:3:channel|prescaler|ALT_INV_LessThan1~12_combout\ : std_logic;
SIGNAL \timers:3:channel|prescaler|ALT_INV_LessThan0~0_combout\ : std_logic;
SIGNAL \ALT_INV_IO_DATA[1]~input_o\ : std_logic;
SIGNAL \ALT_INV_IO_DATA[2]~input_o\ : std_logic;
SIGNAL \ALT_INV_IO_DATA[4]~input_o\ : std_logic;
SIGNAL \ALT_INV_IO_DATA[5]~input_o\ : std_logic;
SIGNAL \ALT_INV_IO_DATA[6]~input_o\ : std_logic;
SIGNAL \ALT_INV_IO_DATA[8]~input_o\ : std_logic;
SIGNAL \ALT_INV_IO_DATA[10]~input_o\ : std_logic;
SIGNAL \ALT_INV_IO_DATA[9]~input_o\ : std_logic;
SIGNAL \ALT_INV_IO_DATA[7]~input_o\ : std_logic;
SIGNAL \ALT_INV_IO_DATA[0]~input_o\ : std_logic;
SIGNAL \ALT_INV_IO_DATA[3]~input_o\ : std_logic;
SIGNAL \ALT_INV_IO_ADDR[9]~input_o\ : std_logic;
SIGNAL \timers:2:channel|prescaler|ALT_INV_TICK~DUPLICATE_q\ : std_logic;
SIGNAL \ALT_INV_IO_DATA[14]~input_o\ : std_logic;
SIGNAL \ALT_INV_IO_READ~input_o\ : std_logic;
SIGNAL \ALT_INV_IO_ADDR[8]~input_o\ : std_logic;
SIGNAL \ALT_INV_IO_ADDR[7]~input_o\ : std_logic;
SIGNAL \ALT_INV_IO_ADDR[4]~input_o\ : std_logic;
SIGNAL \ALT_INV_IO_DATA[13]~input_o\ : std_logic;
SIGNAL \ALT_INV_IO_ADDR[6]~input_o\ : std_logic;
SIGNAL \timers:0:channel|prescaler|ALT_INV_cycle_count[0]~DUPLICATE_q\ : std_logic;
SIGNAL \timers:1:channel|prescaler|ALT_INV_cycle_count[1]~DUPLICATE_q\ : std_logic;
SIGNAL \ALT_INV_IO_ADDR[1]~input_o\ : std_logic;
SIGNAL \ALT_INV_IO_ADDR[10]~input_o\ : std_logic;
SIGNAL \ALT_INV_IO_WRITE~input_o\ : std_logic;
SIGNAL \ALT_INV_IO_ADDR[3]~input_o\ : std_logic;
SIGNAL \ALT_INV_IO_ADDR[0]~input_o\ : std_logic;
SIGNAL \ALT_INV_IO_DATA[11]~input_o\ : std_logic;
SIGNAL \ALT_INV_IO_DATA[12]~input_o\ : std_logic;
SIGNAL \ALT_INV_IO_ADDR[2]~input_o\ : std_logic;
SIGNAL \timers:2:channel|prescaler|ALT_INV_cycle_count[0]~DUPLICATE_q\ : std_logic;
SIGNAL \ALT_INV_IO_DATA[15]~input_o\ : std_logic;
SIGNAL \ALT_INV_IO_ADDR[5]~input_o\ : std_logic;

BEGIN

ww_CLOCK <= CLOCK;
ww_RESETN <= RESETN;
ww_IO_ADDR <= IO_ADDR;
ww_IO_READ <= IO_READ;
ww_IO_WRITE <= IO_WRITE;
ww_devoe <= devoe;
ww_devclrn <= devclrn;
ww_devpor <= devpor;
\timers:0:channel|ALT_INV_periods_r\(10) <= NOT \timers:0:channel|periods_r\(10);
\timers:1:channel|ALT_INV_periods_r\(11) <= NOT \timers:1:channel|periods_r\(11);
\timers:2:channel|ALT_INV_elapsed_r\(12) <= NOT \timers:2:channel|elapsed_r\(12);
\timers:1:channel|ALT_INV_periods_r\(12) <= NOT \timers:1:channel|periods_r\(12);
\timers:0:channel|ALT_INV_periods_r\(12) <= NOT \timers:0:channel|periods_r\(12);
\timers:2:channel|ALT_INV_periods_r\(13) <= NOT \timers:2:channel|periods_r\(13);
\timers:0:channel|ALT_INV_elapsed_r\(13) <= NOT \timers:0:channel|elapsed_r\(13);
\timers:3:channel|ALT_INV_elapsed_r\(12) <= NOT \timers:3:channel|elapsed_r\(12);
\timers:3:channel|ALT_INV_periods_r\(12) <= NOT \timers:3:channel|periods_r\(12);
\timers:0:channel|ALT_INV_elapsed_r\(10) <= NOT \timers:0:channel|elapsed_r\(10);
\timers:2:channel|ALT_INV_periods_r\(11) <= NOT \timers:2:channel|periods_r\(11);
\timers:1:channel|ALT_INV_elapsed_r\(11) <= NOT \timers:1:channel|elapsed_r\(11);
\timers:2:channel|ALT_INV_elapsed_r\(11) <= NOT \timers:2:channel|elapsed_r\(11);
\timers:3:channel|ALT_INV_elapsed_r\(11) <= NOT \timers:3:channel|elapsed_r\(11);
\timers:1:channel|ALT_INV_elapsed_r\(12) <= NOT \timers:1:channel|elapsed_r\(12);
\timers:0:channel|ALT_INV_elapsed_r\(11) <= NOT \timers:0:channel|elapsed_r\(11);
\timers:0:channel|ALT_INV_periods_r\(11) <= NOT \timers:0:channel|periods_r\(11);
\timers:3:channel|ALT_INV_periods_r\(10) <= NOT \timers:3:channel|periods_r\(10);
\timers:3:channel|ALT_INV_periods_r\(11) <= NOT \timers:3:channel|periods_r\(11);
\timers:1:channel|ALT_INV_elapsed_r\(10) <= NOT \timers:1:channel|elapsed_r\(10);
\timers:2:channel|ALT_INV_elapsed_r\(10) <= NOT \timers:2:channel|elapsed_r\(10);
\timers:3:channel|ALT_INV_elapsed_r\(10) <= NOT \timers:3:channel|elapsed_r\(10);
\timers:2:channel|ALT_INV_periods_r\(12) <= NOT \timers:2:channel|periods_r\(12);
\timers:1:channel|ALT_INV_periods_r\(10) <= NOT \timers:1:channel|periods_r\(10);
\timers:0:channel|ALT_INV_elapsed_r\(12) <= NOT \timers:0:channel|elapsed_r\(12);
\timers:1:channel|ALT_INV_periods_r\(15) <= NOT \timers:1:channel|periods_r\(15);
\timers:1:channel|ALT_INV_elapsed_r\(13) <= NOT \timers:1:channel|elapsed_r\(13);
\timers:2:channel|ALT_INV_elapsed_r\(13) <= NOT \timers:2:channel|elapsed_r\(13);
\timers:1:channel|ALT_INV_periods_r\(14) <= NOT \timers:1:channel|periods_r\(14);
\timers:0:channel|ALT_INV_periods_r\(14) <= NOT \timers:0:channel|periods_r\(14);
\timers:2:channel|ALT_INV_periods_r\(15) <= NOT \timers:2:channel|periods_r\(15);
\timers:1:channel|ALT_INV_periods_r\(13) <= NOT \timers:1:channel|periods_r\(13);
\timers:2:channel|ALT_INV_elapsed_r\(14) <= NOT \timers:2:channel|elapsed_r\(14);
\timers:3:channel|ALT_INV_periods_r\(13) <= NOT \timers:3:channel|periods_r\(13);
\timers:3:channel|ALT_INV_elapsed_r\(13) <= NOT \timers:3:channel|elapsed_r\(13);
\timers:1:channel|ALT_INV_elapsed_r\(14) <= NOT \timers:1:channel|elapsed_r\(14);
\timers:0:channel|ALT_INV_periods_r\(13) <= NOT \timers:0:channel|periods_r\(13);
\timers:2:channel|ALT_INV_periods_r\(14) <= NOT \timers:2:channel|periods_r\(14);
\timers:0:channel|ALT_INV_elapsed_r\(14) <= NOT \timers:0:channel|elapsed_r\(14);
\timers:3:channel|ALT_INV_elapsed_r\(14) <= NOT \timers:3:channel|elapsed_r\(14);
\timers:3:channel|ALT_INV_periods_r\(14) <= NOT \timers:3:channel|periods_r\(14);
\timers:3:channel|ALT_INV_elapsed_r\(15) <= NOT \timers:3:channel|elapsed_r\(15);
\timers:3:channel|ALT_INV_periods_r\(15) <= NOT \timers:3:channel|periods_r\(15);
\timers:0:channel|ALT_INV_elapsed_r\(15) <= NOT \timers:0:channel|elapsed_r\(15);
\timers:1:channel|ALT_INV_elapsed_r\(15) <= NOT \timers:1:channel|elapsed_r\(15);
\timers:2:channel|ALT_INV_elapsed_r\(15) <= NOT \timers:2:channel|elapsed_r\(15);
\timers:2:channel|ALT_INV_elapsed_r\(8) <= NOT \timers:2:channel|elapsed_r\(8);
\timers:3:channel|ALT_INV_periods_r\(8) <= NOT \timers:3:channel|periods_r\(8);
\timers:0:channel|ALT_INV_periods_r\(8) <= NOT \timers:0:channel|periods_r\(8);
\timers:0:channel|ALT_INV_elapsed_r\(9) <= NOT \timers:0:channel|elapsed_r\(9);
\timers:1:channel|ALT_INV_periods_r\(8) <= NOT \timers:1:channel|periods_r\(8);
\timers:1:channel|ALT_INV_elapsed_r\(9) <= NOT \timers:1:channel|elapsed_r\(9);
\timers:2:channel|ALT_INV_elapsed_r\(9) <= NOT \timers:2:channel|elapsed_r\(9);
\timers:3:channel|ALT_INV_elapsed_r\(9) <= NOT \timers:3:channel|elapsed_r\(9);
\timers:3:channel|ALT_INV_periods_r\(9) <= NOT \timers:3:channel|periods_r\(9);
\timers:1:channel|ALT_INV_periods_r\(9) <= NOT \timers:1:channel|periods_r\(9);
\timers:0:channel|ALT_INV_periods_r\(9) <= NOT \timers:0:channel|periods_r\(9);
\timers:3:channel|ALT_INV_elapsed_r\(8) <= NOT \timers:3:channel|elapsed_r\(8);
\timers:2:channel|ALT_INV_periods_r\(9) <= NOT \timers:2:channel|periods_r\(9);
\timers:2:channel|ALT_INV_periods_r\(10) <= NOT \timers:2:channel|periods_r\(10);
\timers:0:channel|ALT_INV_elapsed_r\(0) <= NOT \timers:0:channel|elapsed_r\(0);
\timers:3:channel|ALT_INV_periods_r\(0) <= NOT \timers:3:channel|periods_r\(0);
\timers:1:channel|ALT_INV_elapsed_r\(0) <= NOT \timers:1:channel|elapsed_r\(0);
\timers:1:channel|ALT_INV_periods_r\(1) <= NOT \timers:1:channel|periods_r\(1);
\timers:3:channel|ALT_INV_elapsed_r\(2) <= NOT \timers:3:channel|elapsed_r\(2);
\timers:1:channel|ALT_INV_periods_r\(2) <= NOT \timers:1:channel|periods_r\(2);
\timers:0:channel|ALT_INV_elapsed_r\(3) <= NOT \timers:0:channel|elapsed_r\(3);
\timers:3:channel|ALT_INV_elapsed_r\(3) <= NOT \timers:3:channel|elapsed_r\(3);
\timers:3:channel|ALT_INV_periods_r\(3) <= NOT \timers:3:channel|periods_r\(3);
\timers:0:channel|ALT_INV_elapsed_r\(2) <= NOT \timers:0:channel|elapsed_r\(2);
\timers:2:channel|ALT_INV_periods_r\(2) <= NOT \timers:2:channel|periods_r\(2);
\timers:2:channel|ALT_INV_elapsed_r\(3) <= NOT \timers:2:channel|elapsed_r\(3);
\timers:1:channel|ALT_INV_periods_r\(3) <= NOT \timers:1:channel|periods_r\(3);
\timers:0:channel|ALT_INV_periods_r\(3) <= NOT \timers:0:channel|periods_r\(3);
\timers:2:channel|ALT_INV_periods_r\(4) <= NOT \timers:2:channel|periods_r\(4);
\timers:0:channel|ALT_INV_elapsed_r\(4) <= NOT \timers:0:channel|elapsed_r\(4);
\timers:1:channel|ALT_INV_elapsed_r\(4) <= NOT \timers:1:channel|elapsed_r\(4);
\timers:2:channel|ALT_INV_elapsed_r\(4) <= NOT \timers:2:channel|elapsed_r\(4);
\timers:2:channel|ALT_INV_periods_r\(3) <= NOT \timers:2:channel|periods_r\(3);
\timers:3:channel|ALT_INV_periods_r\(4) <= NOT \timers:3:channel|periods_r\(4);
\timers:3:channel|ALT_INV_elapsed_r\(4) <= NOT \timers:3:channel|elapsed_r\(4);
\timers:2:channel|ALT_INV_periods_r\(0) <= NOT \timers:2:channel|periods_r\(0);
\timers:3:channel|ALT_INV_elapsed_r\(0) <= NOT \timers:3:channel|elapsed_r\(0);
\timers:2:channel|ALT_INV_elapsed_r\(0) <= NOT \timers:2:channel|elapsed_r\(0);
\timers:2:channel|ALT_INV_periods_r\(1) <= NOT \timers:2:channel|periods_r\(1);
\timers:1:channel|ALT_INV_periods_r\(0) <= NOT \timers:1:channel|periods_r\(0);
\timers:1:channel|ALT_INV_elapsed_r\(1) <= NOT \timers:1:channel|elapsed_r\(1);
\timers:2:channel|ALT_INV_elapsed_r\(1) <= NOT \timers:2:channel|elapsed_r\(1);
\timers:0:channel|ALT_INV_elapsed_r\(1) <= NOT \timers:0:channel|elapsed_r\(1);
\timers:3:channel|ALT_INV_elapsed_r\(1) <= NOT \timers:3:channel|elapsed_r\(1);
\timers:3:channel|ALT_INV_periods_r\(1) <= NOT \timers:3:channel|periods_r\(1);
\timers:0:channel|ALT_INV_periods_r\(1) <= NOT \timers:0:channel|periods_r\(1);
\timers:1:channel|ALT_INV_elapsed_r\(2) <= NOT \timers:1:channel|elapsed_r\(2);
\timers:2:channel|ALT_INV_elapsed_r\(2) <= NOT \timers:2:channel|elapsed_r\(2);
\timers:3:channel|ALT_INV_periods_r\(2) <= NOT \timers:3:channel|periods_r\(2);
\timers:0:channel|ALT_INV_periods_r\(2) <= NOT \timers:0:channel|periods_r\(2);
\timers:1:channel|ALT_INV_elapsed_r\(3) <= NOT \timers:1:channel|elapsed_r\(3);
\timers:0:channel|ALT_INV_periods_r\(0) <= NOT \timers:0:channel|periods_r\(0);
\timers:2:channel|ALT_INV_periods_r\(5) <= NOT \timers:2:channel|periods_r\(5);
\timers:1:channel|ALT_INV_periods_r\(4) <= NOT \timers:1:channel|periods_r\(4);
\timers:1:channel|ALT_INV_elapsed_r\(6) <= NOT \timers:1:channel|elapsed_r\(6);
\timers:0:channel|ALT_INV_periods_r\(4) <= NOT \timers:0:channel|periods_r\(4);
\timers:3:channel|ALT_INV_elapsed_r\(5) <= NOT \timers:3:channel|elapsed_r\(5);
\timers:2:channel|ALT_INV_periods_r\(6) <= NOT \timers:2:channel|periods_r\(6);
\timers:0:channel|ALT_INV_elapsed_r\(6) <= NOT \timers:0:channel|elapsed_r\(6);
\timers:0:channel|ALT_INV_periods_r\(6) <= NOT \timers:0:channel|periods_r\(6);
\timers:0:channel|ALT_INV_elapsed_r\(7) <= NOT \timers:0:channel|elapsed_r\(7);
\timers:0:channel|ALT_INV_elapsed_r\(5) <= NOT \timers:0:channel|elapsed_r\(5);
\timers:2:channel|ALT_INV_elapsed_r\(5) <= NOT \timers:2:channel|elapsed_r\(5);
\timers:2:channel|ALT_INV_elapsed_r\(7) <= NOT \timers:2:channel|elapsed_r\(7);
\timers:3:channel|ALT_INV_elapsed_r\(7) <= NOT \timers:3:channel|elapsed_r\(7);
\timers:0:channel|ALT_INV_periods_r\(7) <= NOT \timers:0:channel|periods_r\(7);
\timers:1:channel|ALT_INV_periods_r\(5) <= NOT \timers:1:channel|periods_r\(5);
\timers:3:channel|ALT_INV_periods_r\(6) <= NOT \timers:3:channel|periods_r\(6);
\timers:3:channel|ALT_INV_elapsed_r\(6) <= NOT \timers:3:channel|elapsed_r\(6);
\timers:3:channel|ALT_INV_periods_r\(5) <= NOT \timers:3:channel|periods_r\(5);
\timers:1:channel|ALT_INV_elapsed_r\(5) <= NOT \timers:1:channel|elapsed_r\(5);
\timers:2:channel|ALT_INV_elapsed_r\(6) <= NOT \timers:2:channel|elapsed_r\(6);
\timers:2:channel|ALT_INV_periods_r\(7) <= NOT \timers:2:channel|periods_r\(7);
\timers:1:channel|ALT_INV_elapsed_r\(7) <= NOT \timers:1:channel|elapsed_r\(7);
\timers:0:channel|ALT_INV_periods_r\(5) <= NOT \timers:0:channel|periods_r\(5);
\timers:1:channel|ALT_INV_periods_r\(6) <= NOT \timers:1:channel|periods_r\(6);
\timers:3:channel|ALT_INV_periods_r\(7) <= NOT \timers:3:channel|periods_r\(7);
\timers:1:channel|ALT_INV_periods_r\(7) <= NOT \timers:1:channel|periods_r\(7);
\timers:2:channel|ALT_INV_periods_r\(8) <= NOT \timers:2:channel|periods_r\(8);
\timers:1:channel|ALT_INV_elapsed_r\(8) <= NOT \timers:1:channel|elapsed_r\(8);
\timers:0:channel|ALT_INV_elapsed_r\(8) <= NOT \timers:0:channel|elapsed_r\(8);
\timers:0:channel|ALT_INV_Add0~21_sumout\ <= NOT \timers:0:channel|Add0~21_sumout\;
\timers:0:channel|ALT_INV_Add0~25_sumout\ <= NOT \timers:0:channel|Add0~25_sumout\;
\timers:0:channel|ALT_INV_Add0~29_sumout\ <= NOT \timers:0:channel|Add0~29_sumout\;
\timers:0:channel|ALT_INV_Add0~33_sumout\ <= NOT \timers:0:channel|Add0~33_sumout\;
\timers:2:channel|ALT_INV_Add0~13_sumout\ <= NOT \timers:2:channel|Add0~13_sumout\;
\timers:2:channel|ALT_INV_Add0~29_sumout\ <= NOT \timers:2:channel|Add0~29_sumout\;
\timers:2:channel|ALT_INV_Add0~5_sumout\ <= NOT \timers:2:channel|Add0~5_sumout\;
\timers:2:channel|ALT_INV_Add0~41_sumout\ <= NOT \timers:2:channel|Add0~41_sumout\;
\timers:0:channel|ALT_INV_Add0~45_sumout\ <= NOT \timers:0:channel|Add0~45_sumout\;
\timers:0:channel|ALT_INV_Add0~49_sumout\ <= NOT \timers:0:channel|Add0~49_sumout\;
\timers:0:channel|ALT_INV_Add0~53_sumout\ <= NOT \timers:0:channel|Add0~53_sumout\;
\timers:0:channel|ALT_INV_Add0~37_sumout\ <= NOT \timers:0:channel|Add0~37_sumout\;
\timers:0:channel|ALT_INV_Add0~57_sumout\ <= NOT \timers:0:channel|Add0~57_sumout\;
\timers:0:channel|ALT_INV_Add0~41_sumout\ <= NOT \timers:0:channel|Add0~41_sumout\;
\timers:0:channel|ALT_INV_periods_r\(15) <= NOT \timers:0:channel|periods_r\(15);
\timers:2:channel|ALT_INV_Add0~1_sumout\ <= NOT \timers:2:channel|Add0~1_sumout\;
\timers:2:channel|ALT_INV_Add0~49_sumout\ <= NOT \timers:2:channel|Add0~49_sumout\;
\timers:2:channel|ALT_INV_Add0~9_sumout\ <= NOT \timers:2:channel|Add0~9_sumout\;
\timers:2:channel|ALT_INV_Add0~61_sumout\ <= NOT \timers:2:channel|Add0~61_sumout\;
\timers:2:channel|ALT_INV_Add0~25_sumout\ <= NOT \timers:2:channel|Add0~25_sumout\;
\timers:0:channel|ALT_INV_Add0~5_sumout\ <= NOT \timers:0:channel|Add0~5_sumout\;
\timers:0:channel|ALT_INV_Add0~9_sumout\ <= NOT \timers:0:channel|Add0~9_sumout\;
\timers:2:channel|ALT_INV_Add0~21_sumout\ <= NOT \timers:2:channel|Add0~21_sumout\;
\timers:0:channel|ALT_INV_Add0~17_sumout\ <= NOT \timers:0:channel|Add0~17_sumout\;
\timers:2:channel|ALT_INV_Add0~33_sumout\ <= NOT \timers:2:channel|Add0~33_sumout\;
\timers:2:channel|ALT_INV_Add0~37_sumout\ <= NOT \timers:2:channel|Add0~37_sumout\;
\timers:2:channel|ALT_INV_Add0~53_sumout\ <= NOT \timers:2:channel|Add0~53_sumout\;
\timers:2:channel|ALT_INV_Add0~45_sumout\ <= NOT \timers:2:channel|Add0~45_sumout\;
\timers:0:channel|ALT_INV_Add0~13_sumout\ <= NOT \timers:0:channel|Add0~13_sumout\;
\timers:2:channel|ALT_INV_Add0~17_sumout\ <= NOT \timers:2:channel|Add0~17_sumout\;
\timers:2:channel|ALT_INV_Add0~57_sumout\ <= NOT \timers:2:channel|Add0~57_sumout\;
\timers:0:channel|ALT_INV_Add0~1_sumout\ <= NOT \timers:0:channel|Add0~1_sumout\;
\timers:3:channel|ALT_INV_Add0~25_sumout\ <= NOT \timers:3:channel|Add0~25_sumout\;
\timers:3:channel|ALT_INV_Add0~17_sumout\ <= NOT \timers:3:channel|Add0~17_sumout\;
\timers:1:channel|ALT_INV_Add0~25_sumout\ <= NOT \timers:1:channel|Add0~25_sumout\;
\timers:3:channel|ALT_INV_Add0~29_sumout\ <= NOT \timers:3:channel|Add0~29_sumout\;
\timers:3:channel|ALT_INV_Add0~37_sumout\ <= NOT \timers:3:channel|Add0~37_sumout\;
\timers:3:channel|ALT_INV_Add0~41_sumout\ <= NOT \timers:3:channel|Add0~41_sumout\;
\timers:3:channel|ALT_INV_Add0~49_sumout\ <= NOT \timers:3:channel|Add0~49_sumout\;
\timers:0:channel|ALT_INV_Add0~61_sumout\ <= NOT \timers:0:channel|Add0~61_sumout\;
\timers:1:channel|ALT_INV_Add0~37_sumout\ <= NOT \timers:1:channel|Add0~37_sumout\;
\timers:1:channel|ALT_INV_Add0~45_sumout\ <= NOT \timers:1:channel|Add0~45_sumout\;
\timers:3:channel|ALT_INV_Add0~33_sumout\ <= NOT \timers:3:channel|Add0~33_sumout\;
\timers:3:channel|ALT_INV_Add0~45_sumout\ <= NOT \timers:3:channel|Add0~45_sumout\;
\timers:1:channel|ALT_INV_Add0~49_sumout\ <= NOT \timers:1:channel|Add0~49_sumout\;
\timers:1:channel|ALT_INV_Add0~13_sumout\ <= NOT \timers:1:channel|Add0~13_sumout\;
\timers:1:channel|ALT_INV_Add0~17_sumout\ <= NOT \timers:1:channel|Add0~17_sumout\;
\timers:1:channel|ALT_INV_Add0~53_sumout\ <= NOT \timers:1:channel|Add0~53_sumout\;
\timers:1:channel|ALT_INV_Add0~1_sumout\ <= NOT \timers:1:channel|Add0~1_sumout\;
\timers:1:channel|ALT_INV_Add0~41_sumout\ <= NOT \timers:1:channel|Add0~41_sumout\;
\timers:1:channel|ALT_INV_Add0~61_sumout\ <= NOT \timers:1:channel|Add0~61_sumout\;
\timers:1:channel|ALT_INV_Add0~9_sumout\ <= NOT \timers:1:channel|Add0~9_sumout\;
\timers:1:channel|ALT_INV_Add0~21_sumout\ <= NOT \timers:1:channel|Add0~21_sumout\;
\timers:1:channel|ALT_INV_Add0~33_sumout\ <= NOT \timers:1:channel|Add0~33_sumout\;
\timers:1:channel|ALT_INV_Add0~5_sumout\ <= NOT \timers:1:channel|Add0~5_sumout\;
\timers:3:channel|ALT_INV_Add0~1_sumout\ <= NOT \timers:3:channel|Add0~1_sumout\;
\timers:1:channel|ALT_INV_Add0~57_sumout\ <= NOT \timers:1:channel|Add0~57_sumout\;
\timers:3:channel|ALT_INV_Add0~9_sumout\ <= NOT \timers:3:channel|Add0~9_sumout\;
\timers:3:channel|ALT_INV_Add0~5_sumout\ <= NOT \timers:3:channel|Add0~5_sumout\;
\timers:1:channel|ALT_INV_Add0~29_sumout\ <= NOT \timers:1:channel|Add0~29_sumout\;
\timers:3:channel|ALT_INV_Add0~13_sumout\ <= NOT \timers:3:channel|Add0~13_sumout\;
\timers:3:channel|ALT_INV_Add0~21_sumout\ <= NOT \timers:3:channel|Add0~21_sumout\;
\timers:3:channel|ALT_INV_Add0~61_sumout\ <= NOT \timers:3:channel|Add0~61_sumout\;
\timers:3:channel|ALT_INV_Add0~53_sumout\ <= NOT \timers:3:channel|Add0~53_sumout\;
\timers:3:channel|ALT_INV_Add0~57_sumout\ <= NOT \timers:3:channel|Add0~57_sumout\;
\timers:2:channel|prescaler|ALT_INV_Add1~1_sumout\ <= NOT \timers:2:channel|prescaler|Add1~1_sumout\;
\timers:2:channel|prescaler|ALT_INV_Add1~5_sumout\ <= NOT \timers:2:channel|prescaler|Add1~5_sumout\;
\timers:2:channel|prescaler|ALT_INV_Add1~13_sumout\ <= NOT \timers:2:channel|prescaler|Add1~13_sumout\;
\timers:2:channel|prescaler|ALT_INV_Add1~17_sumout\ <= NOT \timers:2:channel|prescaler|Add1~17_sumout\;
\timers:2:channel|prescaler|ALT_INV_Add1~21_sumout\ <= NOT \timers:2:channel|prescaler|Add1~21_sumout\;
\timers:2:channel|prescaler|ALT_INV_Add1~9_sumout\ <= NOT \timers:2:channel|prescaler|Add1~9_sumout\;
\timers:1:channel|prescaler|ALT_INV_Add1~17_sumout\ <= NOT \timers:1:channel|prescaler|Add1~17_sumout\;
\timers:2:channel|prescaler|ALT_INV_Add1~45_sumout\ <= NOT \timers:2:channel|prescaler|Add1~45_sumout\;
\timers:2:channel|prescaler|ALT_INV_Add1~61_sumout\ <= NOT \timers:2:channel|prescaler|Add1~61_sumout\;
\timers:0:channel|prescaler|ALT_INV_Add1~53_sumout\ <= NOT \timers:0:channel|prescaler|Add1~53_sumout\;
\timers:0:channel|prescaler|ALT_INV_Add1~25_sumout\ <= NOT \timers:0:channel|prescaler|Add1~25_sumout\;
\timers:2:channel|prescaler|ALT_INV_Add1~33_sumout\ <= NOT \timers:2:channel|prescaler|Add1~33_sumout\;
\timers:1:channel|prescaler|ALT_INV_Add1~9_sumout\ <= NOT \timers:1:channel|prescaler|Add1~9_sumout\;
\timers:0:channel|prescaler|ALT_INV_Add1~33_sumout\ <= NOT \timers:0:channel|prescaler|Add1~33_sumout\;
\timers:0:channel|prescaler|ALT_INV_Add1~49_sumout\ <= NOT \timers:0:channel|prescaler|Add1~49_sumout\;
\timers:1:channel|prescaler|ALT_INV_Add1~5_sumout\ <= NOT \timers:1:channel|prescaler|Add1~5_sumout\;
\timers:1:channel|prescaler|ALT_INV_Add1~21_sumout\ <= NOT \timers:1:channel|prescaler|Add1~21_sumout\;
\timers:0:channel|prescaler|ALT_INV_Add1~37_sumout\ <= NOT \timers:0:channel|prescaler|Add1~37_sumout\;
\timers:2:channel|prescaler|ALT_INV_Add1~25_sumout\ <= NOT \timers:2:channel|prescaler|Add1~25_sumout\;
\timers:2:channel|prescaler|ALT_INV_Add1~41_sumout\ <= NOT \timers:2:channel|prescaler|Add1~41_sumout\;
\timers:1:channel|prescaler|ALT_INV_Add1~25_sumout\ <= NOT \timers:1:channel|prescaler|Add1~25_sumout\;
\timers:0:channel|prescaler|ALT_INV_Add1~61_sumout\ <= NOT \timers:0:channel|prescaler|Add1~61_sumout\;
\timers:2:channel|prescaler|ALT_INV_Add1~49_sumout\ <= NOT \timers:2:channel|prescaler|Add1~49_sumout\;
\timers:0:channel|prescaler|ALT_INV_Add1~21_sumout\ <= NOT \timers:0:channel|prescaler|Add1~21_sumout\;
\timers:0:channel|prescaler|ALT_INV_Add1~41_sumout\ <= NOT \timers:0:channel|prescaler|Add1~41_sumout\;
\timers:2:channel|prescaler|ALT_INV_Add1~29_sumout\ <= NOT \timers:2:channel|prescaler|Add1~29_sumout\;
\timers:0:channel|prescaler|ALT_INV_Add1~9_sumout\ <= NOT \timers:0:channel|prescaler|Add1~9_sumout\;
\timers:0:channel|prescaler|ALT_INV_Add1~29_sumout\ <= NOT \timers:0:channel|prescaler|Add1~29_sumout\;
\timers:0:channel|prescaler|ALT_INV_Add1~13_sumout\ <= NOT \timers:0:channel|prescaler|Add1~13_sumout\;
\timers:0:channel|prescaler|ALT_INV_Add1~45_sumout\ <= NOT \timers:0:channel|prescaler|Add1~45_sumout\;
\timers:2:channel|prescaler|ALT_INV_Add1~53_sumout\ <= NOT \timers:2:channel|prescaler|Add1~53_sumout\;
\timers:0:channel|prescaler|ALT_INV_Add1~17_sumout\ <= NOT \timers:0:channel|prescaler|Add1~17_sumout\;
\timers:0:channel|prescaler|ALT_INV_Add1~5_sumout\ <= NOT \timers:0:channel|prescaler|Add1~5_sumout\;
\timers:0:channel|prescaler|ALT_INV_Add1~1_sumout\ <= NOT \timers:0:channel|prescaler|Add1~1_sumout\;
\timers:1:channel|prescaler|ALT_INV_Add1~13_sumout\ <= NOT \timers:1:channel|prescaler|Add1~13_sumout\;
\timers:2:channel|prescaler|ALT_INV_Add1~37_sumout\ <= NOT \timers:2:channel|prescaler|Add1~37_sumout\;
\timers:2:channel|prescaler|ALT_INV_Add1~57_sumout\ <= NOT \timers:2:channel|prescaler|Add1~57_sumout\;
\timers:0:channel|prescaler|ALT_INV_Add1~57_sumout\ <= NOT \timers:0:channel|prescaler|Add1~57_sumout\;
\timers:1:channel|prescaler|ALT_INV_Add1~1_sumout\ <= NOT \timers:1:channel|prescaler|Add1~1_sumout\;
\timers:2:channel|prescaler|ALT_INV_ms_count\(2) <= NOT \timers:2:channel|prescaler|ms_count\(2);
\timers:1:channel|prescaler|ALT_INV_Add1~33_sumout\ <= NOT \timers:1:channel|prescaler|Add1~33_sumout\;
\timers:3:channel|prescaler|ALT_INV_Add1~53_sumout\ <= NOT \timers:3:channel|prescaler|Add1~53_sumout\;
\timers:1:channel|prescaler|ALT_INV_Add1~53_sumout\ <= NOT \timers:1:channel|prescaler|Add1~53_sumout\;
\timers:3:channel|prescaler|ALT_INV_Add1~41_sumout\ <= NOT \timers:3:channel|prescaler|Add1~41_sumout\;
\timers:1:channel|prescaler|ALT_INV_Add1~37_sumout\ <= NOT \timers:1:channel|prescaler|Add1~37_sumout\;
\timers:3:channel|prescaler|ALT_INV_Add1~17_sumout\ <= NOT \timers:3:channel|prescaler|Add1~17_sumout\;
\timers:2:channel|prescaler|ALT_INV_ms_count\(9) <= NOT \timers:2:channel|prescaler|ms_count\(9);
\timers:2:channel|prescaler|ALT_INV_ms_count\(0) <= NOT \timers:2:channel|prescaler|ms_count\(0);
\timers:2:channel|prescaler|ALT_INV_ms_count\(7) <= NOT \timers:2:channel|prescaler|ms_count\(7);
\timers:3:channel|prescaler|ALT_INV_Add1~1_sumout\ <= NOT \timers:3:channel|prescaler|Add1~1_sumout\;
\timers:3:channel|prescaler|ALT_INV_Add1~29_sumout\ <= NOT \timers:3:channel|prescaler|Add1~29_sumout\;
\timers:3:channel|prescaler|ALT_INV_Add1~61_sumout\ <= NOT \timers:3:channel|prescaler|Add1~61_sumout\;
\timers:2:channel|prescaler|ALT_INV_ms_count\(4) <= NOT \timers:2:channel|prescaler|ms_count\(4);
\timers:3:channel|prescaler|ALT_INV_Add1~9_sumout\ <= NOT \timers:3:channel|prescaler|Add1~9_sumout\;
\timers:1:channel|prescaler|ALT_INV_Add1~45_sumout\ <= NOT \timers:1:channel|prescaler|Add1~45_sumout\;
\timers:1:channel|prescaler|ALT_INV_Add1~49_sumout\ <= NOT \timers:1:channel|prescaler|Add1~49_sumout\;
\timers:2:channel|prescaler|ALT_INV_ms_count\(11) <= NOT \timers:2:channel|prescaler|ms_count\(11);
\timers:3:channel|prescaler|ALT_INV_Add1~5_sumout\ <= NOT \timers:3:channel|prescaler|Add1~5_sumout\;
\timers:2:channel|prescaler|ALT_INV_ms_count\(12) <= NOT \timers:2:channel|prescaler|ms_count\(12);
\timers:1:channel|prescaler|ALT_INV_Add1~29_sumout\ <= NOT \timers:1:channel|prescaler|Add1~29_sumout\;
\timers:2:channel|prescaler|ALT_INV_ms_count\(10) <= NOT \timers:2:channel|prescaler|ms_count\(10);
\timers:2:channel|prescaler|ALT_INV_ms_count\(1) <= NOT \timers:2:channel|prescaler|ms_count\(1);
\timers:3:channel|prescaler|ALT_INV_Add1~33_sumout\ <= NOT \timers:3:channel|prescaler|Add1~33_sumout\;
\timers:3:channel|prescaler|ALT_INV_Add1~45_sumout\ <= NOT \timers:3:channel|prescaler|Add1~45_sumout\;
\timers:3:channel|prescaler|ALT_INV_Add1~21_sumout\ <= NOT \timers:3:channel|prescaler|Add1~21_sumout\;
\timers:3:channel|prescaler|ALT_INV_Add1~49_sumout\ <= NOT \timers:3:channel|prescaler|Add1~49_sumout\;
\timers:1:channel|prescaler|ALT_INV_Add1~41_sumout\ <= NOT \timers:1:channel|prescaler|Add1~41_sumout\;
\timers:1:channel|prescaler|ALT_INV_Add1~61_sumout\ <= NOT \timers:1:channel|prescaler|Add1~61_sumout\;
\timers:3:channel|prescaler|ALT_INV_Add1~13_sumout\ <= NOT \timers:3:channel|prescaler|Add1~13_sumout\;
\timers:2:channel|prescaler|ALT_INV_ms_count\(13) <= NOT \timers:2:channel|prescaler|ms_count\(13);
\timers:2:channel|prescaler|ALT_INV_ms_count\(14) <= NOT \timers:2:channel|prescaler|ms_count\(14);
\timers:3:channel|prescaler|ALT_INV_Add1~37_sumout\ <= NOT \timers:3:channel|prescaler|Add1~37_sumout\;
\timers:3:channel|prescaler|ALT_INV_Add1~57_sumout\ <= NOT \timers:3:channel|prescaler|Add1~57_sumout\;
\timers:2:channel|prescaler|ALT_INV_ms_count\(8) <= NOT \timers:2:channel|prescaler|ms_count\(8);
\timers:1:channel|prescaler|ALT_INV_Add1~57_sumout\ <= NOT \timers:1:channel|prescaler|Add1~57_sumout\;
\timers:3:channel|prescaler|ALT_INV_Add1~25_sumout\ <= NOT \timers:3:channel|prescaler|Add1~25_sumout\;
\timers:2:channel|prescaler|ALT_INV_ms_count\(3) <= NOT \timers:2:channel|prescaler|ms_count\(3);
\timers:2:channel|prescaler|ALT_INV_ms_count\(15) <= NOT \timers:2:channel|prescaler|ms_count\(15);
\timers:0:channel|prescaler|ALT_INV_ms_count\(7) <= NOT \timers:0:channel|prescaler|ms_count\(7);
\timers:1:channel|prescaler|ALT_INV_ms_count\(14) <= NOT \timers:1:channel|prescaler|ms_count\(14);
\timers:1:channel|prescaler|ALT_INV_ms_count\(8) <= NOT \timers:1:channel|prescaler|ms_count\(8);
\timers:1:channel|prescaler|ALT_INV_ms_count\(2) <= NOT \timers:1:channel|prescaler|ms_count\(2);
\timers:1:channel|prescaler|ALT_INV_ms_count\(7) <= NOT \timers:1:channel|prescaler|ms_count\(7);
\timers:0:channel|prescaler|ALT_INV_ms_count\(10) <= NOT \timers:0:channel|prescaler|ms_count\(10);
\timers:3:channel|prescaler|ALT_INV_ms_count\(8) <= NOT \timers:3:channel|prescaler|ms_count\(8);
\timers:3:channel|prescaler|ALT_INV_ms_count\(7) <= NOT \timers:3:channel|prescaler|ms_count\(7);
\timers:0:channel|prescaler|ALT_INV_ms_count\(6) <= NOT \timers:0:channel|prescaler|ms_count\(6);
\ALT_INV_read_value[0]~1_combout\ <= NOT \read_value[0]~1_combout\;
\ALT_INV_read_value[0]~2_combout\ <= NOT \read_value[0]~2_combout\;
\timers:1:channel|prescaler|ALT_INV_ms_count\(4) <= NOT \timers:1:channel|prescaler|ms_count\(4);
\timers:2:channel|prescaler|ALT_INV_ms_count\(6) <= NOT \timers:2:channel|prescaler|ms_count\(6);
\ALT_INV_read_value[1]~5_combout\ <= NOT \read_value[1]~5_combout\;
\ALT_INV_read_value[1]~6_combout\ <= NOT \read_value[1]~6_combout\;
\ALT_INV_read_value[2]~8_combout\ <= NOT \read_value[2]~8_combout\;
\timers:0:channel|prescaler|ALT_INV_ms_count\(9) <= NOT \timers:0:channel|prescaler|ms_count\(9);
\timers:1:channel|prescaler|ALT_INV_ms_count\(15) <= NOT \timers:1:channel|prescaler|ms_count\(15);
\timers:1:channel|prescaler|ALT_INV_ms_count\(5) <= NOT \timers:1:channel|prescaler|ms_count\(5);
\timers:0:channel|prescaler|ALT_INV_ms_count\(2) <= NOT \timers:0:channel|prescaler|ms_count\(2);
\timers:3:channel|prescaler|ALT_INV_ms_count\(14) <= NOT \timers:3:channel|prescaler|ms_count\(14);
\timers:3:channel|prescaler|ALT_INV_ms_count\(5) <= NOT \timers:3:channel|prescaler|ms_count\(5);
\timers:0:channel|prescaler|ALT_INV_ms_count\(1) <= NOT \timers:0:channel|prescaler|ms_count\(1);
\timers:0:channel|prescaler|ALT_INV_ms_count\(14) <= NOT \timers:0:channel|prescaler|ms_count\(14);
\timers:3:channel|prescaler|ALT_INV_ms_count\(2) <= NOT \timers:3:channel|prescaler|ms_count\(2);
\ALT_INV_Equal0~0_combout\ <= NOT \Equal0~0_combout\;
\timers:0:channel|prescaler|ALT_INV_ms_count\(12) <= NOT \timers:0:channel|prescaler|ms_count\(12);
\timers:0:channel|prescaler|ALT_INV_ms_count\(15) <= NOT \timers:0:channel|prescaler|ms_count\(15);
\timers:0:channel|prescaler|ALT_INV_ms_count\(4) <= NOT \timers:0:channel|prescaler|ms_count\(4);
\timers:3:channel|prescaler|ALT_INV_ms_count\(0) <= NOT \timers:3:channel|prescaler|ms_count\(0);
\timers:1:channel|prescaler|ALT_INV_ms_count\(13) <= NOT \timers:1:channel|prescaler|ms_count\(13);
\timers:3:channel|prescaler|ALT_INV_ms_count\(12) <= NOT \timers:3:channel|prescaler|ms_count\(12);
\timers:1:channel|prescaler|ALT_INV_ms_count\(11) <= NOT \timers:1:channel|prescaler|ms_count\(11);
\timers:0:channel|prescaler|ALT_INV_ms_count\(11) <= NOT \timers:0:channel|prescaler|ms_count\(11);
\timers:0:channel|prescaler|ALT_INV_ms_count\(3) <= NOT \timers:0:channel|prescaler|ms_count\(3);
\timers:1:channel|prescaler|ALT_INV_ms_count\(12) <= NOT \timers:1:channel|prescaler|ms_count\(12);
\timers:1:channel|prescaler|ALT_INV_ms_count\(0) <= NOT \timers:1:channel|prescaler|ms_count\(0);
\timers:1:channel|prescaler|ALT_INV_ms_count\(9) <= NOT \timers:1:channel|prescaler|ms_count\(9);
\timers:3:channel|prescaler|ALT_INV_ms_count\(13) <= NOT \timers:3:channel|prescaler|ms_count\(13);
\timers:3:channel|prescaler|ALT_INV_ms_count\(11) <= NOT \timers:3:channel|prescaler|ms_count\(11);
\timers:3:channel|prescaler|ALT_INV_ms_count\(4) <= NOT \timers:3:channel|prescaler|ms_count\(4);
\timers:1:channel|prescaler|ALT_INV_ms_count\(6) <= NOT \timers:1:channel|prescaler|ms_count\(6);
\timers:1:channel|prescaler|ALT_INV_ms_count\(3) <= NOT \timers:1:channel|prescaler|ms_count\(3);
\timers:0:channel|prescaler|ALT_INV_ms_count\(13) <= NOT \timers:0:channel|prescaler|ms_count\(13);
\timers:2:channel|prescaler|ALT_INV_ms_count\(5) <= NOT \timers:2:channel|prescaler|ms_count\(5);
\timers:0:channel|prescaler|ALT_INV_ms_count\(8) <= NOT \timers:0:channel|prescaler|ms_count\(8);
\timers:0:channel|prescaler|ALT_INV_ms_count\(0) <= NOT \timers:0:channel|prescaler|ms_count\(0);
\timers:0:channel|prescaler|ALT_INV_ms_count\(5) <= NOT \timers:0:channel|prescaler|ms_count\(5);
\timers:1:channel|prescaler|ALT_INV_ms_count\(10) <= NOT \timers:1:channel|prescaler|ms_count\(10);
\timers:1:channel|prescaler|ALT_INV_ms_count\(1) <= NOT \timers:1:channel|prescaler|ms_count\(1);
\timers:3:channel|prescaler|ALT_INV_ms_count\(15) <= NOT \timers:3:channel|prescaler|ms_count\(15);
\timers:3:channel|prescaler|ALT_INV_ms_count\(10) <= NOT \timers:3:channel|prescaler|ms_count\(10);
\timers:3:channel|prescaler|ALT_INV_ms_count\(3) <= NOT \timers:3:channel|prescaler|ms_count\(3);
\timers:3:channel|prescaler|ALT_INV_ms_count\(1) <= NOT \timers:3:channel|prescaler|ms_count\(1);
\timers:3:channel|prescaler|ALT_INV_ms_count\(6) <= NOT \timers:3:channel|prescaler|ms_count\(6);
\ALT_INV_read_value[0]~0_combout\ <= NOT \read_value[0]~0_combout\;
\timers:3:channel|prescaler|ALT_INV_ms_count\(9) <= NOT \timers:3:channel|prescaler|ms_count\(9);
\ALT_INV_read_value[0]~3_combout\ <= NOT \read_value[0]~3_combout\;
\ALT_INV_read_value[13]~42_combout\ <= NOT \read_value[13]~42_combout\;
\timers:2:channel|ALT_INV_LessThan0~10_combout\ <= NOT \timers:2:channel|LessThan0~10_combout\;
\timers:2:channel|ALT_INV_mode_r\(1) <= NOT \timers:2:channel|mode_r\(1);
\timers:2:channel|ALT_INV_LessThan0~11_combout\ <= NOT \timers:2:channel|LessThan0~11_combout\;
\ALT_INV_read_value[7]~23_combout\ <= NOT \read_value[7]~23_combout\;
\ALT_INV_read_value[11]~35_combout\ <= NOT \read_value[11]~35_combout\;
\ALT_INV_read_value[8]~27_combout\ <= NOT \read_value[8]~27_combout\;
\ALT_INV_read_value[12]~39_combout\ <= NOT \read_value[12]~39_combout\;
\ALT_INV_read_value[9]~29_combout\ <= NOT \read_value[9]~29_combout\;
\ALT_INV_read_value[15]~48_combout\ <= NOT \read_value[15]~48_combout\;
\ALT_INV_Equal11~0_combout\ <= NOT \Equal11~0_combout\;
\timers:2:channel|ALT_INV_LessThan0~2_combout\ <= NOT \timers:2:channel|LessThan0~2_combout\;
\timers:0:channel|ALT_INV_periods_r~0_combout\ <= NOT \timers:0:channel|periods_r~0_combout\;
\timers:2:channel|ALT_INV_LessThan0~9_combout\ <= NOT \timers:2:channel|LessThan0~9_combout\;
\timers:2:channel|ALT_INV_LessThan0~12_combout\ <= NOT \timers:2:channel|LessThan0~12_combout\;
\timers:2:channel|ALT_INV_LessThan0~14_combout\ <= NOT \timers:2:channel|LessThan0~14_combout\;
\ALT_INV_read_value[3]~12_combout\ <= NOT \read_value[3]~12_combout\;
\ALT_INV_read_value[8]~26_combout\ <= NOT \read_value[8]~26_combout\;
\ALT_INV_read_value[2]~9_combout\ <= NOT \read_value[2]~9_combout\;
\ALT_INV_read_value[12]~38_combout\ <= NOT \read_value[12]~38_combout\;
\ALT_INV_Equal11~1_combout\ <= NOT \Equal11~1_combout\;
\timers:2:channel|ALT_INV_LessThan0~3_combout\ <= NOT \timers:2:channel|LessThan0~3_combout\;
\timers:2:channel|ALT_INV_LessThan0~8_combout\ <= NOT \timers:2:channel|LessThan0~8_combout\;
\timers:2:channel|ALT_INV_LessThan0~13_combout\ <= NOT \timers:2:channel|LessThan0~13_combout\;
\ALT_INV_read_value[14]~45_combout\ <= NOT \read_value[14]~45_combout\;
\timers:2:channel|ALT_INV_LessThan0~15_combout\ <= NOT \timers:2:channel|LessThan0~15_combout\;
\timers:2:channel|ALT_INV_LessThan0~5_combout\ <= NOT \timers:2:channel|LessThan0~5_combout\;
\ALT_INV_read_value[5]~18_combout\ <= NOT \read_value[5]~18_combout\;
\ALT_INV_read_value[4]~14_combout\ <= NOT \read_value[4]~14_combout\;
\ALT_INV_read_value[7]~24_combout\ <= NOT \read_value[7]~24_combout\;
\ALT_INV_read_value[9]~30_combout\ <= NOT \read_value[9]~30_combout\;
\ALT_INV_read_value[6]~20_combout\ <= NOT \read_value[6]~20_combout\;
\ALT_INV_read_value[5]~17_combout\ <= NOT \read_value[5]~17_combout\;
\ALT_INV_read_value[10]~32_combout\ <= NOT \read_value[10]~32_combout\;
\ALT_INV_read_value[11]~36_combout\ <= NOT \read_value[11]~36_combout\;
\ALT_INV_read_value[13]~41_combout\ <= NOT \read_value[13]~41_combout\;
\ALT_INV_read_value[14]~44_combout\ <= NOT \read_value[14]~44_combout\;
\ALT_INV_read_value[15]~47_combout\ <= NOT \read_value[15]~47_combout\;
\ALT_INV_read_value[4]~15_combout\ <= NOT \read_value[4]~15_combout\;
\timers:2:channel|ALT_INV_running_r~q\ <= NOT \timers:2:channel|running_r~q\;
\timers:2:channel|ALT_INV_LessThan0~0_combout\ <= NOT \timers:2:channel|LessThan0~0_combout\;
\ALT_INV_read_value[3]~11_combout\ <= NOT \read_value[3]~11_combout\;
\ALT_INV_read_value[6]~21_combout\ <= NOT \read_value[6]~21_combout\;
\ALT_INV_read_value[10]~33_combout\ <= NOT \read_value[10]~33_combout\;
\timers:2:channel|ALT_INV_LessThan0~1_combout\ <= NOT \timers:2:channel|LessThan0~1_combout\;
\timers:2:channel|ALT_INV_LessThan0~4_combout\ <= NOT \timers:2:channel|LessThan0~4_combout\;
\timers:2:channel|ALT_INV_LessThan0~6_combout\ <= NOT \timers:2:channel|LessThan0~6_combout\;
\timers:2:channel|ALT_INV_LessThan0~7_combout\ <= NOT \timers:2:channel|LessThan0~7_combout\;
\timers:0:channel|ALT_INV_LessThan0~15_combout\ <= NOT \timers:0:channel|LessThan0~15_combout\;
\timers:1:channel|ALT_INV_LessThan0~6_combout\ <= NOT \timers:1:channel|LessThan0~6_combout\;
\timers:0:channel|ALT_INV_mode_r\(1) <= NOT \timers:0:channel|mode_r\(1);
\timers:0:channel|ALT_INV_elapsed_r[2]~2_combout\ <= NOT \timers:0:channel|elapsed_r[2]~2_combout\;
\timers:1:channel|ALT_INV_LessThan0~12_combout\ <= NOT \timers:1:channel|LessThan0~12_combout\;
\timers:2:channel|ALT_INV_LessThan0~16_combout\ <= NOT \timers:2:channel|LessThan0~16_combout\;
\timers:0:channel|ALT_INV_LessThan0~6_combout\ <= NOT \timers:0:channel|LessThan0~6_combout\;
\timers:0:channel|ALT_INV_LessThan0~10_combout\ <= NOT \timers:0:channel|LessThan0~10_combout\;
\timers:0:channel|ALT_INV_LessThan0~11_combout\ <= NOT \timers:0:channel|LessThan0~11_combout\;
\timers:1:channel|ALT_INV_mode_r\(1) <= NOT \timers:1:channel|mode_r\(1);
\timers:1:channel|ALT_INV_LessThan0~13_combout\ <= NOT \timers:1:channel|LessThan0~13_combout\;
\timers:2:channel|prescaler|ALT_INV_TICK~q\ <= NOT \timers:2:channel|prescaler|TICK~q\;
\timers:0:channel|ALT_INV_LessThan0~7_combout\ <= NOT \timers:0:channel|LessThan0~7_combout\;
\timers:0:channel|ALT_INV_LessThan0~2_combout\ <= NOT \timers:0:channel|LessThan0~2_combout\;
\timers:0:channel|ALT_INV_LessThan0~14_combout\ <= NOT \timers:0:channel|LessThan0~14_combout\;
\timers:1:channel|ALT_INV_LessThan0~5_combout\ <= NOT \timers:1:channel|LessThan0~5_combout\;
\timers:0:channel|ALT_INV_LessThan0~17_combout\ <= NOT \timers:0:channel|LessThan0~17_combout\;
\timers:0:channel|prescaler|ALT_INV_TICK~q\ <= NOT \timers:0:channel|prescaler|TICK~q\;
\timers:0:channel|ALT_INV_LessThan0~5_combout\ <= NOT \timers:0:channel|LessThan0~5_combout\;
\timers:0:channel|ALT_INV_LessThan0~9_combout\ <= NOT \timers:0:channel|LessThan0~9_combout\;
\timers:0:channel|ALT_INV_LessThan0~4_combout\ <= NOT \timers:0:channel|LessThan0~4_combout\;
ALT_INV_write_hit(0) <= NOT write_hit(0);
\timers:1:channel|ALT_INV_LessThan0~1_combout\ <= NOT \timers:1:channel|LessThan0~1_combout\;
\timers:0:channel|ALT_INV_LessThan0~3_combout\ <= NOT \timers:0:channel|LessThan0~3_combout\;
\timers:1:channel|ALT_INV_running_r~q\ <= NOT \timers:1:channel|running_r~q\;
\timers:1:channel|ALT_INV_LessThan0~2_combout\ <= NOT \timers:1:channel|LessThan0~2_combout\;
\timers:1:channel|ALT_INV_LessThan0~10_combout\ <= NOT \timers:1:channel|LessThan0~10_combout\;
\timers:0:channel|ALT_INV_LessThan0~13_combout\ <= NOT \timers:0:channel|LessThan0~13_combout\;
\timers:0:channel|ALT_INV_mode_r\(0) <= NOT \timers:0:channel|mode_r\(0);
\timers:0:channel|ALT_INV_LessThan0~0_combout\ <= NOT \timers:0:channel|LessThan0~0_combout\;
\timers:0:channel|ALT_INV_LessThan0~12_combout\ <= NOT \timers:0:channel|LessThan0~12_combout\;
\timers:1:channel|ALT_INV_duration_r\(0) <= NOT \timers:1:channel|duration_r\(0);
\timers:1:channel|ALT_INV_LessThan0~3_combout\ <= NOT \timers:1:channel|LessThan0~3_combout\;
\timers:1:channel|ALT_INV_LessThan0~4_combout\ <= NOT \timers:1:channel|LessThan0~4_combout\;
\timers:1:channel|ALT_INV_LessThan0~8_combout\ <= NOT \timers:1:channel|LessThan0~8_combout\;
\timers:1:channel|ALT_INV_LessThan0~9_combout\ <= NOT \timers:1:channel|LessThan0~9_combout\;
\timers:0:channel|ALT_INV_LessThan0~8_combout\ <= NOT \timers:0:channel|LessThan0~8_combout\;
\timers:1:channel|ALT_INV_LessThan0~11_combout\ <= NOT \timers:1:channel|LessThan0~11_combout\;
\timers:1:channel|ALT_INV_LessThan0~15_combout\ <= NOT \timers:1:channel|LessThan0~15_combout\;
\timers:1:channel|ALT_INV_LessThan0~16_combout\ <= NOT \timers:1:channel|LessThan0~16_combout\;
\timers:1:channel|ALT_INV_LessThan0~0_combout\ <= NOT \timers:1:channel|LessThan0~0_combout\;
\timers:0:channel|ALT_INV_LessThan0~18_combout\ <= NOT \timers:0:channel|LessThan0~18_combout\;
\timers:0:channel|ALT_INV_duration_r\(0) <= NOT \timers:0:channel|duration_r\(0);
\timers:1:channel|ALT_INV_LessThan0~7_combout\ <= NOT \timers:1:channel|LessThan0~7_combout\;
\timers:1:channel|ALT_INV_LessThan0~14_combout\ <= NOT \timers:1:channel|LessThan0~14_combout\;
\timers:0:channel|ALT_INV_LessThan0~16_combout\ <= NOT \timers:0:channel|LessThan0~16_combout\;
\timers:0:channel|ALT_INV_LessThan0~1_combout\ <= NOT \timers:0:channel|LessThan0~1_combout\;
\ALT_INV_Equal11~2_combout\ <= NOT \Equal11~2_combout\;
\timers:1:channel|ALT_INV_LessThan0~17_combout\ <= NOT \timers:1:channel|LessThan0~17_combout\;
\timers:0:channel|ALT_INV_periods_r~1_combout\ <= NOT \timers:0:channel|periods_r~1_combout\;
\timers:0:channel|ALT_INV_running_r~q\ <= NOT \timers:0:channel|running_r~q\;
\timers:1:channel|ALT_INV_mode_r\(0) <= NOT \timers:1:channel|mode_r\(0);
\timers:1:channel|ALT_INV_LessThan0~18_combout\ <= NOT \timers:1:channel|LessThan0~18_combout\;
\timers:2:channel|ALT_INV_duration_r\(1) <= NOT \timers:2:channel|duration_r\(1);
\ALT_INV_Equal11~3_combout\ <= NOT \Equal11~3_combout\;
\timers:3:channel|ALT_INV_duration_r\(1) <= NOT \timers:3:channel|duration_r\(1);
\timers:3:channel|ALT_INV_LessThan0~14_combout\ <= NOT \timers:3:channel|LessThan0~14_combout\;
\timers:0:channel|ALT_INV_duration_r\(3) <= NOT \timers:0:channel|duration_r\(3);
\ALT_INV_Equal11~4_combout\ <= NOT \Equal11~4_combout\;
\timers:2:channel|ALT_INV_duration_r\(3) <= NOT \timers:2:channel|duration_r\(3);
\timers:3:channel|ALT_INV_LessThan0~15_combout\ <= NOT \timers:3:channel|LessThan0~15_combout\;
\timers:3:channel|ALT_INV_LessThan0~17_combout\ <= NOT \timers:3:channel|LessThan0~17_combout\;
\timers:3:channel|ALT_INV_LessThan0~7_combout\ <= NOT \timers:3:channel|LessThan0~7_combout\;
\timers:3:channel|ALT_INV_duration_r\(3) <= NOT \timers:3:channel|duration_r\(3);
\timers:3:channel|ALT_INV_mode_r\(1) <= NOT \timers:3:channel|mode_r\(1);
\timers:3:channel|ALT_INV_LessThan0~5_combout\ <= NOT \timers:3:channel|LessThan0~5_combout\;
\timers:3:channel|ALT_INV_LessThan0~4_combout\ <= NOT \timers:3:channel|LessThan0~4_combout\;
\timers:3:channel|ALT_INV_LessThan0~9_combout\ <= NOT \timers:3:channel|LessThan0~9_combout\;
\timers:3:channel|ALT_INV_LessThan0~11_combout\ <= NOT \timers:3:channel|LessThan0~11_combout\;
\timers:3:channel|ALT_INV_LessThan0~13_combout\ <= NOT \timers:3:channel|LessThan0~13_combout\;
\timers:3:channel|ALT_INV_LessThan0~16_combout\ <= NOT \timers:3:channel|LessThan0~16_combout\;
\timers:3:channel|ALT_INV_running_r~q\ <= NOT \timers:3:channel|running_r~q\;
\timers:3:channel|ALT_INV_LessThan0~10_combout\ <= NOT \timers:3:channel|LessThan0~10_combout\;
\timers:3:channel|ALT_INV_LessThan0~18_combout\ <= NOT \timers:3:channel|LessThan0~18_combout\;
\timers:3:channel|ALT_INV_elapsed_r[9]~2_combout\ <= NOT \timers:3:channel|elapsed_r[9]~2_combout\;
\timers:0:channel|ALT_INV_duration_r\(1) <= NOT \timers:0:channel|duration_r\(1);
\timers:1:channel|ALT_INV_duration_r\(2) <= NOT \timers:1:channel|duration_r\(2);
\timers:3:channel|ALT_INV_duration_r\(2) <= NOT \timers:3:channel|duration_r\(2);
\timers:2:channel|ALT_INV_LessThan0~17_combout\ <= NOT \timers:2:channel|LessThan0~17_combout\;
\timers:1:channel|ALT_INV_duration_r\(3) <= NOT \timers:1:channel|duration_r\(3);
\timers:0:channel|ALT_INV_duration_r\(4) <= NOT \timers:0:channel|duration_r\(4);
\timers:2:channel|ALT_INV_duration_r\(2) <= NOT \timers:2:channel|duration_r\(2);
\timers:0:channel|ALT_INV_duration_r\(2) <= NOT \timers:0:channel|duration_r\(2);
\timers:1:channel|ALT_INV_duration_r\(4) <= NOT \timers:1:channel|duration_r\(4);
\timers:3:channel|ALT_INV_duration_r\(0) <= NOT \timers:3:channel|duration_r\(0);
\timers:3:channel|ALT_INV_mode_r\(0) <= NOT \timers:3:channel|mode_r\(0);
\timers:3:channel|ALT_INV_LessThan0~0_combout\ <= NOT \timers:3:channel|LessThan0~0_combout\;
\timers:3:channel|ALT_INV_LessThan0~1_combout\ <= NOT \timers:3:channel|LessThan0~1_combout\;
\timers:3:channel|ALT_INV_LessThan0~6_combout\ <= NOT \timers:3:channel|LessThan0~6_combout\;
\timers:2:channel|ALT_INV_LessThan0~18_combout\ <= NOT \timers:2:channel|LessThan0~18_combout\;
\timers:3:channel|ALT_INV_LessThan0~12_combout\ <= NOT \timers:3:channel|LessThan0~12_combout\;
\timers:3:channel|ALT_INV_LessThan0~3_combout\ <= NOT \timers:3:channel|LessThan0~3_combout\;
\timers:2:channel|ALT_INV_duration_r\(0) <= NOT \timers:2:channel|duration_r\(0);
\timers:2:channel|ALT_INV_elapsed_r[6]~3_combout\ <= NOT \timers:2:channel|elapsed_r[6]~3_combout\;
\timers:3:channel|ALT_INV_LessThan0~8_combout\ <= NOT \timers:3:channel|LessThan0~8_combout\;
\timers:3:channel|prescaler|ALT_INV_TICK~q\ <= NOT \timers:3:channel|prescaler|TICK~q\;
\timers:3:channel|ALT_INV_LessThan0~2_combout\ <= NOT \timers:3:channel|LessThan0~2_combout\;
\timers:2:channel|ALT_INV_mode_r\(0) <= NOT \timers:2:channel|mode_r\(0);
\timers:1:channel|prescaler|ALT_INV_TICK~q\ <= NOT \timers:1:channel|prescaler|TICK~q\;
\timers:1:channel|ALT_INV_elapsed_r[14]~2_combout\ <= NOT \timers:1:channel|elapsed_r[14]~2_combout\;
\timers:1:channel|ALT_INV_duration_r\(1) <= NOT \timers:1:channel|duration_r\(1);
\timers:2:channel|ALT_INV_duration_r\(15) <= NOT \timers:2:channel|duration_r\(15);
\timers:0:channel|ALT_INV_duration_r\(7) <= NOT \timers:0:channel|duration_r\(7);
\timers:0:channel|ALT_INV_duration_r\(8) <= NOT \timers:0:channel|duration_r\(8);
\timers:0:channel|ALT_INV_duration_r\(9) <= NOT \timers:0:channel|duration_r\(9);
\timers:0:channel|ALT_INV_duration_r\(5) <= NOT \timers:0:channel|duration_r\(5);
\timers:1:channel|ALT_INV_duration_r\(9) <= NOT \timers:1:channel|duration_r\(9);
\timers:1:channel|ALT_INV_duration_r\(5) <= NOT \timers:1:channel|duration_r\(5);
\timers:2:channel|ALT_INV_duration_r\(9) <= NOT \timers:2:channel|duration_r\(9);
\timers:0:channel|ALT_INV_duration_r\(11) <= NOT \timers:0:channel|duration_r\(11);
\timers:3:channel|ALT_INV_duration_r\(10) <= NOT \timers:3:channel|duration_r\(10);
\timers:1:channel|ALT_INV_duration_r\(10) <= NOT \timers:1:channel|duration_r\(10);
\timers:0:channel|ALT_INV_duration_r\(12) <= NOT \timers:0:channel|duration_r\(12);
\timers:0:channel|ALT_INV_duration_r\(13) <= NOT \timers:0:channel|duration_r\(13);
\timers:1:channel|ALT_INV_duration_r\(13) <= NOT \timers:1:channel|duration_r\(13);
\timers:0:channel|ALT_INV_duration_r\(14) <= NOT \timers:0:channel|duration_r\(14);
\timers:2:channel|ALT_INV_timescale_r\(11) <= NOT \timers:2:channel|timescale_r\(11);
\timers:2:channel|ALT_INV_timescale_r\(13) <= NOT \timers:2:channel|timescale_r\(13);
\timers:2:channel|ALT_INV_duration_r\(13) <= NOT \timers:2:channel|duration_r\(13);
\timers:2:channel|ALT_INV_duration_r\(12) <= NOT \timers:2:channel|duration_r\(12);
\timers:3:channel|ALT_INV_duration_r\(5) <= NOT \timers:3:channel|duration_r\(5);
\timers:3:channel|ALT_INV_duration_r\(8) <= NOT \timers:3:channel|duration_r\(8);
\timers:2:channel|ALT_INV_timescale_r\(12) <= NOT \timers:2:channel|timescale_r\(12);
\timers:2:channel|prescaler|ALT_INV_LessThan1~0_combout\ <= NOT \timers:2:channel|prescaler|LessThan1~0_combout\;
\timers:2:channel|ALT_INV_timescale_r\(10) <= NOT \timers:2:channel|timescale_r\(10);
\timers:2:channel|prescaler|ALT_INV_LessThan1~1_combout\ <= NOT \timers:2:channel|prescaler|LessThan1~1_combout\;
\timers:1:channel|ALT_INV_duration_r\(15) <= NOT \timers:1:channel|duration_r\(15);
\timers:3:channel|ALT_INV_duration_r\(11) <= NOT \timers:3:channel|duration_r\(11);
\timers:3:channel|ALT_INV_duration_r\(14) <= NOT \timers:3:channel|duration_r\(14);
\timers:2:channel|prescaler|ALT_INV_LessThan1~2_combout\ <= NOT \timers:2:channel|prescaler|LessThan1~2_combout\;
\timers:2:channel|ALT_INV_duration_r\(10) <= NOT \timers:2:channel|duration_r\(10);
\timers:2:channel|prescaler|ALT_INV_LessThan1~3_combout\ <= NOT \timers:2:channel|prescaler|LessThan1~3_combout\;
\timers:2:channel|prescaler|ALT_INV_LessThan1~4_combout\ <= NOT \timers:2:channel|prescaler|LessThan1~4_combout\;
\timers:2:channel|ALT_INV_timescale_r\(8) <= NOT \timers:2:channel|timescale_r\(8);
\timers:1:channel|ALT_INV_duration_r\(7) <= NOT \timers:1:channel|duration_r\(7);
\timers:1:channel|ALT_INV_duration_r\(12) <= NOT \timers:1:channel|duration_r\(12);
\timers:1:channel|ALT_INV_duration_r\(14) <= NOT \timers:1:channel|duration_r\(14);
\timers:3:channel|ALT_INV_duration_r\(6) <= NOT \timers:3:channel|duration_r\(6);
\timers:0:channel|ALT_INV_duration_r\(6) <= NOT \timers:0:channel|duration_r\(6);
\timers:2:channel|ALT_INV_duration_r\(7) <= NOT \timers:2:channel|duration_r\(7);
\timers:2:channel|ALT_INV_duration_r\(5) <= NOT \timers:2:channel|duration_r\(5);
\timers:2:channel|ALT_INV_duration_r\(14) <= NOT \timers:2:channel|duration_r\(14);
\timers:3:channel|ALT_INV_duration_r\(4) <= NOT \timers:3:channel|duration_r\(4);
\timers:2:channel|ALT_INV_running_r~0_combout\ <= NOT \timers:2:channel|running_r~0_combout\;
\timers:2:channel|ALT_INV_duration_r\(4) <= NOT \timers:2:channel|duration_r\(4);
\timers:3:channel|ALT_INV_duration_r\(12) <= NOT \timers:3:channel|duration_r\(12);
\timers:1:channel|ALT_INV_duration_r\(6) <= NOT \timers:1:channel|duration_r\(6);
\timers:3:channel|ALT_INV_duration_r\(7) <= NOT \timers:3:channel|duration_r\(7);
\timers:3:channel|ALT_INV_duration_r\(9) <= NOT \timers:3:channel|duration_r\(9);
\timers:1:channel|ALT_INV_duration_r\(11) <= NOT \timers:1:channel|duration_r\(11);
\timers:0:channel|ALT_INV_duration_r\(10) <= NOT \timers:0:channel|duration_r\(10);
\timers:3:channel|ALT_INV_duration_r\(15) <= NOT \timers:3:channel|duration_r\(15);
\timers:0:channel|ALT_INV_duration_r\(15) <= NOT \timers:0:channel|duration_r\(15);
\timers:3:channel|ALT_INV_duration_r\(13) <= NOT \timers:3:channel|duration_r\(13);
\timers:2:channel|ALT_INV_timescale_r\(15) <= NOT \timers:2:channel|timescale_r\(15);
\timers:2:channel|ALT_INV_timescale_r\(14) <= NOT \timers:2:channel|timescale_r\(14);
\timers:2:channel|ALT_INV_duration_r\(6) <= NOT \timers:2:channel|duration_r\(6);
\timers:2:channel|ALT_INV_duration_r\(11) <= NOT \timers:2:channel|duration_r\(11);
\timers:0:channel|ALT_INV_Mux33~0_combout\ <= NOT \timers:0:channel|Mux33~0_combout\;
\timers:0:channel|ALT_INV_process_0~0_combout\ <= NOT \timers:0:channel|process_0~0_combout\;
\timers:1:channel|ALT_INV_duration_r\(8) <= NOT \timers:1:channel|duration_r\(8);
\timers:2:channel|ALT_INV_duration_r\(8) <= NOT \timers:2:channel|duration_r\(8);
\timers:0:channel|ALT_INV_timescale_r\(7) <= NOT \timers:0:channel|timescale_r\(7);
\timers:0:channel|ALT_INV_running_r~0_combout\ <= NOT \timers:0:channel|running_r~0_combout\;
\timers:0:channel|ALT_INV_timescale_r\(13) <= NOT \timers:0:channel|timescale_r\(13);
\timers:2:channel|prescaler|ALT_INV_TICK~0_combout\ <= NOT \timers:2:channel|prescaler|TICK~0_combout\;
\timers:2:channel|prescaler|ALT_INV_LessThan1~9_combout\ <= NOT \timers:2:channel|prescaler|LessThan1~9_combout\;
\timers:0:channel|ALT_INV_Equal1~1_combout\ <= NOT \timers:0:channel|Equal1~1_combout\;
\timers:0:channel|ALT_INV_timescale_r\(12) <= NOT \timers:0:channel|timescale_r\(12);
\timers:2:channel|prescaler|ALT_INV_LessThan1~7_combout\ <= NOT \timers:2:channel|prescaler|LessThan1~7_combout\;
\timers:2:channel|prescaler|ALT_INV_LessThan1~14_combout\ <= NOT \timers:2:channel|prescaler|LessThan1~14_combout\;
\timers:2:channel|prescaler|ALT_INV_LessThan0~0_combout\ <= NOT \timers:2:channel|prescaler|LessThan0~0_combout\;
\timers:0:channel|ALT_INV_Equal1~0_combout\ <= NOT \timers:0:channel|Equal1~0_combout\;
\timers:0:channel|ALT_INV_timescale_r\(10) <= NOT \timers:0:channel|timescale_r\(10);
\timers:2:channel|ALT_INV_timescale_r\(9) <= NOT \timers:2:channel|timescale_r\(9);
\timers:2:channel|ALT_INV_timescale_r\(1) <= NOT \timers:2:channel|timescale_r\(1);
\timers:0:channel|prescaler|ALT_INV_LessThan1~5_combout\ <= NOT \timers:0:channel|prescaler|LessThan1~5_combout\;
\timers:0:channel|prescaler|ALT_INV_LessThan1~7_combout\ <= NOT \timers:0:channel|prescaler|LessThan1~7_combout\;
\timers:2:channel|prescaler|ALT_INV_LessThan1~5_combout\ <= NOT \timers:2:channel|prescaler|LessThan1~5_combout\;
\timers:2:channel|ALT_INV_timescale_r\(5) <= NOT \timers:2:channel|timescale_r\(5);
\timers:2:channel|prescaler|ALT_INV_cycle_count\(3) <= NOT \timers:2:channel|prescaler|cycle_count\(3);
\timers:2:channel|ALT_INV_timescale_r\(7) <= NOT \timers:2:channel|timescale_r\(7);
\timers:2:channel|ALT_INV_timescale_r\(4) <= NOT \timers:2:channel|timescale_r\(4);
\timers:2:channel|prescaler|ALT_INV_LessThan1~8_combout\ <= NOT \timers:2:channel|prescaler|LessThan1~8_combout\;
\timers:2:channel|prescaler|ALT_INV_cycle_count\(2) <= NOT \timers:2:channel|prescaler|cycle_count\(2);
\timers:0:channel|ALT_INV_process_0~1_combout\ <= NOT \timers:0:channel|process_0~1_combout\;
\timers:0:channel|ALT_INV_timescale_r\(15) <= NOT \timers:0:channel|timescale_r\(15);
\timers:0:channel|prescaler|ALT_INV_LessThan1~3_combout\ <= NOT \timers:0:channel|prescaler|LessThan1~3_combout\;
\timers:0:channel|prescaler|ALT_INV_LessThan1~9_combout\ <= NOT \timers:0:channel|prescaler|LessThan1~9_combout\;
\timers:0:channel|ALT_INV_timescale_r\(6) <= NOT \timers:0:channel|timescale_r\(6);
\timers:0:channel|ALT_INV_timescale_r\(5) <= NOT \timers:0:channel|timescale_r\(5);
\timers:2:channel|prescaler|ALT_INV_LessThan1~12_combout\ <= NOT \timers:2:channel|prescaler|LessThan1~12_combout\;
\timers:2:channel|prescaler|ALT_INV_LessThan1~6_combout\ <= NOT \timers:2:channel|prescaler|LessThan1~6_combout\;
\timers:2:channel|prescaler|ALT_INV_cycle_count\(0) <= NOT \timers:2:channel|prescaler|cycle_count\(0);
\timers:0:channel|ALT_INV_timescale_r\(2) <= NOT \timers:0:channel|timescale_r\(2);
\timers:2:channel|ALT_INV_timescale_r\(2) <= NOT \timers:2:channel|timescale_r\(2);
\timers:0:channel|prescaler|ALT_INV_LessThan1~6_combout\ <= NOT \timers:0:channel|prescaler|LessThan1~6_combout\;
\timers:0:channel|ALT_INV_Equal1~2_combout\ <= NOT \timers:0:channel|Equal1~2_combout\;
\timers:0:channel|ALT_INV_timescale_r\(1) <= NOT \timers:0:channel|timescale_r\(1);
\timers:2:channel|prescaler|ALT_INV_LessThan1~10_combout\ <= NOT \timers:2:channel|prescaler|LessThan1~10_combout\;
\timers:2:channel|ALT_INV_timescale_r\(6) <= NOT \timers:2:channel|timescale_r\(6);
\timers:2:channel|prescaler|ALT_INV_LessThan1~11_combout\ <= NOT \timers:2:channel|prescaler|LessThan1~11_combout\;
\timers:0:channel|ALT_INV_timescale_r\(14) <= NOT \timers:0:channel|timescale_r\(14);
\timers:2:channel|prescaler|ALT_INV_LessThan1~15_combout\ <= NOT \timers:2:channel|prescaler|LessThan1~15_combout\;
\timers:2:channel|prescaler|ALT_INV_cycle_count\(1) <= NOT \timers:2:channel|prescaler|cycle_count\(1);
\timers:2:channel|ALT_INV_timescale_r\(0) <= NOT \timers:2:channel|timescale_r\(0);
\timers:0:channel|prescaler|ALT_INV_LessThan1~1_combout\ <= NOT \timers:0:channel|prescaler|LessThan1~1_combout\;
\timers:2:channel|ALT_INV_clear_prescale~q\ <= NOT \timers:2:channel|clear_prescale~q\;
\timers:0:channel|prescaler|ALT_INV_LessThan1~2_combout\ <= NOT \timers:0:channel|prescaler|LessThan1~2_combout\;
\timers:2:channel|prescaler|ALT_INV_LessThan1~13_combout\ <= NOT \timers:2:channel|prescaler|LessThan1~13_combout\;
\timers:0:channel|ALT_INV_timescale_r\(4) <= NOT \timers:0:channel|timescale_r\(4);
\timers:0:channel|ALT_INV_timescale_r\(3) <= NOT \timers:0:channel|timescale_r\(3);
\timers:0:channel|prescaler|ALT_INV_LessThan1~0_combout\ <= NOT \timers:0:channel|prescaler|LessThan1~0_combout\;
\timers:0:channel|prescaler|ALT_INV_LessThan1~4_combout\ <= NOT \timers:0:channel|prescaler|LessThan1~4_combout\;
\timers:0:channel|ALT_INV_timescale_r\(8) <= NOT \timers:0:channel|timescale_r\(8);
\timers:0:channel|ALT_INV_timescale_r\(0) <= NOT \timers:0:channel|timescale_r\(0);
\timers:0:channel|prescaler|ALT_INV_LessThan1~8_combout\ <= NOT \timers:0:channel|prescaler|LessThan1~8_combout\;
\timers:0:channel|ALT_INV_timescale_r\(9) <= NOT \timers:0:channel|timescale_r\(9);
\timers:2:channel|ALT_INV_timescale_r\(3) <= NOT \timers:2:channel|timescale_r\(3);
\timers:0:channel|ALT_INV_timescale_r\(11) <= NOT \timers:0:channel|timescale_r\(11);
\timers:1:channel|prescaler|ALT_INV_LessThan1~8_combout\ <= NOT \timers:1:channel|prescaler|LessThan1~8_combout\;
\timers:1:channel|ALT_INV_timescale_r\(8) <= NOT \timers:1:channel|timescale_r\(8);
\timers:1:channel|ALT_INV_timescale_r\(7) <= NOT \timers:1:channel|timescale_r\(7);
\timers:1:channel|prescaler|ALT_INV_LessThan1~11_combout\ <= NOT \timers:1:channel|prescaler|LessThan1~11_combout\;
\timers:1:channel|prescaler|ALT_INV_LessThan1~12_combout\ <= NOT \timers:1:channel|prescaler|LessThan1~12_combout\;
\timers:1:channel|ALT_INV_timescale_r\(3) <= NOT \timers:1:channel|timescale_r\(3);
\timers:1:channel|prescaler|ALT_INV_LessThan1~13_combout\ <= NOT \timers:1:channel|prescaler|LessThan1~13_combout\;
\timers:1:channel|prescaler|ALT_INV_LessThan1~15_combout\ <= NOT \timers:1:channel|prescaler|LessThan1~15_combout\;
\timers:0:channel|prescaler|ALT_INV_cycle_count\(2) <= NOT \timers:0:channel|prescaler|cycle_count\(2);
\timers:0:channel|prescaler|ALT_INV_cycle_count\(0) <= NOT \timers:0:channel|prescaler|cycle_count\(0);
\timers:1:channel|prescaler|ALT_INV_LessThan1~6_combout\ <= NOT \timers:1:channel|prescaler|LessThan1~6_combout\;
\timers:1:channel|ALT_INV_clear_prescale~q\ <= NOT \timers:1:channel|clear_prescale~q\;
\timers:1:channel|prescaler|ALT_INV_cycle_count\(3) <= NOT \timers:1:channel|prescaler|cycle_count\(3);
\timers:0:channel|prescaler|ALT_INV_LessThan1~15_combout\ <= NOT \timers:0:channel|prescaler|LessThan1~15_combout\;
\timers:0:channel|prescaler|ALT_INV_LessThan0~0_combout\ <= NOT \timers:0:channel|prescaler|LessThan0~0_combout\;
\timers:1:channel|ALT_INV_timescale_r\(10) <= NOT \timers:1:channel|timescale_r\(10);
\timers:1:channel|ALT_INV_timescale_r\(13) <= NOT \timers:1:channel|timescale_r\(13);
\timers:1:channel|ALT_INV_timescale_r\(5) <= NOT \timers:1:channel|timescale_r\(5);
\timers:1:channel|ALT_INV_timescale_r\(15) <= NOT \timers:1:channel|timescale_r\(15);
\timers:1:channel|prescaler|ALT_INV_cycle_count\(2) <= NOT \timers:1:channel|prescaler|cycle_count\(2);
\timers:1:channel|ALT_INV_timescale_r\(6) <= NOT \timers:1:channel|timescale_r\(6);
\timers:0:channel|prescaler|ALT_INV_cycle_count\(1) <= NOT \timers:0:channel|prescaler|cycle_count\(1);
\timers:0:channel|ALT_INV_clear_prescale~q\ <= NOT \timers:0:channel|clear_prescale~q\;
\timers:1:channel|prescaler|ALT_INV_cycle_count\(1) <= NOT \timers:1:channel|prescaler|cycle_count\(1);
\timers:1:channel|prescaler|ALT_INV_cycle_count\(0) <= NOT \timers:1:channel|prescaler|cycle_count\(0);
\timers:1:channel|prescaler|ALT_INV_LessThan1~14_combout\ <= NOT \timers:1:channel|prescaler|LessThan1~14_combout\;
\timers:1:channel|prescaler|ALT_INV_LessThan0~0_combout\ <= NOT \timers:1:channel|prescaler|LessThan0~0_combout\;
\timers:1:channel|prescaler|ALT_INV_TICK~0_combout\ <= NOT \timers:1:channel|prescaler|TICK~0_combout\;
\timers:3:channel|ALT_INV_running_r~0_combout\ <= NOT \timers:3:channel|running_r~0_combout\;
\timers:0:channel|prescaler|ALT_INV_cycle_count\(3) <= NOT \timers:0:channel|prescaler|cycle_count\(3);
\timers:1:channel|ALT_INV_timescale_r\(11) <= NOT \timers:1:channel|timescale_r\(11);
\timers:1:channel|ALT_INV_timescale_r\(12) <= NOT \timers:1:channel|timescale_r\(12);
\timers:1:channel|prescaler|ALT_INV_LessThan1~0_combout\ <= NOT \timers:1:channel|prescaler|LessThan1~0_combout\;
\timers:1:channel|ALT_INV_timescale_r\(2) <= NOT \timers:1:channel|timescale_r\(2);
\timers:1:channel|prescaler|ALT_INV_LessThan1~2_combout\ <= NOT \timers:1:channel|prescaler|LessThan1~2_combout\;
\timers:1:channel|prescaler|ALT_INV_LessThan1~9_combout\ <= NOT \timers:1:channel|prescaler|LessThan1~9_combout\;
\timers:1:channel|prescaler|ALT_INV_LessThan1~10_combout\ <= NOT \timers:1:channel|prescaler|LessThan1~10_combout\;
\timers:0:channel|prescaler|ALT_INV_LessThan1~10_combout\ <= NOT \timers:0:channel|prescaler|LessThan1~10_combout\;
\timers:1:channel|prescaler|ALT_INV_LessThan1~7_combout\ <= NOT \timers:1:channel|prescaler|LessThan1~7_combout\;
\timers:1:channel|ALT_INV_timescale_r\(0) <= NOT \timers:1:channel|timescale_r\(0);
\timers:0:channel|prescaler|ALT_INV_LessThan1~12_combout\ <= NOT \timers:0:channel|prescaler|LessThan1~12_combout\;
\timers:0:channel|prescaler|ALT_INV_TICK~0_combout\ <= NOT \timers:0:channel|prescaler|TICK~0_combout\;
\timers:1:channel|prescaler|ALT_INV_LessThan1~1_combout\ <= NOT \timers:1:channel|prescaler|LessThan1~1_combout\;
\timers:0:channel|prescaler|ALT_INV_LessThan1~11_combout\ <= NOT \timers:0:channel|prescaler|LessThan1~11_combout\;
\timers:0:channel|prescaler|ALT_INV_LessThan1~13_combout\ <= NOT \timers:0:channel|prescaler|LessThan1~13_combout\;
\timers:1:channel|prescaler|ALT_INV_LessThan1~4_combout\ <= NOT \timers:1:channel|prescaler|LessThan1~4_combout\;
\timers:1:channel|ALT_INV_timescale_r\(14) <= NOT \timers:1:channel|timescale_r\(14);
\timers:1:channel|prescaler|ALT_INV_LessThan1~5_combout\ <= NOT \timers:1:channel|prescaler|LessThan1~5_combout\;
\timers:1:channel|ALT_INV_timescale_r\(9) <= NOT \timers:1:channel|timescale_r\(9);
\timers:1:channel|prescaler|ALT_INV_LessThan1~3_combout\ <= NOT \timers:1:channel|prescaler|LessThan1~3_combout\;
\timers:1:channel|ALT_INV_timescale_r\(1) <= NOT \timers:1:channel|timescale_r\(1);
\timers:1:channel|ALT_INV_timescale_r\(4) <= NOT \timers:1:channel|timescale_r\(4);
\timers:1:channel|ALT_INV_running_r~0_combout\ <= NOT \timers:1:channel|running_r~0_combout\;
\timers:0:channel|prescaler|ALT_INV_LessThan1~14_combout\ <= NOT \timers:0:channel|prescaler|LessThan1~14_combout\;
\timers:3:channel|prescaler|ALT_INV_LessThan1~10_combout\ <= NOT \timers:3:channel|prescaler|LessThan1~10_combout\;
\timers:3:channel|prescaler|ALT_INV_LessThan1~4_combout\ <= NOT \timers:3:channel|prescaler|LessThan1~4_combout\;
\timers:3:channel|ALT_INV_timescale_r\(9) <= NOT \timers:3:channel|timescale_r\(9);
\timers:3:channel|ALT_INV_timescale_r\(1) <= NOT \timers:3:channel|timescale_r\(1);
\timers:3:channel|prescaler|ALT_INV_LessThan1~5_combout\ <= NOT \timers:3:channel|prescaler|LessThan1~5_combout\;
\timers:3:channel|ALT_INV_clear_prescale~q\ <= NOT \timers:3:channel|clear_prescale~q\;
\timers:3:channel|ALT_INV_timescale_r\(11) <= NOT \timers:3:channel|timescale_r\(11);
\timers:3:channel|prescaler|ALT_INV_LessThan1~7_combout\ <= NOT \timers:3:channel|prescaler|LessThan1~7_combout\;
\timers:3:channel|ALT_INV_timescale_r\(7) <= NOT \timers:3:channel|timescale_r\(7);
\timers:3:channel|prescaler|ALT_INV_cycle_count\(0) <= NOT \timers:3:channel|prescaler|cycle_count\(0);
\timers:3:channel|ALT_INV_process_0~2_combout\ <= NOT \timers:3:channel|process_0~2_combout\;
\timers:3:channel|ALT_INV_timescale_r\(3) <= NOT \timers:3:channel|timescale_r\(3);
\timers:3:channel|prescaler|ALT_INV_LessThan1~13_combout\ <= NOT \timers:3:channel|prescaler|LessThan1~13_combout\;
\timers:3:channel|prescaler|ALT_INV_TICK~0_combout\ <= NOT \timers:3:channel|prescaler|TICK~0_combout\;
\timers:3:channel|ALT_INV_timescale_r\(13) <= NOT \timers:3:channel|timescale_r\(13);
\timers:3:channel|prescaler|ALT_INV_LessThan1~8_combout\ <= NOT \timers:3:channel|prescaler|LessThan1~8_combout\;
\timers:3:channel|prescaler|ALT_INV_LessThan1~2_combout\ <= NOT \timers:3:channel|prescaler|LessThan1~2_combout\;
\timers:3:channel|ALT_INV_timescale_r\(4) <= NOT \timers:3:channel|timescale_r\(4);
\timers:3:channel|ALT_INV_timescale_r\(10) <= NOT \timers:3:channel|timescale_r\(10);
\timers:3:channel|prescaler|ALT_INV_LessThan1~6_combout\ <= NOT \timers:3:channel|prescaler|LessThan1~6_combout\;
\timers:3:channel|prescaler|ALT_INV_LessThan1~0_combout\ <= NOT \timers:3:channel|prescaler|LessThan1~0_combout\;
\timers:3:channel|ALT_INV_timescale_r\(15) <= NOT \timers:3:channel|timescale_r\(15);
\timers:3:channel|prescaler|ALT_INV_LessThan1~3_combout\ <= NOT \timers:3:channel|prescaler|LessThan1~3_combout\;
\timers:3:channel|ALT_INV_timescale_r\(2) <= NOT \timers:3:channel|timescale_r\(2);
\timers:3:channel|prescaler|ALT_INV_LessThan1~14_combout\ <= NOT \timers:3:channel|prescaler|LessThan1~14_combout\;
\timers:3:channel|prescaler|ALT_INV_LessThan1~15_combout\ <= NOT \timers:3:channel|prescaler|LessThan1~15_combout\;
\timers:3:channel|ALT_INV_timescale_r\(8) <= NOT \timers:3:channel|timescale_r\(8);
\timers:3:channel|ALT_INV_timescale_r\(6) <= NOT \timers:3:channel|timescale_r\(6);
\timers:3:channel|prescaler|ALT_INV_LessThan1~11_combout\ <= NOT \timers:3:channel|prescaler|LessThan1~11_combout\;
\timers:3:channel|ALT_INV_timescale_r\(14) <= NOT \timers:3:channel|timescale_r\(14);
\timers:3:channel|prescaler|ALT_INV_LessThan1~9_combout\ <= NOT \timers:3:channel|prescaler|LessThan1~9_combout\;
\timers:3:channel|prescaler|ALT_INV_cycle_count\(3) <= NOT \timers:3:channel|prescaler|cycle_count\(3);
\timers:3:channel|prescaler|ALT_INV_LessThan1~1_combout\ <= NOT \timers:3:channel|prescaler|LessThan1~1_combout\;
\timers:3:channel|ALT_INV_timescale_r\(5) <= NOT \timers:3:channel|timescale_r\(5);
\timers:3:channel|prescaler|ALT_INV_LessThan1~12_combout\ <= NOT \timers:3:channel|prescaler|LessThan1~12_combout\;
\timers:3:channel|ALT_INV_timescale_r\(12) <= NOT \timers:3:channel|timescale_r\(12);
\timers:3:channel|ALT_INV_timescale_r\(0) <= NOT \timers:3:channel|timescale_r\(0);
\timers:3:channel|prescaler|ALT_INV_cycle_count\(2) <= NOT \timers:3:channel|prescaler|cycle_count\(2);
\timers:3:channel|prescaler|ALT_INV_cycle_count\(1) <= NOT \timers:3:channel|prescaler|cycle_count\(1);
\timers:3:channel|prescaler|ALT_INV_LessThan0~0_combout\ <= NOT \timers:3:channel|prescaler|LessThan0~0_combout\;
\ALT_INV_IO_DATA[1]~input_o\ <= NOT \IO_DATA[1]~input_o\;
\ALT_INV_IO_DATA[2]~input_o\ <= NOT \IO_DATA[2]~input_o\;
\ALT_INV_IO_DATA[4]~input_o\ <= NOT \IO_DATA[4]~input_o\;
\ALT_INV_IO_DATA[5]~input_o\ <= NOT \IO_DATA[5]~input_o\;
\ALT_INV_IO_DATA[6]~input_o\ <= NOT \IO_DATA[6]~input_o\;
\ALT_INV_IO_DATA[8]~input_o\ <= NOT \IO_DATA[8]~input_o\;
\ALT_INV_IO_DATA[10]~input_o\ <= NOT \IO_DATA[10]~input_o\;
\ALT_INV_IO_DATA[9]~input_o\ <= NOT \IO_DATA[9]~input_o\;
\ALT_INV_IO_DATA[7]~input_o\ <= NOT \IO_DATA[7]~input_o\;
\ALT_INV_IO_DATA[0]~input_o\ <= NOT \IO_DATA[0]~input_o\;
\ALT_INV_IO_DATA[3]~input_o\ <= NOT \IO_DATA[3]~input_o\;
\ALT_INV_IO_ADDR[9]~input_o\ <= NOT \IO_ADDR[9]~input_o\;
\timers:2:channel|prescaler|ALT_INV_TICK~DUPLICATE_q\ <= NOT \timers:2:channel|prescaler|TICK~DUPLICATE_q\;
\ALT_INV_IO_DATA[14]~input_o\ <= NOT \IO_DATA[14]~input_o\;
\ALT_INV_IO_READ~input_o\ <= NOT \IO_READ~input_o\;
\ALT_INV_IO_ADDR[8]~input_o\ <= NOT \IO_ADDR[8]~input_o\;
\ALT_INV_IO_ADDR[7]~input_o\ <= NOT \IO_ADDR[7]~input_o\;
\ALT_INV_IO_ADDR[4]~input_o\ <= NOT \IO_ADDR[4]~input_o\;
\ALT_INV_IO_DATA[13]~input_o\ <= NOT \IO_DATA[13]~input_o\;
\ALT_INV_IO_ADDR[6]~input_o\ <= NOT \IO_ADDR[6]~input_o\;
\timers:0:channel|prescaler|ALT_INV_cycle_count[0]~DUPLICATE_q\ <= NOT \timers:0:channel|prescaler|cycle_count[0]~DUPLICATE_q\;
\timers:1:channel|prescaler|ALT_INV_cycle_count[1]~DUPLICATE_q\ <= NOT \timers:1:channel|prescaler|cycle_count[1]~DUPLICATE_q\;
\ALT_INV_IO_ADDR[1]~input_o\ <= NOT \IO_ADDR[1]~input_o\;
\ALT_INV_IO_ADDR[10]~input_o\ <= NOT \IO_ADDR[10]~input_o\;
\ALT_INV_IO_WRITE~input_o\ <= NOT \IO_WRITE~input_o\;
\ALT_INV_IO_ADDR[3]~input_o\ <= NOT \IO_ADDR[3]~input_o\;
\ALT_INV_IO_ADDR[0]~input_o\ <= NOT \IO_ADDR[0]~input_o\;
\ALT_INV_IO_DATA[11]~input_o\ <= NOT \IO_DATA[11]~input_o\;
\ALT_INV_IO_DATA[12]~input_o\ <= NOT \IO_DATA[12]~input_o\;
\ALT_INV_IO_ADDR[2]~input_o\ <= NOT \IO_ADDR[2]~input_o\;
\timers:2:channel|prescaler|ALT_INV_cycle_count[0]~DUPLICATE_q\ <= NOT \timers:2:channel|prescaler|cycle_count[0]~DUPLICATE_q\;
\ALT_INV_IO_DATA[15]~input_o\ <= NOT \IO_DATA[15]~input_o\;
\ALT_INV_IO_ADDR[5]~input_o\ <= NOT \IO_ADDR[5]~input_o\;

-- Location: IOOBUF_X16_Y81_N2
\IO_DATA[0]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \read_value[0]~4_combout\,
	oe => \drive_en~combout\,
	devoe => ww_devoe,
	o => IO_DATA(0));

-- Location: IOOBUF_X26_Y81_N42
\IO_DATA[1]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \read_value[1]~7_combout\,
	oe => \drive_en~combout\,
	devoe => ww_devoe,
	o => IO_DATA(1));

-- Location: IOOBUF_X24_Y81_N2
\IO_DATA[2]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \read_value[2]~10_combout\,
	oe => \drive_en~combout\,
	devoe => ww_devoe,
	o => IO_DATA(2));

-- Location: IOOBUF_X22_Y81_N36
\IO_DATA[3]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \read_value[3]~13_combout\,
	oe => \drive_en~combout\,
	devoe => ww_devoe,
	o => IO_DATA(3));

-- Location: IOOBUF_X28_Y81_N19
\IO_DATA[4]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \read_value[4]~16_combout\,
	oe => \drive_en~combout\,
	devoe => ww_devoe,
	o => IO_DATA(4));

-- Location: IOOBUF_X18_Y81_N42
\IO_DATA[5]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \read_value[5]~19_combout\,
	oe => \drive_en~combout\,
	devoe => ww_devoe,
	o => IO_DATA(5));

-- Location: IOOBUF_X16_Y81_N53
\IO_DATA[6]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \read_value[6]~22_combout\,
	oe => \drive_en~combout\,
	devoe => ww_devoe,
	o => IO_DATA(6));

-- Location: IOOBUF_X22_Y81_N19
\IO_DATA[7]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \read_value[7]~25_combout\,
	oe => \drive_en~combout\,
	devoe => ww_devoe,
	o => IO_DATA(7));

-- Location: IOOBUF_X16_Y81_N36
\IO_DATA[8]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \read_value[8]~28_combout\,
	oe => \drive_en~combout\,
	devoe => ww_devoe,
	o => IO_DATA(8));

-- Location: IOOBUF_X16_Y81_N19
\IO_DATA[9]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \read_value[9]~31_combout\,
	oe => \drive_en~combout\,
	devoe => ww_devoe,
	o => IO_DATA(9));

-- Location: IOOBUF_X18_Y81_N93
\IO_DATA[10]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \read_value[10]~34_combout\,
	oe => \drive_en~combout\,
	devoe => ww_devoe,
	o => IO_DATA(10));

-- Location: IOOBUF_X18_Y81_N76
\IO_DATA[11]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \read_value[11]~37_combout\,
	oe => \drive_en~combout\,
	devoe => ww_devoe,
	o => IO_DATA(11));

-- Location: IOOBUF_X28_Y81_N36
\IO_DATA[12]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \read_value[12]~40_combout\,
	oe => \drive_en~combout\,
	devoe => ww_devoe,
	o => IO_DATA(12));

-- Location: IOOBUF_X24_Y81_N36
\IO_DATA[13]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \read_value[13]~43_combout\,
	oe => \drive_en~combout\,
	devoe => ww_devoe,
	o => IO_DATA(13));

-- Location: IOOBUF_X26_Y81_N76
\IO_DATA[14]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \read_value[14]~46_combout\,
	oe => \drive_en~combout\,
	devoe => ww_devoe,
	o => IO_DATA(14));

-- Location: IOOBUF_X22_Y81_N2
\IO_DATA[15]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \read_value[15]~49_combout\,
	oe => \drive_en~combout\,
	devoe => ww_devoe,
	o => IO_DATA(15));

-- Location: IOIBUF_X26_Y81_N92
\IO_ADDR[3]~input\ : cyclonev_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_IO_ADDR(3),
	o => \IO_ADDR[3]~input_o\);

-- Location: IOIBUF_X24_Y81_N18
\IO_ADDR[2]~input\ : cyclonev_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_IO_ADDR(2),
	o => \IO_ADDR[2]~input_o\);

-- Location: IOIBUF_X20_Y81_N1
\IO_ADDR[0]~input\ : cyclonev_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_IO_ADDR(0),
	o => \IO_ADDR[0]~input_o\);

-- Location: IOIBUF_X26_Y81_N58
\IO_ADDR[1]~input\ : cyclonev_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_IO_ADDR(1),
	o => \IO_ADDR[1]~input_o\);

-- Location: MLABCELL_X21_Y67_N0
\read_value[0]~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \read_value[0]~0_combout\ = ( !\IO_ADDR[1]~input_o\ & ( (!\IO_ADDR[0]~input_o\) # ((\IO_ADDR[3]~input_o\ & !\IO_ADDR[2]~input_o\)) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111111100110000111111110011000000000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \ALT_INV_IO_ADDR[3]~input_o\,
	datac => \ALT_INV_IO_ADDR[2]~input_o\,
	datad => \ALT_INV_IO_ADDR[0]~input_o\,
	dataf => \ALT_INV_IO_ADDR[1]~input_o\,
	combout => \read_value[0]~0_combout\);

-- Location: MLABCELL_X21_Y67_N33
\read_value[0]~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \read_value[0]~1_combout\ = ( !\IO_ADDR[1]~input_o\ & ( ((!\IO_ADDR[3]~input_o\) # (!\IO_ADDR[0]~input_o\)) # (\IO_ADDR[2]~input_o\) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111111111011101111111111101110100000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_IO_ADDR[2]~input_o\,
	datab => \ALT_INV_IO_ADDR[3]~input_o\,
	datad => \ALT_INV_IO_ADDR[0]~input_o\,
	dataf => \ALT_INV_IO_ADDR[1]~input_o\,
	combout => \read_value[0]~1_combout\);

-- Location: IOIBUF_X89_Y25_N21
\CLOCK~input\ : cyclonev_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_CLOCK,
	o => \CLOCK~input_o\);

-- Location: CLKCTRL_G10
\CLOCK~inputCLKENA0\ : cyclonev_clkena
-- pragma translate_off
GENERIC MAP (
	clock_type => "global clock",
	disable_mode => "low",
	ena_register_mode => "always enabled",
	ena_register_power_up => "high",
	test_syn => "high")
-- pragma translate_on
PORT MAP (
	inclk => \CLOCK~input_o\,
	outclk => \CLOCK~inputCLKENA0_outclk\);

-- Location: LABCELL_X22_Y63_N0
\timers:3:channel|Add2~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|Add2~1_sumout\ = SUM(( \timers:3:channel|elapsed_r\(0) ) + ( VCC ) + ( !VCC ))
-- \timers:3:channel|Add2~2\ = CARRY(( \timers:3:channel|elapsed_r\(0) ) + ( VCC ) + ( !VCC ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:3:channel|ALT_INV_elapsed_r\(0),
	cin => GND,
	sumout => \timers:3:channel|Add2~1_sumout\,
	cout => \timers:3:channel|Add2~2\);

-- Location: IOIBUF_X16_Y81_N1
\IO_DATA[0]~input\ : cyclonev_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => IO_DATA(0),
	o => \IO_DATA[0]~input_o\);

-- Location: LABCELL_X19_Y67_N57
\timers:3:channel|duration_r[0]~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|duration_r[0]~0_combout\ = ( !\IO_DATA[0]~input_o\ )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111111111111111111111111111111100000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataf => \ALT_INV_IO_DATA[0]~input_o\,
	combout => \timers:3:channel|duration_r[0]~0_combout\);

-- Location: IOIBUF_X89_Y23_N21
\RESETN~input\ : cyclonev_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_RESETN,
	o => \RESETN~input_o\);

-- Location: CLKCTRL_G8
\RESETN~inputCLKENA0\ : cyclonev_clkena
-- pragma translate_off
GENERIC MAP (
	clock_type => "global clock",
	disable_mode => "low",
	ena_register_mode => "always enabled",
	ena_register_power_up => "high",
	test_syn => "high")
-- pragma translate_on
PORT MAP (
	inclk => \RESETN~input_o\,
	outclk => \RESETN~inputCLKENA0_outclk\);

-- Location: IOIBUF_X18_Y81_N41
\IO_DATA[5]~input\ : cyclonev_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => IO_DATA(5),
	o => \IO_DATA[5]~input_o\);

-- Location: IOIBUF_X16_Y81_N52
\IO_DATA[6]~input\ : cyclonev_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => IO_DATA(6),
	o => \IO_DATA[6]~input_o\);

-- Location: IOIBUF_X22_Y81_N18
\IO_DATA[7]~input\ : cyclonev_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => IO_DATA(7),
	o => \IO_DATA[7]~input_o\);

-- Location: IOIBUF_X28_Y81_N18
\IO_DATA[4]~input\ : cyclonev_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => IO_DATA(4),
	o => \IO_DATA[4]~input_o\);

-- Location: IOIBUF_X16_Y81_N35
\IO_DATA[8]~input\ : cyclonev_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => IO_DATA(8),
	o => \IO_DATA[8]~input_o\);

-- Location: IOIBUF_X16_Y81_N18
\IO_DATA[9]~input\ : cyclonev_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => IO_DATA(9),
	o => \IO_DATA[9]~input_o\);

-- Location: LABCELL_X22_Y71_N36
\timers:0:channel|Equal1~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|Equal1~0_combout\ = ( !\IO_DATA[8]~input_o\ & ( !\IO_DATA[9]~input_o\ & ( (!\IO_DATA[5]~input_o\ & (!\IO_DATA[6]~input_o\ & (!\IO_DATA[7]~input_o\ & !\IO_DATA[4]~input_o\))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1000000000000000000000000000000000000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_IO_DATA[5]~input_o\,
	datab => \ALT_INV_IO_DATA[6]~input_o\,
	datac => \ALT_INV_IO_DATA[7]~input_o\,
	datad => \ALT_INV_IO_DATA[4]~input_o\,
	datae => \ALT_INV_IO_DATA[8]~input_o\,
	dataf => \ALT_INV_IO_DATA[9]~input_o\,
	combout => \timers:0:channel|Equal1~0_combout\);

-- Location: IOIBUF_X18_Y81_N92
\IO_DATA[10]~input\ : cyclonev_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => IO_DATA(10),
	o => \IO_DATA[10]~input_o\);

-- Location: IOIBUF_X24_Y81_N1
\IO_DATA[2]~input\ : cyclonev_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => IO_DATA(2),
	o => \IO_DATA[2]~input_o\);

-- Location: IOIBUF_X22_Y81_N35
\IO_DATA[3]~input\ : cyclonev_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => IO_DATA(3),
	o => \IO_DATA[3]~input_o\);

-- Location: IOIBUF_X26_Y81_N41
\IO_DATA[1]~input\ : cyclonev_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => IO_DATA(1),
	o => \IO_DATA[1]~input_o\);

-- Location: MLABCELL_X21_Y70_N36
\timers:0:channel|Equal1~2\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|Equal1~2_combout\ = ( !\IO_DATA[1]~input_o\ & ( (!\IO_DATA[2]~input_o\ & (!\IO_DATA[0]~input_o\ & !\IO_DATA[3]~input_o\)) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1010000000000000101000000000000000000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_IO_DATA[2]~input_o\,
	datac => \ALT_INV_IO_DATA[0]~input_o\,
	datad => \ALT_INV_IO_DATA[3]~input_o\,
	dataf => \ALT_INV_IO_DATA[1]~input_o\,
	combout => \timers:0:channel|Equal1~2_combout\);

-- Location: IOIBUF_X22_Y81_N1
\IO_DATA[15]~input\ : cyclonev_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => IO_DATA(15),
	o => \IO_DATA[15]~input_o\);

-- Location: IOIBUF_X18_Y81_N75
\IO_DATA[11]~input\ : cyclonev_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => IO_DATA(11),
	o => \IO_DATA[11]~input_o\);

-- Location: IOIBUF_X26_Y81_N75
\IO_DATA[14]~input\ : cyclonev_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => IO_DATA(14),
	o => \IO_DATA[14]~input_o\);

-- Location: IOIBUF_X28_Y81_N35
\IO_DATA[12]~input\ : cyclonev_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => IO_DATA(12),
	o => \IO_DATA[12]~input_o\);

-- Location: IOIBUF_X24_Y81_N35
\IO_DATA[13]~input\ : cyclonev_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => IO_DATA(13),
	o => \IO_DATA[13]~input_o\);

-- Location: MLABCELL_X21_Y70_N9
\timers:0:channel|Equal1~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|Equal1~1_combout\ = ( !\IO_DATA[13]~input_o\ & ( (!\IO_DATA[15]~input_o\ & (!\IO_DATA[11]~input_o\ & (!\IO_DATA[14]~input_o\ & !\IO_DATA[12]~input_o\))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1000000000000000100000000000000000000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_IO_DATA[15]~input_o\,
	datab => \ALT_INV_IO_DATA[11]~input_o\,
	datac => \ALT_INV_IO_DATA[14]~input_o\,
	datad => \ALT_INV_IO_DATA[12]~input_o\,
	dataf => \ALT_INV_IO_DATA[13]~input_o\,
	combout => \timers:0:channel|Equal1~1_combout\);

-- Location: MLABCELL_X21_Y70_N30
\timers:0:channel|process_0~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|process_0~1_combout\ = ( \IO_ADDR[0]~input_o\ & ( !\IO_ADDR[1]~input_o\ & ( (!\timers:0:channel|Equal1~0_combout\) # (((!\timers:0:channel|Equal1~2_combout\) # (!\timers:0:channel|Equal1~1_combout\)) # (\IO_DATA[10]~input_o\)) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111101100000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:0:channel|ALT_INV_Equal1~0_combout\,
	datab => \ALT_INV_IO_DATA[10]~input_o\,
	datac => \timers:0:channel|ALT_INV_Equal1~2_combout\,
	datad => \timers:0:channel|ALT_INV_Equal1~1_combout\,
	datae => \ALT_INV_IO_ADDR[0]~input_o\,
	dataf => \ALT_INV_IO_ADDR[1]~input_o\,
	combout => \timers:0:channel|process_0~1_combout\);

-- Location: IOIBUF_X24_Y81_N52
\IO_ADDR[10]~input\ : cyclonev_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_IO_ADDR(10),
	o => \IO_ADDR[10]~input_o\);

-- Location: LABCELL_X22_Y64_N48
\Equal11~3\ : cyclonev_lcell_comb
-- Equation(s):
-- \Equal11~3_combout\ = (\IO_ADDR[3]~input_o\ & \IO_ADDR[2]~input_o\)

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0001000100010001000100010001000100010001000100010001000100010001",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_IO_ADDR[3]~input_o\,
	datab => \ALT_INV_IO_ADDR[2]~input_o\,
	combout => \Equal11~3_combout\);

-- Location: IOIBUF_X20_Y81_N18
\IO_WRITE~input\ : cyclonev_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_IO_WRITE,
	o => \IO_WRITE~input_o\);

-- Location: IOIBUF_X18_Y81_N58
\IO_ADDR[5]~input\ : cyclonev_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_IO_ADDR(5),
	o => \IO_ADDR[5]~input_o\);

-- Location: IOIBUF_X20_Y81_N35
\IO_ADDR[6]~input\ : cyclonev_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_IO_ADDR(6),
	o => \IO_ADDR[6]~input_o\);

-- Location: IOIBUF_X22_Y81_N52
\IO_ADDR[7]~input\ : cyclonev_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_IO_ADDR(7),
	o => \IO_ADDR[7]~input_o\);

-- Location: IOIBUF_X20_Y81_N52
\IO_ADDR[4]~input\ : cyclonev_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_IO_ADDR(4),
	o => \IO_ADDR[4]~input_o\);

-- Location: IOIBUF_X28_Y81_N1
\IO_ADDR[9]~input\ : cyclonev_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_IO_ADDR(9),
	o => \IO_ADDR[9]~input_o\);

-- Location: IOIBUF_X12_Y81_N52
\IO_ADDR[8]~input\ : cyclonev_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_IO_ADDR(8),
	o => \IO_ADDR[8]~input_o\);

-- Location: LABCELL_X22_Y77_N48
\Equal0~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \Equal0~0_combout\ = ( !\IO_ADDR[9]~input_o\ & ( !\IO_ADDR[8]~input_o\ & ( (\IO_ADDR[5]~input_o\ & (\IO_ADDR[6]~input_o\ & (!\IO_ADDR[7]~input_o\ & \IO_ADDR[4]~input_o\))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000010000000000000000000000000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_IO_ADDR[5]~input_o\,
	datab => \ALT_INV_IO_ADDR[6]~input_o\,
	datac => \ALT_INV_IO_ADDR[7]~input_o\,
	datad => \ALT_INV_IO_ADDR[4]~input_o\,
	datae => \ALT_INV_IO_ADDR[9]~input_o\,
	dataf => \ALT_INV_IO_ADDR[8]~input_o\,
	combout => \Equal0~0_combout\);

-- Location: MLABCELL_X21_Y72_N21
\timers:3:channel|process_0~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|process_0~0_combout\ = ( \Equal0~0_combout\ & ( (\timers:0:channel|process_0~1_combout\ & (!\IO_ADDR[10]~input_o\ & (\Equal11~3_combout\ & \IO_WRITE~input_o\))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000001000000000000000100",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:0:channel|ALT_INV_process_0~1_combout\,
	datab => \ALT_INV_IO_ADDR[10]~input_o\,
	datac => \ALT_INV_Equal11~3_combout\,
	datad => \ALT_INV_IO_WRITE~input_o\,
	dataf => \ALT_INV_Equal0~0_combout\,
	combout => \timers:3:channel|process_0~0_combout\);

-- Location: FF_X24_Y63_N2
\timers:3:channel|duration_r[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \timers:3:channel|duration_r[0]~0_combout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sload => VCC,
	ena => \timers:3:channel|process_0~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:3:channel|duration_r\(0));

-- Location: MLABCELL_X21_Y63_N18
\timers:3:channel|duration_r[0]~_wirecell\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|duration_r[0]~_wirecell_combout\ = !\timers:3:channel|duration_r\(0)

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111000011110000111100001111000011110000111100001111000011110000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:3:channel|ALT_INV_duration_r\(0),
	combout => \timers:3:channel|duration_r[0]~_wirecell_combout\);

-- Location: LABCELL_X24_Y69_N18
\timers:0:channel|process_0~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|process_0~0_combout\ = ( \IO_DATA[1]~input_o\ & ( (!\IO_ADDR[0]~input_o\ & !\IO_ADDR[1]~input_o\) ) ) # ( !\IO_DATA[1]~input_o\ & ( (!\IO_ADDR[0]~input_o\ & (!\IO_ADDR[1]~input_o\ & \IO_DATA[0]~input_o\)) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000100000001000000010000000100010001000100010001000100010001000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_IO_ADDR[0]~input_o\,
	datab => \ALT_INV_IO_ADDR[1]~input_o\,
	datac => \ALT_INV_IO_DATA[0]~input_o\,
	dataf => \ALT_INV_IO_DATA[1]~input_o\,
	combout => \timers:0:channel|process_0~0_combout\);

-- Location: LABCELL_X22_Y65_N42
\timers:3:channel|process_0~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|process_0~1_combout\ = ( \timers:0:channel|process_0~0_combout\ & ( (!\IO_ADDR[10]~input_o\ & (\Equal0~0_combout\ & (\Equal11~3_combout\ & \IO_WRITE~input_o\))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000100000000000000010",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_IO_ADDR[10]~input_o\,
	datab => \ALT_INV_Equal0~0_combout\,
	datac => \ALT_INV_Equal11~3_combout\,
	datad => \ALT_INV_IO_WRITE~input_o\,
	dataf => \timers:0:channel|ALT_INV_process_0~0_combout\,
	combout => \timers:3:channel|process_0~1_combout\);

-- Location: FF_X22_Y65_N53
\timers:3:channel|mode_r[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \IO_DATA[1]~input_o\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sload => VCC,
	ena => \timers:3:channel|process_0~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:3:channel|mode_r\(1));

-- Location: LABCELL_X24_Y69_N27
\timers:0:channel|periods_r~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|periods_r~0_combout\ = ( \IO_DATA[0]~input_o\ & ( \IO_DATA[1]~input_o\ & ( (\IO_ADDR[0]~input_o\ & \IO_ADDR[1]~input_o\) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000000001000100010001",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_IO_ADDR[0]~input_o\,
	datab => \ALT_INV_IO_ADDR[1]~input_o\,
	datae => \ALT_INV_IO_DATA[0]~input_o\,
	dataf => \ALT_INV_IO_DATA[1]~input_o\,
	combout => \timers:0:channel|periods_r~0_combout\);

-- Location: MLABCELL_X21_Y77_N24
\timers:0:channel|Mux33~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|Mux33~0_combout\ = ( \IO_DATA[1]~input_o\ & ( \IO_ADDR[1]~input_o\ & ( (\IO_ADDR[0]~input_o\ & !\IO_DATA[0]~input_o\) ) ) ) # ( !\IO_DATA[1]~input_o\ & ( \IO_ADDR[1]~input_o\ & ( (\IO_ADDR[0]~input_o\ & \IO_DATA[0]~input_o\) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000101000001010101000001010000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_IO_ADDR[0]~input_o\,
	datac => \ALT_INV_IO_DATA[0]~input_o\,
	datae => \ALT_INV_IO_DATA[1]~input_o\,
	dataf => \ALT_INV_IO_ADDR[1]~input_o\,
	combout => \timers:0:channel|Mux33~0_combout\);

-- Location: MLABCELL_X21_Y72_N0
\Equal11~4\ : cyclonev_lcell_comb
-- Equation(s):
-- \Equal11~4_combout\ = ( \Equal11~3_combout\ & ( \Equal0~0_combout\ & ( (!\IO_ADDR[10]~input_o\ & \IO_WRITE~input_o\) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000000000110000001100",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \ALT_INV_IO_ADDR[10]~input_o\,
	datac => \ALT_INV_IO_WRITE~input_o\,
	datae => \ALT_INV_Equal11~3_combout\,
	dataf => \ALT_INV_Equal0~0_combout\,
	combout => \Equal11~4_combout\);

-- Location: LABCELL_X22_Y65_N36
\timers:3:channel|mode_r[0]~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|mode_r[0]~0_combout\ = !\IO_DATA[0]~input_o\

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111000011110000111100001111000011110000111100001111000011110000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \ALT_INV_IO_DATA[0]~input_o\,
	combout => \timers:3:channel|mode_r[0]~0_combout\);

-- Location: FF_X22_Y65_N38
\timers:3:channel|mode_r[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:3:channel|mode_r[0]~0_combout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	ena => \timers:3:channel|process_0~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:3:channel|mode_r\(0));

-- Location: MLABCELL_X21_Y70_N33
\timers:3:channel|process_0~2\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|process_0~2_combout\ = ( \IO_ADDR[1]~input_o\ & ( !\IO_ADDR[0]~input_o\ & ( (!\timers:0:channel|Equal1~0_combout\) # (((!\timers:0:channel|Equal1~1_combout\) # (!\timers:0:channel|Equal1~2_combout\)) # (\IO_DATA[10]~input_o\)) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111101100000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:0:channel|ALT_INV_Equal1~0_combout\,
	datab => \ALT_INV_IO_DATA[10]~input_o\,
	datac => \timers:0:channel|ALT_INV_Equal1~1_combout\,
	datad => \timers:0:channel|ALT_INV_Equal1~2_combout\,
	datae => \ALT_INV_IO_ADDR[1]~input_o\,
	dataf => \ALT_INV_IO_ADDR[0]~input_o\,
	combout => \timers:3:channel|process_0~2_combout\);

-- Location: MLABCELL_X21_Y71_N24
\timers:3:channel|clear_prescale~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|clear_prescale~0_combout\ = ( \Equal11~4_combout\ & ( \timers:3:channel|running_r~q\ & ( (\timers:3:channel|process_0~2_combout\ & !\timers:0:channel|periods_r~0_combout\) ) ) ) # ( \Equal11~4_combout\ & ( !\timers:3:channel|running_r~q\ 
-- & ( (\timers:0:channel|periods_r~0_combout\) # (\timers:3:channel|process_0~2_combout\) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000010111110101111100000000000000000101000001010000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:3:channel|ALT_INV_process_0~2_combout\,
	datac => \timers:0:channel|ALT_INV_periods_r~0_combout\,
	datae => \ALT_INV_Equal11~4_combout\,
	dataf => \timers:3:channel|ALT_INV_running_r~q\,
	combout => \timers:3:channel|clear_prescale~0_combout\);

-- Location: FF_X21_Y71_N26
\timers:3:channel|clear_prescale\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:3:channel|clear_prescale~0_combout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:3:channel|clear_prescale~q\);

-- Location: LABCELL_X22_Y65_N54
\timers:3:channel|prescaler|cycle_count~4\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|prescaler|cycle_count~4_combout\ = ( !\timers:3:channel|prescaler|LessThan0~0_combout\ & ( (!\timers:3:channel|clear_prescale~q\ & !\timers:3:channel|prescaler|cycle_count\(0)) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1100110000000000110011000000000000000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \timers:3:channel|ALT_INV_clear_prescale~q\,
	datad => \timers:3:channel|prescaler|ALT_INV_cycle_count\(0),
	dataf => \timers:3:channel|prescaler|ALT_INV_LessThan0~0_combout\,
	combout => \timers:3:channel|prescaler|cycle_count~4_combout\);

-- Location: LABCELL_X22_Y65_N57
\timers:3:channel|prescaler|cycle_count[0]~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|prescaler|cycle_count[0]~1_combout\ = ( \timers:3:channel|running_r~q\ ) # ( !\timers:3:channel|running_r~q\ & ( \timers:3:channel|clear_prescale~q\ ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0011001100110011001100110011001111111111111111111111111111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \timers:3:channel|ALT_INV_clear_prescale~q\,
	dataf => \timers:3:channel|ALT_INV_running_r~q\,
	combout => \timers:3:channel|prescaler|cycle_count[0]~1_combout\);

-- Location: FF_X22_Y65_N56
\timers:3:channel|prescaler|cycle_count[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:3:channel|prescaler|cycle_count~4_combout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	ena => \timers:3:channel|prescaler|cycle_count[0]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:3:channel|prescaler|cycle_count\(0));

-- Location: LABCELL_X22_Y65_N18
\timers:3:channel|prescaler|cycle_count~3\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|prescaler|cycle_count~3_combout\ = ( !\timers:3:channel|prescaler|LessThan0~0_combout\ & ( (!\timers:3:channel|clear_prescale~q\ & (!\timers:3:channel|prescaler|cycle_count\(0) $ (!\timers:3:channel|prescaler|cycle_count\(1)))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000110011000000000011001100000000000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \timers:3:channel|ALT_INV_clear_prescale~q\,
	datac => \timers:3:channel|prescaler|ALT_INV_cycle_count\(0),
	datad => \timers:3:channel|prescaler|ALT_INV_cycle_count\(1),
	dataf => \timers:3:channel|prescaler|ALT_INV_LessThan0~0_combout\,
	combout => \timers:3:channel|prescaler|cycle_count~3_combout\);

-- Location: FF_X22_Y65_N20
\timers:3:channel|prescaler|cycle_count[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:3:channel|prescaler|cycle_count~3_combout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	ena => \timers:3:channel|prescaler|cycle_count[0]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:3:channel|prescaler|cycle_count\(1));

-- Location: LABCELL_X23_Y65_N54
\timers:3:channel|prescaler|cycle_count~2\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|prescaler|cycle_count~2_combout\ = ( \timers:3:channel|prescaler|cycle_count\(0) & ( \timers:3:channel|prescaler|cycle_count\(1) & ( (!\timers:3:channel|prescaler|cycle_count\(3) & (!\timers:3:channel|clear_prescale~q\ & 
-- !\timers:3:channel|prescaler|cycle_count\(2))) ) ) ) # ( !\timers:3:channel|prescaler|cycle_count\(0) & ( \timers:3:channel|prescaler|cycle_count\(1) & ( (!\timers:3:channel|prescaler|cycle_count\(3) & (!\timers:3:channel|clear_prescale~q\ & 
-- \timers:3:channel|prescaler|cycle_count\(2))) ) ) ) # ( \timers:3:channel|prescaler|cycle_count\(0) & ( !\timers:3:channel|prescaler|cycle_count\(1) & ( (!\timers:3:channel|prescaler|cycle_count\(3) & (!\timers:3:channel|clear_prescale~q\ & 
-- \timers:3:channel|prescaler|cycle_count\(2))) ) ) ) # ( !\timers:3:channel|prescaler|cycle_count\(0) & ( !\timers:3:channel|prescaler|cycle_count\(1) & ( (!\timers:3:channel|prescaler|cycle_count\(3) & (!\timers:3:channel|clear_prescale~q\ & 
-- \timers:3:channel|prescaler|cycle_count\(2))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000100000001000000010000000100000001000000010001000000010000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:3:channel|prescaler|ALT_INV_cycle_count\(3),
	datab => \timers:3:channel|ALT_INV_clear_prescale~q\,
	datac => \timers:3:channel|prescaler|ALT_INV_cycle_count\(2),
	datae => \timers:3:channel|prescaler|ALT_INV_cycle_count\(0),
	dataf => \timers:3:channel|prescaler|ALT_INV_cycle_count\(1),
	combout => \timers:3:channel|prescaler|cycle_count~2_combout\);

-- Location: FF_X22_Y65_N5
\timers:3:channel|prescaler|cycle_count[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \timers:3:channel|prescaler|cycle_count~2_combout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sload => VCC,
	ena => \timers:3:channel|prescaler|cycle_count[0]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:3:channel|prescaler|cycle_count\(2));

-- Location: LABCELL_X22_Y65_N0
\timers:3:channel|prescaler|cycle_count~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|prescaler|cycle_count~0_combout\ = ( !\timers:3:channel|clear_prescale~q\ & ( (!\timers:3:channel|prescaler|cycle_count\(1) & (!\timers:3:channel|prescaler|cycle_count\(0) & (!\timers:3:channel|prescaler|cycle_count\(2) & 
-- \timers:3:channel|prescaler|cycle_count\(3)))) # (\timers:3:channel|prescaler|cycle_count\(1) & (\timers:3:channel|prescaler|cycle_count\(0) & (\timers:3:channel|prescaler|cycle_count\(2) & !\timers:3:channel|prescaler|cycle_count\(3)))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000110000000000000011000000000000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:3:channel|prescaler|ALT_INV_cycle_count\(1),
	datab => \timers:3:channel|prescaler|ALT_INV_cycle_count\(0),
	datac => \timers:3:channel|prescaler|ALT_INV_cycle_count\(2),
	datad => \timers:3:channel|prescaler|ALT_INV_cycle_count\(3),
	dataf => \timers:3:channel|ALT_INV_clear_prescale~q\,
	combout => \timers:3:channel|prescaler|cycle_count~0_combout\);

-- Location: FF_X22_Y65_N1
\timers:3:channel|prescaler|cycle_count[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:3:channel|prescaler|cycle_count~0_combout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	ena => \timers:3:channel|prescaler|cycle_count[0]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:3:channel|prescaler|cycle_count\(3));

-- Location: LABCELL_X22_Y65_N21
\timers:3:channel|prescaler|LessThan0~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|prescaler|LessThan0~0_combout\ = ( \timers:3:channel|prescaler|cycle_count\(2) & ( \timers:3:channel|prescaler|cycle_count\(3) ) ) # ( !\timers:3:channel|prescaler|cycle_count\(2) & ( (\timers:3:channel|prescaler|cycle_count\(3) & 
-- ((\timers:3:channel|prescaler|cycle_count\(0)) # (\timers:3:channel|prescaler|cycle_count\(1)))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000010100001111000001010000111100001111000011110000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:3:channel|prescaler|ALT_INV_cycle_count\(1),
	datac => \timers:3:channel|prescaler|ALT_INV_cycle_count\(3),
	datad => \timers:3:channel|prescaler|ALT_INV_cycle_count\(0),
	dataf => \timers:3:channel|prescaler|ALT_INV_cycle_count\(2),
	combout => \timers:3:channel|prescaler|LessThan0~0_combout\);

-- Location: LABCELL_X22_Y65_N27
\timers:3:channel|prescaler|ms_count[4]~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|prescaler|ms_count[4]~1_combout\ = ( \timers:3:channel|running_r~q\ & ( (\timers:3:channel|prescaler|LessThan0~0_combout\) # (\timers:3:channel|clear_prescale~q\) ) ) # ( !\timers:3:channel|running_r~q\ & ( 
-- \timers:3:channel|clear_prescale~q\ ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000111100001111000011110000111100001111111111110000111111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:3:channel|ALT_INV_clear_prescale~q\,
	datad => \timers:3:channel|prescaler|ALT_INV_LessThan0~0_combout\,
	dataf => \timers:3:channel|ALT_INV_running_r~q\,
	combout => \timers:3:channel|prescaler|ms_count[4]~1_combout\);

-- Location: FF_X22_Y72_N32
\timers:3:channel|prescaler|ms_count[10]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:3:channel|prescaler|Add1~21_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:3:channel|prescaler|ms_count[4]~0_combout\,
	ena => \timers:3:channel|prescaler|ms_count[4]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:3:channel|prescaler|ms_count\(10));

-- Location: LABCELL_X22_Y72_N0
\timers:3:channel|prescaler|Add1~49\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|prescaler|Add1~49_sumout\ = SUM(( \timers:3:channel|prescaler|ms_count\(0) ) + ( VCC ) + ( !VCC ))
-- \timers:3:channel|prescaler|Add1~50\ = CARRY(( \timers:3:channel|prescaler|ms_count\(0) ) + ( VCC ) + ( !VCC ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000000000000011111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datad => \timers:3:channel|prescaler|ALT_INV_ms_count\(0),
	cin => GND,
	sumout => \timers:3:channel|prescaler|Add1~49_sumout\,
	cout => \timers:3:channel|prescaler|Add1~50\);

-- Location: FF_X22_Y72_N2
\timers:3:channel|prescaler|ms_count[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:3:channel|prescaler|Add1~49_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:3:channel|prescaler|ms_count[4]~0_combout\,
	ena => \timers:3:channel|prescaler|ms_count[4]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:3:channel|prescaler|ms_count\(0));

-- Location: LABCELL_X22_Y72_N3
\timers:3:channel|prescaler|Add1~45\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|prescaler|Add1~45_sumout\ = SUM(( \timers:3:channel|prescaler|ms_count\(1) ) + ( GND ) + ( \timers:3:channel|prescaler|Add1~50\ ))
-- \timers:3:channel|prescaler|Add1~46\ = CARRY(( \timers:3:channel|prescaler|ms_count\(1) ) + ( GND ) + ( \timers:3:channel|prescaler|Add1~50\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000000011111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datad => \timers:3:channel|prescaler|ALT_INV_ms_count\(1),
	cin => \timers:3:channel|prescaler|Add1~50\,
	sumout => \timers:3:channel|prescaler|Add1~45_sumout\,
	cout => \timers:3:channel|prescaler|Add1~46\);

-- Location: FF_X22_Y72_N5
\timers:3:channel|prescaler|ms_count[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:3:channel|prescaler|Add1~45_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:3:channel|prescaler|ms_count[4]~0_combout\,
	ena => \timers:3:channel|prescaler|ms_count[4]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:3:channel|prescaler|ms_count\(1));

-- Location: LABCELL_X22_Y72_N6
\timers:3:channel|prescaler|Add1~41\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|prescaler|Add1~41_sumout\ = SUM(( \timers:3:channel|prescaler|ms_count\(2) ) + ( GND ) + ( \timers:3:channel|prescaler|Add1~46\ ))
-- \timers:3:channel|prescaler|Add1~42\ = CARRY(( \timers:3:channel|prescaler|ms_count\(2) ) + ( GND ) + ( \timers:3:channel|prescaler|Add1~46\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000000011111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datad => \timers:3:channel|prescaler|ALT_INV_ms_count\(2),
	cin => \timers:3:channel|prescaler|Add1~46\,
	sumout => \timers:3:channel|prescaler|Add1~41_sumout\,
	cout => \timers:3:channel|prescaler|Add1~42\);

-- Location: FF_X22_Y72_N7
\timers:3:channel|prescaler|ms_count[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:3:channel|prescaler|Add1~41_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:3:channel|prescaler|ms_count[4]~0_combout\,
	ena => \timers:3:channel|prescaler|ms_count[4]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:3:channel|prescaler|ms_count\(2));

-- Location: LABCELL_X22_Y72_N9
\timers:3:channel|prescaler|Add1~37\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|prescaler|Add1~37_sumout\ = SUM(( \timers:3:channel|prescaler|ms_count\(3) ) + ( GND ) + ( \timers:3:channel|prescaler|Add1~42\ ))
-- \timers:3:channel|prescaler|Add1~38\ = CARRY(( \timers:3:channel|prescaler|ms_count\(3) ) + ( GND ) + ( \timers:3:channel|prescaler|Add1~42\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:3:channel|prescaler|ALT_INV_ms_count\(3),
	cin => \timers:3:channel|prescaler|Add1~42\,
	sumout => \timers:3:channel|prescaler|Add1~37_sumout\,
	cout => \timers:3:channel|prescaler|Add1~38\);

-- Location: FF_X22_Y72_N11
\timers:3:channel|prescaler|ms_count[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:3:channel|prescaler|Add1~37_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:3:channel|prescaler|ms_count[4]~0_combout\,
	ena => \timers:3:channel|prescaler|ms_count[4]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:3:channel|prescaler|ms_count\(3));

-- Location: LABCELL_X22_Y72_N12
\timers:3:channel|prescaler|Add1~33\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|prescaler|Add1~33_sumout\ = SUM(( \timers:3:channel|prescaler|ms_count\(4) ) + ( GND ) + ( \timers:3:channel|prescaler|Add1~38\ ))
-- \timers:3:channel|prescaler|Add1~34\ = CARRY(( \timers:3:channel|prescaler|ms_count\(4) ) + ( GND ) + ( \timers:3:channel|prescaler|Add1~38\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \timers:3:channel|prescaler|ALT_INV_ms_count\(4),
	cin => \timers:3:channel|prescaler|Add1~38\,
	sumout => \timers:3:channel|prescaler|Add1~33_sumout\,
	cout => \timers:3:channel|prescaler|Add1~34\);

-- Location: FF_X22_Y72_N14
\timers:3:channel|prescaler|ms_count[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:3:channel|prescaler|Add1~33_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:3:channel|prescaler|ms_count[4]~0_combout\,
	ena => \timers:3:channel|prescaler|ms_count[4]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:3:channel|prescaler|ms_count\(4));

-- Location: LABCELL_X22_Y72_N15
\timers:3:channel|prescaler|Add1~61\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|prescaler|Add1~61_sumout\ = SUM(( \timers:3:channel|prescaler|ms_count\(5) ) + ( GND ) + ( \timers:3:channel|prescaler|Add1~34\ ))
-- \timers:3:channel|prescaler|Add1~62\ = CARRY(( \timers:3:channel|prescaler|ms_count\(5) ) + ( GND ) + ( \timers:3:channel|prescaler|Add1~34\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:3:channel|prescaler|ALT_INV_ms_count\(5),
	cin => \timers:3:channel|prescaler|Add1~34\,
	sumout => \timers:3:channel|prescaler|Add1~61_sumout\,
	cout => \timers:3:channel|prescaler|Add1~62\);

-- Location: FF_X22_Y72_N17
\timers:3:channel|prescaler|ms_count[5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:3:channel|prescaler|Add1~61_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:3:channel|prescaler|ms_count[4]~0_combout\,
	ena => \timers:3:channel|prescaler|ms_count[4]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:3:channel|prescaler|ms_count\(5));

-- Location: LABCELL_X22_Y72_N18
\timers:3:channel|prescaler|Add1~57\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|prescaler|Add1~57_sumout\ = SUM(( \timers:3:channel|prescaler|ms_count\(6) ) + ( GND ) + ( \timers:3:channel|prescaler|Add1~62\ ))
-- \timers:3:channel|prescaler|Add1~58\ = CARRY(( \timers:3:channel|prescaler|ms_count\(6) ) + ( GND ) + ( \timers:3:channel|prescaler|Add1~62\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:3:channel|prescaler|ALT_INV_ms_count\(6),
	cin => \timers:3:channel|prescaler|Add1~62\,
	sumout => \timers:3:channel|prescaler|Add1~57_sumout\,
	cout => \timers:3:channel|prescaler|Add1~58\);

-- Location: FF_X22_Y72_N20
\timers:3:channel|prescaler|ms_count[6]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:3:channel|prescaler|Add1~57_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:3:channel|prescaler|ms_count[4]~0_combout\,
	ena => \timers:3:channel|prescaler|ms_count[4]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:3:channel|prescaler|ms_count\(6));

-- Location: LABCELL_X22_Y72_N21
\timers:3:channel|prescaler|Add1~53\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|prescaler|Add1~53_sumout\ = SUM(( \timers:3:channel|prescaler|ms_count\(7) ) + ( GND ) + ( \timers:3:channel|prescaler|Add1~58\ ))
-- \timers:3:channel|prescaler|Add1~54\ = CARRY(( \timers:3:channel|prescaler|ms_count\(7) ) + ( GND ) + ( \timers:3:channel|prescaler|Add1~58\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000000011111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datad => \timers:3:channel|prescaler|ALT_INV_ms_count\(7),
	cin => \timers:3:channel|prescaler|Add1~58\,
	sumout => \timers:3:channel|prescaler|Add1~53_sumout\,
	cout => \timers:3:channel|prescaler|Add1~54\);

-- Location: FF_X22_Y72_N23
\timers:3:channel|prescaler|ms_count[7]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:3:channel|prescaler|Add1~53_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:3:channel|prescaler|ms_count[4]~0_combout\,
	ena => \timers:3:channel|prescaler|ms_count[4]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:3:channel|prescaler|ms_count\(7));

-- Location: LABCELL_X22_Y72_N24
\timers:3:channel|prescaler|Add1~25\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|prescaler|Add1~25_sumout\ = SUM(( \timers:3:channel|prescaler|ms_count\(8) ) + ( GND ) + ( \timers:3:channel|prescaler|Add1~54\ ))
-- \timers:3:channel|prescaler|Add1~26\ = CARRY(( \timers:3:channel|prescaler|ms_count\(8) ) + ( GND ) + ( \timers:3:channel|prescaler|Add1~54\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:3:channel|prescaler|ALT_INV_ms_count\(8),
	cin => \timers:3:channel|prescaler|Add1~54\,
	sumout => \timers:3:channel|prescaler|Add1~25_sumout\,
	cout => \timers:3:channel|prescaler|Add1~26\);

-- Location: FF_X22_Y72_N26
\timers:3:channel|prescaler|ms_count[8]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:3:channel|prescaler|Add1~25_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:3:channel|prescaler|ms_count[4]~0_combout\,
	ena => \timers:3:channel|prescaler|ms_count[4]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:3:channel|prescaler|ms_count\(8));

-- Location: LABCELL_X22_Y72_N27
\timers:3:channel|prescaler|Add1~29\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|prescaler|Add1~29_sumout\ = SUM(( \timers:3:channel|prescaler|ms_count\(9) ) + ( GND ) + ( \timers:3:channel|prescaler|Add1~26\ ))
-- \timers:3:channel|prescaler|Add1~30\ = CARRY(( \timers:3:channel|prescaler|ms_count\(9) ) + ( GND ) + ( \timers:3:channel|prescaler|Add1~26\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000000011111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datad => \timers:3:channel|prescaler|ALT_INV_ms_count\(9),
	cin => \timers:3:channel|prescaler|Add1~26\,
	sumout => \timers:3:channel|prescaler|Add1~29_sumout\,
	cout => \timers:3:channel|prescaler|Add1~30\);

-- Location: FF_X22_Y72_N29
\timers:3:channel|prescaler|ms_count[9]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:3:channel|prescaler|Add1~29_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:3:channel|prescaler|ms_count[4]~0_combout\,
	ena => \timers:3:channel|prescaler|ms_count[4]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:3:channel|prescaler|ms_count\(9));

-- Location: LABCELL_X22_Y72_N30
\timers:3:channel|prescaler|Add1~21\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|prescaler|Add1~21_sumout\ = SUM(( \timers:3:channel|prescaler|ms_count\(10) ) + ( GND ) + ( \timers:3:channel|prescaler|Add1~30\ ))
-- \timers:3:channel|prescaler|Add1~22\ = CARRY(( \timers:3:channel|prescaler|ms_count\(10) ) + ( GND ) + ( \timers:3:channel|prescaler|Add1~30\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \timers:3:channel|prescaler|ALT_INV_ms_count\(10),
	cin => \timers:3:channel|prescaler|Add1~30\,
	sumout => \timers:3:channel|prescaler|Add1~21_sumout\,
	cout => \timers:3:channel|prescaler|Add1~22\);

-- Location: MLABCELL_X21_Y72_N33
\timers:3:channel|process_0~3\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|process_0~3_combout\ = ( \Equal11~3_combout\ & ( \Equal0~0_combout\ & ( (\timers:3:channel|process_0~2_combout\ & (!\IO_ADDR[10]~input_o\ & \IO_WRITE~input_o\)) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000000000000001010000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:3:channel|ALT_INV_process_0~2_combout\,
	datac => \ALT_INV_IO_ADDR[10]~input_o\,
	datad => \ALT_INV_IO_WRITE~input_o\,
	datae => \ALT_INV_Equal11~3_combout\,
	dataf => \ALT_INV_Equal0~0_combout\,
	combout => \timers:3:channel|process_0~3_combout\);

-- Location: FF_X23_Y72_N32
\timers:3:channel|timescale_r[11]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \IO_DATA[11]~input_o\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sload => VCC,
	ena => \timers:3:channel|process_0~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:3:channel|timescale_r\(11));

-- Location: FF_X22_Y72_N35
\timers:3:channel|prescaler|ms_count[11]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:3:channel|prescaler|Add1~5_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:3:channel|prescaler|ms_count[4]~0_combout\,
	ena => \timers:3:channel|prescaler|ms_count[4]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:3:channel|prescaler|ms_count\(11));

-- Location: LABCELL_X22_Y72_N33
\timers:3:channel|prescaler|Add1~5\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|prescaler|Add1~5_sumout\ = SUM(( \timers:3:channel|prescaler|ms_count\(11) ) + ( GND ) + ( \timers:3:channel|prescaler|Add1~22\ ))
-- \timers:3:channel|prescaler|Add1~6\ = CARRY(( \timers:3:channel|prescaler|ms_count\(11) ) + ( GND ) + ( \timers:3:channel|prescaler|Add1~22\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000101010101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:3:channel|prescaler|ALT_INV_ms_count\(11),
	cin => \timers:3:channel|prescaler|Add1~22\,
	sumout => \timers:3:channel|prescaler|Add1~5_sumout\,
	cout => \timers:3:channel|prescaler|Add1~6\);

-- Location: FF_X23_Y72_N41
\timers:3:channel|timescale_r[10]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \IO_DATA[10]~input_o\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sload => VCC,
	ena => \timers:3:channel|process_0~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:3:channel|timescale_r\(10));

-- Location: FF_X23_Y72_N35
\timers:3:channel|timescale_r[12]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \IO_DATA[12]~input_o\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sload => VCC,
	ena => \timers:3:channel|process_0~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:3:channel|timescale_r\(12));

-- Location: FF_X21_Y72_N14
\timers:3:channel|timescale_r[14]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \IO_DATA[14]~input_o\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sload => VCC,
	ena => \timers:3:channel|process_0~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:3:channel|timescale_r\(14));

-- Location: FF_X22_Y72_N37
\timers:3:channel|prescaler|ms_count[12]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:3:channel|prescaler|Add1~17_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:3:channel|prescaler|ms_count[4]~0_combout\,
	ena => \timers:3:channel|prescaler|ms_count[4]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:3:channel|prescaler|ms_count\(12));

-- Location: LABCELL_X22_Y72_N36
\timers:3:channel|prescaler|Add1~17\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|prescaler|Add1~17_sumout\ = SUM(( \timers:3:channel|prescaler|ms_count\(12) ) + ( GND ) + ( \timers:3:channel|prescaler|Add1~6\ ))
-- \timers:3:channel|prescaler|Add1~18\ = CARRY(( \timers:3:channel|prescaler|ms_count\(12) ) + ( GND ) + ( \timers:3:channel|prescaler|Add1~6\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000000011111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datad => \timers:3:channel|prescaler|ALT_INV_ms_count\(12),
	cin => \timers:3:channel|prescaler|Add1~6\,
	sumout => \timers:3:channel|prescaler|Add1~17_sumout\,
	cout => \timers:3:channel|prescaler|Add1~18\);

-- Location: FF_X22_Y72_N40
\timers:3:channel|prescaler|ms_count[13]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:3:channel|prescaler|Add1~13_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:3:channel|prescaler|ms_count[4]~0_combout\,
	ena => \timers:3:channel|prescaler|ms_count[4]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:3:channel|prescaler|ms_count\(13));

-- Location: LABCELL_X22_Y72_N39
\timers:3:channel|prescaler|Add1~13\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|prescaler|Add1~13_sumout\ = SUM(( \timers:3:channel|prescaler|ms_count\(13) ) + ( GND ) + ( \timers:3:channel|prescaler|Add1~18\ ))
-- \timers:3:channel|prescaler|Add1~14\ = CARRY(( \timers:3:channel|prescaler|ms_count\(13) ) + ( GND ) + ( \timers:3:channel|prescaler|Add1~18\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:3:channel|prescaler|ALT_INV_ms_count\(13),
	cin => \timers:3:channel|prescaler|Add1~18\,
	sumout => \timers:3:channel|prescaler|Add1~13_sumout\,
	cout => \timers:3:channel|prescaler|Add1~14\);

-- Location: FF_X22_Y72_N55
\timers:3:channel|timescale_r[13]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \IO_DATA[13]~input_o\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sload => VCC,
	ena => \timers:3:channel|process_0~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:3:channel|timescale_r\(13));

-- Location: FF_X22_Y72_N43
\timers:3:channel|prescaler|ms_count[14]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:3:channel|prescaler|Add1~9_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:3:channel|prescaler|ms_count[4]~0_combout\,
	ena => \timers:3:channel|prescaler|ms_count[4]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:3:channel|prescaler|ms_count\(14));

-- Location: LABCELL_X22_Y72_N42
\timers:3:channel|prescaler|Add1~9\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|prescaler|Add1~9_sumout\ = SUM(( \timers:3:channel|prescaler|ms_count\(14) ) + ( GND ) + ( \timers:3:channel|prescaler|Add1~14\ ))
-- \timers:3:channel|prescaler|Add1~10\ = CARRY(( \timers:3:channel|prescaler|ms_count\(14) ) + ( GND ) + ( \timers:3:channel|prescaler|Add1~14\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000000011111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datad => \timers:3:channel|prescaler|ALT_INV_ms_count\(14),
	cin => \timers:3:channel|prescaler|Add1~14\,
	sumout => \timers:3:channel|prescaler|Add1~9_sumout\,
	cout => \timers:3:channel|prescaler|Add1~10\);

-- Location: LABCELL_X22_Y72_N54
\timers:3:channel|prescaler|LessThan1~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|prescaler|LessThan1~0_combout\ = ( \timers:3:channel|timescale_r\(13) & ( \timers:3:channel|prescaler|Add1~9_sumout\ & ( (\timers:3:channel|timescale_r\(14) & (\timers:3:channel|prescaler|Add1~13_sumout\ & 
-- (!\timers:3:channel|timescale_r\(12) $ (\timers:3:channel|prescaler|Add1~17_sumout\)))) ) ) ) # ( !\timers:3:channel|timescale_r\(13) & ( \timers:3:channel|prescaler|Add1~9_sumout\ & ( (\timers:3:channel|timescale_r\(14) & 
-- (!\timers:3:channel|prescaler|Add1~13_sumout\ & (!\timers:3:channel|timescale_r\(12) $ (\timers:3:channel|prescaler|Add1~17_sumout\)))) ) ) ) # ( \timers:3:channel|timescale_r\(13) & ( !\timers:3:channel|prescaler|Add1~9_sumout\ & ( 
-- (!\timers:3:channel|timescale_r\(14) & (\timers:3:channel|prescaler|Add1~13_sumout\ & (!\timers:3:channel|timescale_r\(12) $ (\timers:3:channel|prescaler|Add1~17_sumout\)))) ) ) ) # ( !\timers:3:channel|timescale_r\(13) & ( 
-- !\timers:3:channel|prescaler|Add1~9_sumout\ & ( (!\timers:3:channel|timescale_r\(14) & (!\timers:3:channel|prescaler|Add1~13_sumout\ & (!\timers:3:channel|timescale_r\(12) $ (\timers:3:channel|prescaler|Add1~17_sumout\)))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1000010000000000000000001000010000100001000000000000000000100001",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:3:channel|ALT_INV_timescale_r\(12),
	datab => \timers:3:channel|ALT_INV_timescale_r\(14),
	datac => \timers:3:channel|prescaler|ALT_INV_Add1~17_sumout\,
	datad => \timers:3:channel|prescaler|ALT_INV_Add1~13_sumout\,
	datae => \timers:3:channel|ALT_INV_timescale_r\(13),
	dataf => \timers:3:channel|prescaler|ALT_INV_Add1~9_sumout\,
	combout => \timers:3:channel|prescaler|LessThan1~0_combout\);

-- Location: MLABCELL_X21_Y72_N15
\timers:3:channel|prescaler|LessThan1~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|prescaler|LessThan1~1_combout\ = ( \timers:3:channel|prescaler|Add1~9_sumout\ & ( \timers:3:channel|prescaler|Add1~17_sumout\ & ( (\timers:3:channel|timescale_r\(14) & (\timers:3:channel|timescale_r\(13) & 
-- !\timers:3:channel|prescaler|Add1~13_sumout\)) ) ) ) # ( !\timers:3:channel|prescaler|Add1~9_sumout\ & ( \timers:3:channel|prescaler|Add1~17_sumout\ & ( ((\timers:3:channel|timescale_r\(13) & !\timers:3:channel|prescaler|Add1~13_sumout\)) # 
-- (\timers:3:channel|timescale_r\(14)) ) ) ) # ( \timers:3:channel|prescaler|Add1~9_sumout\ & ( !\timers:3:channel|prescaler|Add1~17_sumout\ & ( (\timers:3:channel|timescale_r\(14) & ((!\timers:3:channel|timescale_r\(13) & 
-- (\timers:3:channel|timescale_r\(12) & !\timers:3:channel|prescaler|Add1~13_sumout\)) # (\timers:3:channel|timescale_r\(13) & ((!\timers:3:channel|prescaler|Add1~13_sumout\) # (\timers:3:channel|timescale_r\(12)))))) ) ) ) # ( 
-- !\timers:3:channel|prescaler|Add1~9_sumout\ & ( !\timers:3:channel|prescaler|Add1~17_sumout\ & ( ((!\timers:3:channel|timescale_r\(13) & (\timers:3:channel|timescale_r\(12) & !\timers:3:channel|prescaler|Add1~13_sumout\)) # 
-- (\timers:3:channel|timescale_r\(13) & ((!\timers:3:channel|prescaler|Add1~13_sumout\) # (\timers:3:channel|timescale_r\(12))))) # (\timers:3:channel|timescale_r\(14)) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0111111101010111000101010000000101110111010101010001000100000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:3:channel|ALT_INV_timescale_r\(14),
	datab => \timers:3:channel|ALT_INV_timescale_r\(13),
	datac => \timers:3:channel|ALT_INV_timescale_r\(12),
	datad => \timers:3:channel|prescaler|ALT_INV_Add1~13_sumout\,
	datae => \timers:3:channel|prescaler|ALT_INV_Add1~9_sumout\,
	dataf => \timers:3:channel|prescaler|ALT_INV_Add1~17_sumout\,
	combout => \timers:3:channel|prescaler|LessThan1~1_combout\);

-- Location: MLABCELL_X21_Y72_N54
\timers:3:channel|prescaler|LessThan1~2\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|prescaler|LessThan1~2_combout\ = ( \timers:3:channel|prescaler|LessThan1~0_combout\ & ( !\timers:3:channel|prescaler|LessThan1~1_combout\ & ( (!\timers:3:channel|timescale_r\(11) & (((!\timers:3:channel|timescale_r\(10)) # 
-- (\timers:3:channel|prescaler|Add1~5_sumout\)) # (\timers:3:channel|prescaler|Add1~21_sumout\))) # (\timers:3:channel|timescale_r\(11) & (\timers:3:channel|prescaler|Add1~5_sumout\ & ((!\timers:3:channel|timescale_r\(10)) # 
-- (\timers:3:channel|prescaler|Add1~21_sumout\)))) ) ) ) # ( !\timers:3:channel|prescaler|LessThan1~0_combout\ & ( !\timers:3:channel|prescaler|LessThan1~1_combout\ ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111111111111111110011110100110100000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:3:channel|prescaler|ALT_INV_Add1~21_sumout\,
	datab => \timers:3:channel|ALT_INV_timescale_r\(11),
	datac => \timers:3:channel|prescaler|ALT_INV_Add1~5_sumout\,
	datad => \timers:3:channel|ALT_INV_timescale_r\(10),
	datae => \timers:3:channel|prescaler|ALT_INV_LessThan1~0_combout\,
	dataf => \timers:3:channel|prescaler|ALT_INV_LessThan1~1_combout\,
	combout => \timers:3:channel|prescaler|LessThan1~2_combout\);

-- Location: MLABCELL_X21_Y72_N51
\timers:3:channel|timescale_r[9]~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|timescale_r[9]~1_combout\ = ( !\IO_DATA[9]~input_o\ )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111111111111111111111111111111100000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataf => \ALT_INV_IO_DATA[9]~input_o\,
	combout => \timers:3:channel|timescale_r[9]~1_combout\);

-- Location: FF_X21_Y72_N53
\timers:3:channel|timescale_r[9]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:3:channel|timescale_r[9]~1_combout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	ena => \timers:3:channel|process_0~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:3:channel|timescale_r\(9));

-- Location: LABCELL_X23_Y72_N36
\timers:3:channel|prescaler|LessThan1~4\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|prescaler|LessThan1~4_combout\ = ( \timers:3:channel|timescale_r\(10) & ( !\timers:3:channel|prescaler|Add1~21_sumout\ ) ) # ( !\timers:3:channel|timescale_r\(10) & ( \timers:3:channel|prescaler|Add1~21_sumout\ ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000111100001111000011110000111111110000111100001111000011110000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:3:channel|prescaler|ALT_INV_Add1~21_sumout\,
	dataf => \timers:3:channel|ALT_INV_timescale_r\(10),
	combout => \timers:3:channel|prescaler|LessThan1~4_combout\);

-- Location: MLABCELL_X21_Y72_N36
\timers:3:channel|timescale_r[8]~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|timescale_r[8]~0_combout\ = ( !\IO_DATA[8]~input_o\ )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111111111111111111111111111111100000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataf => \ALT_INV_IO_DATA[8]~input_o\,
	combout => \timers:3:channel|timescale_r[8]~0_combout\);

-- Location: FF_X21_Y72_N38
\timers:3:channel|timescale_r[8]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:3:channel|timescale_r[8]~0_combout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	ena => \timers:3:channel|process_0~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:3:channel|timescale_r\(8));

-- Location: MLABCELL_X21_Y72_N18
\timers:3:channel|prescaler|LessThan1~14\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|prescaler|LessThan1~14_combout\ = ( !\timers:3:channel|prescaler|Add1~25_sumout\ & ( !\timers:3:channel|timescale_r\(8) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111000011110000111100001111000000000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:3:channel|ALT_INV_timescale_r\(8),
	dataf => \timers:3:channel|prescaler|ALT_INV_Add1~25_sumout\,
	combout => \timers:3:channel|prescaler|LessThan1~14_combout\);

-- Location: LABCELL_X23_Y72_N33
\timers:3:channel|prescaler|LessThan1~3\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|prescaler|LessThan1~3_combout\ = ( !\timers:3:channel|prescaler|Add1~5_sumout\ & ( \timers:3:channel|timescale_r\(11) ) ) # ( \timers:3:channel|prescaler|Add1~5_sumout\ & ( !\timers:3:channel|timescale_r\(11) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111111111111111111110000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datae => \timers:3:channel|prescaler|ALT_INV_Add1~5_sumout\,
	dataf => \timers:3:channel|ALT_INV_timescale_r\(11),
	combout => \timers:3:channel|prescaler|LessThan1~3_combout\);

-- Location: MLABCELL_X21_Y72_N24
\timers:3:channel|prescaler|LessThan1~15\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|prescaler|LessThan1~15_combout\ = ( \timers:3:channel|prescaler|LessThan1~0_combout\ & ( !\timers:3:channel|prescaler|LessThan1~3_combout\ & ( (!\timers:3:channel|prescaler|LessThan1~4_combout\ & ((!\timers:3:channel|timescale_r\(9) & 
-- ((!\timers:3:channel|prescaler|Add1~29_sumout\) # (\timers:3:channel|prescaler|LessThan1~14_combout\))) # (\timers:3:channel|timescale_r\(9) & (!\timers:3:channel|prescaler|Add1~29_sumout\ & \timers:3:channel|prescaler|LessThan1~14_combout\)))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000100000001110000000000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:3:channel|ALT_INV_timescale_r\(9),
	datab => \timers:3:channel|prescaler|ALT_INV_Add1~29_sumout\,
	datac => \timers:3:channel|prescaler|ALT_INV_LessThan1~4_combout\,
	datad => \timers:3:channel|prescaler|ALT_INV_LessThan1~14_combout\,
	datae => \timers:3:channel|prescaler|ALT_INV_LessThan1~0_combout\,
	dataf => \timers:3:channel|prescaler|ALT_INV_LessThan1~3_combout\,
	combout => \timers:3:channel|prescaler|LessThan1~15_combout\);

-- Location: FF_X22_Y72_N49
\timers:3:channel|timescale_r[15]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \IO_DATA[15]~input_o\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sload => VCC,
	ena => \timers:3:channel|process_0~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:3:channel|timescale_r\(15));

-- Location: MLABCELL_X21_Y72_N45
\timers:3:channel|prescaler|LessThan1~5\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|prescaler|LessThan1~5_combout\ = ( !\timers:3:channel|timescale_r\(8) & ( \timers:3:channel|prescaler|Add1~25_sumout\ ) ) # ( \timers:3:channel|timescale_r\(8) & ( !\timers:3:channel|prescaler|Add1~25_sumout\ ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111111111111111111110000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datae => \timers:3:channel|ALT_INV_timescale_r\(8),
	dataf => \timers:3:channel|prescaler|ALT_INV_Add1~25_sumout\,
	combout => \timers:3:channel|prescaler|LessThan1~5_combout\);

-- Location: LABCELL_X23_Y72_N45
\timers:3:channel|prescaler|LessThan1~6\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|prescaler|LessThan1~6_combout\ = ( \timers:3:channel|timescale_r\(9) & ( !\timers:3:channel|prescaler|Add1~29_sumout\ ) ) # ( !\timers:3:channel|timescale_r\(9) & ( \timers:3:channel|prescaler|Add1~29_sumout\ ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000011111111000000001111111111111111000000001111111100000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datad => \timers:3:channel|prescaler|ALT_INV_Add1~29_sumout\,
	dataf => \timers:3:channel|ALT_INV_timescale_r\(9),
	combout => \timers:3:channel|prescaler|LessThan1~6_combout\);

-- Location: FF_X23_Y72_N17
\timers:3:channel|timescale_r[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \IO_DATA[0]~input_o\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sload => VCC,
	ena => \timers:3:channel|process_0~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:3:channel|timescale_r\(0));

-- Location: MLABCELL_X21_Y71_N21
\timers:3:channel|timescale_r[2]~feeder\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|timescale_r[2]~feeder_combout\ = ( \IO_DATA[2]~input_o\ )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000011111111111111111111111111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataf => \ALT_INV_IO_DATA[2]~input_o\,
	combout => \timers:3:channel|timescale_r[2]~feeder_combout\);

-- Location: FF_X21_Y71_N23
\timers:3:channel|timescale_r[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:3:channel|timescale_r[2]~feeder_combout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	ena => \timers:3:channel|process_0~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:3:channel|timescale_r\(2));

-- Location: FF_X23_Y72_N8
\timers:3:channel|timescale_r[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \IO_DATA[1]~input_o\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sload => VCC,
	ena => \timers:3:channel|process_0~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:3:channel|timescale_r\(1));

-- Location: LABCELL_X23_Y72_N6
\timers:3:channel|prescaler|LessThan1~8\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|prescaler|LessThan1~8_combout\ = ( \timers:3:channel|timescale_r\(1) & ( \timers:3:channel|prescaler|Add1~41_sumout\ & ( (\timers:3:channel|timescale_r\(2) & ((!\timers:3:channel|prescaler|Add1~45_sumout\) # 
-- ((!\timers:3:channel|prescaler|Add1~49_sumout\ & \timers:3:channel|timescale_r\(0))))) ) ) ) # ( !\timers:3:channel|timescale_r\(1) & ( \timers:3:channel|prescaler|Add1~41_sumout\ & ( (!\timers:3:channel|prescaler|Add1~49_sumout\ & 
-- (\timers:3:channel|timescale_r\(0) & (\timers:3:channel|timescale_r\(2) & !\timers:3:channel|prescaler|Add1~45_sumout\))) ) ) ) # ( \timers:3:channel|timescale_r\(1) & ( !\timers:3:channel|prescaler|Add1~41_sumout\ & ( (!\timers:3:channel|timescale_r\(2) 
-- & ((!\timers:3:channel|prescaler|Add1~45_sumout\) # ((!\timers:3:channel|prescaler|Add1~49_sumout\ & \timers:3:channel|timescale_r\(0))))) ) ) ) # ( !\timers:3:channel|timescale_r\(1) & ( !\timers:3:channel|prescaler|Add1~41_sumout\ & ( 
-- (!\timers:3:channel|prescaler|Add1~49_sumout\ & (\timers:3:channel|timescale_r\(0) & (!\timers:3:channel|timescale_r\(2) & !\timers:3:channel|prescaler|Add1~45_sumout\))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0010000000000000111100000010000000000010000000000000111100000010",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:3:channel|prescaler|ALT_INV_Add1~49_sumout\,
	datab => \timers:3:channel|ALT_INV_timescale_r\(0),
	datac => \timers:3:channel|ALT_INV_timescale_r\(2),
	datad => \timers:3:channel|prescaler|ALT_INV_Add1~45_sumout\,
	datae => \timers:3:channel|ALT_INV_timescale_r\(1),
	dataf => \timers:3:channel|prescaler|ALT_INV_Add1~41_sumout\,
	combout => \timers:3:channel|prescaler|LessThan1~8_combout\);

-- Location: MLABCELL_X21_Y72_N39
\timers:3:channel|timescale_r[3]~2\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|timescale_r[3]~2_combout\ = ( !\IO_DATA[3]~input_o\ )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111111111111111111111111111111100000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataf => \ALT_INV_IO_DATA[3]~input_o\,
	combout => \timers:3:channel|timescale_r[3]~2_combout\);

-- Location: FF_X21_Y72_N41
\timers:3:channel|timescale_r[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:3:channel|timescale_r[3]~2_combout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	ena => \timers:3:channel|process_0~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:3:channel|timescale_r\(3));

-- Location: FF_X23_Y72_N49
\timers:3:channel|timescale_r[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \IO_DATA[4]~input_o\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sload => VCC,
	ena => \timers:3:channel|process_0~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:3:channel|timescale_r\(4));

-- Location: LABCELL_X23_Y72_N42
\timers:3:channel|prescaler|LessThan1~7\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|prescaler|LessThan1~7_combout\ = ( \timers:3:channel|prescaler|Add1~37_sumout\ & ( (!\timers:3:channel|timescale_r\(3) & (!\timers:3:channel|timescale_r\(4) $ (\timers:3:channel|prescaler|Add1~33_sumout\))) ) ) # ( 
-- !\timers:3:channel|prescaler|Add1~37_sumout\ & ( (\timers:3:channel|timescale_r\(3) & (!\timers:3:channel|timescale_r\(4) $ (\timers:3:channel|prescaler|Add1~33_sumout\))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0100010000010001010001000001000110001000001000101000100000100010",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:3:channel|ALT_INV_timescale_r\(3),
	datab => \timers:3:channel|ALT_INV_timescale_r\(4),
	datad => \timers:3:channel|prescaler|ALT_INV_Add1~33_sumout\,
	dataf => \timers:3:channel|prescaler|ALT_INV_Add1~37_sumout\,
	combout => \timers:3:channel|prescaler|LessThan1~7_combout\);

-- Location: LABCELL_X23_Y72_N48
\timers:3:channel|prescaler|LessThan1~9\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|prescaler|LessThan1~9_combout\ = ( \timers:3:channel|timescale_r\(4) & ( \timers:3:channel|prescaler|Add1~41_sumout\ & ( (!\timers:3:channel|prescaler|Add1~33_sumout\) # ((!\timers:3:channel|timescale_r\(3) & 
-- !\timers:3:channel|prescaler|Add1~37_sumout\)) ) ) ) # ( !\timers:3:channel|timescale_r\(4) & ( \timers:3:channel|prescaler|Add1~41_sumout\ & ( (!\timers:3:channel|timescale_r\(3) & (!\timers:3:channel|prescaler|Add1~33_sumout\ & 
-- !\timers:3:channel|prescaler|Add1~37_sumout\)) ) ) ) # ( \timers:3:channel|timescale_r\(4) & ( !\timers:3:channel|prescaler|Add1~41_sumout\ & ( (!\timers:3:channel|prescaler|Add1~33_sumout\) # ((!\timers:3:channel|timescale_r\(2) & 
-- (!\timers:3:channel|timescale_r\(3) & !\timers:3:channel|prescaler|Add1~37_sumout\)) # (\timers:3:channel|timescale_r\(2) & ((!\timers:3:channel|timescale_r\(3)) # (!\timers:3:channel|prescaler|Add1~37_sumout\)))) ) ) ) # ( 
-- !\timers:3:channel|timescale_r\(4) & ( !\timers:3:channel|prescaler|Add1~41_sumout\ & ( (!\timers:3:channel|prescaler|Add1~33_sumout\ & ((!\timers:3:channel|timescale_r\(2) & (!\timers:3:channel|timescale_r\(3) & 
-- !\timers:3:channel|prescaler|Add1~37_sumout\)) # (\timers:3:channel|timescale_r\(2) & ((!\timers:3:channel|timescale_r\(3)) # (!\timers:3:channel|prescaler|Add1~37_sumout\))))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1101000001000000111111011111010011000000000000001111110011110000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:3:channel|ALT_INV_timescale_r\(2),
	datab => \timers:3:channel|ALT_INV_timescale_r\(3),
	datac => \timers:3:channel|prescaler|ALT_INV_Add1~33_sumout\,
	datad => \timers:3:channel|prescaler|ALT_INV_Add1~37_sumout\,
	datae => \timers:3:channel|ALT_INV_timescale_r\(4),
	dataf => \timers:3:channel|prescaler|ALT_INV_Add1~41_sumout\,
	combout => \timers:3:channel|prescaler|LessThan1~9_combout\);

-- Location: MLABCELL_X21_Y72_N6
\timers:3:channel|timescale_r[7]~3\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|timescale_r[7]~3_combout\ = !\IO_DATA[7]~input_o\

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111000011110000111100001111000011110000111100001111000011110000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \ALT_INV_IO_DATA[7]~input_o\,
	combout => \timers:3:channel|timescale_r[7]~3_combout\);

-- Location: FF_X21_Y72_N8
\timers:3:channel|timescale_r[7]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:3:channel|timescale_r[7]~3_combout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	ena => \timers:3:channel|process_0~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:3:channel|timescale_r\(7));

-- Location: MLABCELL_X21_Y72_N9
\timers:3:channel|timescale_r[6]~4\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|timescale_r[6]~4_combout\ = ( !\IO_DATA[6]~input_o\ )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111111111111111111111111111111100000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataf => \ALT_INV_IO_DATA[6]~input_o\,
	combout => \timers:3:channel|timescale_r[6]~4_combout\);

-- Location: FF_X21_Y72_N11
\timers:3:channel|timescale_r[6]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:3:channel|timescale_r[6]~4_combout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	ena => \timers:3:channel|process_0~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:3:channel|timescale_r\(6));

-- Location: LABCELL_X23_Y72_N39
\timers:3:channel|timescale_r[5]~5\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|timescale_r[5]~5_combout\ = !\IO_DATA[5]~input_o\

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1010101010101010101010101010101010101010101010101010101010101010",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_IO_DATA[5]~input_o\,
	combout => \timers:3:channel|timescale_r[5]~5_combout\);

-- Location: FF_X23_Y72_N38
\timers:3:channel|timescale_r[5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \timers:3:channel|timescale_r[5]~5_combout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sload => VCC,
	ena => \timers:3:channel|process_0~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:3:channel|timescale_r\(5));

-- Location: LABCELL_X23_Y72_N54
\timers:3:channel|prescaler|LessThan1~11\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|prescaler|LessThan1~11_combout\ = ( \timers:3:channel|prescaler|Add1~53_sumout\ & ( \timers:3:channel|prescaler|Add1~57_sumout\ & ( (!\timers:3:channel|timescale_r\(7) & (!\timers:3:channel|timescale_r\(6) & 
-- (!\timers:3:channel|timescale_r\(5) & !\timers:3:channel|prescaler|Add1~61_sumout\))) ) ) ) # ( !\timers:3:channel|prescaler|Add1~53_sumout\ & ( \timers:3:channel|prescaler|Add1~57_sumout\ & ( (!\timers:3:channel|timescale_r\(7)) # 
-- ((!\timers:3:channel|timescale_r\(6) & (!\timers:3:channel|timescale_r\(5) & !\timers:3:channel|prescaler|Add1~61_sumout\))) ) ) ) # ( \timers:3:channel|prescaler|Add1~53_sumout\ & ( !\timers:3:channel|prescaler|Add1~57_sumout\ & ( 
-- (!\timers:3:channel|timescale_r\(7) & ((!\timers:3:channel|timescale_r\(6)) # ((!\timers:3:channel|timescale_r\(5) & !\timers:3:channel|prescaler|Add1~61_sumout\)))) ) ) ) # ( !\timers:3:channel|prescaler|Add1~53_sumout\ & ( 
-- !\timers:3:channel|prescaler|Add1~57_sumout\ & ( (!\timers:3:channel|timescale_r\(7)) # ((!\timers:3:channel|timescale_r\(6)) # ((!\timers:3:channel|timescale_r\(5) & !\timers:3:channel|prescaler|Add1~61_sumout\))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111111011101110101010001000100011101010101010101000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:3:channel|ALT_INV_timescale_r\(7),
	datab => \timers:3:channel|ALT_INV_timescale_r\(6),
	datac => \timers:3:channel|ALT_INV_timescale_r\(5),
	datad => \timers:3:channel|prescaler|ALT_INV_Add1~61_sumout\,
	datae => \timers:3:channel|prescaler|ALT_INV_Add1~53_sumout\,
	dataf => \timers:3:channel|prescaler|ALT_INV_Add1~57_sumout\,
	combout => \timers:3:channel|prescaler|LessThan1~11_combout\);

-- Location: LABCELL_X23_Y72_N12
\timers:3:channel|prescaler|LessThan1~10\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|prescaler|LessThan1~10_combout\ = ( \timers:3:channel|prescaler|Add1~53_sumout\ & ( \timers:3:channel|prescaler|Add1~61_sumout\ & ( (!\timers:3:channel|timescale_r\(7) & (!\timers:3:channel|timescale_r\(5) & 
-- (!\timers:3:channel|timescale_r\(6) $ (!\timers:3:channel|prescaler|Add1~57_sumout\)))) ) ) ) # ( !\timers:3:channel|prescaler|Add1~53_sumout\ & ( \timers:3:channel|prescaler|Add1~61_sumout\ & ( (\timers:3:channel|timescale_r\(7) & 
-- (!\timers:3:channel|timescale_r\(5) & (!\timers:3:channel|timescale_r\(6) $ (!\timers:3:channel|prescaler|Add1~57_sumout\)))) ) ) ) # ( \timers:3:channel|prescaler|Add1~53_sumout\ & ( !\timers:3:channel|prescaler|Add1~61_sumout\ & ( 
-- (!\timers:3:channel|timescale_r\(7) & (\timers:3:channel|timescale_r\(5) & (!\timers:3:channel|timescale_r\(6) $ (!\timers:3:channel|prescaler|Add1~57_sumout\)))) ) ) ) # ( !\timers:3:channel|prescaler|Add1~53_sumout\ & ( 
-- !\timers:3:channel|prescaler|Add1~61_sumout\ & ( (\timers:3:channel|timescale_r\(7) & (\timers:3:channel|timescale_r\(5) & (!\timers:3:channel|timescale_r\(6) $ (!\timers:3:channel|prescaler|Add1~57_sumout\)))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000100000100000000100000100000010000010000000010000010000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:3:channel|ALT_INV_timescale_r\(7),
	datab => \timers:3:channel|ALT_INV_timescale_r\(6),
	datac => \timers:3:channel|ALT_INV_timescale_r\(5),
	datad => \timers:3:channel|prescaler|ALT_INV_Add1~57_sumout\,
	datae => \timers:3:channel|prescaler|ALT_INV_Add1~53_sumout\,
	dataf => \timers:3:channel|prescaler|ALT_INV_Add1~61_sumout\,
	combout => \timers:3:channel|prescaler|LessThan1~10_combout\);

-- Location: LABCELL_X23_Y72_N3
\timers:3:channel|prescaler|LessThan1~12\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|prescaler|LessThan1~12_combout\ = ( !\timers:3:channel|prescaler|LessThan1~11_combout\ & ( \timers:3:channel|prescaler|LessThan1~10_combout\ & ( (!\timers:3:channel|prescaler|LessThan1~9_combout\ & 
-- ((!\timers:3:channel|prescaler|LessThan1~8_combout\) # (!\timers:3:channel|prescaler|LessThan1~7_combout\))) ) ) ) # ( !\timers:3:channel|prescaler|LessThan1~11_combout\ & ( !\timers:3:channel|prescaler|LessThan1~10_combout\ ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111111111111111000000000000000011111100000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \timers:3:channel|prescaler|ALT_INV_LessThan1~8_combout\,
	datac => \timers:3:channel|prescaler|ALT_INV_LessThan1~7_combout\,
	datad => \timers:3:channel|prescaler|ALT_INV_LessThan1~9_combout\,
	datae => \timers:3:channel|prescaler|ALT_INV_LessThan1~11_combout\,
	dataf => \timers:3:channel|prescaler|ALT_INV_LessThan1~10_combout\,
	combout => \timers:3:channel|prescaler|LessThan1~12_combout\);

-- Location: LABCELL_X23_Y72_N18
\timers:3:channel|prescaler|LessThan1~13\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|prescaler|LessThan1~13_combout\ = ( !\timers:3:channel|prescaler|LessThan1~12_combout\ & ( \timers:3:channel|prescaler|LessThan1~0_combout\ & ( (!\timers:3:channel|prescaler|LessThan1~3_combout\ & 
-- (!\timers:3:channel|prescaler|LessThan1~4_combout\ & (\timers:3:channel|prescaler|LessThan1~5_combout\ & \timers:3:channel|prescaler|LessThan1~6_combout\))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000010000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:3:channel|prescaler|ALT_INV_LessThan1~3_combout\,
	datab => \timers:3:channel|prescaler|ALT_INV_LessThan1~4_combout\,
	datac => \timers:3:channel|prescaler|ALT_INV_LessThan1~5_combout\,
	datad => \timers:3:channel|prescaler|ALT_INV_LessThan1~6_combout\,
	datae => \timers:3:channel|prescaler|ALT_INV_LessThan1~12_combout\,
	dataf => \timers:3:channel|prescaler|ALT_INV_LessThan1~0_combout\,
	combout => \timers:3:channel|prescaler|LessThan1~13_combout\);

-- Location: LABCELL_X22_Y72_N48
\timers:3:channel|prescaler|ms_count[4]~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|prescaler|ms_count[4]~0_combout\ = ( \timers:3:channel|timescale_r\(15) & ( \timers:3:channel|prescaler|LessThan1~13_combout\ & ( \timers:3:channel|clear_prescale~q\ ) ) ) # ( !\timers:3:channel|timescale_r\(15) & ( 
-- \timers:3:channel|prescaler|LessThan1~13_combout\ & ( (\timers:3:channel|clear_prescale~q\) # (\timers:3:channel|prescaler|Add1~1_sumout\) ) ) ) # ( \timers:3:channel|timescale_r\(15) & ( !\timers:3:channel|prescaler|LessThan1~13_combout\ & ( 
-- ((\timers:3:channel|prescaler|Add1~1_sumout\ & (\timers:3:channel|prescaler|LessThan1~2_combout\ & !\timers:3:channel|prescaler|LessThan1~15_combout\))) # (\timers:3:channel|clear_prescale~q\) ) ) ) # ( !\timers:3:channel|timescale_r\(15) & ( 
-- !\timers:3:channel|prescaler|LessThan1~13_combout\ & ( (((\timers:3:channel|prescaler|LessThan1~2_combout\ & !\timers:3:channel|prescaler|LessThan1~15_combout\)) # (\timers:3:channel|clear_prescale~q\)) # (\timers:3:channel|prescaler|Add1~1_sumout\) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0111111101110111001101110011001101110111011101110011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:3:channel|prescaler|ALT_INV_Add1~1_sumout\,
	datab => \timers:3:channel|ALT_INV_clear_prescale~q\,
	datac => \timers:3:channel|prescaler|ALT_INV_LessThan1~2_combout\,
	datad => \timers:3:channel|prescaler|ALT_INV_LessThan1~15_combout\,
	datae => \timers:3:channel|ALT_INV_timescale_r\(15),
	dataf => \timers:3:channel|prescaler|ALT_INV_LessThan1~13_combout\,
	combout => \timers:3:channel|prescaler|ms_count[4]~0_combout\);

-- Location: FF_X22_Y72_N47
\timers:3:channel|prescaler|ms_count[15]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:3:channel|prescaler|Add1~1_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:3:channel|prescaler|ms_count[4]~0_combout\,
	ena => \timers:3:channel|prescaler|ms_count[4]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:3:channel|prescaler|ms_count\(15));

-- Location: LABCELL_X22_Y72_N45
\timers:3:channel|prescaler|Add1~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|prescaler|Add1~1_sumout\ = SUM(( \timers:3:channel|prescaler|ms_count\(15) ) + ( GND ) + ( \timers:3:channel|prescaler|Add1~10\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:3:channel|prescaler|ALT_INV_ms_count\(15),
	cin => \timers:3:channel|prescaler|Add1~10\,
	sumout => \timers:3:channel|prescaler|Add1~1_sumout\);

-- Location: LABCELL_X22_Y65_N45
\timers:3:channel|prescaler|TICK~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|prescaler|TICK~0_combout\ = ( !\timers:3:channel|clear_prescale~q\ & ( (\timers:3:channel|running_r~q\ & \timers:3:channel|prescaler|LessThan0~0_combout\) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000001111000000000000111100000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:3:channel|ALT_INV_running_r~q\,
	datad => \timers:3:channel|prescaler|ALT_INV_LessThan0~0_combout\,
	dataf => \timers:3:channel|ALT_INV_clear_prescale~q\,
	combout => \timers:3:channel|prescaler|TICK~0_combout\);

-- Location: LABCELL_X23_Y72_N24
\timers:3:channel|prescaler|TICK~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|prescaler|TICK~1_combout\ = ( \timers:3:channel|prescaler|LessThan1~2_combout\ & ( \timers:3:channel|timescale_r\(15) & ( (\timers:3:channel|prescaler|Add1~1_sumout\ & (\timers:3:channel|prescaler|TICK~0_combout\ & 
-- (!\timers:3:channel|prescaler|LessThan1~13_combout\ & !\timers:3:channel|prescaler|LessThan1~15_combout\))) ) ) ) # ( \timers:3:channel|prescaler|LessThan1~2_combout\ & ( !\timers:3:channel|timescale_r\(15) & ( (\timers:3:channel|prescaler|TICK~0_combout\ 
-- & (((!\timers:3:channel|prescaler|LessThan1~13_combout\ & !\timers:3:channel|prescaler|LessThan1~15_combout\)) # (\timers:3:channel|prescaler|Add1~1_sumout\))) ) ) ) # ( !\timers:3:channel|prescaler|LessThan1~2_combout\ & ( 
-- !\timers:3:channel|timescale_r\(15) & ( (\timers:3:channel|prescaler|Add1~1_sumout\ & \timers:3:channel|prescaler|TICK~0_combout\) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0001000100010001001100010001000100000000000000000001000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:3:channel|prescaler|ALT_INV_Add1~1_sumout\,
	datab => \timers:3:channel|prescaler|ALT_INV_TICK~0_combout\,
	datac => \timers:3:channel|prescaler|ALT_INV_LessThan1~13_combout\,
	datad => \timers:3:channel|prescaler|ALT_INV_LessThan1~15_combout\,
	datae => \timers:3:channel|prescaler|ALT_INV_LessThan1~2_combout\,
	dataf => \timers:3:channel|ALT_INV_timescale_r\(15),
	combout => \timers:3:channel|prescaler|TICK~1_combout\);

-- Location: FF_X23_Y72_N25
\timers:3:channel|prescaler|TICK\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:3:channel|prescaler|TICK~1_combout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:3:channel|prescaler|TICK~q\);

-- Location: LABCELL_X22_Y65_N48
\timers:3:channel|running_r~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|running_r~0_combout\ = ( \timers:3:channel|mode_r\(0) & ( \timers:3:channel|prescaler|TICK~q\ & ( (\timers:3:channel|running_r~q\ & \timers:3:channel|mode_r\(1)) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000000000001100000011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \timers:3:channel|ALT_INV_running_r~q\,
	datac => \timers:3:channel|ALT_INV_mode_r\(1),
	datae => \timers:3:channel|ALT_INV_mode_r\(0),
	dataf => \timers:3:channel|prescaler|ALT_INV_TICK~q\,
	combout => \timers:3:channel|running_r~0_combout\);

-- Location: FF_X24_Y63_N47
\timers:3:channel|duration_r[15]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \IO_DATA[15]~input_o\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sload => VCC,
	ena => \timers:3:channel|process_0~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:3:channel|duration_r\(15));

-- Location: FF_X24_Y63_N44
\timers:3:channel|duration_r[14]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \IO_DATA[14]~input_o\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sload => VCC,
	ena => \timers:3:channel|process_0~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:3:channel|duration_r\(14));

-- Location: FF_X24_Y63_N41
\timers:3:channel|duration_r[13]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \IO_DATA[13]~input_o\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sload => VCC,
	ena => \timers:3:channel|process_0~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:3:channel|duration_r\(13));

-- Location: FF_X24_Y63_N38
\timers:3:channel|duration_r[12]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \IO_DATA[12]~input_o\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sload => VCC,
	ena => \timers:3:channel|process_0~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:3:channel|duration_r\(12));

-- Location: FF_X24_Y63_N35
\timers:3:channel|duration_r[11]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \IO_DATA[11]~input_o\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sload => VCC,
	ena => \timers:3:channel|process_0~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:3:channel|duration_r\(11));

-- Location: FF_X24_Y63_N32
\timers:3:channel|duration_r[10]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \IO_DATA[10]~input_o\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sload => VCC,
	ena => \timers:3:channel|process_0~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:3:channel|duration_r\(10));

-- Location: FF_X24_Y63_N29
\timers:3:channel|duration_r[9]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \IO_DATA[9]~input_o\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sload => VCC,
	ena => \timers:3:channel|process_0~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:3:channel|duration_r\(9));

-- Location: FF_X24_Y63_N23
\timers:3:channel|duration_r[8]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \IO_DATA[8]~input_o\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sload => VCC,
	ena => \timers:3:channel|process_0~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:3:channel|duration_r\(8));

-- Location: FF_X24_Y63_N56
\timers:3:channel|duration_r[7]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \IO_DATA[7]~input_o\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sload => VCC,
	ena => \timers:3:channel|process_0~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:3:channel|duration_r\(7));

-- Location: FF_X24_Y63_N50
\timers:3:channel|duration_r[6]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \IO_DATA[6]~input_o\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sload => VCC,
	ena => \timers:3:channel|process_0~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:3:channel|duration_r\(6));

-- Location: FF_X24_Y63_N53
\timers:3:channel|duration_r[5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \IO_DATA[5]~input_o\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sload => VCC,
	ena => \timers:3:channel|process_0~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:3:channel|duration_r\(5));

-- Location: FF_X24_Y63_N59
\timers:3:channel|duration_r[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \IO_DATA[4]~input_o\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sload => VCC,
	ena => \timers:3:channel|process_0~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:3:channel|duration_r\(4));

-- Location: FF_X24_Y63_N11
\timers:3:channel|duration_r[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \IO_DATA[3]~input_o\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sload => VCC,
	ena => \timers:3:channel|process_0~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:3:channel|duration_r\(3));

-- Location: FF_X24_Y63_N17
\timers:3:channel|duration_r[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \IO_DATA[2]~input_o\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sload => VCC,
	ena => \timers:3:channel|process_0~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:3:channel|duration_r\(2));

-- Location: FF_X24_Y63_N5
\timers:3:channel|duration_r[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \IO_DATA[1]~input_o\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sload => VCC,
	ena => \timers:3:channel|process_0~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:3:channel|duration_r\(1));

-- Location: LABCELL_X24_Y63_N0
\timers:3:channel|Add0~49\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|Add0~49_sumout\ = SUM(( !\timers:3:channel|duration_r\(0) ) + ( VCC ) + ( !VCC ))
-- \timers:3:channel|Add0~50\ = CARRY(( !\timers:3:channel|duration_r\(0) ) + ( VCC ) + ( !VCC ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000001111111100000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datad => \timers:3:channel|ALT_INV_duration_r\(0),
	cin => GND,
	sumout => \timers:3:channel|Add0~49_sumout\,
	cout => \timers:3:channel|Add0~50\);

-- Location: LABCELL_X24_Y63_N3
\timers:3:channel|Add0~45\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|Add0~45_sumout\ = SUM(( \timers:3:channel|duration_r\(1) ) + ( VCC ) + ( \timers:3:channel|Add0~50\ ))
-- \timers:3:channel|Add0~46\ = CARRY(( \timers:3:channel|duration_r\(1) ) + ( VCC ) + ( \timers:3:channel|Add0~50\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000000000000011111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datad => \timers:3:channel|ALT_INV_duration_r\(1),
	cin => \timers:3:channel|Add0~50\,
	sumout => \timers:3:channel|Add0~45_sumout\,
	cout => \timers:3:channel|Add0~46\);

-- Location: LABCELL_X24_Y63_N6
\timers:3:channel|Add0~41\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|Add0~41_sumout\ = SUM(( \timers:3:channel|duration_r\(2) ) + ( VCC ) + ( \timers:3:channel|Add0~46\ ))
-- \timers:3:channel|Add0~42\ = CARRY(( \timers:3:channel|duration_r\(2) ) + ( VCC ) + ( \timers:3:channel|Add0~46\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000000011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \timers:3:channel|ALT_INV_duration_r\(2),
	cin => \timers:3:channel|Add0~46\,
	sumout => \timers:3:channel|Add0~41_sumout\,
	cout => \timers:3:channel|Add0~42\);

-- Location: LABCELL_X24_Y63_N9
\timers:3:channel|Add0~37\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|Add0~37_sumout\ = SUM(( \timers:3:channel|duration_r\(3) ) + ( VCC ) + ( \timers:3:channel|Add0~42\ ))
-- \timers:3:channel|Add0~38\ = CARRY(( \timers:3:channel|duration_r\(3) ) + ( VCC ) + ( \timers:3:channel|Add0~42\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:3:channel|ALT_INV_duration_r\(3),
	cin => \timers:3:channel|Add0~42\,
	sumout => \timers:3:channel|Add0~37_sumout\,
	cout => \timers:3:channel|Add0~38\);

-- Location: LABCELL_X24_Y63_N12
\timers:3:channel|Add0~33\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|Add0~33_sumout\ = SUM(( \timers:3:channel|duration_r\(4) ) + ( VCC ) + ( \timers:3:channel|Add0~38\ ))
-- \timers:3:channel|Add0~34\ = CARRY(( \timers:3:channel|duration_r\(4) ) + ( VCC ) + ( \timers:3:channel|Add0~38\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000000000000011111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datad => \timers:3:channel|ALT_INV_duration_r\(4),
	cin => \timers:3:channel|Add0~38\,
	sumout => \timers:3:channel|Add0~33_sumout\,
	cout => \timers:3:channel|Add0~34\);

-- Location: LABCELL_X24_Y63_N15
\timers:3:channel|Add0~61\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|Add0~61_sumout\ = SUM(( \timers:3:channel|duration_r\(5) ) + ( VCC ) + ( \timers:3:channel|Add0~34\ ))
-- \timers:3:channel|Add0~62\ = CARRY(( \timers:3:channel|duration_r\(5) ) + ( VCC ) + ( \timers:3:channel|Add0~34\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000000101010101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:3:channel|ALT_INV_duration_r\(5),
	cin => \timers:3:channel|Add0~34\,
	sumout => \timers:3:channel|Add0~61_sumout\,
	cout => \timers:3:channel|Add0~62\);

-- Location: LABCELL_X24_Y63_N18
\timers:3:channel|Add0~57\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|Add0~57_sumout\ = SUM(( \timers:3:channel|duration_r\(6) ) + ( VCC ) + ( \timers:3:channel|Add0~62\ ))
-- \timers:3:channel|Add0~58\ = CARRY(( \timers:3:channel|duration_r\(6) ) + ( VCC ) + ( \timers:3:channel|Add0~62\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:3:channel|ALT_INV_duration_r\(6),
	cin => \timers:3:channel|Add0~62\,
	sumout => \timers:3:channel|Add0~57_sumout\,
	cout => \timers:3:channel|Add0~58\);

-- Location: LABCELL_X24_Y63_N21
\timers:3:channel|Add0~53\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|Add0~53_sumout\ = SUM(( \timers:3:channel|duration_r\(7) ) + ( VCC ) + ( \timers:3:channel|Add0~58\ ))
-- \timers:3:channel|Add0~54\ = CARRY(( \timers:3:channel|duration_r\(7) ) + ( VCC ) + ( \timers:3:channel|Add0~58\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000000000000011111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datad => \timers:3:channel|ALT_INV_duration_r\(7),
	cin => \timers:3:channel|Add0~58\,
	sumout => \timers:3:channel|Add0~53_sumout\,
	cout => \timers:3:channel|Add0~54\);

-- Location: LABCELL_X24_Y63_N24
\timers:3:channel|Add0~29\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|Add0~29_sumout\ = SUM(( \timers:3:channel|duration_r\(8) ) + ( VCC ) + ( \timers:3:channel|Add0~54\ ))
-- \timers:3:channel|Add0~30\ = CARRY(( \timers:3:channel|duration_r\(8) ) + ( VCC ) + ( \timers:3:channel|Add0~54\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000000000000011111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datad => \timers:3:channel|ALT_INV_duration_r\(8),
	cin => \timers:3:channel|Add0~54\,
	sumout => \timers:3:channel|Add0~29_sumout\,
	cout => \timers:3:channel|Add0~30\);

-- Location: LABCELL_X24_Y63_N27
\timers:3:channel|Add0~25\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|Add0~25_sumout\ = SUM(( \timers:3:channel|duration_r\(9) ) + ( VCC ) + ( \timers:3:channel|Add0~30\ ))
-- \timers:3:channel|Add0~26\ = CARRY(( \timers:3:channel|duration_r\(9) ) + ( VCC ) + ( \timers:3:channel|Add0~30\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000000000000011111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datad => \timers:3:channel|ALT_INV_duration_r\(9),
	cin => \timers:3:channel|Add0~30\,
	sumout => \timers:3:channel|Add0~25_sumout\,
	cout => \timers:3:channel|Add0~26\);

-- Location: LABCELL_X24_Y63_N30
\timers:3:channel|Add0~21\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|Add0~21_sumout\ = SUM(( \timers:3:channel|duration_r\(10) ) + ( VCC ) + ( \timers:3:channel|Add0~26\ ))
-- \timers:3:channel|Add0~22\ = CARRY(( \timers:3:channel|duration_r\(10) ) + ( VCC ) + ( \timers:3:channel|Add0~26\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000000011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \timers:3:channel|ALT_INV_duration_r\(10),
	cin => \timers:3:channel|Add0~26\,
	sumout => \timers:3:channel|Add0~21_sumout\,
	cout => \timers:3:channel|Add0~22\);

-- Location: LABCELL_X24_Y63_N33
\timers:3:channel|Add0~17\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|Add0~17_sumout\ = SUM(( \timers:3:channel|duration_r\(11) ) + ( VCC ) + ( \timers:3:channel|Add0~22\ ))
-- \timers:3:channel|Add0~18\ = CARRY(( \timers:3:channel|duration_r\(11) ) + ( VCC ) + ( \timers:3:channel|Add0~22\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000000101010101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:3:channel|ALT_INV_duration_r\(11),
	cin => \timers:3:channel|Add0~22\,
	sumout => \timers:3:channel|Add0~17_sumout\,
	cout => \timers:3:channel|Add0~18\);

-- Location: LABCELL_X24_Y63_N36
\timers:3:channel|Add0~13\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|Add0~13_sumout\ = SUM(( \timers:3:channel|duration_r\(12) ) + ( VCC ) + ( \timers:3:channel|Add0~18\ ))
-- \timers:3:channel|Add0~14\ = CARRY(( \timers:3:channel|duration_r\(12) ) + ( VCC ) + ( \timers:3:channel|Add0~18\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:3:channel|ALT_INV_duration_r\(12),
	cin => \timers:3:channel|Add0~18\,
	sumout => \timers:3:channel|Add0~13_sumout\,
	cout => \timers:3:channel|Add0~14\);

-- Location: LABCELL_X24_Y63_N39
\timers:3:channel|Add0~9\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|Add0~9_sumout\ = SUM(( \timers:3:channel|duration_r\(13) ) + ( VCC ) + ( \timers:3:channel|Add0~14\ ))
-- \timers:3:channel|Add0~10\ = CARRY(( \timers:3:channel|duration_r\(13) ) + ( VCC ) + ( \timers:3:channel|Add0~14\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000000000000011111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datad => \timers:3:channel|ALT_INV_duration_r\(13),
	cin => \timers:3:channel|Add0~14\,
	sumout => \timers:3:channel|Add0~9_sumout\,
	cout => \timers:3:channel|Add0~10\);

-- Location: LABCELL_X24_Y63_N42
\timers:3:channel|Add0~5\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|Add0~5_sumout\ = SUM(( \timers:3:channel|duration_r\(14) ) + ( VCC ) + ( \timers:3:channel|Add0~10\ ))
-- \timers:3:channel|Add0~6\ = CARRY(( \timers:3:channel|duration_r\(14) ) + ( VCC ) + ( \timers:3:channel|Add0~10\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000000011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \timers:3:channel|ALT_INV_duration_r\(14),
	cin => \timers:3:channel|Add0~10\,
	sumout => \timers:3:channel|Add0~5_sumout\,
	cout => \timers:3:channel|Add0~6\);

-- Location: LABCELL_X24_Y63_N45
\timers:3:channel|Add0~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|Add0~1_sumout\ = SUM(( \timers:3:channel|duration_r\(15) ) + ( VCC ) + ( \timers:3:channel|Add0~6\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:3:channel|ALT_INV_duration_r\(15),
	cin => \timers:3:channel|Add0~6\,
	sumout => \timers:3:channel|Add0~1_sumout\);

-- Location: LABCELL_X22_Y63_N3
\timers:3:channel|Add2~5\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|Add2~5_sumout\ = SUM(( \timers:3:channel|elapsed_r\(1) ) + ( GND ) + ( \timers:3:channel|Add2~2\ ))
-- \timers:3:channel|Add2~6\ = CARRY(( \timers:3:channel|elapsed_r\(1) ) + ( GND ) + ( \timers:3:channel|Add2~2\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000000011111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datad => \timers:3:channel|ALT_INV_elapsed_r\(1),
	cin => \timers:3:channel|Add2~2\,
	sumout => \timers:3:channel|Add2~5_sumout\,
	cout => \timers:3:channel|Add2~6\);

-- Location: LABCELL_X23_Y63_N0
\timers:3:channel|LessThan0~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|LessThan0~0_combout\ = ( \timers:3:channel|Add0~9_sumout\ & ( \timers:3:channel|Add0~5_sumout\ & ( (\timers:3:channel|elapsed_r\(13) & (\timers:3:channel|elapsed_r\(14) & (!\timers:3:channel|elapsed_r\(12) $ 
-- (\timers:3:channel|Add0~13_sumout\)))) ) ) ) # ( !\timers:3:channel|Add0~9_sumout\ & ( \timers:3:channel|Add0~5_sumout\ & ( (!\timers:3:channel|elapsed_r\(13) & (\timers:3:channel|elapsed_r\(14) & (!\timers:3:channel|elapsed_r\(12) $ 
-- (\timers:3:channel|Add0~13_sumout\)))) ) ) ) # ( \timers:3:channel|Add0~9_sumout\ & ( !\timers:3:channel|Add0~5_sumout\ & ( (\timers:3:channel|elapsed_r\(13) & (!\timers:3:channel|elapsed_r\(14) & (!\timers:3:channel|elapsed_r\(12) $ 
-- (\timers:3:channel|Add0~13_sumout\)))) ) ) ) # ( !\timers:3:channel|Add0~9_sumout\ & ( !\timers:3:channel|Add0~5_sumout\ & ( (!\timers:3:channel|elapsed_r\(13) & (!\timers:3:channel|elapsed_r\(14) & (!\timers:3:channel|elapsed_r\(12) $ 
-- (\timers:3:channel|Add0~13_sumout\)))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1000010000000000001000010000000000000000100001000000000000100001",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:3:channel|ALT_INV_elapsed_r\(12),
	datab => \timers:3:channel|ALT_INV_elapsed_r\(13),
	datac => \timers:3:channel|ALT_INV_Add0~13_sumout\,
	datad => \timers:3:channel|ALT_INV_elapsed_r\(14),
	datae => \timers:3:channel|ALT_INV_Add0~9_sumout\,
	dataf => \timers:3:channel|ALT_INV_Add0~5_sumout\,
	combout => \timers:3:channel|LessThan0~0_combout\);

-- Location: LABCELL_X24_Y63_N48
\timers:3:channel|LessThan0~5\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|LessThan0~5_combout\ = ( \timers:3:channel|Add0~5_sumout\ & ( \timers:3:channel|Add0~9_sumout\ & ( (!\timers:3:channel|elapsed_r\(14)) # ((!\timers:3:channel|elapsed_r\(13)) # ((!\timers:3:channel|elapsed_r\(12) & 
-- \timers:3:channel|Add0~13_sumout\))) ) ) ) # ( !\timers:3:channel|Add0~5_sumout\ & ( \timers:3:channel|Add0~9_sumout\ & ( (!\timers:3:channel|elapsed_r\(14) & ((!\timers:3:channel|elapsed_r\(13)) # ((!\timers:3:channel|elapsed_r\(12) & 
-- \timers:3:channel|Add0~13_sumout\)))) ) ) ) # ( \timers:3:channel|Add0~5_sumout\ & ( !\timers:3:channel|Add0~9_sumout\ & ( (!\timers:3:channel|elapsed_r\(14)) # ((!\timers:3:channel|elapsed_r\(12) & (!\timers:3:channel|elapsed_r\(13) & 
-- \timers:3:channel|Add0~13_sumout\))) ) ) ) # ( !\timers:3:channel|Add0~5_sumout\ & ( !\timers:3:channel|Add0~9_sumout\ & ( (!\timers:3:channel|elapsed_r\(14) & (!\timers:3:channel|elapsed_r\(12) & (!\timers:3:channel|elapsed_r\(13) & 
-- \timers:3:channel|Add0~13_sumout\))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000010000000101010101110101010100000101010001111101011111110",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:3:channel|ALT_INV_elapsed_r\(14),
	datab => \timers:3:channel|ALT_INV_elapsed_r\(12),
	datac => \timers:3:channel|ALT_INV_elapsed_r\(13),
	datad => \timers:3:channel|ALT_INV_Add0~13_sumout\,
	datae => \timers:3:channel|ALT_INV_Add0~5_sumout\,
	dataf => \timers:3:channel|ALT_INV_Add0~9_sumout\,
	combout => \timers:3:channel|LessThan0~5_combout\);

-- Location: LABCELL_X23_Y63_N54
\timers:3:channel|LessThan0~6\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|LessThan0~6_combout\ = ( \timers:3:channel|LessThan0~0_combout\ & ( !\timers:3:channel|LessThan0~5_combout\ & ( (!\timers:3:channel|elapsed_r\(11) & (!\timers:3:channel|Add0~17_sumout\ & ((!\timers:3:channel|Add0~21_sumout\) # 
-- (\timers:3:channel|elapsed_r\(10))))) # (\timers:3:channel|elapsed_r\(11) & (((!\timers:3:channel|Add0~21_sumout\) # (!\timers:3:channel|Add0~17_sumout\)) # (\timers:3:channel|elapsed_r\(10)))) ) ) ) # ( !\timers:3:channel|LessThan0~0_combout\ & ( 
-- !\timers:3:channel|LessThan0~5_combout\ ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111111111111111111101110011000100000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:3:channel|ALT_INV_elapsed_r\(10),
	datab => \timers:3:channel|ALT_INV_elapsed_r\(11),
	datac => \timers:3:channel|ALT_INV_Add0~21_sumout\,
	datad => \timers:3:channel|ALT_INV_Add0~17_sumout\,
	datae => \timers:3:channel|ALT_INV_LessThan0~0_combout\,
	dataf => \timers:3:channel|ALT_INV_LessThan0~5_combout\,
	combout => \timers:3:channel|LessThan0~6_combout\);

-- Location: LABCELL_X23_Y63_N42
\timers:3:channel|LessThan0~2\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|LessThan0~2_combout\ = ( \timers:3:channel|Add0~21_sumout\ & ( !\timers:3:channel|elapsed_r\(10) ) ) # ( !\timers:3:channel|Add0~21_sumout\ & ( \timers:3:channel|elapsed_r\(10) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000111100001111000011110000111111110000111100001111000011110000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:3:channel|ALT_INV_elapsed_r\(10),
	dataf => \timers:3:channel|ALT_INV_Add0~21_sumout\,
	combout => \timers:3:channel|LessThan0~2_combout\);

-- Location: LABCELL_X23_Y63_N12
\timers:3:channel|LessThan0~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|LessThan0~1_combout\ = ( \timers:3:channel|Add0~17_sumout\ & ( !\timers:3:channel|elapsed_r\(11) ) ) # ( !\timers:3:channel|Add0~17_sumout\ & ( \timers:3:channel|elapsed_r\(11) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0011001100110011001100110011001111001100110011001100110011001100",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \timers:3:channel|ALT_INV_elapsed_r\(11),
	dataf => \timers:3:channel|ALT_INV_Add0~17_sumout\,
	combout => \timers:3:channel|LessThan0~1_combout\);

-- Location: LABCELL_X23_Y62_N36
\timers:3:channel|LessThan0~14\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|LessThan0~14_combout\ = ( !\timers:3:channel|elapsed_r\(8) & ( \timers:3:channel|Add0~29_sumout\ ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000011111111111111110000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datae => \timers:3:channel|ALT_INV_elapsed_r\(8),
	dataf => \timers:3:channel|ALT_INV_Add0~29_sumout\,
	combout => \timers:3:channel|LessThan0~14_combout\);

-- Location: LABCELL_X23_Y63_N6
\timers:3:channel|LessThan0~15\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|LessThan0~15_combout\ = ( \timers:3:channel|LessThan0~0_combout\ & ( \timers:3:channel|LessThan0~14_combout\ & ( (!\timers:3:channel|LessThan0~2_combout\ & (!\timers:3:channel|LessThan0~1_combout\ & ((!\timers:3:channel|elapsed_r\(9)) # 
-- (\timers:3:channel|Add0~25_sumout\)))) ) ) ) # ( \timers:3:channel|LessThan0~0_combout\ & ( !\timers:3:channel|LessThan0~14_combout\ & ( (\timers:3:channel|Add0~25_sumout\ & (!\timers:3:channel|LessThan0~2_combout\ & (!\timers:3:channel|elapsed_r\(9) & 
-- !\timers:3:channel|LessThan0~1_combout\))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000010000000000000000000000000000001100010000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:3:channel|ALT_INV_Add0~25_sumout\,
	datab => \timers:3:channel|ALT_INV_LessThan0~2_combout\,
	datac => \timers:3:channel|ALT_INV_elapsed_r\(9),
	datad => \timers:3:channel|ALT_INV_LessThan0~1_combout\,
	datae => \timers:3:channel|ALT_INV_LessThan0~0_combout\,
	dataf => \timers:3:channel|ALT_INV_LessThan0~14_combout\,
	combout => \timers:3:channel|LessThan0~15_combout\);

-- Location: MLABCELL_X21_Y63_N21
\timers:3:channel|LessThan0~7\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|LessThan0~7_combout\ = ( \timers:3:channel|Add0~29_sumout\ & ( !\timers:3:channel|elapsed_r\(8) ) ) # ( !\timers:3:channel|Add0~29_sumout\ & ( \timers:3:channel|elapsed_r\(8) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000111100001111000011110000111111110000111100001111000011110000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:3:channel|ALT_INV_elapsed_r\(8),
	dataf => \timers:3:channel|ALT_INV_Add0~29_sumout\,
	combout => \timers:3:channel|LessThan0~7_combout\);

-- Location: LABCELL_X23_Y63_N15
\timers:3:channel|LessThan0~3\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|LessThan0~3_combout\ = ( \timers:3:channel|Add0~25_sumout\ & ( !\timers:3:channel|elapsed_r\(9) ) ) # ( !\timers:3:channel|Add0~25_sumout\ & ( \timers:3:channel|elapsed_r\(9) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000111100001111000011110000111111110000111100001111000011110000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:3:channel|ALT_INV_elapsed_r\(9),
	dataf => \timers:3:channel|ALT_INV_Add0~25_sumout\,
	combout => \timers:3:channel|LessThan0~3_combout\);

-- Location: LABCELL_X23_Y63_N24
\timers:3:channel|LessThan0~9\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|LessThan0~9_combout\ = ( \timers:3:channel|Add0~41_sumout\ & ( \timers:3:channel|Add0~45_sumout\ & ( (\timers:3:channel|elapsed_r\(2) & ((!\timers:3:channel|elapsed_r\(1)) # ((!\timers:3:channel|elapsed_r\(0) & 
-- \timers:3:channel|Add0~49_sumout\)))) ) ) ) # ( !\timers:3:channel|Add0~41_sumout\ & ( \timers:3:channel|Add0~45_sumout\ & ( (!\timers:3:channel|elapsed_r\(2) & ((!\timers:3:channel|elapsed_r\(1)) # ((!\timers:3:channel|elapsed_r\(0) & 
-- \timers:3:channel|Add0~49_sumout\)))) ) ) ) # ( \timers:3:channel|Add0~41_sumout\ & ( !\timers:3:channel|Add0~45_sumout\ & ( (!\timers:3:channel|elapsed_r\(0) & (\timers:3:channel|Add0~49_sumout\ & (!\timers:3:channel|elapsed_r\(1) & 
-- \timers:3:channel|elapsed_r\(2)))) ) ) ) # ( !\timers:3:channel|Add0~41_sumout\ & ( !\timers:3:channel|Add0~45_sumout\ & ( (!\timers:3:channel|elapsed_r\(0) & (\timers:3:channel|Add0~49_sumout\ & (!\timers:3:channel|elapsed_r\(1) & 
-- !\timers:3:channel|elapsed_r\(2)))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0010000000000000000000000010000011110010000000000000000011110010",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:3:channel|ALT_INV_elapsed_r\(0),
	datab => \timers:3:channel|ALT_INV_Add0~49_sumout\,
	datac => \timers:3:channel|ALT_INV_elapsed_r\(1),
	datad => \timers:3:channel|ALT_INV_elapsed_r\(2),
	datae => \timers:3:channel|ALT_INV_Add0~41_sumout\,
	dataf => \timers:3:channel|ALT_INV_Add0~45_sumout\,
	combout => \timers:3:channel|LessThan0~9_combout\);

-- Location: LABCELL_X23_Y63_N36
\timers:3:channel|LessThan0~11\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|LessThan0~11_combout\ = ( \timers:3:channel|Add0~53_sumout\ & ( \timers:3:channel|Add0~61_sumout\ & ( (\timers:3:channel|elapsed_r\(5) & (\timers:3:channel|elapsed_r\(7) & (!\timers:3:channel|Add0~57_sumout\ $ 
-- (\timers:3:channel|elapsed_r\(6))))) ) ) ) # ( !\timers:3:channel|Add0~53_sumout\ & ( \timers:3:channel|Add0~61_sumout\ & ( (\timers:3:channel|elapsed_r\(5) & (!\timers:3:channel|elapsed_r\(7) & (!\timers:3:channel|Add0~57_sumout\ $ 
-- (\timers:3:channel|elapsed_r\(6))))) ) ) ) # ( \timers:3:channel|Add0~53_sumout\ & ( !\timers:3:channel|Add0~61_sumout\ & ( (!\timers:3:channel|elapsed_r\(5) & (\timers:3:channel|elapsed_r\(7) & (!\timers:3:channel|Add0~57_sumout\ $ 
-- (\timers:3:channel|elapsed_r\(6))))) ) ) ) # ( !\timers:3:channel|Add0~53_sumout\ & ( !\timers:3:channel|Add0~61_sumout\ & ( (!\timers:3:channel|elapsed_r\(5) & (!\timers:3:channel|elapsed_r\(7) & (!\timers:3:channel|Add0~57_sumout\ $ 
-- (\timers:3:channel|elapsed_r\(6))))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1000000000100000000010000000001001000000000100000000010000000001",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:3:channel|ALT_INV_elapsed_r\(5),
	datab => \timers:3:channel|ALT_INV_Add0~57_sumout\,
	datac => \timers:3:channel|ALT_INV_elapsed_r\(7),
	datad => \timers:3:channel|ALT_INV_elapsed_r\(6),
	datae => \timers:3:channel|ALT_INV_Add0~53_sumout\,
	dataf => \timers:3:channel|ALT_INV_Add0~61_sumout\,
	combout => \timers:3:channel|LessThan0~11_combout\);

-- Location: LABCELL_X24_Y63_N54
\timers:3:channel|LessThan0~8\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|LessThan0~8_combout\ = ( \timers:3:channel|Add0~37_sumout\ & ( \timers:3:channel|Add0~33_sumout\ & ( (\timers:3:channel|elapsed_r\(4) & \timers:3:channel|elapsed_r\(3)) ) ) ) # ( !\timers:3:channel|Add0~37_sumout\ & ( 
-- \timers:3:channel|Add0~33_sumout\ & ( (\timers:3:channel|elapsed_r\(4) & !\timers:3:channel|elapsed_r\(3)) ) ) ) # ( \timers:3:channel|Add0~37_sumout\ & ( !\timers:3:channel|Add0~33_sumout\ & ( (!\timers:3:channel|elapsed_r\(4) & 
-- \timers:3:channel|elapsed_r\(3)) ) ) ) # ( !\timers:3:channel|Add0~37_sumout\ & ( !\timers:3:channel|Add0~33_sumout\ & ( (!\timers:3:channel|elapsed_r\(4) & !\timers:3:channel|elapsed_r\(3)) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1010000010100000000010100000101001010000010100000000010100000101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:3:channel|ALT_INV_elapsed_r\(4),
	datac => \timers:3:channel|ALT_INV_elapsed_r\(3),
	datae => \timers:3:channel|ALT_INV_Add0~37_sumout\,
	dataf => \timers:3:channel|ALT_INV_Add0~33_sumout\,
	combout => \timers:3:channel|LessThan0~8_combout\);

-- Location: LABCELL_X23_Y63_N51
\timers:3:channel|LessThan0~12\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|LessThan0~12_combout\ = ( \timers:3:channel|Add0~53_sumout\ & ( \timers:3:channel|Add0~61_sumout\ & ( (!\timers:3:channel|elapsed_r\(7)) # ((!\timers:3:channel|elapsed_r\(6) & ((!\timers:3:channel|elapsed_r\(5)) # 
-- (\timers:3:channel|Add0~57_sumout\))) # (\timers:3:channel|elapsed_r\(6) & (\timers:3:channel|Add0~57_sumout\ & !\timers:3:channel|elapsed_r\(5)))) ) ) ) # ( !\timers:3:channel|Add0~53_sumout\ & ( \timers:3:channel|Add0~61_sumout\ & ( 
-- (!\timers:3:channel|elapsed_r\(7) & ((!\timers:3:channel|elapsed_r\(6) & ((!\timers:3:channel|elapsed_r\(5)) # (\timers:3:channel|Add0~57_sumout\))) # (\timers:3:channel|elapsed_r\(6) & (\timers:3:channel|Add0~57_sumout\ & 
-- !\timers:3:channel|elapsed_r\(5))))) ) ) ) # ( \timers:3:channel|Add0~53_sumout\ & ( !\timers:3:channel|Add0~61_sumout\ & ( (!\timers:3:channel|elapsed_r\(7)) # ((!\timers:3:channel|elapsed_r\(6) & \timers:3:channel|Add0~57_sumout\)) ) ) ) # ( 
-- !\timers:3:channel|Add0~53_sumout\ & ( !\timers:3:channel|Add0~61_sumout\ & ( (!\timers:3:channel|elapsed_r\(7) & (!\timers:3:channel|elapsed_r\(6) & \timers:3:channel|Add0~57_sumout\)) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000100000001000101011101010111010001010000010001110111110101110",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:3:channel|ALT_INV_elapsed_r\(7),
	datab => \timers:3:channel|ALT_INV_elapsed_r\(6),
	datac => \timers:3:channel|ALT_INV_Add0~57_sumout\,
	datad => \timers:3:channel|ALT_INV_elapsed_r\(5),
	datae => \timers:3:channel|ALT_INV_Add0~53_sumout\,
	dataf => \timers:3:channel|ALT_INV_Add0~61_sumout\,
	combout => \timers:3:channel|LessThan0~12_combout\);

-- Location: LABCELL_X23_Y64_N0
\timers:3:channel|LessThan0~10\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|LessThan0~10_combout\ = ( \timers:3:channel|Add0~37_sumout\ & ( \timers:3:channel|Add0~33_sumout\ & ( (!\timers:3:channel|elapsed_r\(3)) # ((!\timers:3:channel|elapsed_r\(4)) # ((!\timers:3:channel|elapsed_r\(2) & 
-- \timers:3:channel|Add0~41_sumout\))) ) ) ) # ( !\timers:3:channel|Add0~37_sumout\ & ( \timers:3:channel|Add0~33_sumout\ & ( (!\timers:3:channel|elapsed_r\(4)) # ((!\timers:3:channel|elapsed_r\(3) & (!\timers:3:channel|elapsed_r\(2) & 
-- \timers:3:channel|Add0~41_sumout\))) ) ) ) # ( \timers:3:channel|Add0~37_sumout\ & ( !\timers:3:channel|Add0~33_sumout\ & ( (!\timers:3:channel|elapsed_r\(4) & ((!\timers:3:channel|elapsed_r\(3)) # ((!\timers:3:channel|elapsed_r\(2) & 
-- \timers:3:channel|Add0~41_sumout\)))) ) ) ) # ( !\timers:3:channel|Add0~37_sumout\ & ( !\timers:3:channel|Add0~33_sumout\ & ( (!\timers:3:channel|elapsed_r\(3) & (!\timers:3:channel|elapsed_r\(2) & (\timers:3:channel|Add0~41_sumout\ & 
-- !\timers:3:channel|elapsed_r\(4)))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000100000000000101011100000000011111111000010001111111110101110",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:3:channel|ALT_INV_elapsed_r\(3),
	datab => \timers:3:channel|ALT_INV_elapsed_r\(2),
	datac => \timers:3:channel|ALT_INV_Add0~41_sumout\,
	datad => \timers:3:channel|ALT_INV_elapsed_r\(4),
	datae => \timers:3:channel|ALT_INV_Add0~37_sumout\,
	dataf => \timers:3:channel|ALT_INV_Add0~33_sumout\,
	combout => \timers:3:channel|LessThan0~10_combout\);

-- Location: MLABCELL_X21_Y63_N42
\timers:3:channel|LessThan0~17\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|LessThan0~17_combout\ = ( !\timers:3:channel|LessThan0~12_combout\ & ( \timers:3:channel|LessThan0~10_combout\ & ( !\timers:3:channel|LessThan0~11_combout\ ) ) ) # ( !\timers:3:channel|LessThan0~12_combout\ & ( 
-- !\timers:3:channel|LessThan0~10_combout\ & ( (!\timers:3:channel|LessThan0~9_combout\) # ((!\timers:3:channel|LessThan0~11_combout\) # (!\timers:3:channel|LessThan0~8_combout\)) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111111111111100000000000000000011110000111100000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \timers:3:channel|ALT_INV_LessThan0~9_combout\,
	datac => \timers:3:channel|ALT_INV_LessThan0~11_combout\,
	datad => \timers:3:channel|ALT_INV_LessThan0~8_combout\,
	datae => \timers:3:channel|ALT_INV_LessThan0~12_combout\,
	dataf => \timers:3:channel|ALT_INV_LessThan0~10_combout\,
	combout => \timers:3:channel|LessThan0~17_combout\);

-- Location: MLABCELL_X21_Y63_N54
\timers:3:channel|LessThan0~18\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|LessThan0~18_combout\ = ( \timers:3:channel|LessThan0~0_combout\ & ( !\timers:3:channel|LessThan0~17_combout\ & ( (!\timers:3:channel|LessThan0~7_combout\ & (!\timers:3:channel|LessThan0~2_combout\ & 
-- (!\timers:3:channel|LessThan0~3_combout\ & !\timers:3:channel|LessThan0~1_combout\))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000100000000000000000000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:3:channel|ALT_INV_LessThan0~7_combout\,
	datab => \timers:3:channel|ALT_INV_LessThan0~2_combout\,
	datac => \timers:3:channel|ALT_INV_LessThan0~3_combout\,
	datad => \timers:3:channel|ALT_INV_LessThan0~1_combout\,
	datae => \timers:3:channel|ALT_INV_LessThan0~0_combout\,
	dataf => \timers:3:channel|ALT_INV_LessThan0~17_combout\,
	combout => \timers:3:channel|LessThan0~18_combout\);

-- Location: LABCELL_X22_Y63_N54
\timers:3:channel|elapsed_r[9]~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|elapsed_r[9]~1_combout\ = ( \timers:3:channel|LessThan0~15_combout\ & ( \timers:3:channel|LessThan0~18_combout\ & ( (\timers:3:channel|mode_r\(1) & (!\timers:3:channel|Add0~1_sumout\ & \timers:3:channel|elapsed_r\(15))) ) ) ) # ( 
-- !\timers:3:channel|LessThan0~15_combout\ & ( \timers:3:channel|LessThan0~18_combout\ & ( (\timers:3:channel|mode_r\(1) & (!\timers:3:channel|Add0~1_sumout\ & \timers:3:channel|elapsed_r\(15))) ) ) ) # ( \timers:3:channel|LessThan0~15_combout\ & ( 
-- !\timers:3:channel|LessThan0~18_combout\ & ( (\timers:3:channel|mode_r\(1) & (!\timers:3:channel|Add0~1_sumout\ & \timers:3:channel|elapsed_r\(15))) ) ) ) # ( !\timers:3:channel|LessThan0~15_combout\ & ( !\timers:3:channel|LessThan0~18_combout\ & ( 
-- (\timers:3:channel|mode_r\(1) & ((!\timers:3:channel|LessThan0~6_combout\ & (!\timers:3:channel|Add0~1_sumout\ & \timers:3:channel|elapsed_r\(15))) # (\timers:3:channel|LessThan0~6_combout\ & ((!\timers:3:channel|Add0~1_sumout\) # 
-- (\timers:3:channel|elapsed_r\(15)))))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0001000001010001000000000101000000000000010100000000000001010000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:3:channel|ALT_INV_mode_r\(1),
	datab => \timers:3:channel|ALT_INV_LessThan0~6_combout\,
	datac => \timers:3:channel|ALT_INV_Add0~1_sumout\,
	datad => \timers:3:channel|ALT_INV_elapsed_r\(15),
	datae => \timers:3:channel|ALT_INV_LessThan0~15_combout\,
	dataf => \timers:3:channel|ALT_INV_LessThan0~18_combout\,
	combout => \timers:3:channel|elapsed_r[9]~1_combout\);

-- Location: LABCELL_X24_Y69_N21
\timers:0:channel|periods_r~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|periods_r~1_combout\ = (\IO_ADDR[0]~input_o\ & \IO_ADDR[1]~input_o\)

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0001000100010001000100010001000100010001000100010001000100010001",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_IO_ADDR[0]~input_o\,
	datab => \ALT_INV_IO_ADDR[1]~input_o\,
	combout => \timers:0:channel|periods_r~1_combout\);

-- Location: LABCELL_X22_Y65_N39
\timers:3:channel|elapsed_r[9]~2\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|elapsed_r[9]~2_combout\ = ( \timers:3:channel|prescaler|TICK~q\ & ( (!\timers:3:channel|mode_r\(0)) # (\timers:3:channel|mode_r\(1)) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000011111111010101011111111101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:3:channel|ALT_INV_mode_r\(1),
	datad => \timers:3:channel|ALT_INV_mode_r\(0),
	dataf => \timers:3:channel|prescaler|ALT_INV_TICK~q\,
	combout => \timers:3:channel|elapsed_r[9]~2_combout\);

-- Location: LABCELL_X22_Y65_N30
\timers:3:channel|elapsed_r[9]~3\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|elapsed_r[9]~3_combout\ = ( \IO_DATA[1]~input_o\ & ( \timers:3:channel|elapsed_r[9]~2_combout\ & ( ((\IO_DATA[0]~input_o\ & (\timers:0:channel|periods_r~1_combout\ & \Equal11~4_combout\))) # (\timers:3:channel|running_r~q\) ) ) ) # ( 
-- !\IO_DATA[1]~input_o\ & ( \timers:3:channel|elapsed_r[9]~2_combout\ & ( \timers:3:channel|running_r~q\ ) ) ) # ( \IO_DATA[1]~input_o\ & ( !\timers:3:channel|elapsed_r[9]~2_combout\ & ( (\IO_DATA[0]~input_o\ & (\timers:0:channel|periods_r~1_combout\ & 
-- (\Equal11~4_combout\ & !\timers:3:channel|running_r~q\))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000010000000000000000111111110000000111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_IO_DATA[0]~input_o\,
	datab => \timers:0:channel|ALT_INV_periods_r~1_combout\,
	datac => \ALT_INV_Equal11~4_combout\,
	datad => \timers:3:channel|ALT_INV_running_r~q\,
	datae => \ALT_INV_IO_DATA[1]~input_o\,
	dataf => \timers:3:channel|ALT_INV_elapsed_r[9]~2_combout\,
	combout => \timers:3:channel|elapsed_r[9]~3_combout\);

-- Location: FF_X22_Y63_N5
\timers:3:channel|elapsed_r[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:3:channel|Add2~5_sumout\,
	asdata => \timers:3:channel|duration_r\(1),
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:3:channel|elapsed_r[9]~0_combout\,
	sload => \timers:3:channel|elapsed_r[9]~1_combout\,
	ena => \timers:3:channel|elapsed_r[9]~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:3:channel|elapsed_r\(1));

-- Location: LABCELL_X22_Y63_N6
\timers:3:channel|Add2~9\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|Add2~9_sumout\ = SUM(( \timers:3:channel|elapsed_r\(2) ) + ( GND ) + ( \timers:3:channel|Add2~6\ ))
-- \timers:3:channel|Add2~10\ = CARRY(( \timers:3:channel|elapsed_r\(2) ) + ( GND ) + ( \timers:3:channel|Add2~6\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \timers:3:channel|ALT_INV_elapsed_r\(2),
	cin => \timers:3:channel|Add2~6\,
	sumout => \timers:3:channel|Add2~9_sumout\,
	cout => \timers:3:channel|Add2~10\);

-- Location: FF_X22_Y63_N8
\timers:3:channel|elapsed_r[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:3:channel|Add2~9_sumout\,
	asdata => \timers:3:channel|duration_r\(2),
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:3:channel|elapsed_r[9]~0_combout\,
	sload => \timers:3:channel|elapsed_r[9]~1_combout\,
	ena => \timers:3:channel|elapsed_r[9]~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:3:channel|elapsed_r\(2));

-- Location: LABCELL_X22_Y63_N9
\timers:3:channel|Add2~13\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|Add2~13_sumout\ = SUM(( \timers:3:channel|elapsed_r\(3) ) + ( GND ) + ( \timers:3:channel|Add2~10\ ))
-- \timers:3:channel|Add2~14\ = CARRY(( \timers:3:channel|elapsed_r\(3) ) + ( GND ) + ( \timers:3:channel|Add2~10\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:3:channel|ALT_INV_elapsed_r\(3),
	cin => \timers:3:channel|Add2~10\,
	sumout => \timers:3:channel|Add2~13_sumout\,
	cout => \timers:3:channel|Add2~14\);

-- Location: FF_X22_Y63_N11
\timers:3:channel|elapsed_r[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:3:channel|Add2~13_sumout\,
	asdata => \timers:3:channel|duration_r\(3),
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:3:channel|elapsed_r[9]~0_combout\,
	sload => \timers:3:channel|elapsed_r[9]~1_combout\,
	ena => \timers:3:channel|elapsed_r[9]~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:3:channel|elapsed_r\(3));

-- Location: LABCELL_X22_Y63_N12
\timers:3:channel|Add2~17\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|Add2~17_sumout\ = SUM(( \timers:3:channel|elapsed_r\(4) ) + ( GND ) + ( \timers:3:channel|Add2~14\ ))
-- \timers:3:channel|Add2~18\ = CARRY(( \timers:3:channel|elapsed_r\(4) ) + ( GND ) + ( \timers:3:channel|Add2~14\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \timers:3:channel|ALT_INV_elapsed_r\(4),
	cin => \timers:3:channel|Add2~14\,
	sumout => \timers:3:channel|Add2~17_sumout\,
	cout => \timers:3:channel|Add2~18\);

-- Location: FF_X22_Y63_N14
\timers:3:channel|elapsed_r[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:3:channel|Add2~17_sumout\,
	asdata => \timers:3:channel|duration_r\(4),
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:3:channel|elapsed_r[9]~0_combout\,
	sload => \timers:3:channel|elapsed_r[9]~1_combout\,
	ena => \timers:3:channel|elapsed_r[9]~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:3:channel|elapsed_r\(4));

-- Location: LABCELL_X22_Y63_N15
\timers:3:channel|Add2~21\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|Add2~21_sumout\ = SUM(( \timers:3:channel|elapsed_r\(5) ) + ( GND ) + ( \timers:3:channel|Add2~18\ ))
-- \timers:3:channel|Add2~22\ = CARRY(( \timers:3:channel|elapsed_r\(5) ) + ( GND ) + ( \timers:3:channel|Add2~18\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:3:channel|ALT_INV_elapsed_r\(5),
	cin => \timers:3:channel|Add2~18\,
	sumout => \timers:3:channel|Add2~21_sumout\,
	cout => \timers:3:channel|Add2~22\);

-- Location: FF_X22_Y63_N17
\timers:3:channel|elapsed_r[5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:3:channel|Add2~21_sumout\,
	asdata => \timers:3:channel|duration_r\(5),
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:3:channel|elapsed_r[9]~0_combout\,
	sload => \timers:3:channel|elapsed_r[9]~1_combout\,
	ena => \timers:3:channel|elapsed_r[9]~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:3:channel|elapsed_r\(5));

-- Location: LABCELL_X22_Y63_N18
\timers:3:channel|Add2~25\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|Add2~25_sumout\ = SUM(( \timers:3:channel|elapsed_r\(6) ) + ( GND ) + ( \timers:3:channel|Add2~22\ ))
-- \timers:3:channel|Add2~26\ = CARRY(( \timers:3:channel|elapsed_r\(6) ) + ( GND ) + ( \timers:3:channel|Add2~22\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:3:channel|ALT_INV_elapsed_r\(6),
	cin => \timers:3:channel|Add2~22\,
	sumout => \timers:3:channel|Add2~25_sumout\,
	cout => \timers:3:channel|Add2~26\);

-- Location: FF_X22_Y63_N20
\timers:3:channel|elapsed_r[6]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:3:channel|Add2~25_sumout\,
	asdata => \timers:3:channel|duration_r\(6),
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:3:channel|elapsed_r[9]~0_combout\,
	sload => \timers:3:channel|elapsed_r[9]~1_combout\,
	ena => \timers:3:channel|elapsed_r[9]~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:3:channel|elapsed_r\(6));

-- Location: LABCELL_X22_Y63_N21
\timers:3:channel|Add2~29\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|Add2~29_sumout\ = SUM(( \timers:3:channel|elapsed_r\(7) ) + ( GND ) + ( \timers:3:channel|Add2~26\ ))
-- \timers:3:channel|Add2~30\ = CARRY(( \timers:3:channel|elapsed_r\(7) ) + ( GND ) + ( \timers:3:channel|Add2~26\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000101010101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:3:channel|ALT_INV_elapsed_r\(7),
	cin => \timers:3:channel|Add2~26\,
	sumout => \timers:3:channel|Add2~29_sumout\,
	cout => \timers:3:channel|Add2~30\);

-- Location: FF_X22_Y63_N23
\timers:3:channel|elapsed_r[7]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:3:channel|Add2~29_sumout\,
	asdata => \timers:3:channel|duration_r\(7),
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:3:channel|elapsed_r[9]~0_combout\,
	sload => \timers:3:channel|elapsed_r[9]~1_combout\,
	ena => \timers:3:channel|elapsed_r[9]~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:3:channel|elapsed_r\(7));

-- Location: LABCELL_X22_Y63_N24
\timers:3:channel|Add2~33\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|Add2~33_sumout\ = SUM(( \timers:3:channel|elapsed_r\(8) ) + ( GND ) + ( \timers:3:channel|Add2~30\ ))
-- \timers:3:channel|Add2~34\ = CARRY(( \timers:3:channel|elapsed_r\(8) ) + ( GND ) + ( \timers:3:channel|Add2~30\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:3:channel|ALT_INV_elapsed_r\(8),
	cin => \timers:3:channel|Add2~30\,
	sumout => \timers:3:channel|Add2~33_sumout\,
	cout => \timers:3:channel|Add2~34\);

-- Location: FF_X22_Y63_N26
\timers:3:channel|elapsed_r[8]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:3:channel|Add2~33_sumout\,
	asdata => \timers:3:channel|duration_r\(8),
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:3:channel|elapsed_r[9]~0_combout\,
	sload => \timers:3:channel|elapsed_r[9]~1_combout\,
	ena => \timers:3:channel|elapsed_r[9]~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:3:channel|elapsed_r\(8));

-- Location: LABCELL_X22_Y63_N27
\timers:3:channel|Add2~37\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|Add2~37_sumout\ = SUM(( \timers:3:channel|elapsed_r\(9) ) + ( GND ) + ( \timers:3:channel|Add2~34\ ))
-- \timers:3:channel|Add2~38\ = CARRY(( \timers:3:channel|elapsed_r\(9) ) + ( GND ) + ( \timers:3:channel|Add2~34\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000101010101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:3:channel|ALT_INV_elapsed_r\(9),
	cin => \timers:3:channel|Add2~34\,
	sumout => \timers:3:channel|Add2~37_sumout\,
	cout => \timers:3:channel|Add2~38\);

-- Location: FF_X22_Y63_N29
\timers:3:channel|elapsed_r[9]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:3:channel|Add2~37_sumout\,
	asdata => \timers:3:channel|duration_r\(9),
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:3:channel|elapsed_r[9]~0_combout\,
	sload => \timers:3:channel|elapsed_r[9]~1_combout\,
	ena => \timers:3:channel|elapsed_r[9]~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:3:channel|elapsed_r\(9));

-- Location: LABCELL_X22_Y63_N30
\timers:3:channel|Add2~41\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|Add2~41_sumout\ = SUM(( \timers:3:channel|elapsed_r\(10) ) + ( GND ) + ( \timers:3:channel|Add2~38\ ))
-- \timers:3:channel|Add2~42\ = CARRY(( \timers:3:channel|elapsed_r\(10) ) + ( GND ) + ( \timers:3:channel|Add2~38\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \timers:3:channel|ALT_INV_elapsed_r\(10),
	cin => \timers:3:channel|Add2~38\,
	sumout => \timers:3:channel|Add2~41_sumout\,
	cout => \timers:3:channel|Add2~42\);

-- Location: FF_X22_Y63_N32
\timers:3:channel|elapsed_r[10]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:3:channel|Add2~41_sumout\,
	asdata => \timers:3:channel|duration_r\(10),
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:3:channel|elapsed_r[9]~0_combout\,
	sload => \timers:3:channel|elapsed_r[9]~1_combout\,
	ena => \timers:3:channel|elapsed_r[9]~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:3:channel|elapsed_r\(10));

-- Location: LABCELL_X22_Y63_N33
\timers:3:channel|Add2~45\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|Add2~45_sumout\ = SUM(( \timers:3:channel|elapsed_r\(11) ) + ( GND ) + ( \timers:3:channel|Add2~42\ ))
-- \timers:3:channel|Add2~46\ = CARRY(( \timers:3:channel|elapsed_r\(11) ) + ( GND ) + ( \timers:3:channel|Add2~42\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000101010101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:3:channel|ALT_INV_elapsed_r\(11),
	cin => \timers:3:channel|Add2~42\,
	sumout => \timers:3:channel|Add2~45_sumout\,
	cout => \timers:3:channel|Add2~46\);

-- Location: FF_X22_Y63_N35
\timers:3:channel|elapsed_r[11]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:3:channel|Add2~45_sumout\,
	asdata => \timers:3:channel|duration_r\(11),
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:3:channel|elapsed_r[9]~0_combout\,
	sload => \timers:3:channel|elapsed_r[9]~1_combout\,
	ena => \timers:3:channel|elapsed_r[9]~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:3:channel|elapsed_r\(11));

-- Location: LABCELL_X22_Y63_N36
\timers:3:channel|Add2~49\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|Add2~49_sumout\ = SUM(( \timers:3:channel|elapsed_r\(12) ) + ( GND ) + ( \timers:3:channel|Add2~46\ ))
-- \timers:3:channel|Add2~50\ = CARRY(( \timers:3:channel|elapsed_r\(12) ) + ( GND ) + ( \timers:3:channel|Add2~46\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:3:channel|ALT_INV_elapsed_r\(12),
	cin => \timers:3:channel|Add2~46\,
	sumout => \timers:3:channel|Add2~49_sumout\,
	cout => \timers:3:channel|Add2~50\);

-- Location: FF_X22_Y63_N38
\timers:3:channel|elapsed_r[12]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:3:channel|Add2~49_sumout\,
	asdata => \timers:3:channel|duration_r\(12),
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:3:channel|elapsed_r[9]~0_combout\,
	sload => \timers:3:channel|elapsed_r[9]~1_combout\,
	ena => \timers:3:channel|elapsed_r[9]~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:3:channel|elapsed_r\(12));

-- Location: LABCELL_X22_Y63_N39
\timers:3:channel|Add2~53\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|Add2~53_sumout\ = SUM(( \timers:3:channel|elapsed_r\(13) ) + ( GND ) + ( \timers:3:channel|Add2~50\ ))
-- \timers:3:channel|Add2~54\ = CARRY(( \timers:3:channel|elapsed_r\(13) ) + ( GND ) + ( \timers:3:channel|Add2~50\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:3:channel|ALT_INV_elapsed_r\(13),
	cin => \timers:3:channel|Add2~50\,
	sumout => \timers:3:channel|Add2~53_sumout\,
	cout => \timers:3:channel|Add2~54\);

-- Location: FF_X22_Y63_N41
\timers:3:channel|elapsed_r[13]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:3:channel|Add2~53_sumout\,
	asdata => \timers:3:channel|duration_r\(13),
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:3:channel|elapsed_r[9]~0_combout\,
	sload => \timers:3:channel|elapsed_r[9]~1_combout\,
	ena => \timers:3:channel|elapsed_r[9]~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:3:channel|elapsed_r\(13));

-- Location: LABCELL_X22_Y63_N42
\timers:3:channel|Add2~57\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|Add2~57_sumout\ = SUM(( \timers:3:channel|elapsed_r\(14) ) + ( GND ) + ( \timers:3:channel|Add2~54\ ))
-- \timers:3:channel|Add2~58\ = CARRY(( \timers:3:channel|elapsed_r\(14) ) + ( GND ) + ( \timers:3:channel|Add2~54\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \timers:3:channel|ALT_INV_elapsed_r\(14),
	cin => \timers:3:channel|Add2~54\,
	sumout => \timers:3:channel|Add2~57_sumout\,
	cout => \timers:3:channel|Add2~58\);

-- Location: FF_X22_Y63_N44
\timers:3:channel|elapsed_r[14]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:3:channel|Add2~57_sumout\,
	asdata => \timers:3:channel|duration_r\(14),
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:3:channel|elapsed_r[9]~0_combout\,
	sload => \timers:3:channel|elapsed_r[9]~1_combout\,
	ena => \timers:3:channel|elapsed_r[9]~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:3:channel|elapsed_r\(14));

-- Location: LABCELL_X22_Y63_N45
\timers:3:channel|Add2~61\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|Add2~61_sumout\ = SUM(( \timers:3:channel|elapsed_r\(15) ) + ( GND ) + ( \timers:3:channel|Add2~58\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:3:channel|ALT_INV_elapsed_r\(15),
	cin => \timers:3:channel|Add2~58\,
	sumout => \timers:3:channel|Add2~61_sumout\);

-- Location: FF_X22_Y63_N47
\timers:3:channel|elapsed_r[15]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:3:channel|Add2~61_sumout\,
	asdata => \timers:3:channel|duration_r\(15),
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:3:channel|elapsed_r[9]~0_combout\,
	sload => \timers:3:channel|elapsed_r[9]~1_combout\,
	ena => \timers:3:channel|elapsed_r[9]~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:3:channel|elapsed_r\(15));

-- Location: LABCELL_X23_Y63_N30
\timers:3:channel|LessThan0~13\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|LessThan0~13_combout\ = ( !\timers:3:channel|LessThan0~7_combout\ & ( \timers:3:channel|LessThan0~10_combout\ & ( (\timers:3:channel|LessThan0~12_combout\) # (\timers:3:channel|LessThan0~11_combout\) ) ) ) # ( 
-- !\timers:3:channel|LessThan0~7_combout\ & ( !\timers:3:channel|LessThan0~10_combout\ & ( ((\timers:3:channel|LessThan0~9_combout\ & (\timers:3:channel|LessThan0~8_combout\ & \timers:3:channel|LessThan0~11_combout\))) # 
-- (\timers:3:channel|LessThan0~12_combout\) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000111111111000000000000000000001111111111110000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:3:channel|ALT_INV_LessThan0~9_combout\,
	datab => \timers:3:channel|ALT_INV_LessThan0~8_combout\,
	datac => \timers:3:channel|ALT_INV_LessThan0~11_combout\,
	datad => \timers:3:channel|ALT_INV_LessThan0~12_combout\,
	datae => \timers:3:channel|ALT_INV_LessThan0~7_combout\,
	dataf => \timers:3:channel|ALT_INV_LessThan0~10_combout\,
	combout => \timers:3:channel|LessThan0~13_combout\);

-- Location: LABCELL_X23_Y63_N45
\timers:3:channel|LessThan0~4\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|LessThan0~4_combout\ = ( !\timers:3:channel|LessThan0~2_combout\ & ( (!\timers:3:channel|LessThan0~3_combout\ & (!\timers:3:channel|LessThan0~1_combout\ & \timers:3:channel|LessThan0~0_combout\)) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000011000000000000001100000000000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \timers:3:channel|ALT_INV_LessThan0~3_combout\,
	datac => \timers:3:channel|ALT_INV_LessThan0~1_combout\,
	datad => \timers:3:channel|ALT_INV_LessThan0~0_combout\,
	dataf => \timers:3:channel|ALT_INV_LessThan0~2_combout\,
	combout => \timers:3:channel|LessThan0~4_combout\);

-- Location: LABCELL_X23_Y63_N18
\timers:3:channel|LessThan0~16\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|LessThan0~16_combout\ = ( \timers:3:channel|LessThan0~4_combout\ & ( \timers:3:channel|LessThan0~15_combout\ & ( (!\timers:3:channel|Add0~1_sumout\ & \timers:3:channel|elapsed_r\(15)) ) ) ) # ( !\timers:3:channel|LessThan0~4_combout\ & ( 
-- \timers:3:channel|LessThan0~15_combout\ & ( (!\timers:3:channel|Add0~1_sumout\ & \timers:3:channel|elapsed_r\(15)) ) ) ) # ( \timers:3:channel|LessThan0~4_combout\ & ( !\timers:3:channel|LessThan0~15_combout\ & ( (!\timers:3:channel|Add0~1_sumout\ & 
-- (((\timers:3:channel|LessThan0~6_combout\ & !\timers:3:channel|LessThan0~13_combout\)) # (\timers:3:channel|elapsed_r\(15)))) # (\timers:3:channel|Add0~1_sumout\ & (\timers:3:channel|elapsed_r\(15) & (\timers:3:channel|LessThan0~6_combout\ & 
-- !\timers:3:channel|LessThan0~13_combout\))) ) ) ) # ( !\timers:3:channel|LessThan0~4_combout\ & ( !\timers:3:channel|LessThan0~15_combout\ & ( (!\timers:3:channel|Add0~1_sumout\ & ((\timers:3:channel|LessThan0~6_combout\) # 
-- (\timers:3:channel|elapsed_r\(15)))) # (\timers:3:channel|Add0~1_sumout\ & (\timers:3:channel|elapsed_r\(15) & \timers:3:channel|LessThan0~6_combout\)) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0010101100101011001010110010001000100010001000100010001000100010",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:3:channel|ALT_INV_Add0~1_sumout\,
	datab => \timers:3:channel|ALT_INV_elapsed_r\(15),
	datac => \timers:3:channel|ALT_INV_LessThan0~6_combout\,
	datad => \timers:3:channel|ALT_INV_LessThan0~13_combout\,
	datae => \timers:3:channel|ALT_INV_LessThan0~4_combout\,
	dataf => \timers:3:channel|ALT_INV_LessThan0~15_combout\,
	combout => \timers:3:channel|LessThan0~16_combout\);

-- Location: LABCELL_X22_Y65_N12
\timers:3:channel|Mux33~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|Mux33~0_combout\ = ( \timers:3:channel|running_r~q\ & ( \timers:3:channel|LessThan0~16_combout\ & ( (!\timers:0:channel|Mux33~0_combout\ & (((!\timers:3:channel|running_r~0_combout\)))) # (\timers:0:channel|Mux33~0_combout\ & 
-- ((!\Equal11~4_combout\ & ((!\timers:3:channel|running_r~0_combout\))) # (\Equal11~4_combout\ & (!\IO_DATA[1]~input_o\)))) ) ) ) # ( !\timers:3:channel|running_r~q\ & ( \timers:3:channel|LessThan0~16_combout\ & ( (\timers:0:channel|Mux33~0_combout\ & 
-- (!\IO_DATA[1]~input_o\ & \Equal11~4_combout\)) ) ) ) # ( \timers:3:channel|running_r~q\ & ( !\timers:3:channel|LessThan0~16_combout\ & ( (!\timers:0:channel|Mux33~0_combout\) # ((!\IO_DATA[1]~input_o\) # (!\Equal11~4_combout\)) ) ) ) # ( 
-- !\timers:3:channel|running_r~q\ & ( !\timers:3:channel|LessThan0~16_combout\ & ( (!\timers:0:channel|Mux33~0_combout\ & (((\timers:3:channel|running_r~0_combout\)))) # (\timers:0:channel|Mux33~0_combout\ & ((!\Equal11~4_combout\ & 
-- ((\timers:3:channel|running_r~0_combout\))) # (\Equal11~4_combout\ & (!\IO_DATA[1]~input_o\)))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000010011111110111111101111111000000100000001001111111000000100",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:0:channel|ALT_INV_Mux33~0_combout\,
	datab => \ALT_INV_IO_DATA[1]~input_o\,
	datac => \ALT_INV_Equal11~4_combout\,
	datad => \timers:3:channel|ALT_INV_running_r~0_combout\,
	datae => \timers:3:channel|ALT_INV_running_r~q\,
	dataf => \timers:3:channel|ALT_INV_LessThan0~16_combout\,
	combout => \timers:3:channel|Mux33~0_combout\);

-- Location: FF_X22_Y65_N14
\timers:3:channel|running_r\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:3:channel|Mux33~0_combout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:3:channel|running_r~q\);

-- Location: LABCELL_X22_Y63_N48
\timers:3:channel|elapsed_r[9]~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|elapsed_r[9]~0_combout\ = ( \Equal11~4_combout\ & ( \timers:3:channel|LessThan0~16_combout\ & ( (!\timers:3:channel|mode_r\(1) & (\timers:0:channel|periods_r~0_combout\ & (!\timers:3:channel|running_r~q\))) # 
-- (\timers:3:channel|mode_r\(1) & ((!\timers:3:channel|mode_r\(0)) # ((\timers:0:channel|periods_r~0_combout\ & !\timers:3:channel|running_r~q\)))) ) ) ) # ( !\Equal11~4_combout\ & ( \timers:3:channel|LessThan0~16_combout\ & ( (\timers:3:channel|mode_r\(1) 
-- & !\timers:3:channel|mode_r\(0)) ) ) ) # ( \Equal11~4_combout\ & ( !\timers:3:channel|LessThan0~16_combout\ & ( (\timers:0:channel|periods_r~0_combout\ & !\timers:3:channel|running_r~q\) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000001100000011000001010101000000000111010100110000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:3:channel|ALT_INV_mode_r\(1),
	datab => \timers:0:channel|ALT_INV_periods_r~0_combout\,
	datac => \timers:3:channel|ALT_INV_running_r~q\,
	datad => \timers:3:channel|ALT_INV_mode_r\(0),
	datae => \ALT_INV_Equal11~4_combout\,
	dataf => \timers:3:channel|ALT_INV_LessThan0~16_combout\,
	combout => \timers:3:channel|elapsed_r[9]~0_combout\);

-- Location: FF_X22_Y63_N2
\timers:3:channel|elapsed_r[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:3:channel|Add2~1_sumout\,
	asdata => \timers:3:channel|duration_r[0]~_wirecell_combout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:3:channel|elapsed_r[9]~0_combout\,
	sload => \timers:3:channel|elapsed_r[9]~1_combout\,
	ena => \timers:3:channel|elapsed_r[9]~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:3:channel|elapsed_r\(0));

-- Location: MLABCELL_X21_Y66_N0
\timers:2:channel|Add2~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|Add2~1_sumout\ = SUM(( \timers:2:channel|elapsed_r\(0) ) + ( VCC ) + ( !VCC ))
-- \timers:2:channel|Add2~2\ = CARRY(( \timers:2:channel|elapsed_r\(0) ) + ( VCC ) + ( !VCC ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:2:channel|ALT_INV_elapsed_r\(0),
	cin => GND,
	sumout => \timers:2:channel|Add2~1_sumout\,
	cout => \timers:2:channel|Add2~2\);

-- Location: LABCELL_X19_Y67_N51
\timers:2:channel|duration_r[0]~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|duration_r[0]~0_combout\ = ( !\IO_DATA[0]~input_o\ )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111111111111111111111111111111100000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataf => \ALT_INV_IO_DATA[0]~input_o\,
	combout => \timers:2:channel|duration_r[0]~0_combout\);

-- Location: LABCELL_X22_Y69_N57
\Equal11~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \Equal11~0_combout\ = ( !\IO_ADDR[2]~input_o\ & ( \IO_ADDR[3]~input_o\ ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0101010101010101000000000000000001010101010101010000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_IO_ADDR[3]~input_o\,
	datae => \ALT_INV_IO_ADDR[2]~input_o\,
	combout => \Equal11~0_combout\);

-- Location: LABCELL_X24_Y69_N45
\timers:2:channel|process_0~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|process_0~1_combout\ = ( \timers:0:channel|process_0~1_combout\ & ( (!\IO_ADDR[10]~input_o\ & (\Equal0~0_combout\ & (\IO_WRITE~input_o\ & \Equal11~0_combout\))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000100000000000000010",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_IO_ADDR[10]~input_o\,
	datab => \ALT_INV_Equal0~0_combout\,
	datac => \ALT_INV_IO_WRITE~input_o\,
	datad => \ALT_INV_Equal11~0_combout\,
	dataf => \timers:0:channel|ALT_INV_process_0~1_combout\,
	combout => \timers:2:channel|process_0~1_combout\);

-- Location: FF_X23_Y66_N32
\timers:2:channel|duration_r[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \timers:2:channel|duration_r[0]~0_combout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sload => VCC,
	ena => \timers:2:channel|process_0~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:2:channel|duration_r\(0));

-- Location: LABCELL_X19_Y66_N36
\timers:2:channel|duration_r[0]~_wirecell\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|duration_r[0]~_wirecell_combout\ = ( !\timers:2:channel|duration_r\(0) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111111111111111111111111111111100000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataf => \timers:2:channel|ALT_INV_duration_r\(0),
	combout => \timers:2:channel|duration_r[0]~_wirecell_combout\);

-- Location: MLABCELL_X25_Y72_N3
\timers:2:channel|mode_r[0]~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|mode_r[0]~0_combout\ = ( !\IO_DATA[0]~input_o\ )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111111111111111111111111111111100000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataf => \ALT_INV_IO_DATA[0]~input_o\,
	combout => \timers:2:channel|mode_r[0]~0_combout\);

-- Location: LABCELL_X24_Y69_N57
\timers:2:channel|process_0~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|process_0~0_combout\ = ( \timers:0:channel|process_0~0_combout\ & ( (!\IO_ADDR[10]~input_o\ & (\IO_WRITE~input_o\ & (\Equal0~0_combout\ & \Equal11~0_combout\))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000100000000000000010",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_IO_ADDR[10]~input_o\,
	datab => \ALT_INV_IO_WRITE~input_o\,
	datac => \ALT_INV_Equal0~0_combout\,
	datad => \ALT_INV_Equal11~0_combout\,
	dataf => \timers:0:channel|ALT_INV_process_0~0_combout\,
	combout => \timers:2:channel|process_0~0_combout\);

-- Location: FF_X24_Y71_N53
\timers:2:channel|mode_r[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \timers:2:channel|mode_r[0]~0_combout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sload => VCC,
	ena => \timers:2:channel|process_0~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:2:channel|mode_r\(0));

-- Location: FF_X22_Y71_N17
\timers:2:channel|mode_r[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \IO_DATA[1]~input_o\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sload => VCC,
	ena => \timers:2:channel|process_0~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:2:channel|mode_r\(1));

-- Location: LABCELL_X24_Y69_N54
\Equal11~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \Equal11~1_combout\ = ( !\IO_ADDR[10]~input_o\ & ( (\IO_WRITE~input_o\ & (\Equal0~0_combout\ & \Equal11~0_combout\)) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000011000000000000001100000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \ALT_INV_IO_WRITE~input_o\,
	datac => \ALT_INV_Equal0~0_combout\,
	datad => \ALT_INV_Equal11~0_combout\,
	dataf => \ALT_INV_IO_ADDR[10]~input_o\,
	combout => \Equal11~1_combout\);

-- Location: MLABCELL_X25_Y71_N3
\timers:2:channel|clear_prescale~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|clear_prescale~0_combout\ = ( \Equal11~1_combout\ & ( (!\timers:0:channel|periods_r~0_combout\ & (\timers:3:channel|process_0~2_combout\)) # (\timers:0:channel|periods_r~0_combout\ & ((!\timers:2:channel|running_r~q\))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000001010101110011000101010111001100",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:3:channel|ALT_INV_process_0~2_combout\,
	datab => \timers:2:channel|ALT_INV_running_r~q\,
	datad => \timers:0:channel|ALT_INV_periods_r~0_combout\,
	dataf => \ALT_INV_Equal11~1_combout\,
	combout => \timers:2:channel|clear_prescale~0_combout\);

-- Location: FF_X25_Y71_N5
\timers:2:channel|clear_prescale\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:2:channel|clear_prescale~0_combout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:2:channel|clear_prescale~q\);

-- Location: MLABCELL_X25_Y71_N0
\timers:2:channel|prescaler|cycle_count[3]~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|prescaler|cycle_count[3]~1_combout\ = (\timers:2:channel|clear_prescale~q\) # (\timers:2:channel|running_r~q\)

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0011111100111111001111110011111100111111001111110011111100111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \timers:2:channel|ALT_INV_running_r~q\,
	datac => \timers:2:channel|ALT_INV_clear_prescale~q\,
	combout => \timers:2:channel|prescaler|cycle_count[3]~1_combout\);

-- Location: FF_X25_Y71_N31
\timers:2:channel|prescaler|cycle_count[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:2:channel|prescaler|cycle_count~4_combout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	ena => \timers:2:channel|prescaler|cycle_count[3]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:2:channel|prescaler|cycle_count\(0));

-- Location: MLABCELL_X25_Y71_N30
\timers:2:channel|prescaler|cycle_count~4\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|prescaler|cycle_count~4_combout\ = ( !\timers:2:channel|prescaler|LessThan0~0_combout\ & ( (!\timers:2:channel|clear_prescale~q\ & !\timers:2:channel|prescaler|cycle_count\(0)) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111000000000000111100000000000000000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:2:channel|ALT_INV_clear_prescale~q\,
	datad => \timers:2:channel|prescaler|ALT_INV_cycle_count\(0),
	dataf => \timers:2:channel|prescaler|ALT_INV_LessThan0~0_combout\,
	combout => \timers:2:channel|prescaler|cycle_count~4_combout\);

-- Location: FF_X25_Y71_N32
\timers:2:channel|prescaler|cycle_count[0]~DUPLICATE\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:2:channel|prescaler|cycle_count~4_combout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	ena => \timers:2:channel|prescaler|cycle_count[3]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:2:channel|prescaler|cycle_count[0]~DUPLICATE_q\);

-- Location: MLABCELL_X25_Y71_N15
\timers:2:channel|prescaler|cycle_count~3\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|prescaler|cycle_count~3_combout\ = ( !\timers:2:channel|prescaler|LessThan0~0_combout\ & ( (!\timers:2:channel|clear_prescale~q\ & (!\timers:2:channel|prescaler|cycle_count[0]~DUPLICATE_q\ $ 
-- (!\timers:2:channel|prescaler|cycle_count\(1)))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000101010100000000010101010000000000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:2:channel|ALT_INV_clear_prescale~q\,
	datac => \timers:2:channel|prescaler|ALT_INV_cycle_count[0]~DUPLICATE_q\,
	datad => \timers:2:channel|prescaler|ALT_INV_cycle_count\(1),
	dataf => \timers:2:channel|prescaler|ALT_INV_LessThan0~0_combout\,
	combout => \timers:2:channel|prescaler|cycle_count~3_combout\);

-- Location: FF_X25_Y71_N17
\timers:2:channel|prescaler|cycle_count[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:2:channel|prescaler|cycle_count~3_combout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	ena => \timers:2:channel|prescaler|cycle_count[3]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:2:channel|prescaler|cycle_count\(1));

-- Location: MLABCELL_X25_Y71_N21
\timers:2:channel|prescaler|cycle_count~2\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|prescaler|cycle_count~2_combout\ = ( !\timers:2:channel|prescaler|cycle_count\(3) & ( (!\timers:2:channel|clear_prescale~q\ & (!\timers:2:channel|prescaler|cycle_count\(2) $ (((!\timers:2:channel|prescaler|cycle_count\(1)) # 
-- (!\timers:2:channel|prescaler|cycle_count[0]~DUPLICATE_q\))))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000001010101000000000101010100000000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:2:channel|ALT_INV_clear_prescale~q\,
	datab => \timers:2:channel|prescaler|ALT_INV_cycle_count\(1),
	datac => \timers:2:channel|prescaler|ALT_INV_cycle_count[0]~DUPLICATE_q\,
	datad => \timers:2:channel|prescaler|ALT_INV_cycle_count\(2),
	dataf => \timers:2:channel|prescaler|ALT_INV_cycle_count\(3),
	combout => \timers:2:channel|prescaler|cycle_count~2_combout\);

-- Location: FF_X25_Y71_N22
\timers:2:channel|prescaler|cycle_count[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:2:channel|prescaler|cycle_count~2_combout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	ena => \timers:2:channel|prescaler|cycle_count[3]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:2:channel|prescaler|cycle_count\(2));

-- Location: MLABCELL_X25_Y71_N18
\timers:2:channel|prescaler|cycle_count~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|prescaler|cycle_count~0_combout\ = ( \timers:2:channel|prescaler|cycle_count\(2) & ( (!\timers:2:channel|clear_prescale~q\ & (\timers:2:channel|prescaler|cycle_count\(1) & (\timers:2:channel|prescaler|cycle_count\(0) & 
-- !\timers:2:channel|prescaler|cycle_count\(3)))) ) ) # ( !\timers:2:channel|prescaler|cycle_count\(2) & ( (!\timers:2:channel|clear_prescale~q\ & (!\timers:2:channel|prescaler|cycle_count\(1) & (!\timers:2:channel|prescaler|cycle_count\(0) & 
-- \timers:2:channel|prescaler|cycle_count\(3)))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000010000000000000001000000000000010000000000000001000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:2:channel|ALT_INV_clear_prescale~q\,
	datab => \timers:2:channel|prescaler|ALT_INV_cycle_count\(1),
	datac => \timers:2:channel|prescaler|ALT_INV_cycle_count\(0),
	datad => \timers:2:channel|prescaler|ALT_INV_cycle_count\(3),
	dataf => \timers:2:channel|prescaler|ALT_INV_cycle_count\(2),
	combout => \timers:2:channel|prescaler|cycle_count~0_combout\);

-- Location: FF_X25_Y71_N20
\timers:2:channel|prescaler|cycle_count[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:2:channel|prescaler|cycle_count~0_combout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	ena => \timers:2:channel|prescaler|cycle_count[3]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:2:channel|prescaler|cycle_count\(3));

-- Location: MLABCELL_X25_Y71_N33
\timers:2:channel|prescaler|LessThan0~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|prescaler|LessThan0~0_combout\ = ( \timers:2:channel|prescaler|cycle_count\(2) & ( \timers:2:channel|prescaler|cycle_count\(3) ) ) # ( !\timers:2:channel|prescaler|cycle_count\(2) & ( (\timers:2:channel|prescaler|cycle_count\(3) & 
-- ((\timers:2:channel|prescaler|cycle_count\(1)) # (\timers:2:channel|prescaler|cycle_count[0]~DUPLICATE_q\))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0001010100010101000101010001010101010101010101010101010101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:2:channel|prescaler|ALT_INV_cycle_count\(3),
	datab => \timers:2:channel|prescaler|ALT_INV_cycle_count[0]~DUPLICATE_q\,
	datac => \timers:2:channel|prescaler|ALT_INV_cycle_count\(1),
	dataf => \timers:2:channel|prescaler|ALT_INV_cycle_count\(2),
	combout => \timers:2:channel|prescaler|LessThan0~0_combout\);

-- Location: MLABCELL_X25_Y71_N39
\timers:2:channel|prescaler|TICK~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|prescaler|TICK~0_combout\ = ( !\timers:2:channel|clear_prescale~q\ & ( \timers:2:channel|prescaler|LessThan0~0_combout\ & ( \timers:2:channel|running_r~q\ ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000001111000011110000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:2:channel|ALT_INV_running_r~q\,
	datae => \timers:2:channel|ALT_INV_clear_prescale~q\,
	dataf => \timers:2:channel|prescaler|ALT_INV_LessThan0~0_combout\,
	combout => \timers:2:channel|prescaler|TICK~0_combout\);

-- Location: LABCELL_X22_Y71_N6
\timers:2:channel|timescale_r[8]~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|timescale_r[8]~0_combout\ = !\IO_DATA[8]~input_o\

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111000011110000111100001111000011110000111100001111000011110000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \ALT_INV_IO_DATA[8]~input_o\,
	combout => \timers:2:channel|timescale_r[8]~0_combout\);

-- Location: LABCELL_X22_Y71_N27
\timers:2:channel|process_0~2\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|process_0~2_combout\ = ( \timers:3:channel|process_0~2_combout\ & ( (\Equal0~0_combout\ & (\Equal11~0_combout\ & (\IO_WRITE~input_o\ & !\IO_ADDR[10]~input_o\))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000001000000000000000100000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_Equal0~0_combout\,
	datab => \ALT_INV_Equal11~0_combout\,
	datac => \ALT_INV_IO_WRITE~input_o\,
	datad => \ALT_INV_IO_ADDR[10]~input_o\,
	dataf => \timers:3:channel|ALT_INV_process_0~2_combout\,
	combout => \timers:2:channel|process_0~2_combout\);

-- Location: FF_X22_Y71_N8
\timers:2:channel|timescale_r[8]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:2:channel|timescale_r[8]~0_combout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	ena => \timers:2:channel|process_0~2_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:2:channel|timescale_r\(8));

-- Location: MLABCELL_X25_Y71_N12
\timers:2:channel|prescaler|ms_count[1]~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|prescaler|ms_count[1]~1_combout\ = ((\timers:2:channel|prescaler|LessThan0~0_combout\ & \timers:2:channel|running_r~q\)) # (\timers:2:channel|clear_prescale~q\)

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0101010101011111010101010101111101010101010111110101010101011111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:2:channel|ALT_INV_clear_prescale~q\,
	datac => \timers:2:channel|prescaler|ALT_INV_LessThan0~0_combout\,
	datad => \timers:2:channel|ALT_INV_running_r~q\,
	combout => \timers:2:channel|prescaler|ms_count[1]~1_combout\);

-- Location: FF_X23_Y71_N46
\timers:2:channel|prescaler|ms_count[15]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:2:channel|prescaler|Add1~1_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:2:channel|prescaler|ms_count[1]~0_combout\,
	ena => \timers:2:channel|prescaler|ms_count[1]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:2:channel|prescaler|ms_count\(15));

-- Location: LABCELL_X23_Y71_N0
\timers:2:channel|prescaler|Add1~49\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|prescaler|Add1~49_sumout\ = SUM(( \timers:2:channel|prescaler|ms_count\(0) ) + ( VCC ) + ( !VCC ))
-- \timers:2:channel|prescaler|Add1~50\ = CARRY(( \timers:2:channel|prescaler|ms_count\(0) ) + ( VCC ) + ( !VCC ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000000000000011111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datad => \timers:2:channel|prescaler|ALT_INV_ms_count\(0),
	cin => GND,
	sumout => \timers:2:channel|prescaler|Add1~49_sumout\,
	cout => \timers:2:channel|prescaler|Add1~50\);

-- Location: FF_X23_Y71_N2
\timers:2:channel|prescaler|ms_count[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:2:channel|prescaler|Add1~49_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:2:channel|prescaler|ms_count[1]~0_combout\,
	ena => \timers:2:channel|prescaler|ms_count[1]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:2:channel|prescaler|ms_count\(0));

-- Location: LABCELL_X23_Y71_N3
\timers:2:channel|prescaler|Add1~45\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|prescaler|Add1~45_sumout\ = SUM(( \timers:2:channel|prescaler|ms_count\(1) ) + ( GND ) + ( \timers:2:channel|prescaler|Add1~50\ ))
-- \timers:2:channel|prescaler|Add1~46\ = CARRY(( \timers:2:channel|prescaler|ms_count\(1) ) + ( GND ) + ( \timers:2:channel|prescaler|Add1~50\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000000011111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datad => \timers:2:channel|prescaler|ALT_INV_ms_count\(1),
	cin => \timers:2:channel|prescaler|Add1~50\,
	sumout => \timers:2:channel|prescaler|Add1~45_sumout\,
	cout => \timers:2:channel|prescaler|Add1~46\);

-- Location: FF_X23_Y71_N5
\timers:2:channel|prescaler|ms_count[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:2:channel|prescaler|Add1~45_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:2:channel|prescaler|ms_count[1]~0_combout\,
	ena => \timers:2:channel|prescaler|ms_count[1]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:2:channel|prescaler|ms_count\(1));

-- Location: LABCELL_X23_Y71_N6
\timers:2:channel|prescaler|Add1~41\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|prescaler|Add1~41_sumout\ = SUM(( \timers:2:channel|prescaler|ms_count\(2) ) + ( GND ) + ( \timers:2:channel|prescaler|Add1~46\ ))
-- \timers:2:channel|prescaler|Add1~42\ = CARRY(( \timers:2:channel|prescaler|ms_count\(2) ) + ( GND ) + ( \timers:2:channel|prescaler|Add1~46\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \timers:2:channel|prescaler|ALT_INV_ms_count\(2),
	cin => \timers:2:channel|prescaler|Add1~46\,
	sumout => \timers:2:channel|prescaler|Add1~41_sumout\,
	cout => \timers:2:channel|prescaler|Add1~42\);

-- Location: FF_X23_Y71_N8
\timers:2:channel|prescaler|ms_count[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:2:channel|prescaler|Add1~41_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:2:channel|prescaler|ms_count[1]~0_combout\,
	ena => \timers:2:channel|prescaler|ms_count[1]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:2:channel|prescaler|ms_count\(2));

-- Location: LABCELL_X23_Y71_N9
\timers:2:channel|prescaler|Add1~37\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|prescaler|Add1~37_sumout\ = SUM(( \timers:2:channel|prescaler|ms_count\(3) ) + ( GND ) + ( \timers:2:channel|prescaler|Add1~42\ ))
-- \timers:2:channel|prescaler|Add1~38\ = CARRY(( \timers:2:channel|prescaler|ms_count\(3) ) + ( GND ) + ( \timers:2:channel|prescaler|Add1~42\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:2:channel|prescaler|ALT_INV_ms_count\(3),
	cin => \timers:2:channel|prescaler|Add1~42\,
	sumout => \timers:2:channel|prescaler|Add1~37_sumout\,
	cout => \timers:2:channel|prescaler|Add1~38\);

-- Location: FF_X23_Y71_N11
\timers:2:channel|prescaler|ms_count[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:2:channel|prescaler|Add1~37_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:2:channel|prescaler|ms_count[1]~0_combout\,
	ena => \timers:2:channel|prescaler|ms_count[1]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:2:channel|prescaler|ms_count\(3));

-- Location: LABCELL_X23_Y71_N12
\timers:2:channel|prescaler|Add1~33\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|prescaler|Add1~33_sumout\ = SUM(( \timers:2:channel|prescaler|ms_count\(4) ) + ( GND ) + ( \timers:2:channel|prescaler|Add1~38\ ))
-- \timers:2:channel|prescaler|Add1~34\ = CARRY(( \timers:2:channel|prescaler|ms_count\(4) ) + ( GND ) + ( \timers:2:channel|prescaler|Add1~38\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \timers:2:channel|prescaler|ALT_INV_ms_count\(4),
	cin => \timers:2:channel|prescaler|Add1~38\,
	sumout => \timers:2:channel|prescaler|Add1~33_sumout\,
	cout => \timers:2:channel|prescaler|Add1~34\);

-- Location: FF_X23_Y71_N14
\timers:2:channel|prescaler|ms_count[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:2:channel|prescaler|Add1~33_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:2:channel|prescaler|ms_count[1]~0_combout\,
	ena => \timers:2:channel|prescaler|ms_count[1]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:2:channel|prescaler|ms_count\(4));

-- Location: LABCELL_X23_Y71_N15
\timers:2:channel|prescaler|Add1~61\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|prescaler|Add1~61_sumout\ = SUM(( \timers:2:channel|prescaler|ms_count\(5) ) + ( GND ) + ( \timers:2:channel|prescaler|Add1~34\ ))
-- \timers:2:channel|prescaler|Add1~62\ = CARRY(( \timers:2:channel|prescaler|ms_count\(5) ) + ( GND ) + ( \timers:2:channel|prescaler|Add1~34\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:2:channel|prescaler|ALT_INV_ms_count\(5),
	cin => \timers:2:channel|prescaler|Add1~34\,
	sumout => \timers:2:channel|prescaler|Add1~61_sumout\,
	cout => \timers:2:channel|prescaler|Add1~62\);

-- Location: FF_X23_Y71_N17
\timers:2:channel|prescaler|ms_count[5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:2:channel|prescaler|Add1~61_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:2:channel|prescaler|ms_count[1]~0_combout\,
	ena => \timers:2:channel|prescaler|ms_count[1]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:2:channel|prescaler|ms_count\(5));

-- Location: LABCELL_X23_Y71_N18
\timers:2:channel|prescaler|Add1~57\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|prescaler|Add1~57_sumout\ = SUM(( \timers:2:channel|prescaler|ms_count\(6) ) + ( GND ) + ( \timers:2:channel|prescaler|Add1~62\ ))
-- \timers:2:channel|prescaler|Add1~58\ = CARRY(( \timers:2:channel|prescaler|ms_count\(6) ) + ( GND ) + ( \timers:2:channel|prescaler|Add1~62\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:2:channel|prescaler|ALT_INV_ms_count\(6),
	cin => \timers:2:channel|prescaler|Add1~62\,
	sumout => \timers:2:channel|prescaler|Add1~57_sumout\,
	cout => \timers:2:channel|prescaler|Add1~58\);

-- Location: FF_X23_Y71_N20
\timers:2:channel|prescaler|ms_count[6]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:2:channel|prescaler|Add1~57_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:2:channel|prescaler|ms_count[1]~0_combout\,
	ena => \timers:2:channel|prescaler|ms_count[1]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:2:channel|prescaler|ms_count\(6));

-- Location: LABCELL_X23_Y71_N21
\timers:2:channel|prescaler|Add1~53\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|prescaler|Add1~53_sumout\ = SUM(( \timers:2:channel|prescaler|ms_count\(7) ) + ( GND ) + ( \timers:2:channel|prescaler|Add1~58\ ))
-- \timers:2:channel|prescaler|Add1~54\ = CARRY(( \timers:2:channel|prescaler|ms_count\(7) ) + ( GND ) + ( \timers:2:channel|prescaler|Add1~58\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000000011111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datad => \timers:2:channel|prescaler|ALT_INV_ms_count\(7),
	cin => \timers:2:channel|prescaler|Add1~58\,
	sumout => \timers:2:channel|prescaler|Add1~53_sumout\,
	cout => \timers:2:channel|prescaler|Add1~54\);

-- Location: FF_X23_Y71_N23
\timers:2:channel|prescaler|ms_count[7]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:2:channel|prescaler|Add1~53_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:2:channel|prescaler|ms_count[1]~0_combout\,
	ena => \timers:2:channel|prescaler|ms_count[1]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:2:channel|prescaler|ms_count\(7));

-- Location: LABCELL_X23_Y71_N24
\timers:2:channel|prescaler|Add1~25\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|prescaler|Add1~25_sumout\ = SUM(( \timers:2:channel|prescaler|ms_count\(8) ) + ( GND ) + ( \timers:2:channel|prescaler|Add1~54\ ))
-- \timers:2:channel|prescaler|Add1~26\ = CARRY(( \timers:2:channel|prescaler|ms_count\(8) ) + ( GND ) + ( \timers:2:channel|prescaler|Add1~54\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:2:channel|prescaler|ALT_INV_ms_count\(8),
	cin => \timers:2:channel|prescaler|Add1~54\,
	sumout => \timers:2:channel|prescaler|Add1~25_sumout\,
	cout => \timers:2:channel|prescaler|Add1~26\);

-- Location: LABCELL_X23_Y71_N27
\timers:2:channel|prescaler|Add1~29\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|prescaler|Add1~29_sumout\ = SUM(( \timers:2:channel|prescaler|ms_count\(9) ) + ( GND ) + ( \timers:2:channel|prescaler|Add1~26\ ))
-- \timers:2:channel|prescaler|Add1~30\ = CARRY(( \timers:2:channel|prescaler|ms_count\(9) ) + ( GND ) + ( \timers:2:channel|prescaler|Add1~26\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000000011111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datad => \timers:2:channel|prescaler|ALT_INV_ms_count\(9),
	cin => \timers:2:channel|prescaler|Add1~26\,
	sumout => \timers:2:channel|prescaler|Add1~29_sumout\,
	cout => \timers:2:channel|prescaler|Add1~30\);

-- Location: FF_X23_Y71_N29
\timers:2:channel|prescaler|ms_count[9]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:2:channel|prescaler|Add1~29_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:2:channel|prescaler|ms_count[1]~0_combout\,
	ena => \timers:2:channel|prescaler|ms_count[1]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:2:channel|prescaler|ms_count\(9));

-- Location: LABCELL_X23_Y71_N30
\timers:2:channel|prescaler|Add1~21\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|prescaler|Add1~21_sumout\ = SUM(( \timers:2:channel|prescaler|ms_count\(10) ) + ( GND ) + ( \timers:2:channel|prescaler|Add1~30\ ))
-- \timers:2:channel|prescaler|Add1~22\ = CARRY(( \timers:2:channel|prescaler|ms_count\(10) ) + ( GND ) + ( \timers:2:channel|prescaler|Add1~30\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \timers:2:channel|prescaler|ALT_INV_ms_count\(10),
	cin => \timers:2:channel|prescaler|Add1~30\,
	sumout => \timers:2:channel|prescaler|Add1~21_sumout\,
	cout => \timers:2:channel|prescaler|Add1~22\);

-- Location: FF_X23_Y71_N32
\timers:2:channel|prescaler|ms_count[10]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:2:channel|prescaler|Add1~21_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:2:channel|prescaler|ms_count[1]~0_combout\,
	ena => \timers:2:channel|prescaler|ms_count[1]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:2:channel|prescaler|ms_count\(10));

-- Location: LABCELL_X23_Y71_N33
\timers:2:channel|prescaler|Add1~5\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|prescaler|Add1~5_sumout\ = SUM(( \timers:2:channel|prescaler|ms_count\(11) ) + ( GND ) + ( \timers:2:channel|prescaler|Add1~22\ ))
-- \timers:2:channel|prescaler|Add1~6\ = CARRY(( \timers:2:channel|prescaler|ms_count\(11) ) + ( GND ) + ( \timers:2:channel|prescaler|Add1~22\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000101010101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:2:channel|prescaler|ALT_INV_ms_count\(11),
	cin => \timers:2:channel|prescaler|Add1~22\,
	sumout => \timers:2:channel|prescaler|Add1~5_sumout\,
	cout => \timers:2:channel|prescaler|Add1~6\);

-- Location: FF_X23_Y71_N35
\timers:2:channel|prescaler|ms_count[11]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:2:channel|prescaler|Add1~5_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:2:channel|prescaler|ms_count[1]~0_combout\,
	ena => \timers:2:channel|prescaler|ms_count[1]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:2:channel|prescaler|ms_count\(11));

-- Location: LABCELL_X23_Y71_N36
\timers:2:channel|prescaler|Add1~17\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|prescaler|Add1~17_sumout\ = SUM(( \timers:2:channel|prescaler|ms_count\(12) ) + ( GND ) + ( \timers:2:channel|prescaler|Add1~6\ ))
-- \timers:2:channel|prescaler|Add1~18\ = CARRY(( \timers:2:channel|prescaler|ms_count\(12) ) + ( GND ) + ( \timers:2:channel|prescaler|Add1~6\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:2:channel|prescaler|ALT_INV_ms_count\(12),
	cin => \timers:2:channel|prescaler|Add1~6\,
	sumout => \timers:2:channel|prescaler|Add1~17_sumout\,
	cout => \timers:2:channel|prescaler|Add1~18\);

-- Location: FF_X23_Y71_N37
\timers:2:channel|prescaler|ms_count[12]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:2:channel|prescaler|Add1~17_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:2:channel|prescaler|ms_count[1]~0_combout\,
	ena => \timers:2:channel|prescaler|ms_count[1]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:2:channel|prescaler|ms_count\(12));

-- Location: LABCELL_X23_Y71_N39
\timers:2:channel|prescaler|Add1~13\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|prescaler|Add1~13_sumout\ = SUM(( \timers:2:channel|prescaler|ms_count\(13) ) + ( GND ) + ( \timers:2:channel|prescaler|Add1~18\ ))
-- \timers:2:channel|prescaler|Add1~14\ = CARRY(( \timers:2:channel|prescaler|ms_count\(13) ) + ( GND ) + ( \timers:2:channel|prescaler|Add1~18\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:2:channel|prescaler|ALT_INV_ms_count\(13),
	cin => \timers:2:channel|prescaler|Add1~18\,
	sumout => \timers:2:channel|prescaler|Add1~13_sumout\,
	cout => \timers:2:channel|prescaler|Add1~14\);

-- Location: FF_X23_Y71_N40
\timers:2:channel|prescaler|ms_count[13]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:2:channel|prescaler|Add1~13_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:2:channel|prescaler|ms_count[1]~0_combout\,
	ena => \timers:2:channel|prescaler|ms_count[1]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:2:channel|prescaler|ms_count\(13));

-- Location: LABCELL_X23_Y71_N42
\timers:2:channel|prescaler|Add1~9\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|prescaler|Add1~9_sumout\ = SUM(( \timers:2:channel|prescaler|ms_count\(14) ) + ( GND ) + ( \timers:2:channel|prescaler|Add1~14\ ))
-- \timers:2:channel|prescaler|Add1~10\ = CARRY(( \timers:2:channel|prescaler|ms_count\(14) ) + ( GND ) + ( \timers:2:channel|prescaler|Add1~14\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:2:channel|prescaler|ALT_INV_ms_count\(14),
	cin => \timers:2:channel|prescaler|Add1~14\,
	sumout => \timers:2:channel|prescaler|Add1~9_sumout\,
	cout => \timers:2:channel|prescaler|Add1~10\);

-- Location: FF_X23_Y71_N43
\timers:2:channel|prescaler|ms_count[14]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:2:channel|prescaler|Add1~9_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:2:channel|prescaler|ms_count[1]~0_combout\,
	ena => \timers:2:channel|prescaler|ms_count[1]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:2:channel|prescaler|ms_count\(14));

-- Location: LABCELL_X23_Y71_N45
\timers:2:channel|prescaler|Add1~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|prescaler|Add1~1_sumout\ = SUM(( \timers:2:channel|prescaler|ms_count\(15) ) + ( GND ) + ( \timers:2:channel|prescaler|Add1~10\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000101010101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:2:channel|prescaler|ALT_INV_ms_count\(15),
	cin => \timers:2:channel|prescaler|Add1~10\,
	sumout => \timers:2:channel|prescaler|Add1~1_sumout\);

-- Location: LABCELL_X22_Y71_N24
\timers:2:channel|timescale_r[9]~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|timescale_r[9]~1_combout\ = ( !\IO_DATA[9]~input_o\ )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111111111111111111111111111111100000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataf => \ALT_INV_IO_DATA[9]~input_o\,
	combout => \timers:2:channel|timescale_r[9]~1_combout\);

-- Location: FF_X22_Y71_N26
\timers:2:channel|timescale_r[9]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:2:channel|timescale_r[9]~1_combout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	ena => \timers:2:channel|process_0~2_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:2:channel|timescale_r\(9));

-- Location: LABCELL_X24_Y71_N0
\timers:2:channel|prescaler|LessThan1~14\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|prescaler|LessThan1~14_combout\ = ( !\timers:2:channel|prescaler|Add1~25_sumout\ & ( !\timers:2:channel|timescale_r\(8) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1100110011001100110011001100110000000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \timers:2:channel|ALT_INV_timescale_r\(8),
	dataf => \timers:2:channel|prescaler|ALT_INV_Add1~25_sumout\,
	combout => \timers:2:channel|prescaler|LessThan1~14_combout\);

-- Location: FF_X24_Y71_N40
\timers:2:channel|timescale_r[10]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \IO_DATA[10]~input_o\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sload => VCC,
	ena => \timers:2:channel|process_0~2_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:2:channel|timescale_r\(10));

-- Location: LABCELL_X24_Y71_N39
\timers:2:channel|prescaler|LessThan1~4\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|prescaler|LessThan1~4_combout\ = ( \timers:2:channel|prescaler|Add1~21_sumout\ & ( !\timers:2:channel|timescale_r\(10) ) ) # ( !\timers:2:channel|prescaler|Add1~21_sumout\ & ( \timers:2:channel|timescale_r\(10) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000011111111000000001111111111111111000000001111111100000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datad => \timers:2:channel|ALT_INV_timescale_r\(10),
	dataf => \timers:2:channel|prescaler|ALT_INV_Add1~21_sumout\,
	combout => \timers:2:channel|prescaler|LessThan1~4_combout\);

-- Location: FF_X24_Y71_N56
\timers:2:channel|timescale_r[11]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \IO_DATA[11]~input_o\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sload => VCC,
	ena => \timers:2:channel|process_0~2_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:2:channel|timescale_r\(11));

-- Location: LABCELL_X24_Y71_N54
\timers:2:channel|prescaler|LessThan1~3\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|prescaler|LessThan1~3_combout\ = ( \timers:2:channel|prescaler|Add1~5_sumout\ & ( !\timers:2:channel|timescale_r\(11) ) ) # ( !\timers:2:channel|prescaler|Add1~5_sumout\ & ( \timers:2:channel|timescale_r\(11) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000011111111000000001111111111111111000000001111111100000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datad => \timers:2:channel|ALT_INV_timescale_r\(11),
	dataf => \timers:2:channel|prescaler|ALT_INV_Add1~5_sumout\,
	combout => \timers:2:channel|prescaler|LessThan1~3_combout\);

-- Location: FF_X22_Y71_N38
\timers:2:channel|timescale_r[14]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \IO_DATA[14]~input_o\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sload => VCC,
	ena => \timers:2:channel|process_0~2_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:2:channel|timescale_r\(14));

-- Location: MLABCELL_X21_Y71_N15
\timers:2:channel|timescale_r[12]~feeder\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|timescale_r[12]~feeder_combout\ = ( \IO_DATA[12]~input_o\ )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000011111111111111111111111111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataf => \ALT_INV_IO_DATA[12]~input_o\,
	combout => \timers:2:channel|timescale_r[12]~feeder_combout\);

-- Location: FF_X21_Y71_N17
\timers:2:channel|timescale_r[12]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:2:channel|timescale_r[12]~feeder_combout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	ena => \timers:2:channel|process_0~2_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:2:channel|timescale_r\(12));

-- Location: FF_X23_Y71_N56
\timers:2:channel|timescale_r[13]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \IO_DATA[13]~input_o\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sload => VCC,
	ena => \timers:2:channel|process_0~2_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:2:channel|timescale_r\(13));

-- Location: LABCELL_X23_Y71_N54
\timers:2:channel|prescaler|LessThan1~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|prescaler|LessThan1~0_combout\ = ( \timers:2:channel|timescale_r\(13) & ( \timers:2:channel|prescaler|Add1~9_sumout\ & ( (\timers:2:channel|timescale_r\(14) & (\timers:2:channel|prescaler|Add1~13_sumout\ & 
-- (!\timers:2:channel|timescale_r\(12) $ (\timers:2:channel|prescaler|Add1~17_sumout\)))) ) ) ) # ( !\timers:2:channel|timescale_r\(13) & ( \timers:2:channel|prescaler|Add1~9_sumout\ & ( (\timers:2:channel|timescale_r\(14) & 
-- (!\timers:2:channel|prescaler|Add1~13_sumout\ & (!\timers:2:channel|timescale_r\(12) $ (\timers:2:channel|prescaler|Add1~17_sumout\)))) ) ) ) # ( \timers:2:channel|timescale_r\(13) & ( !\timers:2:channel|prescaler|Add1~9_sumout\ & ( 
-- (!\timers:2:channel|timescale_r\(14) & (\timers:2:channel|prescaler|Add1~13_sumout\ & (!\timers:2:channel|timescale_r\(12) $ (\timers:2:channel|prescaler|Add1~17_sumout\)))) ) ) ) # ( !\timers:2:channel|timescale_r\(13) & ( 
-- !\timers:2:channel|prescaler|Add1~9_sumout\ & ( (!\timers:2:channel|timescale_r\(14) & (!\timers:2:channel|prescaler|Add1~13_sumout\ & (!\timers:2:channel|timescale_r\(12) $ (\timers:2:channel|prescaler|Add1~17_sumout\)))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1000001000000000000000001000001001000001000000000000000001000001",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:2:channel|ALT_INV_timescale_r\(14),
	datab => \timers:2:channel|ALT_INV_timescale_r\(12),
	datac => \timers:2:channel|prescaler|ALT_INV_Add1~17_sumout\,
	datad => \timers:2:channel|prescaler|ALT_INV_Add1~13_sumout\,
	datae => \timers:2:channel|ALT_INV_timescale_r\(13),
	dataf => \timers:2:channel|prescaler|ALT_INV_Add1~9_sumout\,
	combout => \timers:2:channel|prescaler|LessThan1~0_combout\);

-- Location: LABCELL_X24_Y71_N30
\timers:2:channel|prescaler|LessThan1~15\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|prescaler|LessThan1~15_combout\ = ( !\timers:2:channel|prescaler|LessThan1~3_combout\ & ( \timers:2:channel|prescaler|LessThan1~0_combout\ & ( (!\timers:2:channel|prescaler|LessThan1~4_combout\ & 
-- ((!\timers:2:channel|prescaler|Add1~29_sumout\ & ((!\timers:2:channel|timescale_r\(9)) # (\timers:2:channel|prescaler|LessThan1~14_combout\))) # (\timers:2:channel|prescaler|Add1~29_sumout\ & (!\timers:2:channel|timescale_r\(9) & 
-- \timers:2:channel|prescaler|LessThan1~14_combout\)))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000010001110000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:2:channel|prescaler|ALT_INV_Add1~29_sumout\,
	datab => \timers:2:channel|ALT_INV_timescale_r\(9),
	datac => \timers:2:channel|prescaler|ALT_INV_LessThan1~14_combout\,
	datad => \timers:2:channel|prescaler|ALT_INV_LessThan1~4_combout\,
	datae => \timers:2:channel|prescaler|ALT_INV_LessThan1~3_combout\,
	dataf => \timers:2:channel|prescaler|ALT_INV_LessThan1~0_combout\,
	combout => \timers:2:channel|prescaler|LessThan1~15_combout\);

-- Location: LABCELL_X22_Y71_N18
\timers:2:channel|prescaler|LessThan1~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|prescaler|LessThan1~1_combout\ = ( \timers:2:channel|prescaler|Add1~17_sumout\ & ( \timers:2:channel|prescaler|Add1~9_sumout\ & ( (\timers:2:channel|timescale_r\(14) & (!\timers:2:channel|prescaler|Add1~13_sumout\ & 
-- \timers:2:channel|timescale_r\(13))) ) ) ) # ( !\timers:2:channel|prescaler|Add1~17_sumout\ & ( \timers:2:channel|prescaler|Add1~9_sumout\ & ( (\timers:2:channel|timescale_r\(14) & ((!\timers:2:channel|timescale_r\(12) & 
-- (!\timers:2:channel|prescaler|Add1~13_sumout\ & \timers:2:channel|timescale_r\(13))) # (\timers:2:channel|timescale_r\(12) & ((!\timers:2:channel|prescaler|Add1~13_sumout\) # (\timers:2:channel|timescale_r\(13)))))) ) ) ) # ( 
-- \timers:2:channel|prescaler|Add1~17_sumout\ & ( !\timers:2:channel|prescaler|Add1~9_sumout\ & ( ((!\timers:2:channel|prescaler|Add1~13_sumout\ & \timers:2:channel|timescale_r\(13))) # (\timers:2:channel|timescale_r\(14)) ) ) ) # ( 
-- !\timers:2:channel|prescaler|Add1~17_sumout\ & ( !\timers:2:channel|prescaler|Add1~9_sumout\ & ( ((!\timers:2:channel|timescale_r\(12) & (!\timers:2:channel|prescaler|Add1~13_sumout\ & \timers:2:channel|timescale_r\(13))) # 
-- (\timers:2:channel|timescale_r\(12) & ((!\timers:2:channel|prescaler|Add1~13_sumout\) # (\timers:2:channel|timescale_r\(13))))) # (\timers:2:channel|timescale_r\(14)) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0111010111110111010101011111010100010000010100010000000001010000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:2:channel|ALT_INV_timescale_r\(14),
	datab => \timers:2:channel|ALT_INV_timescale_r\(12),
	datac => \timers:2:channel|prescaler|ALT_INV_Add1~13_sumout\,
	datad => \timers:2:channel|ALT_INV_timescale_r\(13),
	datae => \timers:2:channel|prescaler|ALT_INV_Add1~17_sumout\,
	dataf => \timers:2:channel|prescaler|ALT_INV_Add1~9_sumout\,
	combout => \timers:2:channel|prescaler|LessThan1~1_combout\);

-- Location: LABCELL_X22_Y71_N0
\timers:2:channel|prescaler|LessThan1~2\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|prescaler|LessThan1~2_combout\ = ( \timers:2:channel|prescaler|LessThan1~0_combout\ & ( !\timers:2:channel|prescaler|LessThan1~1_combout\ & ( (!\timers:2:channel|prescaler|Add1~5_sumout\ & (!\timers:2:channel|timescale_r\(11) & 
-- ((!\timers:2:channel|timescale_r\(10)) # (\timers:2:channel|prescaler|Add1~21_sumout\)))) # (\timers:2:channel|prescaler|Add1~5_sumout\ & ((!\timers:2:channel|timescale_r\(10)) # ((!\timers:2:channel|timescale_r\(11)) # 
-- (\timers:2:channel|prescaler|Add1~21_sumout\)))) ) ) ) # ( !\timers:2:channel|prescaler|LessThan1~0_combout\ & ( !\timers:2:channel|prescaler|LessThan1~1_combout\ ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111111111111111110111110100010100000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:2:channel|prescaler|ALT_INV_Add1~5_sumout\,
	datab => \timers:2:channel|ALT_INV_timescale_r\(10),
	datac => \timers:2:channel|prescaler|ALT_INV_Add1~21_sumout\,
	datad => \timers:2:channel|ALT_INV_timescale_r\(11),
	datae => \timers:2:channel|prescaler|ALT_INV_LessThan1~0_combout\,
	dataf => \timers:2:channel|prescaler|ALT_INV_LessThan1~1_combout\,
	combout => \timers:2:channel|prescaler|LessThan1~2_combout\);

-- Location: FF_X23_Y71_N50
\timers:2:channel|timescale_r[15]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \IO_DATA[15]~input_o\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sload => VCC,
	ena => \timers:2:channel|process_0~2_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:2:channel|timescale_r\(15));

-- Location: LABCELL_X23_Y71_N48
\timers:2:channel|prescaler|ms_count[1]~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|prescaler|ms_count[1]~0_combout\ = ( \timers:2:channel|timescale_r\(15) & ( \timers:2:channel|prescaler|LessThan1~13_combout\ & ( \timers:2:channel|clear_prescale~q\ ) ) ) # ( !\timers:2:channel|timescale_r\(15) & ( 
-- \timers:2:channel|prescaler|LessThan1~13_combout\ & ( (\timers:2:channel|prescaler|Add1~1_sumout\) # (\timers:2:channel|clear_prescale~q\) ) ) ) # ( \timers:2:channel|timescale_r\(15) & ( !\timers:2:channel|prescaler|LessThan1~13_combout\ & ( 
-- ((\timers:2:channel|prescaler|Add1~1_sumout\ & (!\timers:2:channel|prescaler|LessThan1~15_combout\ & \timers:2:channel|prescaler|LessThan1~2_combout\))) # (\timers:2:channel|clear_prescale~q\) ) ) ) # ( !\timers:2:channel|timescale_r\(15) & ( 
-- !\timers:2:channel|prescaler|LessThan1~13_combout\ & ( (((!\timers:2:channel|prescaler|LessThan1~15_combout\ & \timers:2:channel|prescaler|LessThan1~2_combout\)) # (\timers:2:channel|prescaler|Add1~1_sumout\)) # (\timers:2:channel|clear_prescale~q\) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0111011111110111010101010111010101110111011101110101010101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:2:channel|ALT_INV_clear_prescale~q\,
	datab => \timers:2:channel|prescaler|ALT_INV_Add1~1_sumout\,
	datac => \timers:2:channel|prescaler|ALT_INV_LessThan1~15_combout\,
	datad => \timers:2:channel|prescaler|ALT_INV_LessThan1~2_combout\,
	datae => \timers:2:channel|ALT_INV_timescale_r\(15),
	dataf => \timers:2:channel|prescaler|ALT_INV_LessThan1~13_combout\,
	combout => \timers:2:channel|prescaler|ms_count[1]~0_combout\);

-- Location: FF_X23_Y71_N26
\timers:2:channel|prescaler|ms_count[8]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:2:channel|prescaler|Add1~25_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:2:channel|prescaler|ms_count[1]~0_combout\,
	ena => \timers:2:channel|prescaler|ms_count[1]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:2:channel|prescaler|ms_count\(8));

-- Location: LABCELL_X24_Y71_N18
\timers:2:channel|prescaler|LessThan1~5\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|prescaler|LessThan1~5_combout\ = ( \timers:2:channel|prescaler|Add1~25_sumout\ & ( !\timers:2:channel|timescale_r\(8) ) ) # ( !\timers:2:channel|prescaler|Add1~25_sumout\ & ( \timers:2:channel|timescale_r\(8) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000111100001111000011110000111111110000111100001111000011110000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:2:channel|ALT_INV_timescale_r\(8),
	dataf => \timers:2:channel|prescaler|ALT_INV_Add1~25_sumout\,
	combout => \timers:2:channel|prescaler|LessThan1~5_combout\);

-- Location: LABCELL_X24_Y71_N57
\timers:2:channel|prescaler|LessThan1~6\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|prescaler|LessThan1~6_combout\ = ( \timers:2:channel|timescale_r\(9) & ( !\timers:2:channel|prescaler|Add1~29_sumout\ ) ) # ( !\timers:2:channel|timescale_r\(9) & ( \timers:2:channel|prescaler|Add1~29_sumout\ ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000011111111000000001111111111111111000000001111111100000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datad => \timers:2:channel|prescaler|ALT_INV_Add1~29_sumout\,
	dataf => \timers:2:channel|ALT_INV_timescale_r\(9),
	combout => \timers:2:channel|prescaler|LessThan1~6_combout\);

-- Location: LABCELL_X22_Y71_N9
\timers:2:channel|timescale_r[3]~2\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|timescale_r[3]~2_combout\ = !\IO_DATA[3]~input_o\

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111000011110000111100001111000011110000111100001111000011110000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \ALT_INV_IO_DATA[3]~input_o\,
	combout => \timers:2:channel|timescale_r[3]~2_combout\);

-- Location: FF_X22_Y71_N11
\timers:2:channel|timescale_r[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:2:channel|timescale_r[3]~2_combout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	ena => \timers:2:channel|process_0~2_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:2:channel|timescale_r\(3));

-- Location: FF_X23_Y71_N53
\timers:2:channel|timescale_r[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \IO_DATA[2]~input_o\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sload => VCC,
	ena => \timers:2:channel|process_0~2_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:2:channel|timescale_r\(2));

-- Location: FF_X24_Y71_N25
\timers:2:channel|timescale_r[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \IO_DATA[4]~input_o\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sload => VCC,
	ena => \timers:2:channel|process_0~2_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:2:channel|timescale_r\(4));

-- Location: LABCELL_X24_Y71_N24
\timers:2:channel|prescaler|LessThan1~9\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|prescaler|LessThan1~9_combout\ = ( \timers:2:channel|timescale_r\(4) & ( \timers:2:channel|prescaler|Add1~37_sumout\ & ( (!\timers:2:channel|prescaler|Add1~33_sumout\) # ((!\timers:2:channel|timescale_r\(3) & 
-- (!\timers:2:channel|prescaler|Add1~41_sumout\ & \timers:2:channel|timescale_r\(2)))) ) ) ) # ( !\timers:2:channel|timescale_r\(4) & ( \timers:2:channel|prescaler|Add1~37_sumout\ & ( (!\timers:2:channel|prescaler|Add1~33_sumout\ & 
-- (!\timers:2:channel|timescale_r\(3) & (!\timers:2:channel|prescaler|Add1~41_sumout\ & \timers:2:channel|timescale_r\(2)))) ) ) ) # ( \timers:2:channel|timescale_r\(4) & ( !\timers:2:channel|prescaler|Add1~37_sumout\ & ( 
-- (!\timers:2:channel|prescaler|Add1~33_sumout\) # ((!\timers:2:channel|timescale_r\(3)) # ((!\timers:2:channel|prescaler|Add1~41_sumout\ & \timers:2:channel|timescale_r\(2)))) ) ) ) # ( !\timers:2:channel|timescale_r\(4) & ( 
-- !\timers:2:channel|prescaler|Add1~37_sumout\ & ( (!\timers:2:channel|prescaler|Add1~33_sumout\ & ((!\timers:2:channel|timescale_r\(3)) # ((!\timers:2:channel|prescaler|Add1~41_sumout\ & \timers:2:channel|timescale_r\(2))))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1000100010101000111011101111111000000000100000001010101011101010",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:2:channel|prescaler|ALT_INV_Add1~33_sumout\,
	datab => \timers:2:channel|ALT_INV_timescale_r\(3),
	datac => \timers:2:channel|prescaler|ALT_INV_Add1~41_sumout\,
	datad => \timers:2:channel|ALT_INV_timescale_r\(2),
	datae => \timers:2:channel|ALT_INV_timescale_r\(4),
	dataf => \timers:2:channel|prescaler|ALT_INV_Add1~37_sumout\,
	combout => \timers:2:channel|prescaler|LessThan1~9_combout\);

-- Location: FF_X24_Y71_N29
\timers:2:channel|timescale_r[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \IO_DATA[0]~input_o\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sload => VCC,
	ena => \timers:2:channel|process_0~2_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:2:channel|timescale_r\(0));

-- Location: FF_X24_Y71_N44
\timers:2:channel|timescale_r[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \IO_DATA[1]~input_o\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sload => VCC,
	ena => \timers:2:channel|process_0~2_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:2:channel|timescale_r\(1));

-- Location: LABCELL_X24_Y71_N42
\timers:2:channel|prescaler|LessThan1~8\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|prescaler|LessThan1~8_combout\ = ( \timers:2:channel|timescale_r\(1) & ( \timers:2:channel|prescaler|Add1~49_sumout\ & ( (!\timers:2:channel|prescaler|Add1~45_sumout\ & (!\timers:2:channel|prescaler|Add1~41_sumout\ $ 
-- (\timers:2:channel|timescale_r\(2)))) ) ) ) # ( \timers:2:channel|timescale_r\(1) & ( !\timers:2:channel|prescaler|Add1~49_sumout\ & ( (!\timers:2:channel|timescale_r\(0) & (!\timers:2:channel|prescaler|Add1~45_sumout\ & 
-- (!\timers:2:channel|prescaler|Add1~41_sumout\ $ (\timers:2:channel|timescale_r\(2))))) # (\timers:2:channel|timescale_r\(0) & ((!\timers:2:channel|prescaler|Add1~41_sumout\ $ (\timers:2:channel|timescale_r\(2))))) ) ) ) # ( 
-- !\timers:2:channel|timescale_r\(1) & ( !\timers:2:channel|prescaler|Add1~49_sumout\ & ( (\timers:2:channel|timescale_r\(0) & (!\timers:2:channel|prescaler|Add1~45_sumout\ & (!\timers:2:channel|prescaler|Add1~41_sumout\ $ 
-- (\timers:2:channel|timescale_r\(2))))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0100000000000100110100000000110100000000000000001100000000001100",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:2:channel|ALT_INV_timescale_r\(0),
	datab => \timers:2:channel|prescaler|ALT_INV_Add1~45_sumout\,
	datac => \timers:2:channel|prescaler|ALT_INV_Add1~41_sumout\,
	datad => \timers:2:channel|ALT_INV_timescale_r\(2),
	datae => \timers:2:channel|ALT_INV_timescale_r\(1),
	dataf => \timers:2:channel|prescaler|ALT_INV_Add1~49_sumout\,
	combout => \timers:2:channel|prescaler|LessThan1~8_combout\);

-- Location: LABCELL_X22_Y71_N30
\timers:2:channel|timescale_r[7]~3\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|timescale_r[7]~3_combout\ = !\IO_DATA[7]~input_o\

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111000011110000111100001111000011110000111100001111000011110000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \ALT_INV_IO_DATA[7]~input_o\,
	combout => \timers:2:channel|timescale_r[7]~3_combout\);

-- Location: FF_X22_Y71_N32
\timers:2:channel|timescale_r[7]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:2:channel|timescale_r[7]~3_combout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	ena => \timers:2:channel|process_0~2_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:2:channel|timescale_r\(7));

-- Location: LABCELL_X24_Y71_N3
\timers:2:channel|timescale_r[5]~5\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|timescale_r[5]~5_combout\ = ( !\IO_DATA[5]~input_o\ )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111111111111111111111111111111100000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataf => \ALT_INV_IO_DATA[5]~input_o\,
	combout => \timers:2:channel|timescale_r[5]~5_combout\);

-- Location: FF_X24_Y71_N5
\timers:2:channel|timescale_r[5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:2:channel|timescale_r[5]~5_combout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	ena => \timers:2:channel|process_0~2_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:2:channel|timescale_r\(5));

-- Location: LABCELL_X22_Y71_N33
\timers:2:channel|timescale_r[6]~4\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|timescale_r[6]~4_combout\ = ( !\IO_DATA[6]~input_o\ )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111111111111111111111111111111100000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataf => \ALT_INV_IO_DATA[6]~input_o\,
	combout => \timers:2:channel|timescale_r[6]~4_combout\);

-- Location: FF_X22_Y71_N35
\timers:2:channel|timescale_r[6]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:2:channel|timescale_r[6]~4_combout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	ena => \timers:2:channel|process_0~2_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:2:channel|timescale_r\(6));

-- Location: LABCELL_X24_Y71_N6
\timers:2:channel|prescaler|LessThan1~11\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|prescaler|LessThan1~11_combout\ = ( \timers:2:channel|prescaler|Add1~53_sumout\ & ( \timers:2:channel|prescaler|Add1~57_sumout\ & ( (!\timers:2:channel|timescale_r\(7) & (!\timers:2:channel|prescaler|Add1~61_sumout\ & 
-- (!\timers:2:channel|timescale_r\(5) & !\timers:2:channel|timescale_r\(6)))) ) ) ) # ( !\timers:2:channel|prescaler|Add1~53_sumout\ & ( \timers:2:channel|prescaler|Add1~57_sumout\ & ( (!\timers:2:channel|timescale_r\(7)) # 
-- ((!\timers:2:channel|prescaler|Add1~61_sumout\ & (!\timers:2:channel|timescale_r\(5) & !\timers:2:channel|timescale_r\(6)))) ) ) ) # ( \timers:2:channel|prescaler|Add1~53_sumout\ & ( !\timers:2:channel|prescaler|Add1~57_sumout\ & ( 
-- (!\timers:2:channel|timescale_r\(7) & ((!\timers:2:channel|timescale_r\(6)) # ((!\timers:2:channel|prescaler|Add1~61_sumout\ & !\timers:2:channel|timescale_r\(5))))) ) ) ) # ( !\timers:2:channel|prescaler|Add1~53_sumout\ & ( 
-- !\timers:2:channel|prescaler|Add1~57_sumout\ & ( (!\timers:2:channel|timescale_r\(7)) # ((!\timers:2:channel|timescale_r\(6)) # ((!\timers:2:channel|prescaler|Add1~61_sumout\ & !\timers:2:channel|timescale_r\(5)))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111111111101010101010101000000011101010101010101000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:2:channel|ALT_INV_timescale_r\(7),
	datab => \timers:2:channel|prescaler|ALT_INV_Add1~61_sumout\,
	datac => \timers:2:channel|ALT_INV_timescale_r\(5),
	datad => \timers:2:channel|ALT_INV_timescale_r\(6),
	datae => \timers:2:channel|prescaler|ALT_INV_Add1~53_sumout\,
	dataf => \timers:2:channel|prescaler|ALT_INV_Add1~57_sumout\,
	combout => \timers:2:channel|prescaler|LessThan1~11_combout\);

-- Location: LABCELL_X24_Y71_N36
\timers:2:channel|prescaler|LessThan1~7\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|prescaler|LessThan1~7_combout\ = ( \timers:2:channel|prescaler|Add1~37_sumout\ & ( (!\timers:2:channel|timescale_r\(3) & (!\timers:2:channel|timescale_r\(4) $ (\timers:2:channel|prescaler|Add1~33_sumout\))) ) ) # ( 
-- !\timers:2:channel|prescaler|Add1~37_sumout\ & ( (\timers:2:channel|timescale_r\(3) & (!\timers:2:channel|timescale_r\(4) $ (\timers:2:channel|prescaler|Add1~33_sumout\))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000110000000011000011000000001111000000001100001100000000110000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \timers:2:channel|ALT_INV_timescale_r\(4),
	datac => \timers:2:channel|ALT_INV_timescale_r\(3),
	datad => \timers:2:channel|prescaler|ALT_INV_Add1~33_sumout\,
	dataf => \timers:2:channel|prescaler|ALT_INV_Add1~37_sumout\,
	combout => \timers:2:channel|prescaler|LessThan1~7_combout\);

-- Location: LABCELL_X24_Y71_N48
\timers:2:channel|prescaler|LessThan1~10\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|prescaler|LessThan1~10_combout\ = ( \timers:2:channel|prescaler|Add1~53_sumout\ & ( \timers:2:channel|prescaler|Add1~57_sumout\ & ( (!\timers:2:channel|timescale_r\(7) & (!\timers:2:channel|timescale_r\(6) & 
-- (!\timers:2:channel|prescaler|Add1~61_sumout\ $ (!\timers:2:channel|timescale_r\(5))))) ) ) ) # ( !\timers:2:channel|prescaler|Add1~53_sumout\ & ( \timers:2:channel|prescaler|Add1~57_sumout\ & ( (\timers:2:channel|timescale_r\(7) & 
-- (!\timers:2:channel|timescale_r\(6) & (!\timers:2:channel|prescaler|Add1~61_sumout\ $ (!\timers:2:channel|timescale_r\(5))))) ) ) ) # ( \timers:2:channel|prescaler|Add1~53_sumout\ & ( !\timers:2:channel|prescaler|Add1~57_sumout\ & ( 
-- (!\timers:2:channel|timescale_r\(7) & (\timers:2:channel|timescale_r\(6) & (!\timers:2:channel|prescaler|Add1~61_sumout\ $ (!\timers:2:channel|timescale_r\(5))))) ) ) ) # ( !\timers:2:channel|prescaler|Add1~53_sumout\ & ( 
-- !\timers:2:channel|prescaler|Add1~57_sumout\ & ( (\timers:2:channel|timescale_r\(7) & (\timers:2:channel|timescale_r\(6) & (!\timers:2:channel|prescaler|Add1~61_sumout\ $ (!\timers:2:channel|timescale_r\(5))))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000010100000000000010100000010100000000000010100000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:2:channel|ALT_INV_timescale_r\(7),
	datab => \timers:2:channel|prescaler|ALT_INV_Add1~61_sumout\,
	datac => \timers:2:channel|ALT_INV_timescale_r\(5),
	datad => \timers:2:channel|ALT_INV_timescale_r\(6),
	datae => \timers:2:channel|prescaler|ALT_INV_Add1~53_sumout\,
	dataf => \timers:2:channel|prescaler|ALT_INV_Add1~57_sumout\,
	combout => \timers:2:channel|prescaler|LessThan1~10_combout\);

-- Location: LABCELL_X24_Y71_N21
\timers:2:channel|prescaler|LessThan1~12\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|prescaler|LessThan1~12_combout\ = ( \timers:2:channel|prescaler|LessThan1~10_combout\ & ( (!\timers:2:channel|prescaler|LessThan1~9_combout\ & (!\timers:2:channel|prescaler|LessThan1~11_combout\ & 
-- ((!\timers:2:channel|prescaler|LessThan1~8_combout\) # (!\timers:2:channel|prescaler|LessThan1~7_combout\)))) ) ) # ( !\timers:2:channel|prescaler|LessThan1~10_combout\ & ( !\timers:2:channel|prescaler|LessThan1~11_combout\ ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111000011110000111100001111000010100000100000001010000010000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:2:channel|prescaler|ALT_INV_LessThan1~9_combout\,
	datab => \timers:2:channel|prescaler|ALT_INV_LessThan1~8_combout\,
	datac => \timers:2:channel|prescaler|ALT_INV_LessThan1~11_combout\,
	datad => \timers:2:channel|prescaler|ALT_INV_LessThan1~7_combout\,
	dataf => \timers:2:channel|prescaler|ALT_INV_LessThan1~10_combout\,
	combout => \timers:2:channel|prescaler|LessThan1~12_combout\);

-- Location: LABCELL_X24_Y71_N12
\timers:2:channel|prescaler|LessThan1~13\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|prescaler|LessThan1~13_combout\ = ( !\timers:2:channel|prescaler|LessThan1~12_combout\ & ( \timers:2:channel|prescaler|LessThan1~0_combout\ & ( (\timers:2:channel|prescaler|LessThan1~5_combout\ & 
-- (!\timers:2:channel|prescaler|LessThan1~4_combout\ & (!\timers:2:channel|prescaler|LessThan1~3_combout\ & \timers:2:channel|prescaler|LessThan1~6_combout\))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000010000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:2:channel|prescaler|ALT_INV_LessThan1~5_combout\,
	datab => \timers:2:channel|prescaler|ALT_INV_LessThan1~4_combout\,
	datac => \timers:2:channel|prescaler|ALT_INV_LessThan1~3_combout\,
	datad => \timers:2:channel|prescaler|ALT_INV_LessThan1~6_combout\,
	datae => \timers:2:channel|prescaler|ALT_INV_LessThan1~12_combout\,
	dataf => \timers:2:channel|prescaler|ALT_INV_LessThan1~0_combout\,
	combout => \timers:2:channel|prescaler|LessThan1~13_combout\);

-- Location: LABCELL_X22_Y71_N42
\timers:2:channel|prescaler|TICK~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|prescaler|TICK~1_combout\ = ( !\timers:2:channel|timescale_r\(15) & ( \timers:2:channel|prescaler|LessThan1~15_combout\ & ( (\timers:2:channel|prescaler|TICK~0_combout\ & \timers:2:channel|prescaler|Add1~1_sumout\) ) ) ) # ( 
-- \timers:2:channel|timescale_r\(15) & ( !\timers:2:channel|prescaler|LessThan1~15_combout\ & ( (\timers:2:channel|prescaler|TICK~0_combout\ & (!\timers:2:channel|prescaler|LessThan1~13_combout\ & (\timers:2:channel|prescaler|Add1~1_sumout\ & 
-- \timers:2:channel|prescaler|LessThan1~2_combout\))) ) ) ) # ( !\timers:2:channel|timescale_r\(15) & ( !\timers:2:channel|prescaler|LessThan1~15_combout\ & ( (\timers:2:channel|prescaler|TICK~0_combout\ & 
-- (((!\timers:2:channel|prescaler|LessThan1~13_combout\ & \timers:2:channel|prescaler|LessThan1~2_combout\)) # (\timers:2:channel|prescaler|Add1~1_sumout\))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000010101000101000000000000010000000101000001010000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:2:channel|prescaler|ALT_INV_TICK~0_combout\,
	datab => \timers:2:channel|prescaler|ALT_INV_LessThan1~13_combout\,
	datac => \timers:2:channel|prescaler|ALT_INV_Add1~1_sumout\,
	datad => \timers:2:channel|prescaler|ALT_INV_LessThan1~2_combout\,
	datae => \timers:2:channel|ALT_INV_timescale_r\(15),
	dataf => \timers:2:channel|prescaler|ALT_INV_LessThan1~15_combout\,
	combout => \timers:2:channel|prescaler|TICK~1_combout\);

-- Location: FF_X22_Y71_N44
\timers:2:channel|prescaler|TICK~DUPLICATE\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:2:channel|prescaler|TICK~1_combout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:2:channel|prescaler|TICK~DUPLICATE_q\);

-- Location: LABCELL_X22_Y71_N57
\timers:2:channel|running_r~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|running_r~0_combout\ = ( \timers:2:channel|running_r~q\ & ( \timers:2:channel|prescaler|TICK~DUPLICATE_q\ & ( (\timers:2:channel|mode_r\(0) & \timers:2:channel|mode_r\(1)) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000000000001100000011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \timers:2:channel|ALT_INV_mode_r\(0),
	datac => \timers:2:channel|ALT_INV_mode_r\(1),
	datae => \timers:2:channel|ALT_INV_running_r~q\,
	dataf => \timers:2:channel|prescaler|ALT_INV_TICK~DUPLICATE_q\,
	combout => \timers:2:channel|running_r~0_combout\);

-- Location: MLABCELL_X21_Y66_N3
\timers:2:channel|Add2~5\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|Add2~5_sumout\ = SUM(( \timers:2:channel|elapsed_r\(1) ) + ( GND ) + ( \timers:2:channel|Add2~2\ ))
-- \timers:2:channel|Add2~6\ = CARRY(( \timers:2:channel|elapsed_r\(1) ) + ( GND ) + ( \timers:2:channel|Add2~2\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000000011111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datad => \timers:2:channel|ALT_INV_elapsed_r\(1),
	cin => \timers:2:channel|Add2~2\,
	sumout => \timers:2:channel|Add2~5_sumout\,
	cout => \timers:2:channel|Add2~6\);

-- Location: FF_X23_Y66_N5
\timers:2:channel|duration_r[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \IO_DATA[1]~input_o\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sload => VCC,
	ena => \timers:2:channel|process_0~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:2:channel|duration_r\(1));

-- Location: FF_X23_Y66_N47
\timers:2:channel|duration_r[15]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \IO_DATA[15]~input_o\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sload => VCC,
	ena => \timers:2:channel|process_0~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:2:channel|duration_r\(15));

-- Location: FF_X23_Y66_N44
\timers:2:channel|duration_r[14]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \IO_DATA[14]~input_o\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sload => VCC,
	ena => \timers:2:channel|process_0~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:2:channel|duration_r\(14));

-- Location: FF_X23_Y66_N41
\timers:2:channel|duration_r[13]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \IO_DATA[13]~input_o\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sload => VCC,
	ena => \timers:2:channel|process_0~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:2:channel|duration_r\(13));

-- Location: FF_X23_Y66_N38
\timers:2:channel|duration_r[12]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \IO_DATA[12]~input_o\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sload => VCC,
	ena => \timers:2:channel|process_0~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:2:channel|duration_r\(12));

-- Location: FF_X23_Y66_N35
\timers:2:channel|duration_r[11]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \IO_DATA[11]~input_o\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sload => VCC,
	ena => \timers:2:channel|process_0~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:2:channel|duration_r\(11));

-- Location: FF_X23_Y66_N26
\timers:2:channel|duration_r[10]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \IO_DATA[10]~input_o\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sload => VCC,
	ena => \timers:2:channel|process_0~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:2:channel|duration_r\(10));

-- Location: FF_X23_Y66_N53
\timers:2:channel|duration_r[9]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \IO_DATA[9]~input_o\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sload => VCC,
	ena => \timers:2:channel|process_0~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:2:channel|duration_r\(9));

-- Location: FF_X23_Y66_N59
\timers:2:channel|duration_r[8]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \IO_DATA[8]~input_o\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sload => VCC,
	ena => \timers:2:channel|process_0~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:2:channel|duration_r\(8));

-- Location: FF_X23_Y66_N56
\timers:2:channel|duration_r[7]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \IO_DATA[7]~input_o\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sload => VCC,
	ena => \timers:2:channel|process_0~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:2:channel|duration_r\(7));

-- Location: FF_X23_Y66_N50
\timers:2:channel|duration_r[6]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \IO_DATA[6]~input_o\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sload => VCC,
	ena => \timers:2:channel|process_0~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:2:channel|duration_r\(6));

-- Location: FF_X23_Y66_N23
\timers:2:channel|duration_r[5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \IO_DATA[5]~input_o\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sload => VCC,
	ena => \timers:2:channel|process_0~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:2:channel|duration_r\(5));

-- Location: FF_X23_Y66_N29
\timers:2:channel|duration_r[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \IO_DATA[4]~input_o\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sload => VCC,
	ena => \timers:2:channel|process_0~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:2:channel|duration_r\(4));

-- Location: FF_X23_Y66_N17
\timers:2:channel|duration_r[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \IO_DATA[3]~input_o\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sload => VCC,
	ena => \timers:2:channel|process_0~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:2:channel|duration_r\(3));

-- Location: FF_X23_Y66_N11
\timers:2:channel|duration_r[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \IO_DATA[2]~input_o\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sload => VCC,
	ena => \timers:2:channel|process_0~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:2:channel|duration_r\(2));

-- Location: LABCELL_X23_Y66_N0
\timers:2:channel|Add0~49\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|Add0~49_sumout\ = SUM(( !\timers:2:channel|duration_r\(0) ) + ( VCC ) + ( !VCC ))
-- \timers:2:channel|Add0~50\ = CARRY(( !\timers:2:channel|duration_r\(0) ) + ( VCC ) + ( !VCC ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000001100110011001100",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \timers:2:channel|ALT_INV_duration_r\(0),
	cin => GND,
	sumout => \timers:2:channel|Add0~49_sumout\,
	cout => \timers:2:channel|Add0~50\);

-- Location: LABCELL_X23_Y66_N3
\timers:2:channel|Add0~45\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|Add0~45_sumout\ = SUM(( \timers:2:channel|duration_r\(1) ) + ( VCC ) + ( \timers:2:channel|Add0~50\ ))
-- \timers:2:channel|Add0~46\ = CARRY(( \timers:2:channel|duration_r\(1) ) + ( VCC ) + ( \timers:2:channel|Add0~50\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000000000000011111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datad => \timers:2:channel|ALT_INV_duration_r\(1),
	cin => \timers:2:channel|Add0~50\,
	sumout => \timers:2:channel|Add0~45_sumout\,
	cout => \timers:2:channel|Add0~46\);

-- Location: LABCELL_X23_Y66_N6
\timers:2:channel|Add0~41\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|Add0~41_sumout\ = SUM(( \timers:2:channel|duration_r\(2) ) + ( VCC ) + ( \timers:2:channel|Add0~46\ ))
-- \timers:2:channel|Add0~42\ = CARRY(( \timers:2:channel|duration_r\(2) ) + ( VCC ) + ( \timers:2:channel|Add0~46\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000000011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \timers:2:channel|ALT_INV_duration_r\(2),
	cin => \timers:2:channel|Add0~46\,
	sumout => \timers:2:channel|Add0~41_sumout\,
	cout => \timers:2:channel|Add0~42\);

-- Location: LABCELL_X23_Y66_N9
\timers:2:channel|Add0~37\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|Add0~37_sumout\ = SUM(( \timers:2:channel|duration_r\(3) ) + ( VCC ) + ( \timers:2:channel|Add0~42\ ))
-- \timers:2:channel|Add0~38\ = CARRY(( \timers:2:channel|duration_r\(3) ) + ( VCC ) + ( \timers:2:channel|Add0~42\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:2:channel|ALT_INV_duration_r\(3),
	cin => \timers:2:channel|Add0~42\,
	sumout => \timers:2:channel|Add0~37_sumout\,
	cout => \timers:2:channel|Add0~38\);

-- Location: LABCELL_X23_Y66_N12
\timers:2:channel|Add0~33\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|Add0~33_sumout\ = SUM(( \timers:2:channel|duration_r\(4) ) + ( VCC ) + ( \timers:2:channel|Add0~38\ ))
-- \timers:2:channel|Add0~34\ = CARRY(( \timers:2:channel|duration_r\(4) ) + ( VCC ) + ( \timers:2:channel|Add0~38\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000000000000011111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datad => \timers:2:channel|ALT_INV_duration_r\(4),
	cin => \timers:2:channel|Add0~38\,
	sumout => \timers:2:channel|Add0~33_sumout\,
	cout => \timers:2:channel|Add0~34\);

-- Location: LABCELL_X23_Y66_N15
\timers:2:channel|Add0~61\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|Add0~61_sumout\ = SUM(( \timers:2:channel|duration_r\(5) ) + ( VCC ) + ( \timers:2:channel|Add0~34\ ))
-- \timers:2:channel|Add0~62\ = CARRY(( \timers:2:channel|duration_r\(5) ) + ( VCC ) + ( \timers:2:channel|Add0~34\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000000000000011111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datad => \timers:2:channel|ALT_INV_duration_r\(5),
	cin => \timers:2:channel|Add0~34\,
	sumout => \timers:2:channel|Add0~61_sumout\,
	cout => \timers:2:channel|Add0~62\);

-- Location: LABCELL_X23_Y66_N18
\timers:2:channel|Add0~57\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|Add0~57_sumout\ = SUM(( \timers:2:channel|duration_r\(6) ) + ( VCC ) + ( \timers:2:channel|Add0~62\ ))
-- \timers:2:channel|Add0~58\ = CARRY(( \timers:2:channel|duration_r\(6) ) + ( VCC ) + ( \timers:2:channel|Add0~62\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:2:channel|ALT_INV_duration_r\(6),
	cin => \timers:2:channel|Add0~62\,
	sumout => \timers:2:channel|Add0~57_sumout\,
	cout => \timers:2:channel|Add0~58\);

-- Location: LABCELL_X23_Y66_N21
\timers:2:channel|Add0~53\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|Add0~53_sumout\ = SUM(( \timers:2:channel|duration_r\(7) ) + ( VCC ) + ( \timers:2:channel|Add0~58\ ))
-- \timers:2:channel|Add0~54\ = CARRY(( \timers:2:channel|duration_r\(7) ) + ( VCC ) + ( \timers:2:channel|Add0~58\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000000000000011111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datad => \timers:2:channel|ALT_INV_duration_r\(7),
	cin => \timers:2:channel|Add0~58\,
	sumout => \timers:2:channel|Add0~53_sumout\,
	cout => \timers:2:channel|Add0~54\);

-- Location: LABCELL_X23_Y66_N24
\timers:2:channel|Add0~29\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|Add0~29_sumout\ = SUM(( \timers:2:channel|duration_r\(8) ) + ( VCC ) + ( \timers:2:channel|Add0~54\ ))
-- \timers:2:channel|Add0~30\ = CARRY(( \timers:2:channel|duration_r\(8) ) + ( VCC ) + ( \timers:2:channel|Add0~54\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000000000000011111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datad => \timers:2:channel|ALT_INV_duration_r\(8),
	cin => \timers:2:channel|Add0~54\,
	sumout => \timers:2:channel|Add0~29_sumout\,
	cout => \timers:2:channel|Add0~30\);

-- Location: LABCELL_X23_Y66_N27
\timers:2:channel|Add0~25\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|Add0~25_sumout\ = SUM(( \timers:2:channel|duration_r\(9) ) + ( VCC ) + ( \timers:2:channel|Add0~30\ ))
-- \timers:2:channel|Add0~26\ = CARRY(( \timers:2:channel|duration_r\(9) ) + ( VCC ) + ( \timers:2:channel|Add0~30\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000000101010101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:2:channel|ALT_INV_duration_r\(9),
	cin => \timers:2:channel|Add0~30\,
	sumout => \timers:2:channel|Add0~25_sumout\,
	cout => \timers:2:channel|Add0~26\);

-- Location: LABCELL_X23_Y66_N30
\timers:2:channel|Add0~21\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|Add0~21_sumout\ = SUM(( \timers:2:channel|duration_r\(10) ) + ( VCC ) + ( \timers:2:channel|Add0~26\ ))
-- \timers:2:channel|Add0~22\ = CARRY(( \timers:2:channel|duration_r\(10) ) + ( VCC ) + ( \timers:2:channel|Add0~26\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:2:channel|ALT_INV_duration_r\(10),
	cin => \timers:2:channel|Add0~26\,
	sumout => \timers:2:channel|Add0~21_sumout\,
	cout => \timers:2:channel|Add0~22\);

-- Location: LABCELL_X23_Y66_N33
\timers:2:channel|Add0~17\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|Add0~17_sumout\ = SUM(( \timers:2:channel|duration_r\(11) ) + ( VCC ) + ( \timers:2:channel|Add0~22\ ))
-- \timers:2:channel|Add0~18\ = CARRY(( \timers:2:channel|duration_r\(11) ) + ( VCC ) + ( \timers:2:channel|Add0~22\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000000101010101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:2:channel|ALT_INV_duration_r\(11),
	cin => \timers:2:channel|Add0~22\,
	sumout => \timers:2:channel|Add0~17_sumout\,
	cout => \timers:2:channel|Add0~18\);

-- Location: LABCELL_X23_Y66_N36
\timers:2:channel|Add0~13\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|Add0~13_sumout\ = SUM(( \timers:2:channel|duration_r\(12) ) + ( VCC ) + ( \timers:2:channel|Add0~18\ ))
-- \timers:2:channel|Add0~14\ = CARRY(( \timers:2:channel|duration_r\(12) ) + ( VCC ) + ( \timers:2:channel|Add0~18\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000000000000011111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datad => \timers:2:channel|ALT_INV_duration_r\(12),
	cin => \timers:2:channel|Add0~18\,
	sumout => \timers:2:channel|Add0~13_sumout\,
	cout => \timers:2:channel|Add0~14\);

-- Location: LABCELL_X23_Y66_N39
\timers:2:channel|Add0~9\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|Add0~9_sumout\ = SUM(( \timers:2:channel|duration_r\(13) ) + ( VCC ) + ( \timers:2:channel|Add0~14\ ))
-- \timers:2:channel|Add0~10\ = CARRY(( \timers:2:channel|duration_r\(13) ) + ( VCC ) + ( \timers:2:channel|Add0~14\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:2:channel|ALT_INV_duration_r\(13),
	cin => \timers:2:channel|Add0~14\,
	sumout => \timers:2:channel|Add0~9_sumout\,
	cout => \timers:2:channel|Add0~10\);

-- Location: LABCELL_X23_Y66_N42
\timers:2:channel|Add0~5\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|Add0~5_sumout\ = SUM(( \timers:2:channel|duration_r\(14) ) + ( VCC ) + ( \timers:2:channel|Add0~10\ ))
-- \timers:2:channel|Add0~6\ = CARRY(( \timers:2:channel|duration_r\(14) ) + ( VCC ) + ( \timers:2:channel|Add0~10\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000000011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \timers:2:channel|ALT_INV_duration_r\(14),
	cin => \timers:2:channel|Add0~10\,
	sumout => \timers:2:channel|Add0~5_sumout\,
	cout => \timers:2:channel|Add0~6\);

-- Location: LABCELL_X23_Y66_N45
\timers:2:channel|Add0~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|Add0~1_sumout\ = SUM(( \timers:2:channel|duration_r\(15) ) + ( VCC ) + ( \timers:2:channel|Add0~6\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:2:channel|ALT_INV_duration_r\(15),
	cin => \timers:2:channel|Add0~6\,
	sumout => \timers:2:channel|Add0~1_sumout\);

-- Location: MLABCELL_X21_Y66_N30
\timers:2:channel|Add2~41\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|Add2~41_sumout\ = SUM(( \timers:2:channel|elapsed_r\(10) ) + ( GND ) + ( \timers:2:channel|Add2~38\ ))
-- \timers:2:channel|Add2~42\ = CARRY(( \timers:2:channel|elapsed_r\(10) ) + ( GND ) + ( \timers:2:channel|Add2~38\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \timers:2:channel|ALT_INV_elapsed_r\(10),
	cin => \timers:2:channel|Add2~38\,
	sumout => \timers:2:channel|Add2~41_sumout\,
	cout => \timers:2:channel|Add2~42\);

-- Location: MLABCELL_X21_Y66_N33
\timers:2:channel|Add2~45\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|Add2~45_sumout\ = SUM(( \timers:2:channel|elapsed_r\(11) ) + ( GND ) + ( \timers:2:channel|Add2~42\ ))
-- \timers:2:channel|Add2~46\ = CARRY(( \timers:2:channel|elapsed_r\(11) ) + ( GND ) + ( \timers:2:channel|Add2~42\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000101010101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:2:channel|ALT_INV_elapsed_r\(11),
	cin => \timers:2:channel|Add2~42\,
	sumout => \timers:2:channel|Add2~45_sumout\,
	cout => \timers:2:channel|Add2~46\);

-- Location: LABCELL_X22_Y71_N12
\timers:2:channel|elapsed_r[6]~3\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|elapsed_r[6]~3_combout\ = ( \timers:2:channel|mode_r\(0) & ( \timers:2:channel|mode_r\(1) & ( \timers:2:channel|prescaler|TICK~DUPLICATE_q\ ) ) ) # ( !\timers:2:channel|mode_r\(0) & ( \timers:2:channel|mode_r\(1) & ( 
-- \timers:2:channel|prescaler|TICK~DUPLICATE_q\ ) ) ) # ( !\timers:2:channel|mode_r\(0) & ( !\timers:2:channel|mode_r\(1) & ( \timers:2:channel|prescaler|TICK~DUPLICATE_q\ ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0011001100110011000000000000000000110011001100110011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \timers:2:channel|prescaler|ALT_INV_TICK~DUPLICATE_q\,
	datae => \timers:2:channel|ALT_INV_mode_r\(0),
	dataf => \timers:2:channel|ALT_INV_mode_r\(1),
	combout => \timers:2:channel|elapsed_r[6]~3_combout\);

-- Location: LABCELL_X22_Y71_N48
\timers:2:channel|elapsed_r[6]~4\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|elapsed_r[6]~4_combout\ = ( \IO_DATA[1]~input_o\ & ( \timers:2:channel|elapsed_r[6]~3_combout\ & ( ((\timers:0:channel|periods_r~1_combout\ & (\Equal11~1_combout\ & \IO_DATA[0]~input_o\))) # (\timers:2:channel|running_r~q\) ) ) ) # ( 
-- !\IO_DATA[1]~input_o\ & ( \timers:2:channel|elapsed_r[6]~3_combout\ & ( \timers:2:channel|running_r~q\ ) ) ) # ( \IO_DATA[1]~input_o\ & ( !\timers:2:channel|elapsed_r[6]~3_combout\ & ( (\timers:0:channel|periods_r~1_combout\ & (\Equal11~1_combout\ & 
-- (\IO_DATA[0]~input_o\ & !\timers:2:channel|running_r~q\))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000010000000000000000111111110000000111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:0:channel|ALT_INV_periods_r~1_combout\,
	datab => \ALT_INV_Equal11~1_combout\,
	datac => \ALT_INV_IO_DATA[0]~input_o\,
	datad => \timers:2:channel|ALT_INV_running_r~q\,
	datae => \ALT_INV_IO_DATA[1]~input_o\,
	dataf => \timers:2:channel|ALT_INV_elapsed_r[6]~3_combout\,
	combout => \timers:2:channel|elapsed_r[6]~4_combout\);

-- Location: FF_X21_Y66_N35
\timers:2:channel|elapsed_r[11]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:2:channel|Add2~45_sumout\,
	asdata => \timers:2:channel|duration_r\(11),
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:2:channel|elapsed_r[6]~1_combout\,
	sload => \timers:2:channel|elapsed_r[6]~2_combout\,
	ena => \timers:2:channel|elapsed_r[6]~4_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:2:channel|elapsed_r\(11));

-- Location: MLABCELL_X21_Y66_N36
\timers:2:channel|Add2~49\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|Add2~49_sumout\ = SUM(( \timers:2:channel|elapsed_r\(12) ) + ( GND ) + ( \timers:2:channel|Add2~46\ ))
-- \timers:2:channel|Add2~50\ = CARRY(( \timers:2:channel|elapsed_r\(12) ) + ( GND ) + ( \timers:2:channel|Add2~46\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:2:channel|ALT_INV_elapsed_r\(12),
	cin => \timers:2:channel|Add2~46\,
	sumout => \timers:2:channel|Add2~49_sumout\,
	cout => \timers:2:channel|Add2~50\);

-- Location: FF_X21_Y66_N38
\timers:2:channel|elapsed_r[12]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:2:channel|Add2~49_sumout\,
	asdata => \timers:2:channel|duration_r\(12),
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:2:channel|elapsed_r[6]~1_combout\,
	sload => \timers:2:channel|elapsed_r[6]~2_combout\,
	ena => \timers:2:channel|elapsed_r[6]~4_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:2:channel|elapsed_r\(12));

-- Location: MLABCELL_X21_Y66_N39
\timers:2:channel|Add2~53\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|Add2~53_sumout\ = SUM(( \timers:2:channel|elapsed_r\(13) ) + ( GND ) + ( \timers:2:channel|Add2~50\ ))
-- \timers:2:channel|Add2~54\ = CARRY(( \timers:2:channel|elapsed_r\(13) ) + ( GND ) + ( \timers:2:channel|Add2~50\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:2:channel|ALT_INV_elapsed_r\(13),
	cin => \timers:2:channel|Add2~50\,
	sumout => \timers:2:channel|Add2~53_sumout\,
	cout => \timers:2:channel|Add2~54\);

-- Location: FF_X21_Y66_N41
\timers:2:channel|elapsed_r[13]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:2:channel|Add2~53_sumout\,
	asdata => \timers:2:channel|duration_r\(13),
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:2:channel|elapsed_r[6]~1_combout\,
	sload => \timers:2:channel|elapsed_r[6]~2_combout\,
	ena => \timers:2:channel|elapsed_r[6]~4_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:2:channel|elapsed_r\(13));

-- Location: MLABCELL_X21_Y66_N42
\timers:2:channel|Add2~57\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|Add2~57_sumout\ = SUM(( \timers:2:channel|elapsed_r\(14) ) + ( GND ) + ( \timers:2:channel|Add2~54\ ))
-- \timers:2:channel|Add2~58\ = CARRY(( \timers:2:channel|elapsed_r\(14) ) + ( GND ) + ( \timers:2:channel|Add2~54\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \timers:2:channel|ALT_INV_elapsed_r\(14),
	cin => \timers:2:channel|Add2~54\,
	sumout => \timers:2:channel|Add2~57_sumout\,
	cout => \timers:2:channel|Add2~58\);

-- Location: FF_X21_Y66_N44
\timers:2:channel|elapsed_r[14]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:2:channel|Add2~57_sumout\,
	asdata => \timers:2:channel|duration_r\(14),
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:2:channel|elapsed_r[6]~1_combout\,
	sload => \timers:2:channel|elapsed_r[6]~2_combout\,
	ena => \timers:2:channel|elapsed_r[6]~4_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:2:channel|elapsed_r\(14));

-- Location: MLABCELL_X21_Y66_N45
\timers:2:channel|Add2~61\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|Add2~61_sumout\ = SUM(( \timers:2:channel|elapsed_r\(15) ) + ( GND ) + ( \timers:2:channel|Add2~58\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:2:channel|ALT_INV_elapsed_r\(15),
	cin => \timers:2:channel|Add2~58\,
	sumout => \timers:2:channel|Add2~61_sumout\);

-- Location: FF_X21_Y66_N47
\timers:2:channel|elapsed_r[15]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:2:channel|Add2~61_sumout\,
	asdata => \timers:2:channel|duration_r\(15),
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:2:channel|elapsed_r[6]~1_combout\,
	sload => \timers:2:channel|elapsed_r[6]~2_combout\,
	ena => \timers:2:channel|elapsed_r[6]~4_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:2:channel|elapsed_r\(15));

-- Location: LABCELL_X22_Y66_N54
\timers:2:channel|LessThan0~2\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|LessThan0~2_combout\ = ( \timers:2:channel|Add0~21_sumout\ & ( !\timers:2:channel|elapsed_r\(10) ) ) # ( !\timers:2:channel|Add0~21_sumout\ & ( \timers:2:channel|elapsed_r\(10) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000111100001111000011110000111111110000111100001111000011110000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:2:channel|ALT_INV_elapsed_r\(10),
	dataf => \timers:2:channel|ALT_INV_Add0~21_sumout\,
	combout => \timers:2:channel|LessThan0~2_combout\);

-- Location: LABCELL_X22_Y66_N12
\timers:2:channel|LessThan0~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|LessThan0~1_combout\ = ( \timers:2:channel|Add0~17_sumout\ & ( !\timers:2:channel|elapsed_r\(11) ) ) # ( !\timers:2:channel|Add0~17_sumout\ & ( \timers:2:channel|elapsed_r\(11) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000111100001111000011110000111111110000111100001111000011110000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:2:channel|ALT_INV_elapsed_r\(11),
	dataf => \timers:2:channel|ALT_INV_Add0~17_sumout\,
	combout => \timers:2:channel|LessThan0~1_combout\);

-- Location: LABCELL_X22_Y65_N3
\timers:2:channel|LessThan0~14\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|LessThan0~14_combout\ = ( \timers:2:channel|Add0~29_sumout\ & ( !\timers:2:channel|elapsed_r\(8) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000011110000111100001111000011110000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:2:channel|ALT_INV_elapsed_r\(8),
	dataf => \timers:2:channel|ALT_INV_Add0~29_sumout\,
	combout => \timers:2:channel|LessThan0~14_combout\);

-- Location: LABCELL_X22_Y66_N6
\timers:2:channel|LessThan0~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|LessThan0~0_combout\ = ( \timers:2:channel|Add0~9_sumout\ & ( \timers:2:channel|Add0~5_sumout\ & ( (\timers:2:channel|elapsed_r\(13) & (\timers:2:channel|elapsed_r\(14) & (!\timers:2:channel|elapsed_r\(12) $ 
-- (\timers:2:channel|Add0~13_sumout\)))) ) ) ) # ( !\timers:2:channel|Add0~9_sumout\ & ( \timers:2:channel|Add0~5_sumout\ & ( (!\timers:2:channel|elapsed_r\(13) & (\timers:2:channel|elapsed_r\(14) & (!\timers:2:channel|elapsed_r\(12) $ 
-- (\timers:2:channel|Add0~13_sumout\)))) ) ) ) # ( \timers:2:channel|Add0~9_sumout\ & ( !\timers:2:channel|Add0~5_sumout\ & ( (\timers:2:channel|elapsed_r\(13) & (!\timers:2:channel|elapsed_r\(14) & (!\timers:2:channel|elapsed_r\(12) $ 
-- (\timers:2:channel|Add0~13_sumout\)))) ) ) ) # ( !\timers:2:channel|Add0~9_sumout\ & ( !\timers:2:channel|Add0~5_sumout\ & ( (!\timers:2:channel|elapsed_r\(13) & (!\timers:2:channel|elapsed_r\(14) & (!\timers:2:channel|elapsed_r\(12) $ 
-- (\timers:2:channel|Add0~13_sumout\)))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1000001000000000010000010000000000000000100000100000000001000001",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:2:channel|ALT_INV_elapsed_r\(13),
	datab => \timers:2:channel|ALT_INV_elapsed_r\(12),
	datac => \timers:2:channel|ALT_INV_Add0~13_sumout\,
	datad => \timers:2:channel|ALT_INV_elapsed_r\(14),
	datae => \timers:2:channel|ALT_INV_Add0~9_sumout\,
	dataf => \timers:2:channel|ALT_INV_Add0~5_sumout\,
	combout => \timers:2:channel|LessThan0~0_combout\);

-- Location: LABCELL_X22_Y66_N0
\timers:2:channel|LessThan0~15\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|LessThan0~15_combout\ = ( \timers:2:channel|LessThan0~14_combout\ & ( \timers:2:channel|LessThan0~0_combout\ & ( (!\timers:2:channel|LessThan0~2_combout\ & (!\timers:2:channel|LessThan0~1_combout\ & ((!\timers:2:channel|elapsed_r\(9)) # 
-- (\timers:2:channel|Add0~25_sumout\)))) ) ) ) # ( !\timers:2:channel|LessThan0~14_combout\ & ( \timers:2:channel|LessThan0~0_combout\ & ( (!\timers:2:channel|elapsed_r\(9) & (\timers:2:channel|Add0~25_sumout\ & (!\timers:2:channel|LessThan0~2_combout\ & 
-- !\timers:2:channel|LessThan0~1_combout\))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000100000000000001011000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:2:channel|ALT_INV_elapsed_r\(9),
	datab => \timers:2:channel|ALT_INV_Add0~25_sumout\,
	datac => \timers:2:channel|ALT_INV_LessThan0~2_combout\,
	datad => \timers:2:channel|ALT_INV_LessThan0~1_combout\,
	datae => \timers:2:channel|ALT_INV_LessThan0~14_combout\,
	dataf => \timers:2:channel|ALT_INV_LessThan0~0_combout\,
	combout => \timers:2:channel|LessThan0~15_combout\);

-- Location: LABCELL_X22_Y66_N51
\timers:2:channel|LessThan0~7\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|LessThan0~7_combout\ = ( \timers:2:channel|Add0~29_sumout\ & ( !\timers:2:channel|elapsed_r\(8) ) ) # ( !\timers:2:channel|Add0~29_sumout\ & ( \timers:2:channel|elapsed_r\(8) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000111100001111000011110000111111110000111100001111000011110000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:2:channel|ALT_INV_elapsed_r\(8),
	dataf => \timers:2:channel|ALT_INV_Add0~29_sumout\,
	combout => \timers:2:channel|LessThan0~7_combout\);

-- Location: LABCELL_X22_Y66_N15
\timers:2:channel|LessThan0~3\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|LessThan0~3_combout\ = ( \timers:2:channel|Add0~25_sumout\ & ( !\timers:2:channel|elapsed_r\(9) ) ) # ( !\timers:2:channel|Add0~25_sumout\ & ( \timers:2:channel|elapsed_r\(9) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000111100001111000011110000111111110000111100001111000011110000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:2:channel|ALT_INV_elapsed_r\(9),
	dataf => \timers:2:channel|ALT_INV_Add0~25_sumout\,
	combout => \timers:2:channel|LessThan0~3_combout\);

-- Location: LABCELL_X23_Y65_N6
\timers:2:channel|LessThan0~10\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|LessThan0~10_combout\ = ( \timers:2:channel|Add0~37_sumout\ & ( \timers:2:channel|Add0~33_sumout\ & ( (!\timers:2:channel|elapsed_r\(3)) # ((!\timers:2:channel|elapsed_r\(4)) # ((!\timers:2:channel|elapsed_r\(2) & 
-- \timers:2:channel|Add0~41_sumout\))) ) ) ) # ( !\timers:2:channel|Add0~37_sumout\ & ( \timers:2:channel|Add0~33_sumout\ & ( (!\timers:2:channel|elapsed_r\(4)) # ((!\timers:2:channel|elapsed_r\(2) & (!\timers:2:channel|elapsed_r\(3) & 
-- \timers:2:channel|Add0~41_sumout\))) ) ) ) # ( \timers:2:channel|Add0~37_sumout\ & ( !\timers:2:channel|Add0~33_sumout\ & ( (!\timers:2:channel|elapsed_r\(4) & ((!\timers:2:channel|elapsed_r\(3)) # ((!\timers:2:channel|elapsed_r\(2) & 
-- \timers:2:channel|Add0~41_sumout\)))) ) ) ) # ( !\timers:2:channel|Add0~37_sumout\ & ( !\timers:2:channel|Add0~33_sumout\ & ( (!\timers:2:channel|elapsed_r\(2) & (!\timers:2:channel|elapsed_r\(3) & (!\timers:2:channel|elapsed_r\(4) & 
-- \timers:2:channel|Add0~41_sumout\))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000010000000110000001110000011110000111110001111110011111110",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:2:channel|ALT_INV_elapsed_r\(2),
	datab => \timers:2:channel|ALT_INV_elapsed_r\(3),
	datac => \timers:2:channel|ALT_INV_elapsed_r\(4),
	datad => \timers:2:channel|ALT_INV_Add0~41_sumout\,
	datae => \timers:2:channel|ALT_INV_Add0~37_sumout\,
	dataf => \timers:2:channel|ALT_INV_Add0~33_sumout\,
	combout => \timers:2:channel|LessThan0~10_combout\);

-- Location: LABCELL_X22_Y66_N30
\timers:2:channel|LessThan0~9\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|LessThan0~9_combout\ = ( \timers:2:channel|Add0~41_sumout\ & ( \timers:2:channel|Add0~45_sumout\ & ( (\timers:2:channel|elapsed_r\(2) & ((!\timers:2:channel|elapsed_r\(1)) # ((!\timers:2:channel|elapsed_r\(0) & 
-- \timers:2:channel|Add0~49_sumout\)))) ) ) ) # ( !\timers:2:channel|Add0~41_sumout\ & ( \timers:2:channel|Add0~45_sumout\ & ( (!\timers:2:channel|elapsed_r\(2) & ((!\timers:2:channel|elapsed_r\(1)) # ((!\timers:2:channel|elapsed_r\(0) & 
-- \timers:2:channel|Add0~49_sumout\)))) ) ) ) # ( \timers:2:channel|Add0~41_sumout\ & ( !\timers:2:channel|Add0~45_sumout\ & ( (!\timers:2:channel|elapsed_r\(0) & (\timers:2:channel|elapsed_r\(2) & (!\timers:2:channel|elapsed_r\(1) & 
-- \timers:2:channel|Add0~49_sumout\))) ) ) ) # ( !\timers:2:channel|Add0~41_sumout\ & ( !\timers:2:channel|Add0~45_sumout\ & ( (!\timers:2:channel|elapsed_r\(0) & (!\timers:2:channel|elapsed_r\(2) & (!\timers:2:channel|elapsed_r\(1) & 
-- \timers:2:channel|Add0~49_sumout\))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000010000000000000000010000011000000110010000011000000110010",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:2:channel|ALT_INV_elapsed_r\(0),
	datab => \timers:2:channel|ALT_INV_elapsed_r\(2),
	datac => \timers:2:channel|ALT_INV_elapsed_r\(1),
	datad => \timers:2:channel|ALT_INV_Add0~49_sumout\,
	datae => \timers:2:channel|ALT_INV_Add0~41_sumout\,
	dataf => \timers:2:channel|ALT_INV_Add0~45_sumout\,
	combout => \timers:2:channel|LessThan0~9_combout\);

-- Location: LABCELL_X23_Y66_N57
\timers:2:channel|LessThan0~11\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|LessThan0~11_combout\ = ( \timers:2:channel|elapsed_r\(7) & ( \timers:2:channel|Add0~61_sumout\ & ( (\timers:2:channel|elapsed_r\(5) & (\timers:2:channel|Add0~53_sumout\ & (!\timers:2:channel|elapsed_r\(6) $ 
-- (\timers:2:channel|Add0~57_sumout\)))) ) ) ) # ( !\timers:2:channel|elapsed_r\(7) & ( \timers:2:channel|Add0~61_sumout\ & ( (\timers:2:channel|elapsed_r\(5) & (!\timers:2:channel|Add0~53_sumout\ & (!\timers:2:channel|elapsed_r\(6) $ 
-- (\timers:2:channel|Add0~57_sumout\)))) ) ) ) # ( \timers:2:channel|elapsed_r\(7) & ( !\timers:2:channel|Add0~61_sumout\ & ( (!\timers:2:channel|elapsed_r\(5) & (\timers:2:channel|Add0~53_sumout\ & (!\timers:2:channel|elapsed_r\(6) $ 
-- (\timers:2:channel|Add0~57_sumout\)))) ) ) ) # ( !\timers:2:channel|elapsed_r\(7) & ( !\timers:2:channel|Add0~61_sumout\ & ( (!\timers:2:channel|elapsed_r\(5) & (!\timers:2:channel|Add0~53_sumout\ & (!\timers:2:channel|elapsed_r\(6) $ 
-- (\timers:2:channel|Add0~57_sumout\)))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1000000000100000000010000000001001000000000100000000010000000001",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:2:channel|ALT_INV_elapsed_r\(5),
	datab => \timers:2:channel|ALT_INV_elapsed_r\(6),
	datac => \timers:2:channel|ALT_INV_Add0~53_sumout\,
	datad => \timers:2:channel|ALT_INV_Add0~57_sumout\,
	datae => \timers:2:channel|ALT_INV_elapsed_r\(7),
	dataf => \timers:2:channel|ALT_INV_Add0~61_sumout\,
	combout => \timers:2:channel|LessThan0~11_combout\);

-- Location: LABCELL_X22_Y65_N24
\timers:2:channel|LessThan0~8\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|LessThan0~8_combout\ = ( \timers:2:channel|Add0~33_sumout\ & ( (\timers:2:channel|elapsed_r\(4) & (!\timers:2:channel|elapsed_r\(3) $ (\timers:2:channel|Add0~37_sumout\))) ) ) # ( !\timers:2:channel|Add0~33_sumout\ & ( 
-- (!\timers:2:channel|elapsed_r\(4) & (!\timers:2:channel|elapsed_r\(3) $ (\timers:2:channel|Add0~37_sumout\))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1010000001010000101000000101000000001010000001010000101000000101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:2:channel|ALT_INV_elapsed_r\(3),
	datac => \timers:2:channel|ALT_INV_elapsed_r\(4),
	datad => \timers:2:channel|ALT_INV_Add0~37_sumout\,
	dataf => \timers:2:channel|ALT_INV_Add0~33_sumout\,
	combout => \timers:2:channel|LessThan0~8_combout\);

-- Location: LABCELL_X22_Y67_N48
\timers:2:channel|LessThan0~12\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|LessThan0~12_combout\ = ( \timers:2:channel|Add0~61_sumout\ & ( \timers:2:channel|Add0~57_sumout\ & ( (!\timers:2:channel|elapsed_r\(7) & ((!\timers:2:channel|elapsed_r\(6)) # ((!\timers:2:channel|elapsed_r\(5)) # 
-- (\timers:2:channel|Add0~53_sumout\)))) # (\timers:2:channel|elapsed_r\(7) & (\timers:2:channel|Add0~53_sumout\ & ((!\timers:2:channel|elapsed_r\(6)) # (!\timers:2:channel|elapsed_r\(5))))) ) ) ) # ( !\timers:2:channel|Add0~61_sumout\ & ( 
-- \timers:2:channel|Add0~57_sumout\ & ( (!\timers:2:channel|elapsed_r\(6) & ((!\timers:2:channel|elapsed_r\(7)) # (\timers:2:channel|Add0~53_sumout\))) # (\timers:2:channel|elapsed_r\(6) & (!\timers:2:channel|elapsed_r\(7) & 
-- \timers:2:channel|Add0~53_sumout\)) ) ) ) # ( \timers:2:channel|Add0~61_sumout\ & ( !\timers:2:channel|Add0~57_sumout\ & ( (!\timers:2:channel|elapsed_r\(7) & (((!\timers:2:channel|elapsed_r\(6) & !\timers:2:channel|elapsed_r\(5))) # 
-- (\timers:2:channel|Add0~53_sumout\))) # (\timers:2:channel|elapsed_r\(7) & (!\timers:2:channel|elapsed_r\(6) & (\timers:2:channel|Add0~53_sumout\ & !\timers:2:channel|elapsed_r\(5)))) ) ) ) # ( !\timers:2:channel|Add0~61_sumout\ & ( 
-- !\timers:2:channel|Add0~57_sumout\ & ( (!\timers:2:channel|elapsed_r\(7) & \timers:2:channel|Add0~53_sumout\) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000110000001100100011100000110010001110100011101100111110001110",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:2:channel|ALT_INV_elapsed_r\(6),
	datab => \timers:2:channel|ALT_INV_elapsed_r\(7),
	datac => \timers:2:channel|ALT_INV_Add0~53_sumout\,
	datad => \timers:2:channel|ALT_INV_elapsed_r\(5),
	datae => \timers:2:channel|ALT_INV_Add0~61_sumout\,
	dataf => \timers:2:channel|ALT_INV_Add0~57_sumout\,
	combout => \timers:2:channel|LessThan0~12_combout\);

-- Location: LABCELL_X22_Y66_N48
\timers:2:channel|LessThan0~17\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|LessThan0~17_combout\ = ( !\timers:2:channel|LessThan0~12_combout\ & ( (!\timers:2:channel|LessThan0~11_combout\) # ((!\timers:2:channel|LessThan0~10_combout\ & ((!\timers:2:channel|LessThan0~9_combout\) # 
-- (!\timers:2:channel|LessThan0~8_combout\)))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111101011111000111110101111100000000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:2:channel|ALT_INV_LessThan0~10_combout\,
	datab => \timers:2:channel|ALT_INV_LessThan0~9_combout\,
	datac => \timers:2:channel|ALT_INV_LessThan0~11_combout\,
	datad => \timers:2:channel|ALT_INV_LessThan0~8_combout\,
	dataf => \timers:2:channel|ALT_INV_LessThan0~12_combout\,
	combout => \timers:2:channel|LessThan0~17_combout\);

-- Location: LABCELL_X22_Y66_N18
\timers:2:channel|LessThan0~18\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|LessThan0~18_combout\ = ( !\timers:2:channel|LessThan0~2_combout\ & ( !\timers:2:channel|LessThan0~17_combout\ & ( (!\timers:2:channel|LessThan0~7_combout\ & (!\timers:2:channel|LessThan0~3_combout\ & 
-- (\timers:2:channel|LessThan0~0_combout\ & !\timers:2:channel|LessThan0~1_combout\))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000100000000000000000000000000000000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:2:channel|ALT_INV_LessThan0~7_combout\,
	datab => \timers:2:channel|ALT_INV_LessThan0~3_combout\,
	datac => \timers:2:channel|ALT_INV_LessThan0~0_combout\,
	datad => \timers:2:channel|ALT_INV_LessThan0~1_combout\,
	datae => \timers:2:channel|ALT_INV_LessThan0~2_combout\,
	dataf => \timers:2:channel|ALT_INV_LessThan0~17_combout\,
	combout => \timers:2:channel|LessThan0~18_combout\);

-- Location: MLABCELL_X21_Y66_N54
\timers:2:channel|elapsed_r[6]~2\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|elapsed_r[6]~2_combout\ = ( \timers:2:channel|LessThan0~15_combout\ & ( \timers:2:channel|LessThan0~18_combout\ & ( (!\timers:2:channel|Add0~1_sumout\ & (\timers:2:channel|elapsed_r\(15) & \timers:2:channel|mode_r\(1))) ) ) ) # ( 
-- !\timers:2:channel|LessThan0~15_combout\ & ( \timers:2:channel|LessThan0~18_combout\ & ( (!\timers:2:channel|Add0~1_sumout\ & (\timers:2:channel|elapsed_r\(15) & \timers:2:channel|mode_r\(1))) ) ) ) # ( \timers:2:channel|LessThan0~15_combout\ & ( 
-- !\timers:2:channel|LessThan0~18_combout\ & ( (!\timers:2:channel|Add0~1_sumout\ & (\timers:2:channel|elapsed_r\(15) & \timers:2:channel|mode_r\(1))) ) ) ) # ( !\timers:2:channel|LessThan0~15_combout\ & ( !\timers:2:channel|LessThan0~18_combout\ & ( 
-- (\timers:2:channel|mode_r\(1) & ((!\timers:2:channel|Add0~1_sumout\ & ((\timers:2:channel|LessThan0~6_combout\) # (\timers:2:channel|elapsed_r\(15)))) # (\timers:2:channel|Add0~1_sumout\ & (\timers:2:channel|elapsed_r\(15) & 
-- \timers:2:channel|LessThan0~6_combout\)))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000001000001011000000100000001000000010000000100000001000000010",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:2:channel|ALT_INV_Add0~1_sumout\,
	datab => \timers:2:channel|ALT_INV_elapsed_r\(15),
	datac => \timers:2:channel|ALT_INV_mode_r\(1),
	datad => \timers:2:channel|ALT_INV_LessThan0~6_combout\,
	datae => \timers:2:channel|ALT_INV_LessThan0~15_combout\,
	dataf => \timers:2:channel|ALT_INV_LessThan0~18_combout\,
	combout => \timers:2:channel|elapsed_r[6]~2_combout\);

-- Location: FF_X21_Y66_N5
\timers:2:channel|elapsed_r[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:2:channel|Add2~5_sumout\,
	asdata => \timers:2:channel|duration_r\(1),
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:2:channel|elapsed_r[6]~1_combout\,
	sload => \timers:2:channel|elapsed_r[6]~2_combout\,
	ena => \timers:2:channel|elapsed_r[6]~4_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:2:channel|elapsed_r\(1));

-- Location: MLABCELL_X21_Y66_N6
\timers:2:channel|Add2~9\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|Add2~9_sumout\ = SUM(( \timers:2:channel|elapsed_r\(2) ) + ( GND ) + ( \timers:2:channel|Add2~6\ ))
-- \timers:2:channel|Add2~10\ = CARRY(( \timers:2:channel|elapsed_r\(2) ) + ( GND ) + ( \timers:2:channel|Add2~6\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \timers:2:channel|ALT_INV_elapsed_r\(2),
	cin => \timers:2:channel|Add2~6\,
	sumout => \timers:2:channel|Add2~9_sumout\,
	cout => \timers:2:channel|Add2~10\);

-- Location: FF_X21_Y66_N8
\timers:2:channel|elapsed_r[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:2:channel|Add2~9_sumout\,
	asdata => \timers:2:channel|duration_r\(2),
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:2:channel|elapsed_r[6]~1_combout\,
	sload => \timers:2:channel|elapsed_r[6]~2_combout\,
	ena => \timers:2:channel|elapsed_r[6]~4_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:2:channel|elapsed_r\(2));

-- Location: MLABCELL_X21_Y66_N9
\timers:2:channel|Add2~13\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|Add2~13_sumout\ = SUM(( \timers:2:channel|elapsed_r\(3) ) + ( GND ) + ( \timers:2:channel|Add2~10\ ))
-- \timers:2:channel|Add2~14\ = CARRY(( \timers:2:channel|elapsed_r\(3) ) + ( GND ) + ( \timers:2:channel|Add2~10\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:2:channel|ALT_INV_elapsed_r\(3),
	cin => \timers:2:channel|Add2~10\,
	sumout => \timers:2:channel|Add2~13_sumout\,
	cout => \timers:2:channel|Add2~14\);

-- Location: FF_X21_Y66_N11
\timers:2:channel|elapsed_r[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:2:channel|Add2~13_sumout\,
	asdata => \timers:2:channel|duration_r\(3),
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:2:channel|elapsed_r[6]~1_combout\,
	sload => \timers:2:channel|elapsed_r[6]~2_combout\,
	ena => \timers:2:channel|elapsed_r[6]~4_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:2:channel|elapsed_r\(3));

-- Location: MLABCELL_X21_Y66_N12
\timers:2:channel|Add2~17\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|Add2~17_sumout\ = SUM(( \timers:2:channel|elapsed_r\(4) ) + ( GND ) + ( \timers:2:channel|Add2~14\ ))
-- \timers:2:channel|Add2~18\ = CARRY(( \timers:2:channel|elapsed_r\(4) ) + ( GND ) + ( \timers:2:channel|Add2~14\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \timers:2:channel|ALT_INV_elapsed_r\(4),
	cin => \timers:2:channel|Add2~14\,
	sumout => \timers:2:channel|Add2~17_sumout\,
	cout => \timers:2:channel|Add2~18\);

-- Location: FF_X21_Y66_N14
\timers:2:channel|elapsed_r[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:2:channel|Add2~17_sumout\,
	asdata => \timers:2:channel|duration_r\(4),
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:2:channel|elapsed_r[6]~1_combout\,
	sload => \timers:2:channel|elapsed_r[6]~2_combout\,
	ena => \timers:2:channel|elapsed_r[6]~4_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:2:channel|elapsed_r\(4));

-- Location: MLABCELL_X21_Y66_N15
\timers:2:channel|Add2~21\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|Add2~21_sumout\ = SUM(( \timers:2:channel|elapsed_r\(5) ) + ( GND ) + ( \timers:2:channel|Add2~18\ ))
-- \timers:2:channel|Add2~22\ = CARRY(( \timers:2:channel|elapsed_r\(5) ) + ( GND ) + ( \timers:2:channel|Add2~18\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:2:channel|ALT_INV_elapsed_r\(5),
	cin => \timers:2:channel|Add2~18\,
	sumout => \timers:2:channel|Add2~21_sumout\,
	cout => \timers:2:channel|Add2~22\);

-- Location: FF_X21_Y66_N17
\timers:2:channel|elapsed_r[5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:2:channel|Add2~21_sumout\,
	asdata => \timers:2:channel|duration_r\(5),
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:2:channel|elapsed_r[6]~1_combout\,
	sload => \timers:2:channel|elapsed_r[6]~2_combout\,
	ena => \timers:2:channel|elapsed_r[6]~4_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:2:channel|elapsed_r\(5));

-- Location: MLABCELL_X21_Y66_N18
\timers:2:channel|Add2~25\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|Add2~25_sumout\ = SUM(( \timers:2:channel|elapsed_r\(6) ) + ( GND ) + ( \timers:2:channel|Add2~22\ ))
-- \timers:2:channel|Add2~26\ = CARRY(( \timers:2:channel|elapsed_r\(6) ) + ( GND ) + ( \timers:2:channel|Add2~22\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:2:channel|ALT_INV_elapsed_r\(6),
	cin => \timers:2:channel|Add2~22\,
	sumout => \timers:2:channel|Add2~25_sumout\,
	cout => \timers:2:channel|Add2~26\);

-- Location: FF_X21_Y66_N20
\timers:2:channel|elapsed_r[6]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:2:channel|Add2~25_sumout\,
	asdata => \timers:2:channel|duration_r\(6),
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:2:channel|elapsed_r[6]~1_combout\,
	sload => \timers:2:channel|elapsed_r[6]~2_combout\,
	ena => \timers:2:channel|elapsed_r[6]~4_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:2:channel|elapsed_r\(6));

-- Location: MLABCELL_X21_Y66_N21
\timers:2:channel|Add2~29\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|Add2~29_sumout\ = SUM(( \timers:2:channel|elapsed_r\(7) ) + ( GND ) + ( \timers:2:channel|Add2~26\ ))
-- \timers:2:channel|Add2~30\ = CARRY(( \timers:2:channel|elapsed_r\(7) ) + ( GND ) + ( \timers:2:channel|Add2~26\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000101010101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:2:channel|ALT_INV_elapsed_r\(7),
	cin => \timers:2:channel|Add2~26\,
	sumout => \timers:2:channel|Add2~29_sumout\,
	cout => \timers:2:channel|Add2~30\);

-- Location: FF_X21_Y66_N23
\timers:2:channel|elapsed_r[7]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:2:channel|Add2~29_sumout\,
	asdata => \timers:2:channel|duration_r\(7),
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:2:channel|elapsed_r[6]~1_combout\,
	sload => \timers:2:channel|elapsed_r[6]~2_combout\,
	ena => \timers:2:channel|elapsed_r[6]~4_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:2:channel|elapsed_r\(7));

-- Location: MLABCELL_X21_Y66_N24
\timers:2:channel|Add2~33\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|Add2~33_sumout\ = SUM(( \timers:2:channel|elapsed_r\(8) ) + ( GND ) + ( \timers:2:channel|Add2~30\ ))
-- \timers:2:channel|Add2~34\ = CARRY(( \timers:2:channel|elapsed_r\(8) ) + ( GND ) + ( \timers:2:channel|Add2~30\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:2:channel|ALT_INV_elapsed_r\(8),
	cin => \timers:2:channel|Add2~30\,
	sumout => \timers:2:channel|Add2~33_sumout\,
	cout => \timers:2:channel|Add2~34\);

-- Location: FF_X21_Y66_N26
\timers:2:channel|elapsed_r[8]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:2:channel|Add2~33_sumout\,
	asdata => \timers:2:channel|duration_r\(8),
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:2:channel|elapsed_r[6]~1_combout\,
	sload => \timers:2:channel|elapsed_r[6]~2_combout\,
	ena => \timers:2:channel|elapsed_r[6]~4_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:2:channel|elapsed_r\(8));

-- Location: MLABCELL_X21_Y66_N27
\timers:2:channel|Add2~37\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|Add2~37_sumout\ = SUM(( \timers:2:channel|elapsed_r\(9) ) + ( GND ) + ( \timers:2:channel|Add2~34\ ))
-- \timers:2:channel|Add2~38\ = CARRY(( \timers:2:channel|elapsed_r\(9) ) + ( GND ) + ( \timers:2:channel|Add2~34\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000101010101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:2:channel|ALT_INV_elapsed_r\(9),
	cin => \timers:2:channel|Add2~34\,
	sumout => \timers:2:channel|Add2~37_sumout\,
	cout => \timers:2:channel|Add2~38\);

-- Location: FF_X21_Y66_N29
\timers:2:channel|elapsed_r[9]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:2:channel|Add2~37_sumout\,
	asdata => \timers:2:channel|duration_r\(9),
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:2:channel|elapsed_r[6]~1_combout\,
	sload => \timers:2:channel|elapsed_r[6]~2_combout\,
	ena => \timers:2:channel|elapsed_r[6]~4_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:2:channel|elapsed_r\(9));

-- Location: FF_X21_Y66_N32
\timers:2:channel|elapsed_r[10]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:2:channel|Add2~41_sumout\,
	asdata => \timers:2:channel|duration_r\(10),
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:2:channel|elapsed_r[6]~1_combout\,
	sload => \timers:2:channel|elapsed_r[6]~2_combout\,
	ena => \timers:2:channel|elapsed_r[6]~4_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:2:channel|elapsed_r\(10));

-- Location: LABCELL_X23_Y66_N51
\timers:2:channel|LessThan0~5\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|LessThan0~5_combout\ = ( \timers:2:channel|Add0~9_sumout\ & ( \timers:2:channel|Add0~5_sumout\ & ( (!\timers:2:channel|elapsed_r\(13)) # ((!\timers:2:channel|elapsed_r\(14)) # ((!\timers:2:channel|elapsed_r\(12) & 
-- \timers:2:channel|Add0~13_sumout\))) ) ) ) # ( !\timers:2:channel|Add0~9_sumout\ & ( \timers:2:channel|Add0~5_sumout\ & ( (!\timers:2:channel|elapsed_r\(14)) # ((!\timers:2:channel|elapsed_r\(12) & (!\timers:2:channel|elapsed_r\(13) & 
-- \timers:2:channel|Add0~13_sumout\))) ) ) ) # ( \timers:2:channel|Add0~9_sumout\ & ( !\timers:2:channel|Add0~5_sumout\ & ( (!\timers:2:channel|elapsed_r\(14) & ((!\timers:2:channel|elapsed_r\(13)) # ((!\timers:2:channel|elapsed_r\(12) & 
-- \timers:2:channel|Add0~13_sumout\)))) ) ) ) # ( !\timers:2:channel|Add0~9_sumout\ & ( !\timers:2:channel|Add0~5_sumout\ & ( (!\timers:2:channel|elapsed_r\(12) & (!\timers:2:channel|elapsed_r\(13) & (!\timers:2:channel|elapsed_r\(14) & 
-- \timers:2:channel|Add0~13_sumout\))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000010000000110000001110000011110000111110001111110011111110",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:2:channel|ALT_INV_elapsed_r\(12),
	datab => \timers:2:channel|ALT_INV_elapsed_r\(13),
	datac => \timers:2:channel|ALT_INV_elapsed_r\(14),
	datad => \timers:2:channel|ALT_INV_Add0~13_sumout\,
	datae => \timers:2:channel|ALT_INV_Add0~9_sumout\,
	dataf => \timers:2:channel|ALT_INV_Add0~5_sumout\,
	combout => \timers:2:channel|LessThan0~5_combout\);

-- Location: LABCELL_X22_Y66_N36
\timers:2:channel|LessThan0~6\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|LessThan0~6_combout\ = ( !\timers:2:channel|LessThan0~5_combout\ & ( \timers:2:channel|LessThan0~0_combout\ & ( (!\timers:2:channel|elapsed_r\(11) & (!\timers:2:channel|Add0~17_sumout\ & ((!\timers:2:channel|Add0~21_sumout\) # 
-- (\timers:2:channel|elapsed_r\(10))))) # (\timers:2:channel|elapsed_r\(11) & (((!\timers:2:channel|Add0~21_sumout\) # (!\timers:2:channel|Add0~17_sumout\)) # (\timers:2:channel|elapsed_r\(10)))) ) ) ) # ( !\timers:2:channel|LessThan0~5_combout\ & ( 
-- !\timers:2:channel|LessThan0~0_combout\ ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111111111111111000000000000000011110111001100010000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:2:channel|ALT_INV_elapsed_r\(10),
	datab => \timers:2:channel|ALT_INV_elapsed_r\(11),
	datac => \timers:2:channel|ALT_INV_Add0~21_sumout\,
	datad => \timers:2:channel|ALT_INV_Add0~17_sumout\,
	datae => \timers:2:channel|ALT_INV_LessThan0~5_combout\,
	dataf => \timers:2:channel|ALT_INV_LessThan0~0_combout\,
	combout => \timers:2:channel|LessThan0~6_combout\);

-- Location: LABCELL_X22_Y66_N57
\timers:2:channel|LessThan0~4\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|LessThan0~4_combout\ = ( \timers:2:channel|LessThan0~0_combout\ & ( (!\timers:2:channel|LessThan0~3_combout\ & (!\timers:2:channel|LessThan0~1_combout\ & !\timers:2:channel|LessThan0~2_combout\)) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000011000000000000001100000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \timers:2:channel|ALT_INV_LessThan0~3_combout\,
	datac => \timers:2:channel|ALT_INV_LessThan0~1_combout\,
	datad => \timers:2:channel|ALT_INV_LessThan0~2_combout\,
	dataf => \timers:2:channel|ALT_INV_LessThan0~0_combout\,
	combout => \timers:2:channel|LessThan0~4_combout\);

-- Location: LABCELL_X22_Y66_N42
\timers:2:channel|LessThan0~13\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|LessThan0~13_combout\ = ( \timers:2:channel|LessThan0~8_combout\ & ( \timers:2:channel|LessThan0~12_combout\ & ( !\timers:2:channel|LessThan0~7_combout\ ) ) ) # ( !\timers:2:channel|LessThan0~8_combout\ & ( 
-- \timers:2:channel|LessThan0~12_combout\ & ( !\timers:2:channel|LessThan0~7_combout\ ) ) ) # ( \timers:2:channel|LessThan0~8_combout\ & ( !\timers:2:channel|LessThan0~12_combout\ & ( (!\timers:2:channel|LessThan0~7_combout\ & 
-- (\timers:2:channel|LessThan0~11_combout\ & ((\timers:2:channel|LessThan0~10_combout\) # (\timers:2:channel|LessThan0~9_combout\)))) ) ) ) # ( !\timers:2:channel|LessThan0~8_combout\ & ( !\timers:2:channel|LessThan0~12_combout\ & ( 
-- (!\timers:2:channel|LessThan0~7_combout\ & (\timers:2:channel|LessThan0~11_combout\ & \timers:2:channel|LessThan0~10_combout\)) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000001010000000100000101010101010101010101010101010101010",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:2:channel|ALT_INV_LessThan0~7_combout\,
	datab => \timers:2:channel|ALT_INV_LessThan0~9_combout\,
	datac => \timers:2:channel|ALT_INV_LessThan0~11_combout\,
	datad => \timers:2:channel|ALT_INV_LessThan0~10_combout\,
	datae => \timers:2:channel|ALT_INV_LessThan0~8_combout\,
	dataf => \timers:2:channel|ALT_INV_LessThan0~12_combout\,
	combout => \timers:2:channel|LessThan0~13_combout\);

-- Location: LABCELL_X22_Y66_N24
\timers:2:channel|LessThan0~16\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|LessThan0~16_combout\ = ( \timers:2:channel|LessThan0~4_combout\ & ( \timers:2:channel|LessThan0~13_combout\ & ( (!\timers:2:channel|Add0~1_sumout\ & \timers:2:channel|elapsed_r\(15)) ) ) ) # ( !\timers:2:channel|LessThan0~4_combout\ & ( 
-- \timers:2:channel|LessThan0~13_combout\ & ( (!\timers:2:channel|Add0~1_sumout\ & (((\timers:2:channel|LessThan0~6_combout\ & !\timers:2:channel|LessThan0~15_combout\)) # (\timers:2:channel|elapsed_r\(15)))) # (\timers:2:channel|Add0~1_sumout\ & 
-- (\timers:2:channel|LessThan0~6_combout\ & (!\timers:2:channel|LessThan0~15_combout\ & \timers:2:channel|elapsed_r\(15)))) ) ) ) # ( \timers:2:channel|LessThan0~4_combout\ & ( !\timers:2:channel|LessThan0~13_combout\ & ( (!\timers:2:channel|Add0~1_sumout\ 
-- & (((\timers:2:channel|LessThan0~6_combout\ & !\timers:2:channel|LessThan0~15_combout\)) # (\timers:2:channel|elapsed_r\(15)))) # (\timers:2:channel|Add0~1_sumout\ & (\timers:2:channel|LessThan0~6_combout\ & (!\timers:2:channel|LessThan0~15_combout\ & 
-- \timers:2:channel|elapsed_r\(15)))) ) ) ) # ( !\timers:2:channel|LessThan0~4_combout\ & ( !\timers:2:channel|LessThan0~13_combout\ & ( (!\timers:2:channel|Add0~1_sumout\ & (((\timers:2:channel|LessThan0~6_combout\ & 
-- !\timers:2:channel|LessThan0~15_combout\)) # (\timers:2:channel|elapsed_r\(15)))) # (\timers:2:channel|Add0~1_sumout\ & (\timers:2:channel|LessThan0~6_combout\ & (!\timers:2:channel|LessThan0~15_combout\ & \timers:2:channel|elapsed_r\(15)))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0100000011011100010000001101110001000000110111000000000011001100",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:2:channel|ALT_INV_LessThan0~6_combout\,
	datab => \timers:2:channel|ALT_INV_Add0~1_sumout\,
	datac => \timers:2:channel|ALT_INV_LessThan0~15_combout\,
	datad => \timers:2:channel|ALT_INV_elapsed_r\(15),
	datae => \timers:2:channel|ALT_INV_LessThan0~4_combout\,
	dataf => \timers:2:channel|ALT_INV_LessThan0~13_combout\,
	combout => \timers:2:channel|LessThan0~16_combout\);

-- Location: LABCELL_X22_Y67_N54
\timers:2:channel|Mux33~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|Mux33~0_combout\ = ( \timers:2:channel|running_r~q\ & ( \timers:2:channel|LessThan0~16_combout\ & ( (!\timers:0:channel|Mux33~0_combout\ & (!\timers:2:channel|running_r~0_combout\)) # (\timers:0:channel|Mux33~0_combout\ & 
-- ((!\Equal11~1_combout\ & (!\timers:2:channel|running_r~0_combout\)) # (\Equal11~1_combout\ & ((!\IO_DATA[1]~input_o\))))) ) ) ) # ( !\timers:2:channel|running_r~q\ & ( \timers:2:channel|LessThan0~16_combout\ & ( (!\IO_DATA[1]~input_o\ & 
-- (\timers:0:channel|Mux33~0_combout\ & \Equal11~1_combout\)) ) ) ) # ( \timers:2:channel|running_r~q\ & ( !\timers:2:channel|LessThan0~16_combout\ & ( (!\IO_DATA[1]~input_o\) # ((!\timers:0:channel|Mux33~0_combout\) # (!\Equal11~1_combout\)) ) ) ) # ( 
-- !\timers:2:channel|running_r~q\ & ( !\timers:2:channel|LessThan0~16_combout\ & ( (!\timers:0:channel|Mux33~0_combout\ & (\timers:2:channel|running_r~0_combout\)) # (\timers:0:channel|Mux33~0_combout\ & ((!\Equal11~1_combout\ & 
-- (\timers:2:channel|running_r~0_combout\)) # (\Equal11~1_combout\ & ((!\IO_DATA[1]~input_o\))))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0101010101011100111111111111110000000000000011001010101010101100",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:2:channel|ALT_INV_running_r~0_combout\,
	datab => \ALT_INV_IO_DATA[1]~input_o\,
	datac => \timers:0:channel|ALT_INV_Mux33~0_combout\,
	datad => \ALT_INV_Equal11~1_combout\,
	datae => \timers:2:channel|ALT_INV_running_r~q\,
	dataf => \timers:2:channel|ALT_INV_LessThan0~16_combout\,
	combout => \timers:2:channel|Mux33~0_combout\);

-- Location: FF_X22_Y67_N56
\timers:2:channel|running_r\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:2:channel|Mux33~0_combout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:2:channel|running_r~q\);

-- Location: MLABCELL_X21_Y66_N48
\timers:2:channel|elapsed_r[6]~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|elapsed_r[6]~1_combout\ = ( \timers:2:channel|mode_r\(0) & ( \timers:2:channel|LessThan0~16_combout\ & ( (!\timers:2:channel|running_r~q\ & (\Equal11~1_combout\ & \timers:0:channel|periods_r~0_combout\)) ) ) ) # ( 
-- !\timers:2:channel|mode_r\(0) & ( \timers:2:channel|LessThan0~16_combout\ & ( ((!\timers:2:channel|running_r~q\ & (\Equal11~1_combout\ & \timers:0:channel|periods_r~0_combout\))) # (\timers:2:channel|mode_r\(1)) ) ) ) # ( \timers:2:channel|mode_r\(0) & ( 
-- !\timers:2:channel|LessThan0~16_combout\ & ( (!\timers:2:channel|running_r~q\ & (\Equal11~1_combout\ & \timers:0:channel|periods_r~0_combout\)) ) ) ) # ( !\timers:2:channel|mode_r\(0) & ( !\timers:2:channel|LessThan0~16_combout\ & ( 
-- (!\timers:2:channel|running_r~q\ & (\Equal11~1_combout\ & \timers:0:channel|periods_r~0_combout\)) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000001000000010000000100000001000000010111111110000001000000010",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:2:channel|ALT_INV_running_r~q\,
	datab => \ALT_INV_Equal11~1_combout\,
	datac => \timers:0:channel|ALT_INV_periods_r~0_combout\,
	datad => \timers:2:channel|ALT_INV_mode_r\(1),
	datae => \timers:2:channel|ALT_INV_mode_r\(0),
	dataf => \timers:2:channel|ALT_INV_LessThan0~16_combout\,
	combout => \timers:2:channel|elapsed_r[6]~1_combout\);

-- Location: FF_X21_Y66_N2
\timers:2:channel|elapsed_r[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:2:channel|Add2~1_sumout\,
	asdata => \timers:2:channel|duration_r[0]~_wirecell_combout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:2:channel|elapsed_r[6]~1_combout\,
	sload => \timers:2:channel|elapsed_r[6]~2_combout\,
	ena => \timers:2:channel|elapsed_r[6]~4_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:2:channel|elapsed_r\(0));

-- Location: LABCELL_X23_Y68_N0
\timers:1:channel|Add2~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|Add2~1_sumout\ = SUM(( \timers:1:channel|elapsed_r\(0) ) + ( VCC ) + ( !VCC ))
-- \timers:1:channel|Add2~2\ = CARRY(( \timers:1:channel|elapsed_r\(0) ) + ( VCC ) + ( !VCC ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:1:channel|ALT_INV_elapsed_r\(0),
	cin => GND,
	sumout => \timers:1:channel|Add2~1_sumout\,
	cout => \timers:1:channel|Add2~2\);

-- Location: LABCELL_X19_Y67_N18
\timers:1:channel|duration_r[0]~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|duration_r[0]~0_combout\ = ( !\IO_DATA[0]~input_o\ )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111111111111111111111111111111100000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataf => \ALT_INV_IO_DATA[0]~input_o\,
	combout => \timers:1:channel|duration_r[0]~0_combout\);

-- Location: MLABCELL_X21_Y70_N57
\timers:1:channel|process_0~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|process_0~0_combout\ = ( \IO_WRITE~input_o\ & ( \timers:0:channel|process_0~1_combout\ & ( (!\IO_ADDR[10]~input_o\ & (\IO_ADDR[2]~input_o\ & (\Equal0~0_combout\ & !\IO_ADDR[3]~input_o\))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000000000001000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_IO_ADDR[10]~input_o\,
	datab => \ALT_INV_IO_ADDR[2]~input_o\,
	datac => \ALT_INV_Equal0~0_combout\,
	datad => \ALT_INV_IO_ADDR[3]~input_o\,
	datae => \ALT_INV_IO_WRITE~input_o\,
	dataf => \timers:0:channel|ALT_INV_process_0~1_combout\,
	combout => \timers:1:channel|process_0~0_combout\);

-- Location: FF_X24_Y66_N2
\timers:1:channel|duration_r[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \timers:1:channel|duration_r[0]~0_combout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sload => VCC,
	ena => \timers:1:channel|process_0~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:1:channel|duration_r\(0));

-- Location: LABCELL_X22_Y68_N21
\timers:1:channel|duration_r[0]~_wirecell\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|duration_r[0]~_wirecell_combout\ = ( !\timers:1:channel|duration_r\(0) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111111111111111000000000000000011111111111111110000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datae => \timers:1:channel|ALT_INV_duration_r\(0),
	combout => \timers:1:channel|duration_r[0]~_wirecell_combout\);

-- Location: LABCELL_X24_Y69_N42
\Equal11~2\ : cyclonev_lcell_comb
-- Equation(s):
-- \Equal11~2_combout\ = ( \IO_WRITE~input_o\ & ( (!\IO_ADDR[10]~input_o\ & (\Equal0~0_combout\ & (!\IO_ADDR[3]~input_o\ & \IO_ADDR[2]~input_o\))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000001000000000000000100000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_IO_ADDR[10]~input_o\,
	datab => \ALT_INV_Equal0~0_combout\,
	datac => \ALT_INV_IO_ADDR[3]~input_o\,
	datad => \ALT_INV_IO_ADDR[2]~input_o\,
	dataf => \ALT_INV_IO_WRITE~input_o\,
	combout => \Equal11~2_combout\);

-- Location: LABCELL_X24_Y69_N6
\timers:1:channel|process_0~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|process_0~1_combout\ = ( !\IO_ADDR[3]~input_o\ & ( \timers:0:channel|process_0~0_combout\ & ( (!\IO_ADDR[10]~input_o\ & (\IO_ADDR[2]~input_o\ & (\Equal0~0_combout\ & \IO_WRITE~input_o\))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000100000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_IO_ADDR[10]~input_o\,
	datab => \ALT_INV_IO_ADDR[2]~input_o\,
	datac => \ALT_INV_Equal0~0_combout\,
	datad => \ALT_INV_IO_WRITE~input_o\,
	datae => \ALT_INV_IO_ADDR[3]~input_o\,
	dataf => \timers:0:channel|ALT_INV_process_0~0_combout\,
	combout => \timers:1:channel|process_0~1_combout\);

-- Location: FF_X25_Y69_N59
\timers:1:channel|mode_r[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \IO_DATA[1]~input_o\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sload => VCC,
	ena => \timers:1:channel|process_0~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:1:channel|mode_r\(1));

-- Location: MLABCELL_X25_Y69_N54
\timers:1:channel|mode_r[0]~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|mode_r[0]~0_combout\ = ( !\IO_DATA[0]~input_o\ )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111111111111111111111111111111100000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataf => \ALT_INV_IO_DATA[0]~input_o\,
	combout => \timers:1:channel|mode_r[0]~0_combout\);

-- Location: FF_X25_Y69_N56
\timers:1:channel|mode_r[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:1:channel|mode_r[0]~0_combout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	ena => \timers:1:channel|process_0~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:1:channel|mode_r\(0));

-- Location: MLABCELL_X21_Y70_N54
\timers:1:channel|process_0~2\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|process_0~2_combout\ = ( \IO_WRITE~input_o\ & ( \timers:3:channel|process_0~2_combout\ & ( (!\IO_ADDR[10]~input_o\ & (\IO_ADDR[2]~input_o\ & (!\IO_ADDR[3]~input_o\ & \Equal0~0_combout\))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000000000000000100000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_IO_ADDR[10]~input_o\,
	datab => \ALT_INV_IO_ADDR[2]~input_o\,
	datac => \ALT_INV_IO_ADDR[3]~input_o\,
	datad => \ALT_INV_Equal0~0_combout\,
	datae => \ALT_INV_IO_WRITE~input_o\,
	dataf => \timers:3:channel|ALT_INV_process_0~2_combout\,
	combout => \timers:1:channel|process_0~2_combout\);

-- Location: FF_X24_Y77_N49
\timers:1:channel|timescale_r[15]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \IO_DATA[15]~input_o\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sload => VCC,
	ena => \timers:1:channel|process_0~2_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:1:channel|timescale_r\(15));

-- Location: MLABCELL_X25_Y70_N51
\timers:1:channel|clear_prescale~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|clear_prescale~0_combout\ = ( \timers:0:channel|periods_r~0_combout\ & ( \timers:3:channel|process_0~2_combout\ & ( (\Equal11~2_combout\ & !\timers:1:channel|running_r~q\) ) ) ) # ( !\timers:0:channel|periods_r~0_combout\ & ( 
-- \timers:3:channel|process_0~2_combout\ & ( \Equal11~2_combout\ ) ) ) # ( \timers:0:channel|periods_r~0_combout\ & ( !\timers:3:channel|process_0~2_combout\ & ( (\Equal11~2_combout\ & !\timers:1:channel|running_r~q\) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000010100000101000001010101010101010101000001010000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_Equal11~2_combout\,
	datac => \timers:1:channel|ALT_INV_running_r~q\,
	datae => \timers:0:channel|ALT_INV_periods_r~0_combout\,
	dataf => \timers:3:channel|ALT_INV_process_0~2_combout\,
	combout => \timers:1:channel|clear_prescale~0_combout\);

-- Location: FF_X25_Y70_N53
\timers:1:channel|clear_prescale\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:1:channel|clear_prescale~0_combout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:1:channel|clear_prescale~q\);

-- Location: MLABCELL_X25_Y69_N33
\timers:1:channel|prescaler|cycle_count~4\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|prescaler|cycle_count~4_combout\ = ( !\timers:1:channel|prescaler|LessThan0~0_combout\ & ( (!\timers:1:channel|clear_prescale~q\ & !\timers:1:channel|prescaler|cycle_count\(0)) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1100110000000000110011000000000000000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \timers:1:channel|ALT_INV_clear_prescale~q\,
	datad => \timers:1:channel|prescaler|ALT_INV_cycle_count\(0),
	dataf => \timers:1:channel|prescaler|ALT_INV_LessThan0~0_combout\,
	combout => \timers:1:channel|prescaler|cycle_count~4_combout\);

-- Location: MLABCELL_X25_Y69_N6
\timers:1:channel|prescaler|cycle_count[2]~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|prescaler|cycle_count[2]~1_combout\ = ( \timers:1:channel|running_r~q\ & ( \timers:1:channel|clear_prescale~q\ ) ) # ( !\timers:1:channel|running_r~q\ & ( \timers:1:channel|clear_prescale~q\ ) ) # ( \timers:1:channel|running_r~q\ & ( 
-- !\timers:1:channel|clear_prescale~q\ ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111111111111111111111111111111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datae => \timers:1:channel|ALT_INV_running_r~q\,
	dataf => \timers:1:channel|ALT_INV_clear_prescale~q\,
	combout => \timers:1:channel|prescaler|cycle_count[2]~1_combout\);

-- Location: FF_X25_Y69_N35
\timers:1:channel|prescaler|cycle_count[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:1:channel|prescaler|cycle_count~4_combout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	ena => \timers:1:channel|prescaler|cycle_count[2]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:1:channel|prescaler|cycle_count\(0));

-- Location: MLABCELL_X25_Y69_N27
\timers:1:channel|prescaler|cycle_count~3\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|prescaler|cycle_count~3_combout\ = ( !\timers:1:channel|prescaler|LessThan0~0_combout\ & ( (!\timers:1:channel|clear_prescale~q\ & (!\timers:1:channel|prescaler|cycle_count\(0) $ (!\timers:1:channel|prescaler|cycle_count\(1)))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0101000010100000010100001010000000000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:1:channel|prescaler|ALT_INV_cycle_count\(0),
	datac => \timers:1:channel|ALT_INV_clear_prescale~q\,
	datad => \timers:1:channel|prescaler|ALT_INV_cycle_count\(1),
	dataf => \timers:1:channel|prescaler|ALT_INV_LessThan0~0_combout\,
	combout => \timers:1:channel|prescaler|cycle_count~3_combout\);

-- Location: FF_X25_Y69_N28
\timers:1:channel|prescaler|cycle_count[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:1:channel|prescaler|cycle_count~3_combout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	ena => \timers:1:channel|prescaler|cycle_count[2]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:1:channel|prescaler|cycle_count\(1));

-- Location: MLABCELL_X25_Y69_N18
\timers:1:channel|prescaler|cycle_count~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|prescaler|cycle_count~0_combout\ = ( \timers:1:channel|prescaler|cycle_count\(1) & ( (\timers:1:channel|prescaler|cycle_count\(0) & (!\timers:1:channel|clear_prescale~q\ & (\timers:1:channel|prescaler|cycle_count\(2) & 
-- !\timers:1:channel|prescaler|cycle_count\(3)))) ) ) # ( !\timers:1:channel|prescaler|cycle_count\(1) & ( (!\timers:1:channel|prescaler|cycle_count\(0) & (!\timers:1:channel|clear_prescale~q\ & (!\timers:1:channel|prescaler|cycle_count\(2) & 
-- \timers:1:channel|prescaler|cycle_count\(3)))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000010000000000000001000000000000100000000000000010000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:1:channel|prescaler|ALT_INV_cycle_count\(0),
	datab => \timers:1:channel|ALT_INV_clear_prescale~q\,
	datac => \timers:1:channel|prescaler|ALT_INV_cycle_count\(2),
	datad => \timers:1:channel|prescaler|ALT_INV_cycle_count\(3),
	dataf => \timers:1:channel|prescaler|ALT_INV_cycle_count\(1),
	combout => \timers:1:channel|prescaler|cycle_count~0_combout\);

-- Location: FF_X25_Y69_N19
\timers:1:channel|prescaler|cycle_count[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:1:channel|prescaler|cycle_count~0_combout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	ena => \timers:1:channel|prescaler|cycle_count[2]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:1:channel|prescaler|cycle_count\(3));

-- Location: MLABCELL_X25_Y69_N21
\timers:1:channel|prescaler|cycle_count~2\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|prescaler|cycle_count~2_combout\ = ( !\timers:1:channel|prescaler|cycle_count\(3) & ( (!\timers:1:channel|clear_prescale~q\ & (!\timers:1:channel|prescaler|cycle_count\(2) $ (((!\timers:1:channel|prescaler|cycle_count\(0)) # 
-- (!\timers:1:channel|prescaler|cycle_count\(1)))))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000010011001000000001001100100000000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:1:channel|prescaler|ALT_INV_cycle_count\(0),
	datab => \timers:1:channel|ALT_INV_clear_prescale~q\,
	datac => \timers:1:channel|prescaler|ALT_INV_cycle_count\(1),
	datad => \timers:1:channel|prescaler|ALT_INV_cycle_count\(2),
	dataf => \timers:1:channel|prescaler|ALT_INV_cycle_count\(3),
	combout => \timers:1:channel|prescaler|cycle_count~2_combout\);

-- Location: FF_X25_Y69_N23
\timers:1:channel|prescaler|cycle_count[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:1:channel|prescaler|cycle_count~2_combout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	ena => \timers:1:channel|prescaler|cycle_count[2]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:1:channel|prescaler|cycle_count\(2));

-- Location: FF_X25_Y69_N29
\timers:1:channel|prescaler|cycle_count[1]~DUPLICATE\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:1:channel|prescaler|cycle_count~3_combout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	ena => \timers:1:channel|prescaler|cycle_count[2]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:1:channel|prescaler|cycle_count[1]~DUPLICATE_q\);

-- Location: MLABCELL_X25_Y69_N24
\timers:1:channel|prescaler|LessThan0~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|prescaler|LessThan0~0_combout\ = ( \timers:1:channel|prescaler|cycle_count\(3) & ( ((\timers:1:channel|prescaler|cycle_count[1]~DUPLICATE_q\) # (\timers:1:channel|prescaler|cycle_count\(2))) # 
-- (\timers:1:channel|prescaler|cycle_count\(0)) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000001011111111111110101111111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:1:channel|prescaler|ALT_INV_cycle_count\(0),
	datac => \timers:1:channel|prescaler|ALT_INV_cycle_count\(2),
	datad => \timers:1:channel|prescaler|ALT_INV_cycle_count[1]~DUPLICATE_q\,
	dataf => \timers:1:channel|prescaler|ALT_INV_cycle_count\(3),
	combout => \timers:1:channel|prescaler|LessThan0~0_combout\);

-- Location: MLABCELL_X25_Y69_N15
\timers:1:channel|prescaler|TICK~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|prescaler|TICK~0_combout\ = ( \timers:1:channel|running_r~q\ & ( (\timers:1:channel|prescaler|LessThan0~0_combout\ & !\timers:1:channel|clear_prescale~q\) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000001010000010100000101000001010000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:1:channel|prescaler|ALT_INV_LessThan0~0_combout\,
	datac => \timers:1:channel|ALT_INV_clear_prescale~q\,
	dataf => \timers:1:channel|ALT_INV_running_r~q\,
	combout => \timers:1:channel|prescaler|TICK~0_combout\);

-- Location: MLABCELL_X25_Y77_N27
\timers:1:channel|timescale_r[8]~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|timescale_r[8]~0_combout\ = ( !\IO_DATA[8]~input_o\ )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111111111111111111111111111111100000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataf => \ALT_INV_IO_DATA[8]~input_o\,
	combout => \timers:1:channel|timescale_r[8]~0_combout\);

-- Location: FF_X25_Y77_N29
\timers:1:channel|timescale_r[8]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:1:channel|timescale_r[8]~0_combout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	ena => \timers:1:channel|process_0~2_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:1:channel|timescale_r\(8));

-- Location: MLABCELL_X25_Y69_N30
\timers:1:channel|prescaler|ms_count[7]~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|prescaler|ms_count[7]~1_combout\ = ( \timers:1:channel|running_r~q\ & ( (\timers:1:channel|clear_prescale~q\) # (\timers:1:channel|prescaler|LessThan0~0_combout\) ) ) # ( !\timers:1:channel|running_r~q\ & ( 
-- \timers:1:channel|clear_prescale~q\ ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0011001100110011001100110011001101110111011101110111011101110111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:1:channel|prescaler|ALT_INV_LessThan0~0_combout\,
	datab => \timers:1:channel|ALT_INV_clear_prescale~q\,
	dataf => \timers:1:channel|ALT_INV_running_r~q\,
	combout => \timers:1:channel|prescaler|ms_count[7]~1_combout\);

-- Location: FF_X24_Y77_N26
\timers:1:channel|prescaler|ms_count[8]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:1:channel|prescaler|Add1~25_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:1:channel|prescaler|ms_count[7]~0_combout\,
	ena => \timers:1:channel|prescaler|ms_count[7]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:1:channel|prescaler|ms_count\(8));

-- Location: LABCELL_X24_Y77_N0
\timers:1:channel|prescaler|Add1~49\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|prescaler|Add1~49_sumout\ = SUM(( \timers:1:channel|prescaler|ms_count\(0) ) + ( VCC ) + ( !VCC ))
-- \timers:1:channel|prescaler|Add1~50\ = CARRY(( \timers:1:channel|prescaler|ms_count\(0) ) + ( VCC ) + ( !VCC ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000000000000011111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datad => \timers:1:channel|prescaler|ALT_INV_ms_count\(0),
	cin => GND,
	sumout => \timers:1:channel|prescaler|Add1~49_sumout\,
	cout => \timers:1:channel|prescaler|Add1~50\);

-- Location: FF_X24_Y77_N2
\timers:1:channel|prescaler|ms_count[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:1:channel|prescaler|Add1~49_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:1:channel|prescaler|ms_count[7]~0_combout\,
	ena => \timers:1:channel|prescaler|ms_count[7]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:1:channel|prescaler|ms_count\(0));

-- Location: LABCELL_X24_Y77_N3
\timers:1:channel|prescaler|Add1~45\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|prescaler|Add1~45_sumout\ = SUM(( \timers:1:channel|prescaler|ms_count\(1) ) + ( GND ) + ( \timers:1:channel|prescaler|Add1~50\ ))
-- \timers:1:channel|prescaler|Add1~46\ = CARRY(( \timers:1:channel|prescaler|ms_count\(1) ) + ( GND ) + ( \timers:1:channel|prescaler|Add1~50\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000000011111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datad => \timers:1:channel|prescaler|ALT_INV_ms_count\(1),
	cin => \timers:1:channel|prescaler|Add1~50\,
	sumout => \timers:1:channel|prescaler|Add1~45_sumout\,
	cout => \timers:1:channel|prescaler|Add1~46\);

-- Location: FF_X24_Y77_N5
\timers:1:channel|prescaler|ms_count[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:1:channel|prescaler|Add1~45_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:1:channel|prescaler|ms_count[7]~0_combout\,
	ena => \timers:1:channel|prescaler|ms_count[7]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:1:channel|prescaler|ms_count\(1));

-- Location: LABCELL_X24_Y77_N6
\timers:1:channel|prescaler|Add1~41\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|prescaler|Add1~41_sumout\ = SUM(( \timers:1:channel|prescaler|ms_count\(2) ) + ( GND ) + ( \timers:1:channel|prescaler|Add1~46\ ))
-- \timers:1:channel|prescaler|Add1~42\ = CARRY(( \timers:1:channel|prescaler|ms_count\(2) ) + ( GND ) + ( \timers:1:channel|prescaler|Add1~46\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \timers:1:channel|prescaler|ALT_INV_ms_count\(2),
	cin => \timers:1:channel|prescaler|Add1~46\,
	sumout => \timers:1:channel|prescaler|Add1~41_sumout\,
	cout => \timers:1:channel|prescaler|Add1~42\);

-- Location: FF_X24_Y77_N8
\timers:1:channel|prescaler|ms_count[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:1:channel|prescaler|Add1~41_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:1:channel|prescaler|ms_count[7]~0_combout\,
	ena => \timers:1:channel|prescaler|ms_count[7]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:1:channel|prescaler|ms_count\(2));

-- Location: LABCELL_X24_Y77_N9
\timers:1:channel|prescaler|Add1~37\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|prescaler|Add1~37_sumout\ = SUM(( \timers:1:channel|prescaler|ms_count\(3) ) + ( GND ) + ( \timers:1:channel|prescaler|Add1~42\ ))
-- \timers:1:channel|prescaler|Add1~38\ = CARRY(( \timers:1:channel|prescaler|ms_count\(3) ) + ( GND ) + ( \timers:1:channel|prescaler|Add1~42\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:1:channel|prescaler|ALT_INV_ms_count\(3),
	cin => \timers:1:channel|prescaler|Add1~42\,
	sumout => \timers:1:channel|prescaler|Add1~37_sumout\,
	cout => \timers:1:channel|prescaler|Add1~38\);

-- Location: FF_X24_Y77_N11
\timers:1:channel|prescaler|ms_count[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:1:channel|prescaler|Add1~37_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:1:channel|prescaler|ms_count[7]~0_combout\,
	ena => \timers:1:channel|prescaler|ms_count[7]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:1:channel|prescaler|ms_count\(3));

-- Location: LABCELL_X24_Y77_N12
\timers:1:channel|prescaler|Add1~33\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|prescaler|Add1~33_sumout\ = SUM(( \timers:1:channel|prescaler|ms_count\(4) ) + ( GND ) + ( \timers:1:channel|prescaler|Add1~38\ ))
-- \timers:1:channel|prescaler|Add1~34\ = CARRY(( \timers:1:channel|prescaler|ms_count\(4) ) + ( GND ) + ( \timers:1:channel|prescaler|Add1~38\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \timers:1:channel|prescaler|ALT_INV_ms_count\(4),
	cin => \timers:1:channel|prescaler|Add1~38\,
	sumout => \timers:1:channel|prescaler|Add1~33_sumout\,
	cout => \timers:1:channel|prescaler|Add1~34\);

-- Location: FF_X24_Y77_N14
\timers:1:channel|prescaler|ms_count[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:1:channel|prescaler|Add1~33_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:1:channel|prescaler|ms_count[7]~0_combout\,
	ena => \timers:1:channel|prescaler|ms_count[7]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:1:channel|prescaler|ms_count\(4));

-- Location: LABCELL_X24_Y77_N15
\timers:1:channel|prescaler|Add1~61\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|prescaler|Add1~61_sumout\ = SUM(( \timers:1:channel|prescaler|ms_count\(5) ) + ( GND ) + ( \timers:1:channel|prescaler|Add1~34\ ))
-- \timers:1:channel|prescaler|Add1~62\ = CARRY(( \timers:1:channel|prescaler|ms_count\(5) ) + ( GND ) + ( \timers:1:channel|prescaler|Add1~34\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:1:channel|prescaler|ALT_INV_ms_count\(5),
	cin => \timers:1:channel|prescaler|Add1~34\,
	sumout => \timers:1:channel|prescaler|Add1~61_sumout\,
	cout => \timers:1:channel|prescaler|Add1~62\);

-- Location: FF_X24_Y77_N17
\timers:1:channel|prescaler|ms_count[5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:1:channel|prescaler|Add1~61_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:1:channel|prescaler|ms_count[7]~0_combout\,
	ena => \timers:1:channel|prescaler|ms_count[7]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:1:channel|prescaler|ms_count\(5));

-- Location: LABCELL_X24_Y77_N18
\timers:1:channel|prescaler|Add1~57\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|prescaler|Add1~57_sumout\ = SUM(( \timers:1:channel|prescaler|ms_count\(6) ) + ( GND ) + ( \timers:1:channel|prescaler|Add1~62\ ))
-- \timers:1:channel|prescaler|Add1~58\ = CARRY(( \timers:1:channel|prescaler|ms_count\(6) ) + ( GND ) + ( \timers:1:channel|prescaler|Add1~62\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:1:channel|prescaler|ALT_INV_ms_count\(6),
	cin => \timers:1:channel|prescaler|Add1~62\,
	sumout => \timers:1:channel|prescaler|Add1~57_sumout\,
	cout => \timers:1:channel|prescaler|Add1~58\);

-- Location: FF_X24_Y77_N20
\timers:1:channel|prescaler|ms_count[6]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:1:channel|prescaler|Add1~57_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:1:channel|prescaler|ms_count[7]~0_combout\,
	ena => \timers:1:channel|prescaler|ms_count[7]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:1:channel|prescaler|ms_count\(6));

-- Location: LABCELL_X24_Y77_N21
\timers:1:channel|prescaler|Add1~53\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|prescaler|Add1~53_sumout\ = SUM(( \timers:1:channel|prescaler|ms_count\(7) ) + ( GND ) + ( \timers:1:channel|prescaler|Add1~58\ ))
-- \timers:1:channel|prescaler|Add1~54\ = CARRY(( \timers:1:channel|prescaler|ms_count\(7) ) + ( GND ) + ( \timers:1:channel|prescaler|Add1~58\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000000011111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datad => \timers:1:channel|prescaler|ALT_INV_ms_count\(7),
	cin => \timers:1:channel|prescaler|Add1~58\,
	sumout => \timers:1:channel|prescaler|Add1~53_sumout\,
	cout => \timers:1:channel|prescaler|Add1~54\);

-- Location: FF_X24_Y77_N23
\timers:1:channel|prescaler|ms_count[7]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:1:channel|prescaler|Add1~53_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:1:channel|prescaler|ms_count[7]~0_combout\,
	ena => \timers:1:channel|prescaler|ms_count[7]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:1:channel|prescaler|ms_count\(7));

-- Location: LABCELL_X24_Y77_N24
\timers:1:channel|prescaler|Add1~25\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|prescaler|Add1~25_sumout\ = SUM(( \timers:1:channel|prescaler|ms_count\(8) ) + ( GND ) + ( \timers:1:channel|prescaler|Add1~54\ ))
-- \timers:1:channel|prescaler|Add1~26\ = CARRY(( \timers:1:channel|prescaler|ms_count\(8) ) + ( GND ) + ( \timers:1:channel|prescaler|Add1~54\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:1:channel|prescaler|ALT_INV_ms_count\(8),
	cin => \timers:1:channel|prescaler|Add1~54\,
	sumout => \timers:1:channel|prescaler|Add1~25_sumout\,
	cout => \timers:1:channel|prescaler|Add1~26\);

-- Location: LABCELL_X23_Y77_N27
\timers:1:channel|prescaler|LessThan1~14\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|prescaler|LessThan1~14_combout\ = ( !\timers:1:channel|prescaler|Add1~25_sumout\ & ( !\timers:1:channel|timescale_r\(8) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111000011110000111100001111000000000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:1:channel|ALT_INV_timescale_r\(8),
	dataf => \timers:1:channel|prescaler|ALT_INV_Add1~25_sumout\,
	combout => \timers:1:channel|prescaler|LessThan1~14_combout\);

-- Location: FF_X24_Y77_N29
\timers:1:channel|prescaler|ms_count[9]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:1:channel|prescaler|Add1~29_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:1:channel|prescaler|ms_count[7]~0_combout\,
	ena => \timers:1:channel|prescaler|ms_count[7]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:1:channel|prescaler|ms_count\(9));

-- Location: LABCELL_X24_Y77_N27
\timers:1:channel|prescaler|Add1~29\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|prescaler|Add1~29_sumout\ = SUM(( \timers:1:channel|prescaler|ms_count\(9) ) + ( GND ) + ( \timers:1:channel|prescaler|Add1~26\ ))
-- \timers:1:channel|prescaler|Add1~30\ = CARRY(( \timers:1:channel|prescaler|ms_count\(9) ) + ( GND ) + ( \timers:1:channel|prescaler|Add1~26\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000000011111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datad => \timers:1:channel|prescaler|ALT_INV_ms_count\(9),
	cin => \timers:1:channel|prescaler|Add1~26\,
	sumout => \timers:1:channel|prescaler|Add1~29_sumout\,
	cout => \timers:1:channel|prescaler|Add1~30\);

-- Location: MLABCELL_X25_Y77_N6
\timers:1:channel|timescale_r[9]~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|timescale_r[9]~1_combout\ = ( !\IO_DATA[9]~input_o\ )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111111111111111111111111111111100000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataf => \ALT_INV_IO_DATA[9]~input_o\,
	combout => \timers:1:channel|timescale_r[9]~1_combout\);

-- Location: FF_X25_Y77_N8
\timers:1:channel|timescale_r[9]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:1:channel|timescale_r[9]~1_combout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	ena => \timers:1:channel|process_0~2_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:1:channel|timescale_r\(9));

-- Location: FF_X23_Y77_N7
\timers:1:channel|timescale_r[10]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \IO_DATA[10]~input_o\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sload => VCC,
	ena => \timers:1:channel|process_0~2_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:1:channel|timescale_r\(10));

-- Location: FF_X24_Y77_N32
\timers:1:channel|prescaler|ms_count[10]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:1:channel|prescaler|Add1~21_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:1:channel|prescaler|ms_count[7]~0_combout\,
	ena => \timers:1:channel|prescaler|ms_count[7]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:1:channel|prescaler|ms_count\(10));

-- Location: LABCELL_X24_Y77_N30
\timers:1:channel|prescaler|Add1~21\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|prescaler|Add1~21_sumout\ = SUM(( \timers:1:channel|prescaler|ms_count\(10) ) + ( GND ) + ( \timers:1:channel|prescaler|Add1~30\ ))
-- \timers:1:channel|prescaler|Add1~22\ = CARRY(( \timers:1:channel|prescaler|ms_count\(10) ) + ( GND ) + ( \timers:1:channel|prescaler|Add1~30\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \timers:1:channel|prescaler|ALT_INV_ms_count\(10),
	cin => \timers:1:channel|prescaler|Add1~30\,
	sumout => \timers:1:channel|prescaler|Add1~21_sumout\,
	cout => \timers:1:channel|prescaler|Add1~22\);

-- Location: LABCELL_X23_Y77_N6
\timers:1:channel|prescaler|LessThan1~4\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|prescaler|LessThan1~4_combout\ = ( \timers:1:channel|prescaler|Add1~21_sumout\ & ( !\timers:1:channel|timescale_r\(10) ) ) # ( !\timers:1:channel|prescaler|Add1~21_sumout\ & ( \timers:1:channel|timescale_r\(10) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000011111111000000001111111111111111000000001111111100000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datad => \timers:1:channel|ALT_INV_timescale_r\(10),
	dataf => \timers:1:channel|prescaler|ALT_INV_Add1~21_sumout\,
	combout => \timers:1:channel|prescaler|LessThan1~4_combout\);

-- Location: FF_X25_Y77_N2
\timers:1:channel|timescale_r[12]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \IO_DATA[12]~input_o\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sload => VCC,
	ena => \timers:1:channel|process_0~2_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:1:channel|timescale_r\(12));

-- Location: FF_X24_Y77_N41
\timers:1:channel|prescaler|ms_count[13]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:1:channel|prescaler|Add1~13_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:1:channel|prescaler|ms_count[7]~0_combout\,
	ena => \timers:1:channel|prescaler|ms_count[7]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:1:channel|prescaler|ms_count\(13));

-- Location: LABCELL_X24_Y77_N33
\timers:1:channel|prescaler|Add1~5\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|prescaler|Add1~5_sumout\ = SUM(( \timers:1:channel|prescaler|ms_count\(11) ) + ( GND ) + ( \timers:1:channel|prescaler|Add1~22\ ))
-- \timers:1:channel|prescaler|Add1~6\ = CARRY(( \timers:1:channel|prescaler|ms_count\(11) ) + ( GND ) + ( \timers:1:channel|prescaler|Add1~22\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000101010101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:1:channel|prescaler|ALT_INV_ms_count\(11),
	cin => \timers:1:channel|prescaler|Add1~22\,
	sumout => \timers:1:channel|prescaler|Add1~5_sumout\,
	cout => \timers:1:channel|prescaler|Add1~6\);

-- Location: FF_X24_Y77_N35
\timers:1:channel|prescaler|ms_count[11]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:1:channel|prescaler|Add1~5_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:1:channel|prescaler|ms_count[7]~0_combout\,
	ena => \timers:1:channel|prescaler|ms_count[7]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:1:channel|prescaler|ms_count\(11));

-- Location: LABCELL_X24_Y77_N36
\timers:1:channel|prescaler|Add1~17\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|prescaler|Add1~17_sumout\ = SUM(( \timers:1:channel|prescaler|ms_count\(12) ) + ( GND ) + ( \timers:1:channel|prescaler|Add1~6\ ))
-- \timers:1:channel|prescaler|Add1~18\ = CARRY(( \timers:1:channel|prescaler|ms_count\(12) ) + ( GND ) + ( \timers:1:channel|prescaler|Add1~6\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:1:channel|prescaler|ALT_INV_ms_count\(12),
	cin => \timers:1:channel|prescaler|Add1~6\,
	sumout => \timers:1:channel|prescaler|Add1~17_sumout\,
	cout => \timers:1:channel|prescaler|Add1~18\);

-- Location: FF_X24_Y77_N38
\timers:1:channel|prescaler|ms_count[12]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:1:channel|prescaler|Add1~17_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:1:channel|prescaler|ms_count[7]~0_combout\,
	ena => \timers:1:channel|prescaler|ms_count[7]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:1:channel|prescaler|ms_count\(12));

-- Location: LABCELL_X24_Y77_N39
\timers:1:channel|prescaler|Add1~13\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|prescaler|Add1~13_sumout\ = SUM(( \timers:1:channel|prescaler|ms_count\(13) ) + ( GND ) + ( \timers:1:channel|prescaler|Add1~18\ ))
-- \timers:1:channel|prescaler|Add1~14\ = CARRY(( \timers:1:channel|prescaler|ms_count\(13) ) + ( GND ) + ( \timers:1:channel|prescaler|Add1~18\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:1:channel|prescaler|ALT_INV_ms_count\(13),
	cin => \timers:1:channel|prescaler|Add1~18\,
	sumout => \timers:1:channel|prescaler|Add1~13_sumout\,
	cout => \timers:1:channel|prescaler|Add1~14\);

-- Location: FF_X25_Y77_N44
\timers:1:channel|timescale_r[14]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \IO_DATA[14]~input_o\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sload => VCC,
	ena => \timers:1:channel|process_0~2_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:1:channel|timescale_r\(14));

-- Location: FF_X24_Y77_N55
\timers:1:channel|timescale_r[13]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \IO_DATA[13]~input_o\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sload => VCC,
	ena => \timers:1:channel|process_0~2_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:1:channel|timescale_r\(13));

-- Location: FF_X24_Y77_N44
\timers:1:channel|prescaler|ms_count[14]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:1:channel|prescaler|Add1~9_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:1:channel|prescaler|ms_count[7]~0_combout\,
	ena => \timers:1:channel|prescaler|ms_count[7]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:1:channel|prescaler|ms_count\(14));

-- Location: LABCELL_X24_Y77_N42
\timers:1:channel|prescaler|Add1~9\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|prescaler|Add1~9_sumout\ = SUM(( \timers:1:channel|prescaler|ms_count\(14) ) + ( GND ) + ( \timers:1:channel|prescaler|Add1~14\ ))
-- \timers:1:channel|prescaler|Add1~10\ = CARRY(( \timers:1:channel|prescaler|ms_count\(14) ) + ( GND ) + ( \timers:1:channel|prescaler|Add1~14\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:1:channel|prescaler|ALT_INV_ms_count\(14),
	cin => \timers:1:channel|prescaler|Add1~14\,
	sumout => \timers:1:channel|prescaler|Add1~9_sumout\,
	cout => \timers:1:channel|prescaler|Add1~10\);

-- Location: LABCELL_X24_Y77_N54
\timers:1:channel|prescaler|LessThan1~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|prescaler|LessThan1~0_combout\ = ( \timers:1:channel|timescale_r\(13) & ( \timers:1:channel|prescaler|Add1~9_sumout\ & ( (\timers:1:channel|prescaler|Add1~13_sumout\ & (\timers:1:channel|timescale_r\(14) & 
-- (!\timers:1:channel|timescale_r\(12) $ (\timers:1:channel|prescaler|Add1~17_sumout\)))) ) ) ) # ( !\timers:1:channel|timescale_r\(13) & ( \timers:1:channel|prescaler|Add1~9_sumout\ & ( (!\timers:1:channel|prescaler|Add1~13_sumout\ & 
-- (\timers:1:channel|timescale_r\(14) & (!\timers:1:channel|timescale_r\(12) $ (\timers:1:channel|prescaler|Add1~17_sumout\)))) ) ) ) # ( \timers:1:channel|timescale_r\(13) & ( !\timers:1:channel|prescaler|Add1~9_sumout\ & ( 
-- (\timers:1:channel|prescaler|Add1~13_sumout\ & (!\timers:1:channel|timescale_r\(14) & (!\timers:1:channel|timescale_r\(12) $ (\timers:1:channel|prescaler|Add1~17_sumout\)))) ) ) ) # ( !\timers:1:channel|timescale_r\(13) & ( 
-- !\timers:1:channel|prescaler|Add1~9_sumout\ & ( (!\timers:1:channel|prescaler|Add1~13_sumout\ & (!\timers:1:channel|timescale_r\(14) & (!\timers:1:channel|timescale_r\(12) $ (\timers:1:channel|prescaler|Add1~17_sumout\)))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1000010000000000001000010000000000000000100001000000000000100001",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:1:channel|ALT_INV_timescale_r\(12),
	datab => \timers:1:channel|prescaler|ALT_INV_Add1~13_sumout\,
	datac => \timers:1:channel|prescaler|ALT_INV_Add1~17_sumout\,
	datad => \timers:1:channel|ALT_INV_timescale_r\(14),
	datae => \timers:1:channel|ALT_INV_timescale_r\(13),
	dataf => \timers:1:channel|prescaler|ALT_INV_Add1~9_sumout\,
	combout => \timers:1:channel|prescaler|LessThan1~0_combout\);

-- Location: FF_X23_Y77_N52
\timers:1:channel|timescale_r[11]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \IO_DATA[11]~input_o\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sload => VCC,
	ena => \timers:1:channel|process_0~2_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:1:channel|timescale_r\(11));

-- Location: LABCELL_X23_Y77_N51
\timers:1:channel|prescaler|LessThan1~3\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|prescaler|LessThan1~3_combout\ = ( \timers:1:channel|prescaler|Add1~5_sumout\ & ( !\timers:1:channel|timescale_r\(11) ) ) # ( !\timers:1:channel|prescaler|Add1~5_sumout\ & ( \timers:1:channel|timescale_r\(11) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000011111111000000001111111111111111000000001111111100000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datad => \timers:1:channel|ALT_INV_timescale_r\(11),
	dataf => \timers:1:channel|prescaler|ALT_INV_Add1~5_sumout\,
	combout => \timers:1:channel|prescaler|LessThan1~3_combout\);

-- Location: LABCELL_X23_Y77_N42
\timers:1:channel|prescaler|LessThan1~15\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|prescaler|LessThan1~15_combout\ = ( \timers:1:channel|prescaler|LessThan1~0_combout\ & ( !\timers:1:channel|prescaler|LessThan1~3_combout\ & ( (!\timers:1:channel|prescaler|LessThan1~4_combout\ & 
-- ((!\timers:1:channel|prescaler|LessThan1~14_combout\ & (!\timers:1:channel|prescaler|Add1~29_sumout\ & !\timers:1:channel|timescale_r\(9))) # (\timers:1:channel|prescaler|LessThan1~14_combout\ & ((!\timers:1:channel|prescaler|Add1~29_sumout\) # 
-- (!\timers:1:channel|timescale_r\(9)))))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000110101000000000000000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:1:channel|prescaler|ALT_INV_LessThan1~14_combout\,
	datab => \timers:1:channel|prescaler|ALT_INV_Add1~29_sumout\,
	datac => \timers:1:channel|ALT_INV_timescale_r\(9),
	datad => \timers:1:channel|prescaler|ALT_INV_LessThan1~4_combout\,
	datae => \timers:1:channel|prescaler|ALT_INV_LessThan1~0_combout\,
	dataf => \timers:1:channel|prescaler|ALT_INV_LessThan1~3_combout\,
	combout => \timers:1:channel|prescaler|LessThan1~15_combout\);

-- Location: LABCELL_X23_Y77_N48
\timers:1:channel|prescaler|LessThan1~6\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|prescaler|LessThan1~6_combout\ = ( \timers:1:channel|prescaler|Add1~29_sumout\ & ( !\timers:1:channel|timescale_r\(9) ) ) # ( !\timers:1:channel|prescaler|Add1~29_sumout\ & ( \timers:1:channel|timescale_r\(9) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000111100001111000011110000111111110000111100001111000011110000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:1:channel|ALT_INV_timescale_r\(9),
	dataf => \timers:1:channel|prescaler|ALT_INV_Add1~29_sumout\,
	combout => \timers:1:channel|prescaler|LessThan1~6_combout\);

-- Location: LABCELL_X23_Y77_N15
\timers:1:channel|prescaler|LessThan1~5\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|prescaler|LessThan1~5_combout\ = ( \timers:1:channel|prescaler|Add1~25_sumout\ & ( !\timers:1:channel|timescale_r\(8) ) ) # ( !\timers:1:channel|prescaler|Add1~25_sumout\ & ( \timers:1:channel|timescale_r\(8) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000111100001111000011110000111111110000111100001111000011110000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:1:channel|ALT_INV_timescale_r\(8),
	dataf => \timers:1:channel|prescaler|ALT_INV_Add1~25_sumout\,
	combout => \timers:1:channel|prescaler|LessThan1~5_combout\);

-- Location: MLABCELL_X25_Y77_N39
\timers:1:channel|timescale_r[3]~2\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|timescale_r[3]~2_combout\ = ( !\IO_DATA[3]~input_o\ )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111111111111111111111111111111100000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataf => \ALT_INV_IO_DATA[3]~input_o\,
	combout => \timers:1:channel|timescale_r[3]~2_combout\);

-- Location: FF_X25_Y77_N41
\timers:1:channel|timescale_r[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:1:channel|timescale_r[3]~2_combout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	ena => \timers:1:channel|process_0~2_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:1:channel|timescale_r\(3));

-- Location: FF_X23_Y77_N41
\timers:1:channel|timescale_r[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \IO_DATA[2]~input_o\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sload => VCC,
	ena => \timers:1:channel|process_0~2_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:1:channel|timescale_r\(2));

-- Location: FF_X23_Y77_N55
\timers:1:channel|timescale_r[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \IO_DATA[4]~input_o\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sload => VCC,
	ena => \timers:1:channel|process_0~2_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:1:channel|timescale_r\(4));

-- Location: LABCELL_X23_Y77_N54
\timers:1:channel|prescaler|LessThan1~9\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|prescaler|LessThan1~9_combout\ = ( \timers:1:channel|timescale_r\(4) & ( \timers:1:channel|prescaler|Add1~41_sumout\ & ( (!\timers:1:channel|prescaler|Add1~33_sumout\) # ((!\timers:1:channel|timescale_r\(3) & 
-- !\timers:1:channel|prescaler|Add1~37_sumout\)) ) ) ) # ( !\timers:1:channel|timescale_r\(4) & ( \timers:1:channel|prescaler|Add1~41_sumout\ & ( (!\timers:1:channel|timescale_r\(3) & (!\timers:1:channel|prescaler|Add1~37_sumout\ & 
-- !\timers:1:channel|prescaler|Add1~33_sumout\)) ) ) ) # ( \timers:1:channel|timescale_r\(4) & ( !\timers:1:channel|prescaler|Add1~41_sumout\ & ( (!\timers:1:channel|prescaler|Add1~33_sumout\) # ((!\timers:1:channel|timescale_r\(3) & 
-- ((!\timers:1:channel|prescaler|Add1~37_sumout\) # (\timers:1:channel|timescale_r\(2)))) # (\timers:1:channel|timescale_r\(3) & (\timers:1:channel|timescale_r\(2) & !\timers:1:channel|prescaler|Add1~37_sumout\))) ) ) ) # ( 
-- !\timers:1:channel|timescale_r\(4) & ( !\timers:1:channel|prescaler|Add1~41_sumout\ & ( (!\timers:1:channel|prescaler|Add1~33_sumout\ & ((!\timers:1:channel|timescale_r\(3) & ((!\timers:1:channel|prescaler|Add1~37_sumout\) # 
-- (\timers:1:channel|timescale_r\(2)))) # (\timers:1:channel|timescale_r\(3) & (\timers:1:channel|timescale_r\(2) & !\timers:1:channel|prescaler|Add1~37_sumout\)))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1011001000000000111111111011001010100000000000001111111110100000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:1:channel|ALT_INV_timescale_r\(3),
	datab => \timers:1:channel|ALT_INV_timescale_r\(2),
	datac => \timers:1:channel|prescaler|ALT_INV_Add1~37_sumout\,
	datad => \timers:1:channel|prescaler|ALT_INV_Add1~33_sumout\,
	datae => \timers:1:channel|ALT_INV_timescale_r\(4),
	dataf => \timers:1:channel|prescaler|ALT_INV_Add1~41_sumout\,
	combout => \timers:1:channel|prescaler|LessThan1~9_combout\);

-- Location: FF_X23_Y77_N59
\timers:1:channel|timescale_r[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \IO_DATA[0]~input_o\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sload => VCC,
	ena => \timers:1:channel|process_0~2_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:1:channel|timescale_r\(0));

-- Location: FF_X23_Y77_N32
\timers:1:channel|timescale_r[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \IO_DATA[1]~input_o\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sload => VCC,
	ena => \timers:1:channel|process_0~2_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:1:channel|timescale_r\(1));

-- Location: LABCELL_X23_Y77_N30
\timers:1:channel|prescaler|LessThan1~8\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|prescaler|LessThan1~8_combout\ = ( \timers:1:channel|timescale_r\(1) & ( \timers:1:channel|prescaler|Add1~41_sumout\ & ( (\timers:1:channel|timescale_r\(2) & ((!\timers:1:channel|prescaler|Add1~45_sumout\) # 
-- ((\timers:1:channel|timescale_r\(0) & !\timers:1:channel|prescaler|Add1~49_sumout\)))) ) ) ) # ( !\timers:1:channel|timescale_r\(1) & ( \timers:1:channel|prescaler|Add1~41_sumout\ & ( (!\timers:1:channel|prescaler|Add1~45_sumout\ & 
-- (\timers:1:channel|timescale_r\(0) & (!\timers:1:channel|prescaler|Add1~49_sumout\ & \timers:1:channel|timescale_r\(2)))) ) ) ) # ( \timers:1:channel|timescale_r\(1) & ( !\timers:1:channel|prescaler|Add1~41_sumout\ & ( (!\timers:1:channel|timescale_r\(2) 
-- & ((!\timers:1:channel|prescaler|Add1~45_sumout\) # ((\timers:1:channel|timescale_r\(0) & !\timers:1:channel|prescaler|Add1~49_sumout\)))) ) ) ) # ( !\timers:1:channel|timescale_r\(1) & ( !\timers:1:channel|prescaler|Add1~41_sumout\ & ( 
-- (!\timers:1:channel|prescaler|Add1~45_sumout\ & (\timers:1:channel|timescale_r\(0) & (!\timers:1:channel|prescaler|Add1~49_sumout\ & !\timers:1:channel|timescale_r\(2)))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0010000000000000101110100000000000000000001000000000000010111010",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:1:channel|prescaler|ALT_INV_Add1~45_sumout\,
	datab => \timers:1:channel|ALT_INV_timescale_r\(0),
	datac => \timers:1:channel|prescaler|ALT_INV_Add1~49_sumout\,
	datad => \timers:1:channel|ALT_INV_timescale_r\(2),
	datae => \timers:1:channel|ALT_INV_timescale_r\(1),
	dataf => \timers:1:channel|prescaler|ALT_INV_Add1~41_sumout\,
	combout => \timers:1:channel|prescaler|LessThan1~8_combout\);

-- Location: LABCELL_X23_Y77_N9
\timers:1:channel|prescaler|LessThan1~7\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|prescaler|LessThan1~7_combout\ = ( \timers:1:channel|prescaler|Add1~33_sumout\ & ( (\timers:1:channel|timescale_r\(4) & (!\timers:1:channel|timescale_r\(3) $ (!\timers:1:channel|prescaler|Add1~37_sumout\))) ) ) # ( 
-- !\timers:1:channel|prescaler|Add1~33_sumout\ & ( (!\timers:1:channel|timescale_r\(4) & (!\timers:1:channel|timescale_r\(3) $ (!\timers:1:channel|prescaler|Add1~37_sumout\))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0101000010100000010100001010000000000101000010100000010100001010",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:1:channel|ALT_INV_timescale_r\(3),
	datac => \timers:1:channel|ALT_INV_timescale_r\(4),
	datad => \timers:1:channel|prescaler|ALT_INV_Add1~37_sumout\,
	dataf => \timers:1:channel|prescaler|ALT_INV_Add1~33_sumout\,
	combout => \timers:1:channel|prescaler|LessThan1~7_combout\);

-- Location: LABCELL_X23_Y77_N24
\timers:1:channel|timescale_r[6]~4\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|timescale_r[6]~4_combout\ = ( !\IO_DATA[6]~input_o\ )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111111111111111111111111111111100000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataf => \ALT_INV_IO_DATA[6]~input_o\,
	combout => \timers:1:channel|timescale_r[6]~4_combout\);

-- Location: FF_X23_Y77_N26
\timers:1:channel|timescale_r[6]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:1:channel|timescale_r[6]~4_combout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	ena => \timers:1:channel|process_0~2_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:1:channel|timescale_r\(6));

-- Location: MLABCELL_X25_Y77_N15
\timers:1:channel|timescale_r[5]~5\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|timescale_r[5]~5_combout\ = ( !\IO_DATA[5]~input_o\ )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111111111111111111111111111111100000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataf => \ALT_INV_IO_DATA[5]~input_o\,
	combout => \timers:1:channel|timescale_r[5]~5_combout\);

-- Location: FF_X25_Y77_N17
\timers:1:channel|timescale_r[5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:1:channel|timescale_r[5]~5_combout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	ena => \timers:1:channel|process_0~2_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:1:channel|timescale_r\(5));

-- Location: MLABCELL_X25_Y77_N54
\timers:1:channel|timescale_r[7]~3\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|timescale_r[7]~3_combout\ = ( !\IO_DATA[7]~input_o\ )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111111111111111000000000000000011111111111111110000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datae => \ALT_INV_IO_DATA[7]~input_o\,
	combout => \timers:1:channel|timescale_r[7]~3_combout\);

-- Location: FF_X25_Y77_N56
\timers:1:channel|timescale_r[7]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:1:channel|timescale_r[7]~3_combout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	ena => \timers:1:channel|process_0~2_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:1:channel|timescale_r\(7));

-- Location: LABCELL_X23_Y77_N36
\timers:1:channel|prescaler|LessThan1~11\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|prescaler|LessThan1~11_combout\ = ( \timers:1:channel|prescaler|Add1~53_sumout\ & ( \timers:1:channel|prescaler|Add1~57_sumout\ & ( (!\timers:1:channel|timescale_r\(6) & (!\timers:1:channel|timescale_r\(5) & 
-- (!\timers:1:channel|prescaler|Add1~61_sumout\ & !\timers:1:channel|timescale_r\(7)))) ) ) ) # ( !\timers:1:channel|prescaler|Add1~53_sumout\ & ( \timers:1:channel|prescaler|Add1~57_sumout\ & ( (!\timers:1:channel|timescale_r\(7)) # 
-- ((!\timers:1:channel|timescale_r\(6) & (!\timers:1:channel|timescale_r\(5) & !\timers:1:channel|prescaler|Add1~61_sumout\))) ) ) ) # ( \timers:1:channel|prescaler|Add1~53_sumout\ & ( !\timers:1:channel|prescaler|Add1~57_sumout\ & ( 
-- (!\timers:1:channel|timescale_r\(7) & ((!\timers:1:channel|timescale_r\(6)) # ((!\timers:1:channel|timescale_r\(5) & !\timers:1:channel|prescaler|Add1~61_sumout\)))) ) ) ) # ( !\timers:1:channel|prescaler|Add1~53_sumout\ & ( 
-- !\timers:1:channel|prescaler|Add1~57_sumout\ & ( (!\timers:1:channel|timescale_r\(6)) # ((!\timers:1:channel|timescale_r\(7)) # ((!\timers:1:channel|timescale_r\(5) & !\timers:1:channel|prescaler|Add1~61_sumout\))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111111111101010111010100000000011111111100000001000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:1:channel|ALT_INV_timescale_r\(6),
	datab => \timers:1:channel|ALT_INV_timescale_r\(5),
	datac => \timers:1:channel|prescaler|ALT_INV_Add1~61_sumout\,
	datad => \timers:1:channel|ALT_INV_timescale_r\(7),
	datae => \timers:1:channel|prescaler|ALT_INV_Add1~53_sumout\,
	dataf => \timers:1:channel|prescaler|ALT_INV_Add1~57_sumout\,
	combout => \timers:1:channel|prescaler|LessThan1~11_combout\);

-- Location: LABCELL_X23_Y77_N18
\timers:1:channel|prescaler|LessThan1~10\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|prescaler|LessThan1~10_combout\ = ( \timers:1:channel|prescaler|Add1~53_sumout\ & ( \timers:1:channel|prescaler|Add1~57_sumout\ & ( (!\timers:1:channel|timescale_r\(6) & (!\timers:1:channel|timescale_r\(7) & 
-- (!\timers:1:channel|timescale_r\(5) $ (!\timers:1:channel|prescaler|Add1~61_sumout\)))) ) ) ) # ( !\timers:1:channel|prescaler|Add1~53_sumout\ & ( \timers:1:channel|prescaler|Add1~57_sumout\ & ( (!\timers:1:channel|timescale_r\(6) & 
-- (\timers:1:channel|timescale_r\(7) & (!\timers:1:channel|timescale_r\(5) $ (!\timers:1:channel|prescaler|Add1~61_sumout\)))) ) ) ) # ( \timers:1:channel|prescaler|Add1~53_sumout\ & ( !\timers:1:channel|prescaler|Add1~57_sumout\ & ( 
-- (\timers:1:channel|timescale_r\(6) & (!\timers:1:channel|timescale_r\(7) & (!\timers:1:channel|timescale_r\(5) $ (!\timers:1:channel|prescaler|Add1~61_sumout\)))) ) ) ) # ( !\timers:1:channel|prescaler|Add1~53_sumout\ & ( 
-- !\timers:1:channel|prescaler|Add1~57_sumout\ & ( (\timers:1:channel|timescale_r\(6) & (\timers:1:channel|timescale_r\(7) & (!\timers:1:channel|timescale_r\(5) $ (!\timers:1:channel|prescaler|Add1~61_sumout\)))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000010100000101000000000000000000001010000010100000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:1:channel|ALT_INV_timescale_r\(6),
	datab => \timers:1:channel|ALT_INV_timescale_r\(5),
	datac => \timers:1:channel|prescaler|ALT_INV_Add1~61_sumout\,
	datad => \timers:1:channel|ALT_INV_timescale_r\(7),
	datae => \timers:1:channel|prescaler|ALT_INV_Add1~53_sumout\,
	dataf => \timers:1:channel|prescaler|ALT_INV_Add1~57_sumout\,
	combout => \timers:1:channel|prescaler|LessThan1~10_combout\);

-- Location: LABCELL_X23_Y77_N12
\timers:1:channel|prescaler|LessThan1~12\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|prescaler|LessThan1~12_combout\ = ( \timers:1:channel|prescaler|LessThan1~10_combout\ & ( (!\timers:1:channel|prescaler|LessThan1~9_combout\ & (!\timers:1:channel|prescaler|LessThan1~11_combout\ & 
-- ((!\timers:1:channel|prescaler|LessThan1~8_combout\) # (!\timers:1:channel|prescaler|LessThan1~7_combout\)))) ) ) # ( !\timers:1:channel|prescaler|LessThan1~10_combout\ & ( !\timers:1:channel|prescaler|LessThan1~11_combout\ ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111111100000000111111110000000010101000000000001010100000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:1:channel|prescaler|ALT_INV_LessThan1~9_combout\,
	datab => \timers:1:channel|prescaler|ALT_INV_LessThan1~8_combout\,
	datac => \timers:1:channel|prescaler|ALT_INV_LessThan1~7_combout\,
	datad => \timers:1:channel|prescaler|ALT_INV_LessThan1~11_combout\,
	dataf => \timers:1:channel|prescaler|ALT_INV_LessThan1~10_combout\,
	combout => \timers:1:channel|prescaler|LessThan1~12_combout\);

-- Location: LABCELL_X23_Y77_N0
\timers:1:channel|prescaler|LessThan1~13\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|prescaler|LessThan1~13_combout\ = ( \timers:1:channel|prescaler|LessThan1~0_combout\ & ( !\timers:1:channel|prescaler|LessThan1~12_combout\ & ( (\timers:1:channel|prescaler|LessThan1~6_combout\ & 
-- (\timers:1:channel|prescaler|LessThan1~5_combout\ & (!\timers:1:channel|prescaler|LessThan1~3_combout\ & !\timers:1:channel|prescaler|LessThan1~4_combout\))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000100000000000000000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:1:channel|prescaler|ALT_INV_LessThan1~6_combout\,
	datab => \timers:1:channel|prescaler|ALT_INV_LessThan1~5_combout\,
	datac => \timers:1:channel|prescaler|ALT_INV_LessThan1~3_combout\,
	datad => \timers:1:channel|prescaler|ALT_INV_LessThan1~4_combout\,
	datae => \timers:1:channel|prescaler|ALT_INV_LessThan1~0_combout\,
	dataf => \timers:1:channel|prescaler|ALT_INV_LessThan1~12_combout\,
	combout => \timers:1:channel|prescaler|LessThan1~13_combout\);

-- Location: MLABCELL_X25_Y77_N45
\timers:1:channel|prescaler|LessThan1~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|prescaler|LessThan1~1_combout\ = ( \timers:1:channel|prescaler|Add1~13_sumout\ & ( \timers:1:channel|timescale_r\(13) & ( (!\timers:1:channel|timescale_r\(14) & (\timers:1:channel|timescale_r\(12) & 
-- (!\timers:1:channel|prescaler|Add1~9_sumout\ & !\timers:1:channel|prescaler|Add1~17_sumout\))) # (\timers:1:channel|timescale_r\(14) & ((!\timers:1:channel|prescaler|Add1~9_sumout\) # ((\timers:1:channel|timescale_r\(12) & 
-- !\timers:1:channel|prescaler|Add1~17_sumout\)))) ) ) ) # ( !\timers:1:channel|prescaler|Add1~13_sumout\ & ( \timers:1:channel|timescale_r\(13) & ( (!\timers:1:channel|prescaler|Add1~9_sumout\) # (\timers:1:channel|timescale_r\(14)) ) ) ) # ( 
-- \timers:1:channel|prescaler|Add1~13_sumout\ & ( !\timers:1:channel|timescale_r\(13) & ( (\timers:1:channel|timescale_r\(14) & !\timers:1:channel|prescaler|Add1~9_sumout\) ) ) ) # ( !\timers:1:channel|prescaler|Add1~13_sumout\ & ( 
-- !\timers:1:channel|timescale_r\(13) & ( (!\timers:1:channel|timescale_r\(14) & (\timers:1:channel|timescale_r\(12) & (!\timers:1:channel|prescaler|Add1~9_sumout\ & !\timers:1:channel|prescaler|Add1~17_sumout\))) # (\timers:1:channel|timescale_r\(14) & 
-- ((!\timers:1:channel|prescaler|Add1~9_sumout\) # ((\timers:1:channel|timescale_r\(12) & !\timers:1:channel|prescaler|Add1~17_sumout\)))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0111000100110000001100000011000011110011111100110111000100110000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:1:channel|ALT_INV_timescale_r\(12),
	datab => \timers:1:channel|ALT_INV_timescale_r\(14),
	datac => \timers:1:channel|prescaler|ALT_INV_Add1~9_sumout\,
	datad => \timers:1:channel|prescaler|ALT_INV_Add1~17_sumout\,
	datae => \timers:1:channel|prescaler|ALT_INV_Add1~13_sumout\,
	dataf => \timers:1:channel|ALT_INV_timescale_r\(13),
	combout => \timers:1:channel|prescaler|LessThan1~1_combout\);

-- Location: MLABCELL_X25_Y77_N18
\timers:1:channel|prescaler|LessThan1~2\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|prescaler|LessThan1~2_combout\ = ( !\timers:1:channel|prescaler|LessThan1~1_combout\ & ( \timers:1:channel|prescaler|LessThan1~0_combout\ & ( (!\timers:1:channel|prescaler|Add1~5_sumout\ & (!\timers:1:channel|timescale_r\(11) & 
-- ((!\timers:1:channel|timescale_r\(10)) # (\timers:1:channel|prescaler|Add1~21_sumout\)))) # (\timers:1:channel|prescaler|Add1~5_sumout\ & ((!\timers:1:channel|timescale_r\(10)) # ((!\timers:1:channel|timescale_r\(11)) # 
-- (\timers:1:channel|prescaler|Add1~21_sumout\)))) ) ) ) # ( !\timers:1:channel|prescaler|LessThan1~1_combout\ & ( !\timers:1:channel|prescaler|LessThan1~0_combout\ ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111111111111111000000000000000010110010111100110000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:1:channel|ALT_INV_timescale_r\(10),
	datab => \timers:1:channel|prescaler|ALT_INV_Add1~5_sumout\,
	datac => \timers:1:channel|ALT_INV_timescale_r\(11),
	datad => \timers:1:channel|prescaler|ALT_INV_Add1~21_sumout\,
	datae => \timers:1:channel|prescaler|ALT_INV_LessThan1~1_combout\,
	dataf => \timers:1:channel|prescaler|ALT_INV_LessThan1~0_combout\,
	combout => \timers:1:channel|prescaler|LessThan1~2_combout\);

-- Location: LABCELL_X24_Y77_N48
\timers:1:channel|prescaler|ms_count[7]~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|prescaler|ms_count[7]~0_combout\ = ( \timers:1:channel|timescale_r\(15) & ( \timers:1:channel|prescaler|LessThan1~2_combout\ & ( ((\timers:1:channel|prescaler|Add1~1_sumout\ & (!\timers:1:channel|prescaler|LessThan1~15_combout\ & 
-- !\timers:1:channel|prescaler|LessThan1~13_combout\))) # (\timers:1:channel|clear_prescale~q\) ) ) ) # ( !\timers:1:channel|timescale_r\(15) & ( \timers:1:channel|prescaler|LessThan1~2_combout\ & ( (((!\timers:1:channel|prescaler|LessThan1~15_combout\ & 
-- !\timers:1:channel|prescaler|LessThan1~13_combout\)) # (\timers:1:channel|clear_prescale~q\)) # (\timers:1:channel|prescaler|Add1~1_sumout\) ) ) ) # ( \timers:1:channel|timescale_r\(15) & ( !\timers:1:channel|prescaler|LessThan1~2_combout\ & ( 
-- \timers:1:channel|clear_prescale~q\ ) ) ) # ( !\timers:1:channel|timescale_r\(15) & ( !\timers:1:channel|prescaler|LessThan1~2_combout\ & ( (\timers:1:channel|clear_prescale~q\) # (\timers:1:channel|prescaler|Add1~1_sumout\) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0101111101011111000011110000111111011111010111110100111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:1:channel|prescaler|ALT_INV_Add1~1_sumout\,
	datab => \timers:1:channel|prescaler|ALT_INV_LessThan1~15_combout\,
	datac => \timers:1:channel|ALT_INV_clear_prescale~q\,
	datad => \timers:1:channel|prescaler|ALT_INV_LessThan1~13_combout\,
	datae => \timers:1:channel|ALT_INV_timescale_r\(15),
	dataf => \timers:1:channel|prescaler|ALT_INV_LessThan1~2_combout\,
	combout => \timers:1:channel|prescaler|ms_count[7]~0_combout\);

-- Location: FF_X24_Y77_N47
\timers:1:channel|prescaler|ms_count[15]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:1:channel|prescaler|Add1~1_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:1:channel|prescaler|ms_count[7]~0_combout\,
	ena => \timers:1:channel|prescaler|ms_count[7]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:1:channel|prescaler|ms_count\(15));

-- Location: LABCELL_X24_Y77_N45
\timers:1:channel|prescaler|Add1~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|prescaler|Add1~1_sumout\ = SUM(( \timers:1:channel|prescaler|ms_count\(15) ) + ( GND ) + ( \timers:1:channel|prescaler|Add1~10\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:1:channel|prescaler|ALT_INV_ms_count\(15),
	cin => \timers:1:channel|prescaler|Add1~10\,
	sumout => \timers:1:channel|prescaler|Add1~1_sumout\);

-- Location: MLABCELL_X25_Y77_N48
\timers:1:channel|prescaler|TICK~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|prescaler|TICK~1_combout\ = ( \timers:1:channel|prescaler|LessThan1~15_combout\ & ( \timers:1:channel|prescaler|LessThan1~2_combout\ & ( (!\timers:1:channel|timescale_r\(15) & (\timers:1:channel|prescaler|TICK~0_combout\ & 
-- \timers:1:channel|prescaler|Add1~1_sumout\)) ) ) ) # ( !\timers:1:channel|prescaler|LessThan1~15_combout\ & ( \timers:1:channel|prescaler|LessThan1~2_combout\ & ( (\timers:1:channel|prescaler|TICK~0_combout\ & ((!\timers:1:channel|timescale_r\(15) & 
-- ((!\timers:1:channel|prescaler|LessThan1~13_combout\) # (\timers:1:channel|prescaler|Add1~1_sumout\))) # (\timers:1:channel|timescale_r\(15) & (\timers:1:channel|prescaler|Add1~1_sumout\ & !\timers:1:channel|prescaler|LessThan1~13_combout\)))) ) ) ) # ( 
-- \timers:1:channel|prescaler|LessThan1~15_combout\ & ( !\timers:1:channel|prescaler|LessThan1~2_combout\ & ( (!\timers:1:channel|timescale_r\(15) & (\timers:1:channel|prescaler|TICK~0_combout\ & \timers:1:channel|prescaler|Add1~1_sumout\)) ) ) ) # ( 
-- !\timers:1:channel|prescaler|LessThan1~15_combout\ & ( !\timers:1:channel|prescaler|LessThan1~2_combout\ & ( (!\timers:1:channel|timescale_r\(15) & (\timers:1:channel|prescaler|TICK~0_combout\ & \timers:1:channel|prescaler|Add1~1_sumout\)) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000001000000010000000100000001000100011000000100000001000000010",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:1:channel|ALT_INV_timescale_r\(15),
	datab => \timers:1:channel|prescaler|ALT_INV_TICK~0_combout\,
	datac => \timers:1:channel|prescaler|ALT_INV_Add1~1_sumout\,
	datad => \timers:1:channel|prescaler|ALT_INV_LessThan1~13_combout\,
	datae => \timers:1:channel|prescaler|ALT_INV_LessThan1~15_combout\,
	dataf => \timers:1:channel|prescaler|ALT_INV_LessThan1~2_combout\,
	combout => \timers:1:channel|prescaler|TICK~1_combout\);

-- Location: FF_X25_Y77_N49
\timers:1:channel|prescaler|TICK\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:1:channel|prescaler|TICK~1_combout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:1:channel|prescaler|TICK~q\);

-- Location: MLABCELL_X25_Y69_N36
\timers:1:channel|running_r~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|running_r~0_combout\ = ( \timers:1:channel|mode_r\(1) & ( \timers:1:channel|prescaler|TICK~q\ & ( (\timers:1:channel|running_r~q\ & \timers:1:channel|mode_r\(0)) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000000000001100000011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \timers:1:channel|ALT_INV_running_r~q\,
	datac => \timers:1:channel|ALT_INV_mode_r\(0),
	datae => \timers:1:channel|ALT_INV_mode_r\(1),
	dataf => \timers:1:channel|prescaler|ALT_INV_TICK~q\,
	combout => \timers:1:channel|running_r~0_combout\);

-- Location: LABCELL_X23_Y68_N3
\timers:1:channel|Add2~5\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|Add2~5_sumout\ = SUM(( \timers:1:channel|elapsed_r\(1) ) + ( GND ) + ( \timers:1:channel|Add2~2\ ))
-- \timers:1:channel|Add2~6\ = CARRY(( \timers:1:channel|elapsed_r\(1) ) + ( GND ) + ( \timers:1:channel|Add2~2\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000000011111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datad => \timers:1:channel|ALT_INV_elapsed_r\(1),
	cin => \timers:1:channel|Add2~2\,
	sumout => \timers:1:channel|Add2~5_sumout\,
	cout => \timers:1:channel|Add2~6\);

-- Location: FF_X24_Y66_N5
\timers:1:channel|duration_r[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \IO_DATA[1]~input_o\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sload => VCC,
	ena => \timers:1:channel|process_0~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:1:channel|duration_r\(1));

-- Location: LABCELL_X23_Y68_N21
\timers:1:channel|Add2~29\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|Add2~29_sumout\ = SUM(( \timers:1:channel|elapsed_r\(7) ) + ( GND ) + ( \timers:1:channel|Add2~26\ ))
-- \timers:1:channel|Add2~30\ = CARRY(( \timers:1:channel|elapsed_r\(7) ) + ( GND ) + ( \timers:1:channel|Add2~26\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000101010101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:1:channel|ALT_INV_elapsed_r\(7),
	cin => \timers:1:channel|Add2~26\,
	sumout => \timers:1:channel|Add2~29_sumout\,
	cout => \timers:1:channel|Add2~30\);

-- Location: LABCELL_X23_Y68_N24
\timers:1:channel|Add2~33\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|Add2~33_sumout\ = SUM(( \timers:1:channel|elapsed_r\(8) ) + ( GND ) + ( \timers:1:channel|Add2~30\ ))
-- \timers:1:channel|Add2~34\ = CARRY(( \timers:1:channel|elapsed_r\(8) ) + ( GND ) + ( \timers:1:channel|Add2~30\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:1:channel|ALT_INV_elapsed_r\(8),
	cin => \timers:1:channel|Add2~30\,
	sumout => \timers:1:channel|Add2~33_sumout\,
	cout => \timers:1:channel|Add2~34\);

-- Location: FF_X24_Y66_N56
\timers:1:channel|duration_r[8]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \IO_DATA[8]~input_o\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sload => VCC,
	ena => \timers:1:channel|process_0~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:1:channel|duration_r\(8));

-- Location: MLABCELL_X25_Y69_N57
\timers:1:channel|elapsed_r[14]~2\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|elapsed_r[14]~2_combout\ = ( \timers:1:channel|prescaler|TICK~q\ & ( (!\timers:1:channel|mode_r\(0)) # (\timers:1:channel|mode_r\(1)) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000010101010111111111010101011111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:1:channel|ALT_INV_mode_r\(0),
	datad => \timers:1:channel|ALT_INV_mode_r\(1),
	dataf => \timers:1:channel|prescaler|ALT_INV_TICK~q\,
	combout => \timers:1:channel|elapsed_r[14]~2_combout\);

-- Location: MLABCELL_X25_Y69_N0
\timers:1:channel|elapsed_r[14]~3\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|elapsed_r[14]~3_combout\ = ( \Equal11~2_combout\ & ( \timers:1:channel|elapsed_r[14]~2_combout\ & ( ((\IO_DATA[1]~input_o\ & (\IO_DATA[0]~input_o\ & \timers:0:channel|periods_r~1_combout\))) # (\timers:1:channel|running_r~q\) ) ) ) # ( 
-- !\Equal11~2_combout\ & ( \timers:1:channel|elapsed_r[14]~2_combout\ & ( \timers:1:channel|running_r~q\ ) ) ) # ( \Equal11~2_combout\ & ( !\timers:1:channel|elapsed_r[14]~2_combout\ & ( (\IO_DATA[1]~input_o\ & (\IO_DATA[0]~input_o\ & 
-- (\timers:0:channel|periods_r~1_combout\ & !\timers:1:channel|running_r~q\))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000010000000000000000111111110000000111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_IO_DATA[1]~input_o\,
	datab => \ALT_INV_IO_DATA[0]~input_o\,
	datac => \timers:0:channel|ALT_INV_periods_r~1_combout\,
	datad => \timers:1:channel|ALT_INV_running_r~q\,
	datae => \ALT_INV_Equal11~2_combout\,
	dataf => \timers:1:channel|ALT_INV_elapsed_r[14]~2_combout\,
	combout => \timers:1:channel|elapsed_r[14]~3_combout\);

-- Location: FF_X23_Y68_N26
\timers:1:channel|elapsed_r[8]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:1:channel|Add2~33_sumout\,
	asdata => \timers:1:channel|duration_r\(8),
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:1:channel|elapsed_r[14]~0_combout\,
	sload => \timers:1:channel|elapsed_r[14]~1_combout\,
	ena => \timers:1:channel|elapsed_r[14]~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:1:channel|elapsed_r\(8));

-- Location: LABCELL_X23_Y68_N27
\timers:1:channel|Add2~37\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|Add2~37_sumout\ = SUM(( \timers:1:channel|elapsed_r\(9) ) + ( GND ) + ( \timers:1:channel|Add2~34\ ))
-- \timers:1:channel|Add2~38\ = CARRY(( \timers:1:channel|elapsed_r\(9) ) + ( GND ) + ( \timers:1:channel|Add2~34\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000101010101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:1:channel|ALT_INV_elapsed_r\(9),
	cin => \timers:1:channel|Add2~34\,
	sumout => \timers:1:channel|Add2~37_sumout\,
	cout => \timers:1:channel|Add2~38\);

-- Location: FF_X24_Y66_N59
\timers:1:channel|duration_r[9]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \IO_DATA[9]~input_o\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sload => VCC,
	ena => \timers:1:channel|process_0~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:1:channel|duration_r\(9));

-- Location: FF_X23_Y68_N29
\timers:1:channel|elapsed_r[9]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:1:channel|Add2~37_sumout\,
	asdata => \timers:1:channel|duration_r\(9),
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:1:channel|elapsed_r[14]~0_combout\,
	sload => \timers:1:channel|elapsed_r[14]~1_combout\,
	ena => \timers:1:channel|elapsed_r[14]~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:1:channel|elapsed_r\(9));

-- Location: LABCELL_X23_Y68_N30
\timers:1:channel|Add2~41\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|Add2~41_sumout\ = SUM(( \timers:1:channel|elapsed_r\(10) ) + ( GND ) + ( \timers:1:channel|Add2~38\ ))
-- \timers:1:channel|Add2~42\ = CARRY(( \timers:1:channel|elapsed_r\(10) ) + ( GND ) + ( \timers:1:channel|Add2~38\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \timers:1:channel|ALT_INV_elapsed_r\(10),
	cin => \timers:1:channel|Add2~38\,
	sumout => \timers:1:channel|Add2~41_sumout\,
	cout => \timers:1:channel|Add2~42\);

-- Location: FF_X24_Y66_N23
\timers:1:channel|duration_r[10]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \IO_DATA[10]~input_o\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sload => VCC,
	ena => \timers:1:channel|process_0~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:1:channel|duration_r\(10));

-- Location: FF_X23_Y68_N32
\timers:1:channel|elapsed_r[10]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:1:channel|Add2~41_sumout\,
	asdata => \timers:1:channel|duration_r\(10),
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:1:channel|elapsed_r[14]~0_combout\,
	sload => \timers:1:channel|elapsed_r[14]~1_combout\,
	ena => \timers:1:channel|elapsed_r[14]~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:1:channel|elapsed_r\(10));

-- Location: LABCELL_X23_Y68_N33
\timers:1:channel|Add2~45\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|Add2~45_sumout\ = SUM(( \timers:1:channel|elapsed_r\(11) ) + ( GND ) + ( \timers:1:channel|Add2~42\ ))
-- \timers:1:channel|Add2~46\ = CARRY(( \timers:1:channel|elapsed_r\(11) ) + ( GND ) + ( \timers:1:channel|Add2~42\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000101010101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:1:channel|ALT_INV_elapsed_r\(11),
	cin => \timers:1:channel|Add2~42\,
	sumout => \timers:1:channel|Add2~45_sumout\,
	cout => \timers:1:channel|Add2~46\);

-- Location: FF_X24_Y66_N35
\timers:1:channel|duration_r[11]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \IO_DATA[11]~input_o\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sload => VCC,
	ena => \timers:1:channel|process_0~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:1:channel|duration_r\(11));

-- Location: FF_X23_Y68_N35
\timers:1:channel|elapsed_r[11]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:1:channel|Add2~45_sumout\,
	asdata => \timers:1:channel|duration_r\(11),
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:1:channel|elapsed_r[14]~0_combout\,
	sload => \timers:1:channel|elapsed_r[14]~1_combout\,
	ena => \timers:1:channel|elapsed_r[14]~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:1:channel|elapsed_r\(11));

-- Location: LABCELL_X23_Y68_N36
\timers:1:channel|Add2~49\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|Add2~49_sumout\ = SUM(( \timers:1:channel|elapsed_r\(12) ) + ( GND ) + ( \timers:1:channel|Add2~46\ ))
-- \timers:1:channel|Add2~50\ = CARRY(( \timers:1:channel|elapsed_r\(12) ) + ( GND ) + ( \timers:1:channel|Add2~46\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:1:channel|ALT_INV_elapsed_r\(12),
	cin => \timers:1:channel|Add2~46\,
	sumout => \timers:1:channel|Add2~49_sumout\,
	cout => \timers:1:channel|Add2~50\);

-- Location: FF_X24_Y66_N38
\timers:1:channel|duration_r[12]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \IO_DATA[12]~input_o\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sload => VCC,
	ena => \timers:1:channel|process_0~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:1:channel|duration_r\(12));

-- Location: FF_X23_Y68_N38
\timers:1:channel|elapsed_r[12]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:1:channel|Add2~49_sumout\,
	asdata => \timers:1:channel|duration_r\(12),
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:1:channel|elapsed_r[14]~0_combout\,
	sload => \timers:1:channel|elapsed_r[14]~1_combout\,
	ena => \timers:1:channel|elapsed_r[14]~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:1:channel|elapsed_r\(12));

-- Location: LABCELL_X23_Y68_N39
\timers:1:channel|Add2~53\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|Add2~53_sumout\ = SUM(( \timers:1:channel|elapsed_r\(13) ) + ( GND ) + ( \timers:1:channel|Add2~50\ ))
-- \timers:1:channel|Add2~54\ = CARRY(( \timers:1:channel|elapsed_r\(13) ) + ( GND ) + ( \timers:1:channel|Add2~50\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:1:channel|ALT_INV_elapsed_r\(13),
	cin => \timers:1:channel|Add2~50\,
	sumout => \timers:1:channel|Add2~53_sumout\,
	cout => \timers:1:channel|Add2~54\);

-- Location: FF_X24_Y66_N41
\timers:1:channel|duration_r[13]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \IO_DATA[13]~input_o\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sload => VCC,
	ena => \timers:1:channel|process_0~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:1:channel|duration_r\(13));

-- Location: FF_X23_Y68_N41
\timers:1:channel|elapsed_r[13]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:1:channel|Add2~53_sumout\,
	asdata => \timers:1:channel|duration_r\(13),
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:1:channel|elapsed_r[14]~0_combout\,
	sload => \timers:1:channel|elapsed_r[14]~1_combout\,
	ena => \timers:1:channel|elapsed_r[14]~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:1:channel|elapsed_r\(13));

-- Location: LABCELL_X23_Y68_N42
\timers:1:channel|Add2~57\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|Add2~57_sumout\ = SUM(( \timers:1:channel|elapsed_r\(14) ) + ( GND ) + ( \timers:1:channel|Add2~54\ ))
-- \timers:1:channel|Add2~58\ = CARRY(( \timers:1:channel|elapsed_r\(14) ) + ( GND ) + ( \timers:1:channel|Add2~54\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \timers:1:channel|ALT_INV_elapsed_r\(14),
	cin => \timers:1:channel|Add2~54\,
	sumout => \timers:1:channel|Add2~57_sumout\,
	cout => \timers:1:channel|Add2~58\);

-- Location: FF_X24_Y66_N44
\timers:1:channel|duration_r[14]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \IO_DATA[14]~input_o\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sload => VCC,
	ena => \timers:1:channel|process_0~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:1:channel|duration_r\(14));

-- Location: FF_X23_Y68_N44
\timers:1:channel|elapsed_r[14]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:1:channel|Add2~57_sumout\,
	asdata => \timers:1:channel|duration_r\(14),
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:1:channel|elapsed_r[14]~0_combout\,
	sload => \timers:1:channel|elapsed_r[14]~1_combout\,
	ena => \timers:1:channel|elapsed_r[14]~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:1:channel|elapsed_r\(14));

-- Location: LABCELL_X23_Y68_N45
\timers:1:channel|Add2~61\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|Add2~61_sumout\ = SUM(( \timers:1:channel|elapsed_r\(15) ) + ( GND ) + ( \timers:1:channel|Add2~58\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:1:channel|ALT_INV_elapsed_r\(15),
	cin => \timers:1:channel|Add2~58\,
	sumout => \timers:1:channel|Add2~61_sumout\);

-- Location: FF_X24_Y66_N47
\timers:1:channel|duration_r[15]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \IO_DATA[15]~input_o\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sload => VCC,
	ena => \timers:1:channel|process_0~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:1:channel|duration_r\(15));

-- Location: FF_X23_Y68_N47
\timers:1:channel|elapsed_r[15]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:1:channel|Add2~61_sumout\,
	asdata => \timers:1:channel|duration_r\(15),
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:1:channel|elapsed_r[14]~0_combout\,
	sload => \timers:1:channel|elapsed_r[14]~1_combout\,
	ena => \timers:1:channel|elapsed_r[14]~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:1:channel|elapsed_r\(15));

-- Location: FF_X24_Y66_N50
\timers:1:channel|duration_r[7]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \IO_DATA[7]~input_o\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sload => VCC,
	ena => \timers:1:channel|process_0~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:1:channel|duration_r\(7));

-- Location: FF_X24_Y66_N53
\timers:1:channel|duration_r[6]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \IO_DATA[6]~input_o\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sload => VCC,
	ena => \timers:1:channel|process_0~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:1:channel|duration_r\(6));

-- Location: FF_X24_Y66_N29
\timers:1:channel|duration_r[5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \IO_DATA[5]~input_o\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sload => VCC,
	ena => \timers:1:channel|process_0~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:1:channel|duration_r\(5));

-- Location: FF_X24_Y66_N26
\timers:1:channel|duration_r[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \IO_DATA[4]~input_o\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sload => VCC,
	ena => \timers:1:channel|process_0~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:1:channel|duration_r\(4));

-- Location: FF_X24_Y66_N11
\timers:1:channel|duration_r[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \IO_DATA[3]~input_o\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sload => VCC,
	ena => \timers:1:channel|process_0~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:1:channel|duration_r\(3));

-- Location: FF_X24_Y66_N17
\timers:1:channel|duration_r[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \IO_DATA[2]~input_o\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sload => VCC,
	ena => \timers:1:channel|process_0~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:1:channel|duration_r\(2));

-- Location: LABCELL_X24_Y66_N0
\timers:1:channel|Add0~49\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|Add0~49_sumout\ = SUM(( !\timers:1:channel|duration_r\(0) ) + ( VCC ) + ( !VCC ))
-- \timers:1:channel|Add0~50\ = CARRY(( !\timers:1:channel|duration_r\(0) ) + ( VCC ) + ( !VCC ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000001111111100000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datad => \timers:1:channel|ALT_INV_duration_r\(0),
	cin => GND,
	sumout => \timers:1:channel|Add0~49_sumout\,
	cout => \timers:1:channel|Add0~50\);

-- Location: LABCELL_X24_Y66_N3
\timers:1:channel|Add0~45\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|Add0~45_sumout\ = SUM(( \timers:1:channel|duration_r\(1) ) + ( VCC ) + ( \timers:1:channel|Add0~50\ ))
-- \timers:1:channel|Add0~46\ = CARRY(( \timers:1:channel|duration_r\(1) ) + ( VCC ) + ( \timers:1:channel|Add0~50\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000000000000011111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datad => \timers:1:channel|ALT_INV_duration_r\(1),
	cin => \timers:1:channel|Add0~50\,
	sumout => \timers:1:channel|Add0~45_sumout\,
	cout => \timers:1:channel|Add0~46\);

-- Location: LABCELL_X24_Y66_N6
\timers:1:channel|Add0~41\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|Add0~41_sumout\ = SUM(( \timers:1:channel|duration_r\(2) ) + ( VCC ) + ( \timers:1:channel|Add0~46\ ))
-- \timers:1:channel|Add0~42\ = CARRY(( \timers:1:channel|duration_r\(2) ) + ( VCC ) + ( \timers:1:channel|Add0~46\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000000011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \timers:1:channel|ALT_INV_duration_r\(2),
	cin => \timers:1:channel|Add0~46\,
	sumout => \timers:1:channel|Add0~41_sumout\,
	cout => \timers:1:channel|Add0~42\);

-- Location: LABCELL_X24_Y66_N9
\timers:1:channel|Add0~37\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|Add0~37_sumout\ = SUM(( \timers:1:channel|duration_r\(3) ) + ( VCC ) + ( \timers:1:channel|Add0~42\ ))
-- \timers:1:channel|Add0~38\ = CARRY(( \timers:1:channel|duration_r\(3) ) + ( VCC ) + ( \timers:1:channel|Add0~42\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:1:channel|ALT_INV_duration_r\(3),
	cin => \timers:1:channel|Add0~42\,
	sumout => \timers:1:channel|Add0~37_sumout\,
	cout => \timers:1:channel|Add0~38\);

-- Location: LABCELL_X24_Y66_N12
\timers:1:channel|Add0~33\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|Add0~33_sumout\ = SUM(( \timers:1:channel|duration_r\(4) ) + ( VCC ) + ( \timers:1:channel|Add0~38\ ))
-- \timers:1:channel|Add0~34\ = CARRY(( \timers:1:channel|duration_r\(4) ) + ( VCC ) + ( \timers:1:channel|Add0~38\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:1:channel|ALT_INV_duration_r\(4),
	cin => \timers:1:channel|Add0~38\,
	sumout => \timers:1:channel|Add0~33_sumout\,
	cout => \timers:1:channel|Add0~34\);

-- Location: LABCELL_X24_Y66_N15
\timers:1:channel|Add0~61\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|Add0~61_sumout\ = SUM(( \timers:1:channel|duration_r\(5) ) + ( VCC ) + ( \timers:1:channel|Add0~34\ ))
-- \timers:1:channel|Add0~62\ = CARRY(( \timers:1:channel|duration_r\(5) ) + ( VCC ) + ( \timers:1:channel|Add0~34\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000000000000011111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datad => \timers:1:channel|ALT_INV_duration_r\(5),
	cin => \timers:1:channel|Add0~34\,
	sumout => \timers:1:channel|Add0~61_sumout\,
	cout => \timers:1:channel|Add0~62\);

-- Location: LABCELL_X24_Y66_N18
\timers:1:channel|Add0~57\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|Add0~57_sumout\ = SUM(( \timers:1:channel|duration_r\(6) ) + ( VCC ) + ( \timers:1:channel|Add0~62\ ))
-- \timers:1:channel|Add0~58\ = CARRY(( \timers:1:channel|duration_r\(6) ) + ( VCC ) + ( \timers:1:channel|Add0~62\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:1:channel|ALT_INV_duration_r\(6),
	cin => \timers:1:channel|Add0~62\,
	sumout => \timers:1:channel|Add0~57_sumout\,
	cout => \timers:1:channel|Add0~58\);

-- Location: LABCELL_X24_Y66_N21
\timers:1:channel|Add0~53\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|Add0~53_sumout\ = SUM(( \timers:1:channel|duration_r\(7) ) + ( VCC ) + ( \timers:1:channel|Add0~58\ ))
-- \timers:1:channel|Add0~54\ = CARRY(( \timers:1:channel|duration_r\(7) ) + ( VCC ) + ( \timers:1:channel|Add0~58\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000000101010101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:1:channel|ALT_INV_duration_r\(7),
	cin => \timers:1:channel|Add0~58\,
	sumout => \timers:1:channel|Add0~53_sumout\,
	cout => \timers:1:channel|Add0~54\);

-- Location: LABCELL_X24_Y66_N24
\timers:1:channel|Add0~29\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|Add0~29_sumout\ = SUM(( \timers:1:channel|duration_r\(8) ) + ( VCC ) + ( \timers:1:channel|Add0~54\ ))
-- \timers:1:channel|Add0~30\ = CARRY(( \timers:1:channel|duration_r\(8) ) + ( VCC ) + ( \timers:1:channel|Add0~54\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000000000000011111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datad => \timers:1:channel|ALT_INV_duration_r\(8),
	cin => \timers:1:channel|Add0~54\,
	sumout => \timers:1:channel|Add0~29_sumout\,
	cout => \timers:1:channel|Add0~30\);

-- Location: LABCELL_X24_Y66_N27
\timers:1:channel|Add0~25\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|Add0~25_sumout\ = SUM(( \timers:1:channel|duration_r\(9) ) + ( VCC ) + ( \timers:1:channel|Add0~30\ ))
-- \timers:1:channel|Add0~26\ = CARRY(( \timers:1:channel|duration_r\(9) ) + ( VCC ) + ( \timers:1:channel|Add0~30\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000000000000011111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datad => \timers:1:channel|ALT_INV_duration_r\(9),
	cin => \timers:1:channel|Add0~30\,
	sumout => \timers:1:channel|Add0~25_sumout\,
	cout => \timers:1:channel|Add0~26\);

-- Location: LABCELL_X24_Y66_N30
\timers:1:channel|Add0~21\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|Add0~21_sumout\ = SUM(( \timers:1:channel|duration_r\(10) ) + ( VCC ) + ( \timers:1:channel|Add0~26\ ))
-- \timers:1:channel|Add0~22\ = CARRY(( \timers:1:channel|duration_r\(10) ) + ( VCC ) + ( \timers:1:channel|Add0~26\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000000000000011111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datad => \timers:1:channel|ALT_INV_duration_r\(10),
	cin => \timers:1:channel|Add0~26\,
	sumout => \timers:1:channel|Add0~21_sumout\,
	cout => \timers:1:channel|Add0~22\);

-- Location: LABCELL_X24_Y66_N33
\timers:1:channel|Add0~17\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|Add0~17_sumout\ = SUM(( \timers:1:channel|duration_r\(11) ) + ( VCC ) + ( \timers:1:channel|Add0~22\ ))
-- \timers:1:channel|Add0~18\ = CARRY(( \timers:1:channel|duration_r\(11) ) + ( VCC ) + ( \timers:1:channel|Add0~22\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000000101010101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:1:channel|ALT_INV_duration_r\(11),
	cin => \timers:1:channel|Add0~22\,
	sumout => \timers:1:channel|Add0~17_sumout\,
	cout => \timers:1:channel|Add0~18\);

-- Location: LABCELL_X24_Y66_N36
\timers:1:channel|Add0~13\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|Add0~13_sumout\ = SUM(( \timers:1:channel|duration_r\(12) ) + ( VCC ) + ( \timers:1:channel|Add0~18\ ))
-- \timers:1:channel|Add0~14\ = CARRY(( \timers:1:channel|duration_r\(12) ) + ( VCC ) + ( \timers:1:channel|Add0~18\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:1:channel|ALT_INV_duration_r\(12),
	cin => \timers:1:channel|Add0~18\,
	sumout => \timers:1:channel|Add0~13_sumout\,
	cout => \timers:1:channel|Add0~14\);

-- Location: LABCELL_X24_Y66_N39
\timers:1:channel|Add0~9\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|Add0~9_sumout\ = SUM(( \timers:1:channel|duration_r\(13) ) + ( VCC ) + ( \timers:1:channel|Add0~14\ ))
-- \timers:1:channel|Add0~10\ = CARRY(( \timers:1:channel|duration_r\(13) ) + ( VCC ) + ( \timers:1:channel|Add0~14\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:1:channel|ALT_INV_duration_r\(13),
	cin => \timers:1:channel|Add0~14\,
	sumout => \timers:1:channel|Add0~9_sumout\,
	cout => \timers:1:channel|Add0~10\);

-- Location: LABCELL_X24_Y66_N42
\timers:1:channel|Add0~5\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|Add0~5_sumout\ = SUM(( \timers:1:channel|duration_r\(14) ) + ( VCC ) + ( \timers:1:channel|Add0~10\ ))
-- \timers:1:channel|Add0~6\ = CARRY(( \timers:1:channel|duration_r\(14) ) + ( VCC ) + ( \timers:1:channel|Add0~10\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000000011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \timers:1:channel|ALT_INV_duration_r\(14),
	cin => \timers:1:channel|Add0~10\,
	sumout => \timers:1:channel|Add0~5_sumout\,
	cout => \timers:1:channel|Add0~6\);

-- Location: LABCELL_X24_Y68_N12
\timers:1:channel|LessThan0~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|LessThan0~0_combout\ = ( \timers:1:channel|Add0~5_sumout\ & ( \timers:1:channel|Add0~9_sumout\ & ( (\timers:1:channel|elapsed_r\(13) & (\timers:1:channel|elapsed_r\(14) & (!\timers:1:channel|Add0~13_sumout\ $ 
-- (\timers:1:channel|elapsed_r\(12))))) ) ) ) # ( !\timers:1:channel|Add0~5_sumout\ & ( \timers:1:channel|Add0~9_sumout\ & ( (\timers:1:channel|elapsed_r\(13) & (!\timers:1:channel|elapsed_r\(14) & (!\timers:1:channel|Add0~13_sumout\ $ 
-- (\timers:1:channel|elapsed_r\(12))))) ) ) ) # ( \timers:1:channel|Add0~5_sumout\ & ( !\timers:1:channel|Add0~9_sumout\ & ( (!\timers:1:channel|elapsed_r\(13) & (\timers:1:channel|elapsed_r\(14) & (!\timers:1:channel|Add0~13_sumout\ $ 
-- (\timers:1:channel|elapsed_r\(12))))) ) ) ) # ( !\timers:1:channel|Add0~5_sumout\ & ( !\timers:1:channel|Add0~9_sumout\ & ( (!\timers:1:channel|elapsed_r\(13) & (!\timers:1:channel|elapsed_r\(14) & (!\timers:1:channel|Add0~13_sumout\ $ 
-- (\timers:1:channel|elapsed_r\(12))))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1000000000001000001000000000001001000000000001000001000000000001",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:1:channel|ALT_INV_elapsed_r\(13),
	datab => \timers:1:channel|ALT_INV_elapsed_r\(14),
	datac => \timers:1:channel|ALT_INV_Add0~13_sumout\,
	datad => \timers:1:channel|ALT_INV_elapsed_r\(12),
	datae => \timers:1:channel|ALT_INV_Add0~5_sumout\,
	dataf => \timers:1:channel|ALT_INV_Add0~9_sumout\,
	combout => \timers:1:channel|LessThan0~0_combout\);

-- Location: LABCELL_X24_Y68_N24
\timers:1:channel|LessThan0~5\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|LessThan0~5_combout\ = ( \timers:1:channel|Add0~5_sumout\ & ( \timers:1:channel|Add0~9_sumout\ & ( (!\timers:1:channel|elapsed_r\(13)) # ((!\timers:1:channel|elapsed_r\(14)) # ((\timers:1:channel|Add0~13_sumout\ & 
-- !\timers:1:channel|elapsed_r\(12)))) ) ) ) # ( !\timers:1:channel|Add0~5_sumout\ & ( \timers:1:channel|Add0~9_sumout\ & ( (!\timers:1:channel|elapsed_r\(14) & ((!\timers:1:channel|elapsed_r\(13)) # ((\timers:1:channel|Add0~13_sumout\ & 
-- !\timers:1:channel|elapsed_r\(12))))) ) ) ) # ( \timers:1:channel|Add0~5_sumout\ & ( !\timers:1:channel|Add0~9_sumout\ & ( (!\timers:1:channel|elapsed_r\(14)) # ((!\timers:1:channel|elapsed_r\(13) & (\timers:1:channel|Add0~13_sumout\ & 
-- !\timers:1:channel|elapsed_r\(12)))) ) ) ) # ( !\timers:1:channel|Add0~5_sumout\ & ( !\timers:1:channel|Add0~9_sumout\ & ( (!\timers:1:channel|elapsed_r\(13) & (!\timers:1:channel|elapsed_r\(14) & (\timers:1:channel|Add0~13_sumout\ & 
-- !\timers:1:channel|elapsed_r\(12)))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000100000000000110011101100110010001100100010001110111111101110",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:1:channel|ALT_INV_elapsed_r\(13),
	datab => \timers:1:channel|ALT_INV_elapsed_r\(14),
	datac => \timers:1:channel|ALT_INV_Add0~13_sumout\,
	datad => \timers:1:channel|ALT_INV_elapsed_r\(12),
	datae => \timers:1:channel|ALT_INV_Add0~5_sumout\,
	dataf => \timers:1:channel|ALT_INV_Add0~9_sumout\,
	combout => \timers:1:channel|LessThan0~5_combout\);

-- Location: LABCELL_X24_Y68_N0
\timers:1:channel|LessThan0~6\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|LessThan0~6_combout\ = ( \timers:1:channel|Add0~17_sumout\ & ( !\timers:1:channel|LessThan0~5_combout\ & ( (!\timers:1:channel|LessThan0~0_combout\) # ((\timers:1:channel|elapsed_r\(11) & ((!\timers:1:channel|Add0~21_sumout\) # 
-- (\timers:1:channel|elapsed_r\(10))))) ) ) ) # ( !\timers:1:channel|Add0~17_sumout\ & ( !\timers:1:channel|LessThan0~5_combout\ & ( (((!\timers:1:channel|Add0~21_sumout\) # (!\timers:1:channel|LessThan0~0_combout\)) # (\timers:1:channel|elapsed_r\(11))) # 
-- (\timers:1:channel|elapsed_r\(10)) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111111111110111111111110011000100000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:1:channel|ALT_INV_elapsed_r\(10),
	datab => \timers:1:channel|ALT_INV_elapsed_r\(11),
	datac => \timers:1:channel|ALT_INV_Add0~21_sumout\,
	datad => \timers:1:channel|ALT_INV_LessThan0~0_combout\,
	datae => \timers:1:channel|ALT_INV_Add0~17_sumout\,
	dataf => \timers:1:channel|ALT_INV_LessThan0~5_combout\,
	combout => \timers:1:channel|LessThan0~6_combout\);

-- Location: LABCELL_X24_Y66_N45
\timers:1:channel|Add0~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|Add0~1_sumout\ = SUM(( \timers:1:channel|duration_r\(15) ) + ( VCC ) + ( \timers:1:channel|Add0~6\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:1:channel|ALT_INV_duration_r\(15),
	cin => \timers:1:channel|Add0~6\,
	sumout => \timers:1:channel|Add0~1_sumout\);

-- Location: LABCELL_X24_Y68_N30
\timers:1:channel|LessThan0~2\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|LessThan0~2_combout\ = ( \timers:1:channel|Add0~21_sumout\ & ( !\timers:1:channel|elapsed_r\(10) ) ) # ( !\timers:1:channel|Add0~21_sumout\ & ( \timers:1:channel|elapsed_r\(10) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000111100001111000011110000111111110000111100001111000011110000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:1:channel|ALT_INV_elapsed_r\(10),
	dataf => \timers:1:channel|ALT_INV_Add0~21_sumout\,
	combout => \timers:1:channel|LessThan0~2_combout\);

-- Location: LABCELL_X24_Y68_N9
\timers:1:channel|LessThan0~7\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|LessThan0~7_combout\ = ( \timers:1:channel|Add0~29_sumout\ & ( !\timers:1:channel|elapsed_r\(8) ) ) # ( !\timers:1:channel|Add0~29_sumout\ & ( \timers:1:channel|elapsed_r\(8) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000011111111000000001111111111111111000000001111111100000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datad => \timers:1:channel|ALT_INV_elapsed_r\(8),
	dataf => \timers:1:channel|ALT_INV_Add0~29_sumout\,
	combout => \timers:1:channel|LessThan0~7_combout\);

-- Location: LABCELL_X24_Y68_N42
\timers:1:channel|LessThan0~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|LessThan0~1_combout\ = ( \timers:1:channel|Add0~17_sumout\ & ( !\timers:1:channel|elapsed_r\(11) ) ) # ( !\timers:1:channel|Add0~17_sumout\ & ( \timers:1:channel|elapsed_r\(11) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0011001100110011001100110011001111001100110011001100110011001100",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \timers:1:channel|ALT_INV_elapsed_r\(11),
	dataf => \timers:1:channel|ALT_INV_Add0~17_sumout\,
	combout => \timers:1:channel|LessThan0~1_combout\);

-- Location: LABCELL_X24_Y68_N45
\timers:1:channel|LessThan0~3\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|LessThan0~3_combout\ = !\timers:1:channel|elapsed_r\(9) $ (!\timers:1:channel|Add0~25_sumout\)

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000111111110000000011111111000000001111111100000000111111110000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:1:channel|ALT_INV_elapsed_r\(9),
	datad => \timers:1:channel|ALT_INV_Add0~25_sumout\,
	combout => \timers:1:channel|LessThan0~3_combout\);

-- Location: MLABCELL_X25_Y66_N9
\timers:1:channel|LessThan0~10\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|LessThan0~10_combout\ = ( \timers:1:channel|Add0~33_sumout\ & ( \timers:1:channel|Add0~37_sumout\ & ( (!\timers:1:channel|elapsed_r\(3)) # ((!\timers:1:channel|elapsed_r\(4)) # ((\timers:1:channel|Add0~41_sumout\ & 
-- !\timers:1:channel|elapsed_r\(2)))) ) ) ) # ( !\timers:1:channel|Add0~33_sumout\ & ( \timers:1:channel|Add0~37_sumout\ & ( (!\timers:1:channel|elapsed_r\(4) & ((!\timers:1:channel|elapsed_r\(3)) # ((\timers:1:channel|Add0~41_sumout\ & 
-- !\timers:1:channel|elapsed_r\(2))))) ) ) ) # ( \timers:1:channel|Add0~33_sumout\ & ( !\timers:1:channel|Add0~37_sumout\ & ( (!\timers:1:channel|elapsed_r\(4)) # ((\timers:1:channel|Add0~41_sumout\ & (!\timers:1:channel|elapsed_r\(3) & 
-- !\timers:1:channel|elapsed_r\(2)))) ) ) ) # ( !\timers:1:channel|Add0~33_sumout\ & ( !\timers:1:channel|Add0~37_sumout\ & ( (\timers:1:channel|Add0~41_sumout\ & (!\timers:1:channel|elapsed_r\(3) & (!\timers:1:channel|elapsed_r\(4) & 
-- !\timers:1:channel|elapsed_r\(2)))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0100000000000000111101001111000011010000110000001111110111111100",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:1:channel|ALT_INV_Add0~41_sumout\,
	datab => \timers:1:channel|ALT_INV_elapsed_r\(3),
	datac => \timers:1:channel|ALT_INV_elapsed_r\(4),
	datad => \timers:1:channel|ALT_INV_elapsed_r\(2),
	datae => \timers:1:channel|ALT_INV_Add0~33_sumout\,
	dataf => \timers:1:channel|ALT_INV_Add0~37_sumout\,
	combout => \timers:1:channel|LessThan0~10_combout\);

-- Location: MLABCELL_X25_Y66_N15
\timers:1:channel|LessThan0~9\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|LessThan0~9_combout\ = ( \timers:1:channel|Add0~41_sumout\ & ( \timers:1:channel|Add0~45_sumout\ & ( (\timers:1:channel|elapsed_r\(2) & ((!\timers:1:channel|elapsed_r\(1)) # ((!\timers:1:channel|elapsed_r\(0) & 
-- \timers:1:channel|Add0~49_sumout\)))) ) ) ) # ( !\timers:1:channel|Add0~41_sumout\ & ( \timers:1:channel|Add0~45_sumout\ & ( (!\timers:1:channel|elapsed_r\(2) & ((!\timers:1:channel|elapsed_r\(1)) # ((!\timers:1:channel|elapsed_r\(0) & 
-- \timers:1:channel|Add0~49_sumout\)))) ) ) ) # ( \timers:1:channel|Add0~41_sumout\ & ( !\timers:1:channel|Add0~45_sumout\ & ( (!\timers:1:channel|elapsed_r\(0) & (!\timers:1:channel|elapsed_r\(1) & (\timers:1:channel|Add0~49_sumout\ & 
-- \timers:1:channel|elapsed_r\(2)))) ) ) ) # ( !\timers:1:channel|Add0~41_sumout\ & ( !\timers:1:channel|Add0~45_sumout\ & ( (!\timers:1:channel|elapsed_r\(0) & (!\timers:1:channel|elapsed_r\(1) & (\timers:1:channel|Add0~49_sumout\ & 
-- !\timers:1:channel|elapsed_r\(2)))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000100000000000000000000000100011001110000000000000000011001110",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:1:channel|ALT_INV_elapsed_r\(0),
	datab => \timers:1:channel|ALT_INV_elapsed_r\(1),
	datac => \timers:1:channel|ALT_INV_Add0~49_sumout\,
	datad => \timers:1:channel|ALT_INV_elapsed_r\(2),
	datae => \timers:1:channel|ALT_INV_Add0~41_sumout\,
	dataf => \timers:1:channel|ALT_INV_Add0~45_sumout\,
	combout => \timers:1:channel|LessThan0~9_combout\);

-- Location: LABCELL_X24_Y66_N54
\timers:1:channel|LessThan0~11\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|LessThan0~11_combout\ = ( \timers:1:channel|Add0~53_sumout\ & ( \timers:1:channel|Add0~61_sumout\ & ( (\timers:1:channel|elapsed_r\(7) & (\timers:1:channel|elapsed_r\(5) & (!\timers:1:channel|elapsed_r\(6) $ 
-- (\timers:1:channel|Add0~57_sumout\)))) ) ) ) # ( !\timers:1:channel|Add0~53_sumout\ & ( \timers:1:channel|Add0~61_sumout\ & ( (!\timers:1:channel|elapsed_r\(7) & (\timers:1:channel|elapsed_r\(5) & (!\timers:1:channel|elapsed_r\(6) $ 
-- (\timers:1:channel|Add0~57_sumout\)))) ) ) ) # ( \timers:1:channel|Add0~53_sumout\ & ( !\timers:1:channel|Add0~61_sumout\ & ( (\timers:1:channel|elapsed_r\(7) & (!\timers:1:channel|elapsed_r\(5) & (!\timers:1:channel|elapsed_r\(6) $ 
-- (\timers:1:channel|Add0~57_sumout\)))) ) ) ) # ( !\timers:1:channel|Add0~53_sumout\ & ( !\timers:1:channel|Add0~61_sumout\ & ( (!\timers:1:channel|elapsed_r\(7) & (!\timers:1:channel|elapsed_r\(5) & (!\timers:1:channel|elapsed_r\(6) $ 
-- (\timers:1:channel|Add0~57_sumout\)))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1000001000000000010000010000000000000000100000100000000001000001",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:1:channel|ALT_INV_elapsed_r\(7),
	datab => \timers:1:channel|ALT_INV_elapsed_r\(6),
	datac => \timers:1:channel|ALT_INV_Add0~57_sumout\,
	datad => \timers:1:channel|ALT_INV_elapsed_r\(5),
	datae => \timers:1:channel|ALT_INV_Add0~53_sumout\,
	dataf => \timers:1:channel|ALT_INV_Add0~61_sumout\,
	combout => \timers:1:channel|LessThan0~11_combout\);

-- Location: LABCELL_X24_Y67_N57
\timers:1:channel|LessThan0~8\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|LessThan0~8_combout\ = ( \timers:1:channel|Add0~33_sumout\ & ( (\timers:1:channel|elapsed_r\(4) & (!\timers:1:channel|elapsed_r\(3) $ (\timers:1:channel|Add0~37_sumout\))) ) ) # ( !\timers:1:channel|Add0~33_sumout\ & ( 
-- (!\timers:1:channel|elapsed_r\(4) & (!\timers:1:channel|elapsed_r\(3) $ (\timers:1:channel|Add0~37_sumout\))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1010000000001010101000000000101001010000000001010101000000000101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:1:channel|ALT_INV_elapsed_r\(4),
	datac => \timers:1:channel|ALT_INV_elapsed_r\(3),
	datad => \timers:1:channel|ALT_INV_Add0~37_sumout\,
	dataf => \timers:1:channel|ALT_INV_Add0~33_sumout\,
	combout => \timers:1:channel|LessThan0~8_combout\);

-- Location: LABCELL_X24_Y68_N33
\timers:1:channel|LessThan0~17\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|LessThan0~17_combout\ = ( \timers:1:channel|LessThan0~8_combout\ & ( (!\timers:1:channel|LessThan0~12_combout\ & ((!\timers:1:channel|LessThan0~11_combout\) # ((!\timers:1:channel|LessThan0~10_combout\ & 
-- !\timers:1:channel|LessThan0~9_combout\)))) ) ) # ( !\timers:1:channel|LessThan0~8_combout\ & ( (!\timers:1:channel|LessThan0~12_combout\ & ((!\timers:1:channel|LessThan0~10_combout\) # (!\timers:1:channel|LessThan0~11_combout\))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1100110010001000110011001000100011001100100000001100110010000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:1:channel|ALT_INV_LessThan0~10_combout\,
	datab => \timers:1:channel|ALT_INV_LessThan0~12_combout\,
	datac => \timers:1:channel|ALT_INV_LessThan0~9_combout\,
	datad => \timers:1:channel|ALT_INV_LessThan0~11_combout\,
	dataf => \timers:1:channel|ALT_INV_LessThan0~8_combout\,
	combout => \timers:1:channel|LessThan0~17_combout\);

-- Location: LABCELL_X24_Y68_N36
\timers:1:channel|LessThan0~18\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|LessThan0~18_combout\ = ( !\timers:1:channel|LessThan0~3_combout\ & ( !\timers:1:channel|LessThan0~17_combout\ & ( (!\timers:1:channel|LessThan0~2_combout\ & (\timers:1:channel|LessThan0~0_combout\ & 
-- (!\timers:1:channel|LessThan0~7_combout\ & !\timers:1:channel|LessThan0~1_combout\))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0010000000000000000000000000000000000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:1:channel|ALT_INV_LessThan0~2_combout\,
	datab => \timers:1:channel|ALT_INV_LessThan0~0_combout\,
	datac => \timers:1:channel|ALT_INV_LessThan0~7_combout\,
	datad => \timers:1:channel|ALT_INV_LessThan0~1_combout\,
	datae => \timers:1:channel|ALT_INV_LessThan0~3_combout\,
	dataf => \timers:1:channel|ALT_INV_LessThan0~17_combout\,
	combout => \timers:1:channel|LessThan0~18_combout\);

-- Location: LABCELL_X23_Y65_N39
\timers:1:channel|LessThan0~14\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|LessThan0~14_combout\ = ( \timers:1:channel|Add0~29_sumout\ & ( !\timers:1:channel|elapsed_r\(8) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000011110000111100001111000011110000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:1:channel|ALT_INV_elapsed_r\(8),
	dataf => \timers:1:channel|ALT_INV_Add0~29_sumout\,
	combout => \timers:1:channel|LessThan0~14_combout\);

-- Location: LABCELL_X24_Y68_N18
\timers:1:channel|LessThan0~15\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|LessThan0~15_combout\ = ( \timers:1:channel|LessThan0~14_combout\ & ( \timers:1:channel|LessThan0~0_combout\ & ( (!\timers:1:channel|LessThan0~2_combout\ & (!\timers:1:channel|LessThan0~1_combout\ & ((!\timers:1:channel|elapsed_r\(9)) # 
-- (\timers:1:channel|Add0~25_sumout\)))) ) ) ) # ( !\timers:1:channel|LessThan0~14_combout\ & ( \timers:1:channel|LessThan0~0_combout\ & ( (!\timers:1:channel|elapsed_r\(9) & (!\timers:1:channel|LessThan0~2_combout\ & (\timers:1:channel|Add0~25_sumout\ & 
-- !\timers:1:channel|LessThan0~1_combout\))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000001000000000001000110000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:1:channel|ALT_INV_elapsed_r\(9),
	datab => \timers:1:channel|ALT_INV_LessThan0~2_combout\,
	datac => \timers:1:channel|ALT_INV_Add0~25_sumout\,
	datad => \timers:1:channel|ALT_INV_LessThan0~1_combout\,
	datae => \timers:1:channel|ALT_INV_LessThan0~14_combout\,
	dataf => \timers:1:channel|ALT_INV_LessThan0~0_combout\,
	combout => \timers:1:channel|LessThan0~15_combout\);

-- Location: LABCELL_X23_Y68_N54
\timers:1:channel|elapsed_r[14]~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|elapsed_r[14]~1_combout\ = ( \timers:1:channel|LessThan0~18_combout\ & ( \timers:1:channel|LessThan0~15_combout\ & ( (\timers:1:channel|mode_r\(1) & (\timers:1:channel|elapsed_r\(15) & !\timers:1:channel|Add0~1_sumout\)) ) ) ) # ( 
-- !\timers:1:channel|LessThan0~18_combout\ & ( \timers:1:channel|LessThan0~15_combout\ & ( (\timers:1:channel|mode_r\(1) & (\timers:1:channel|elapsed_r\(15) & !\timers:1:channel|Add0~1_sumout\)) ) ) ) # ( \timers:1:channel|LessThan0~18_combout\ & ( 
-- !\timers:1:channel|LessThan0~15_combout\ & ( (\timers:1:channel|mode_r\(1) & (\timers:1:channel|elapsed_r\(15) & !\timers:1:channel|Add0~1_sumout\)) ) ) ) # ( !\timers:1:channel|LessThan0~18_combout\ & ( !\timers:1:channel|LessThan0~15_combout\ & ( 
-- (\timers:1:channel|mode_r\(1) & ((!\timers:1:channel|elapsed_r\(15) & (\timers:1:channel|LessThan0~6_combout\ & !\timers:1:channel|Add0~1_sumout\)) # (\timers:1:channel|elapsed_r\(15) & ((!\timers:1:channel|Add0~1_sumout\) # 
-- (\timers:1:channel|LessThan0~6_combout\))))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0001010100000001000100010000000000010001000000000001000100000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:1:channel|ALT_INV_mode_r\(1),
	datab => \timers:1:channel|ALT_INV_elapsed_r\(15),
	datac => \timers:1:channel|ALT_INV_LessThan0~6_combout\,
	datad => \timers:1:channel|ALT_INV_Add0~1_sumout\,
	datae => \timers:1:channel|ALT_INV_LessThan0~18_combout\,
	dataf => \timers:1:channel|ALT_INV_LessThan0~15_combout\,
	combout => \timers:1:channel|elapsed_r[14]~1_combout\);

-- Location: FF_X23_Y68_N5
\timers:1:channel|elapsed_r[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:1:channel|Add2~5_sumout\,
	asdata => \timers:1:channel|duration_r\(1),
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:1:channel|elapsed_r[14]~0_combout\,
	sload => \timers:1:channel|elapsed_r[14]~1_combout\,
	ena => \timers:1:channel|elapsed_r[14]~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:1:channel|elapsed_r\(1));

-- Location: LABCELL_X23_Y68_N6
\timers:1:channel|Add2~9\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|Add2~9_sumout\ = SUM(( \timers:1:channel|elapsed_r\(2) ) + ( GND ) + ( \timers:1:channel|Add2~6\ ))
-- \timers:1:channel|Add2~10\ = CARRY(( \timers:1:channel|elapsed_r\(2) ) + ( GND ) + ( \timers:1:channel|Add2~6\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \timers:1:channel|ALT_INV_elapsed_r\(2),
	cin => \timers:1:channel|Add2~6\,
	sumout => \timers:1:channel|Add2~9_sumout\,
	cout => \timers:1:channel|Add2~10\);

-- Location: FF_X23_Y68_N8
\timers:1:channel|elapsed_r[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:1:channel|Add2~9_sumout\,
	asdata => \timers:1:channel|duration_r\(2),
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:1:channel|elapsed_r[14]~0_combout\,
	sload => \timers:1:channel|elapsed_r[14]~1_combout\,
	ena => \timers:1:channel|elapsed_r[14]~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:1:channel|elapsed_r\(2));

-- Location: LABCELL_X23_Y68_N9
\timers:1:channel|Add2~13\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|Add2~13_sumout\ = SUM(( \timers:1:channel|elapsed_r\(3) ) + ( GND ) + ( \timers:1:channel|Add2~10\ ))
-- \timers:1:channel|Add2~14\ = CARRY(( \timers:1:channel|elapsed_r\(3) ) + ( GND ) + ( \timers:1:channel|Add2~10\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:1:channel|ALT_INV_elapsed_r\(3),
	cin => \timers:1:channel|Add2~10\,
	sumout => \timers:1:channel|Add2~13_sumout\,
	cout => \timers:1:channel|Add2~14\);

-- Location: FF_X23_Y68_N11
\timers:1:channel|elapsed_r[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:1:channel|Add2~13_sumout\,
	asdata => \timers:1:channel|duration_r\(3),
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:1:channel|elapsed_r[14]~0_combout\,
	sload => \timers:1:channel|elapsed_r[14]~1_combout\,
	ena => \timers:1:channel|elapsed_r[14]~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:1:channel|elapsed_r\(3));

-- Location: LABCELL_X23_Y68_N12
\timers:1:channel|Add2~17\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|Add2~17_sumout\ = SUM(( \timers:1:channel|elapsed_r\(4) ) + ( GND ) + ( \timers:1:channel|Add2~14\ ))
-- \timers:1:channel|Add2~18\ = CARRY(( \timers:1:channel|elapsed_r\(4) ) + ( GND ) + ( \timers:1:channel|Add2~14\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \timers:1:channel|ALT_INV_elapsed_r\(4),
	cin => \timers:1:channel|Add2~14\,
	sumout => \timers:1:channel|Add2~17_sumout\,
	cout => \timers:1:channel|Add2~18\);

-- Location: FF_X23_Y68_N14
\timers:1:channel|elapsed_r[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:1:channel|Add2~17_sumout\,
	asdata => \timers:1:channel|duration_r\(4),
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:1:channel|elapsed_r[14]~0_combout\,
	sload => \timers:1:channel|elapsed_r[14]~1_combout\,
	ena => \timers:1:channel|elapsed_r[14]~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:1:channel|elapsed_r\(4));

-- Location: LABCELL_X23_Y68_N15
\timers:1:channel|Add2~21\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|Add2~21_sumout\ = SUM(( \timers:1:channel|elapsed_r\(5) ) + ( GND ) + ( \timers:1:channel|Add2~18\ ))
-- \timers:1:channel|Add2~22\ = CARRY(( \timers:1:channel|elapsed_r\(5) ) + ( GND ) + ( \timers:1:channel|Add2~18\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:1:channel|ALT_INV_elapsed_r\(5),
	cin => \timers:1:channel|Add2~18\,
	sumout => \timers:1:channel|Add2~21_sumout\,
	cout => \timers:1:channel|Add2~22\);

-- Location: FF_X23_Y68_N17
\timers:1:channel|elapsed_r[5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:1:channel|Add2~21_sumout\,
	asdata => \timers:1:channel|duration_r\(5),
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:1:channel|elapsed_r[14]~0_combout\,
	sload => \timers:1:channel|elapsed_r[14]~1_combout\,
	ena => \timers:1:channel|elapsed_r[14]~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:1:channel|elapsed_r\(5));

-- Location: LABCELL_X23_Y68_N18
\timers:1:channel|Add2~25\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|Add2~25_sumout\ = SUM(( \timers:1:channel|elapsed_r\(6) ) + ( GND ) + ( \timers:1:channel|Add2~22\ ))
-- \timers:1:channel|Add2~26\ = CARRY(( \timers:1:channel|elapsed_r\(6) ) + ( GND ) + ( \timers:1:channel|Add2~22\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:1:channel|ALT_INV_elapsed_r\(6),
	cin => \timers:1:channel|Add2~22\,
	sumout => \timers:1:channel|Add2~25_sumout\,
	cout => \timers:1:channel|Add2~26\);

-- Location: FF_X23_Y68_N20
\timers:1:channel|elapsed_r[6]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:1:channel|Add2~25_sumout\,
	asdata => \timers:1:channel|duration_r\(6),
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:1:channel|elapsed_r[14]~0_combout\,
	sload => \timers:1:channel|elapsed_r[14]~1_combout\,
	ena => \timers:1:channel|elapsed_r[14]~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:1:channel|elapsed_r\(6));

-- Location: FF_X23_Y68_N23
\timers:1:channel|elapsed_r[7]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:1:channel|Add2~29_sumout\,
	asdata => \timers:1:channel|duration_r\(7),
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:1:channel|elapsed_r[14]~0_combout\,
	sload => \timers:1:channel|elapsed_r[14]~1_combout\,
	ena => \timers:1:channel|elapsed_r[14]~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:1:channel|elapsed_r\(7));

-- Location: LABCELL_X24_Y66_N48
\timers:1:channel|LessThan0~12\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|LessThan0~12_combout\ = ( \timers:1:channel|Add0~53_sumout\ & ( \timers:1:channel|Add0~61_sumout\ & ( (!\timers:1:channel|elapsed_r\(7)) # ((!\timers:1:channel|elapsed_r\(6) & ((!\timers:1:channel|elapsed_r\(5)) # 
-- (\timers:1:channel|Add0~57_sumout\))) # (\timers:1:channel|elapsed_r\(6) & (\timers:1:channel|Add0~57_sumout\ & !\timers:1:channel|elapsed_r\(5)))) ) ) ) # ( !\timers:1:channel|Add0~53_sumout\ & ( \timers:1:channel|Add0~61_sumout\ & ( 
-- (!\timers:1:channel|elapsed_r\(7) & ((!\timers:1:channel|elapsed_r\(6) & ((!\timers:1:channel|elapsed_r\(5)) # (\timers:1:channel|Add0~57_sumout\))) # (\timers:1:channel|elapsed_r\(6) & (\timers:1:channel|Add0~57_sumout\ & 
-- !\timers:1:channel|elapsed_r\(5))))) ) ) ) # ( \timers:1:channel|Add0~53_sumout\ & ( !\timers:1:channel|Add0~61_sumout\ & ( (!\timers:1:channel|elapsed_r\(7)) # ((!\timers:1:channel|elapsed_r\(6) & \timers:1:channel|Add0~57_sumout\)) ) ) ) # ( 
-- !\timers:1:channel|Add0~53_sumout\ & ( !\timers:1:channel|Add0~61_sumout\ & ( (!\timers:1:channel|elapsed_r\(7) & (!\timers:1:channel|elapsed_r\(6) & \timers:1:channel|Add0~57_sumout\)) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000100000001000101011101010111010001010000010001110111110101110",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:1:channel|ALT_INV_elapsed_r\(7),
	datab => \timers:1:channel|ALT_INV_elapsed_r\(6),
	datac => \timers:1:channel|ALT_INV_Add0~57_sumout\,
	datad => \timers:1:channel|ALT_INV_elapsed_r\(5),
	datae => \timers:1:channel|ALT_INV_Add0~53_sumout\,
	dataf => \timers:1:channel|ALT_INV_Add0~61_sumout\,
	combout => \timers:1:channel|LessThan0~12_combout\);

-- Location: LABCELL_X24_Y68_N48
\timers:1:channel|LessThan0~13\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|LessThan0~13_combout\ = ( \timers:1:channel|LessThan0~11_combout\ & ( \timers:1:channel|LessThan0~8_combout\ & ( (!\timers:1:channel|LessThan0~7_combout\ & (((\timers:1:channel|LessThan0~10_combout\) # 
-- (\timers:1:channel|LessThan0~9_combout\)) # (\timers:1:channel|LessThan0~12_combout\))) ) ) ) # ( !\timers:1:channel|LessThan0~11_combout\ & ( \timers:1:channel|LessThan0~8_combout\ & ( (\timers:1:channel|LessThan0~12_combout\ & 
-- !\timers:1:channel|LessThan0~7_combout\) ) ) ) # ( \timers:1:channel|LessThan0~11_combout\ & ( !\timers:1:channel|LessThan0~8_combout\ & ( (!\timers:1:channel|LessThan0~7_combout\ & ((\timers:1:channel|LessThan0~10_combout\) # 
-- (\timers:1:channel|LessThan0~12_combout\))) ) ) ) # ( !\timers:1:channel|LessThan0~11_combout\ & ( !\timers:1:channel|LessThan0~8_combout\ & ( (\timers:1:channel|LessThan0~12_combout\ & !\timers:1:channel|LessThan0~7_combout\) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0101010100000000010111110000000001010101000000000111111100000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:1:channel|ALT_INV_LessThan0~12_combout\,
	datab => \timers:1:channel|ALT_INV_LessThan0~9_combout\,
	datac => \timers:1:channel|ALT_INV_LessThan0~10_combout\,
	datad => \timers:1:channel|ALT_INV_LessThan0~7_combout\,
	datae => \timers:1:channel|ALT_INV_LessThan0~11_combout\,
	dataf => \timers:1:channel|ALT_INV_LessThan0~8_combout\,
	combout => \timers:1:channel|LessThan0~13_combout\);

-- Location: LABCELL_X24_Y68_N6
\timers:1:channel|LessThan0~4\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|LessThan0~4_combout\ = ( \timers:1:channel|LessThan0~0_combout\ & ( (!\timers:1:channel|LessThan0~1_combout\ & (!\timers:1:channel|LessThan0~2_combout\ & !\timers:1:channel|LessThan0~3_combout\)) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000011000000000000001100000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \timers:1:channel|ALT_INV_LessThan0~1_combout\,
	datac => \timers:1:channel|ALT_INV_LessThan0~2_combout\,
	datad => \timers:1:channel|ALT_INV_LessThan0~3_combout\,
	dataf => \timers:1:channel|ALT_INV_LessThan0~0_combout\,
	combout => \timers:1:channel|LessThan0~4_combout\);

-- Location: LABCELL_X24_Y68_N54
\timers:1:channel|LessThan0~16\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|LessThan0~16_combout\ = ( \timers:1:channel|LessThan0~6_combout\ & ( \timers:1:channel|LessThan0~15_combout\ & ( (\timers:1:channel|elapsed_r\(15) & !\timers:1:channel|Add0~1_sumout\) ) ) ) # ( !\timers:1:channel|LessThan0~6_combout\ & ( 
-- \timers:1:channel|LessThan0~15_combout\ & ( (\timers:1:channel|elapsed_r\(15) & !\timers:1:channel|Add0~1_sumout\) ) ) ) # ( \timers:1:channel|LessThan0~6_combout\ & ( !\timers:1:channel|LessThan0~15_combout\ & ( (!\timers:1:channel|elapsed_r\(15) & 
-- (!\timers:1:channel|Add0~1_sumout\ & ((!\timers:1:channel|LessThan0~13_combout\) # (!\timers:1:channel|LessThan0~4_combout\)))) # (\timers:1:channel|elapsed_r\(15) & ((!\timers:1:channel|LessThan0~13_combout\) # ((!\timers:1:channel|Add0~1_sumout\) # 
-- (!\timers:1:channel|LessThan0~4_combout\)))) ) ) ) # ( !\timers:1:channel|LessThan0~6_combout\ & ( !\timers:1:channel|LessThan0~15_combout\ & ( (\timers:1:channel|elapsed_r\(15) & !\timers:1:channel|Add0~1_sumout\) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0011000000110000111100111011001000110000001100000011000000110000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:1:channel|ALT_INV_LessThan0~13_combout\,
	datab => \timers:1:channel|ALT_INV_elapsed_r\(15),
	datac => \timers:1:channel|ALT_INV_Add0~1_sumout\,
	datad => \timers:1:channel|ALT_INV_LessThan0~4_combout\,
	datae => \timers:1:channel|ALT_INV_LessThan0~6_combout\,
	dataf => \timers:1:channel|ALT_INV_LessThan0~15_combout\,
	combout => \timers:1:channel|LessThan0~16_combout\);

-- Location: LABCELL_X24_Y69_N48
\timers:1:channel|Mux33~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|Mux33~0_combout\ = ( \timers:1:channel|running_r~q\ & ( \timers:1:channel|LessThan0~16_combout\ & ( (!\timers:0:channel|Mux33~0_combout\ & (!\timers:1:channel|running_r~0_combout\)) # (\timers:0:channel|Mux33~0_combout\ & 
-- ((!\Equal11~2_combout\ & (!\timers:1:channel|running_r~0_combout\)) # (\Equal11~2_combout\ & ((!\IO_DATA[1]~input_o\))))) ) ) ) # ( !\timers:1:channel|running_r~q\ & ( \timers:1:channel|LessThan0~16_combout\ & ( (!\IO_DATA[1]~input_o\ & 
-- (\timers:0:channel|Mux33~0_combout\ & \Equal11~2_combout\)) ) ) ) # ( \timers:1:channel|running_r~q\ & ( !\timers:1:channel|LessThan0~16_combout\ & ( (!\IO_DATA[1]~input_o\) # ((!\timers:0:channel|Mux33~0_combout\) # (!\Equal11~2_combout\)) ) ) ) # ( 
-- !\timers:1:channel|running_r~q\ & ( !\timers:1:channel|LessThan0~16_combout\ & ( (!\timers:0:channel|Mux33~0_combout\ & (\timers:1:channel|running_r~0_combout\)) # (\timers:0:channel|Mux33~0_combout\ & ((!\Equal11~2_combout\ & 
-- (\timers:1:channel|running_r~0_combout\)) # (\Equal11~2_combout\ & ((!\IO_DATA[1]~input_o\))))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0101010101011100111111111111110000000000000011001010101010101100",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:1:channel|ALT_INV_running_r~0_combout\,
	datab => \ALT_INV_IO_DATA[1]~input_o\,
	datac => \timers:0:channel|ALT_INV_Mux33~0_combout\,
	datad => \ALT_INV_Equal11~2_combout\,
	datae => \timers:1:channel|ALT_INV_running_r~q\,
	dataf => \timers:1:channel|ALT_INV_LessThan0~16_combout\,
	combout => \timers:1:channel|Mux33~0_combout\);

-- Location: FF_X24_Y69_N50
\timers:1:channel|running_r\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:1:channel|Mux33~0_combout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:1:channel|running_r~q\);

-- Location: LABCELL_X23_Y68_N48
\timers:1:channel|elapsed_r[14]~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|elapsed_r[14]~0_combout\ = ( \timers:1:channel|mode_r\(0) & ( \timers:1:channel|LessThan0~16_combout\ & ( (\timers:0:channel|periods_r~0_combout\ & (\Equal11~2_combout\ & !\timers:1:channel|running_r~q\)) ) ) ) # ( 
-- !\timers:1:channel|mode_r\(0) & ( \timers:1:channel|LessThan0~16_combout\ & ( ((\timers:0:channel|periods_r~0_combout\ & (\Equal11~2_combout\ & !\timers:1:channel|running_r~q\))) # (\timers:1:channel|mode_r\(1)) ) ) ) # ( \timers:1:channel|mode_r\(0) & ( 
-- !\timers:1:channel|LessThan0~16_combout\ & ( (\timers:0:channel|periods_r~0_combout\ & (\Equal11~2_combout\ & !\timers:1:channel|running_r~q\)) ) ) ) # ( !\timers:1:channel|mode_r\(0) & ( !\timers:1:channel|LessThan0~16_combout\ & ( 
-- (\timers:0:channel|periods_r~0_combout\ & (\Equal11~2_combout\ & !\timers:1:channel|running_r~q\)) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0001000100000000000100010000000000011111000011110001000100000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:0:channel|ALT_INV_periods_r~0_combout\,
	datab => \ALT_INV_Equal11~2_combout\,
	datac => \timers:1:channel|ALT_INV_mode_r\(1),
	datad => \timers:1:channel|ALT_INV_running_r~q\,
	datae => \timers:1:channel|ALT_INV_mode_r\(0),
	dataf => \timers:1:channel|ALT_INV_LessThan0~16_combout\,
	combout => \timers:1:channel|elapsed_r[14]~0_combout\);

-- Location: FF_X23_Y68_N2
\timers:1:channel|elapsed_r[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:1:channel|Add2~1_sumout\,
	asdata => \timers:1:channel|duration_r[0]~_wirecell_combout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:1:channel|elapsed_r[14]~0_combout\,
	sload => \timers:1:channel|elapsed_r[14]~1_combout\,
	ena => \timers:1:channel|elapsed_r[14]~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:1:channel|elapsed_r\(0));

-- Location: MLABCELL_X25_Y67_N0
\timers:0:channel|Add2~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|Add2~1_sumout\ = SUM(( \timers:0:channel|elapsed_r\(0) ) + ( VCC ) + ( !VCC ))
-- \timers:0:channel|Add2~2\ = CARRY(( \timers:0:channel|elapsed_r\(0) ) + ( VCC ) + ( !VCC ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:0:channel|ALT_INV_elapsed_r\(0),
	cin => GND,
	sumout => \timers:0:channel|Add2~1_sumout\,
	cout => \timers:0:channel|Add2~2\);

-- Location: LABCELL_X19_Y67_N36
\timers:0:channel|duration_r[0]~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|duration_r[0]~0_combout\ = ( !\IO_DATA[0]~input_o\ )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111111111111111111111111111111100000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataf => \ALT_INV_IO_DATA[0]~input_o\,
	combout => \timers:0:channel|duration_r[0]~0_combout\);

-- Location: MLABCELL_X21_Y70_N3
\timers:0:channel|process_0~2\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|process_0~2_combout\ = ( \IO_WRITE~input_o\ & ( \timers:0:channel|process_0~1_combout\ & ( (!\IO_ADDR[10]~input_o\ & (!\IO_ADDR[2]~input_o\ & (\Equal0~0_combout\ & !\IO_ADDR[3]~input_o\))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000000000100000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_IO_ADDR[10]~input_o\,
	datab => \ALT_INV_IO_ADDR[2]~input_o\,
	datac => \ALT_INV_Equal0~0_combout\,
	datad => \ALT_INV_IO_ADDR[3]~input_o\,
	datae => \ALT_INV_IO_WRITE~input_o\,
	dataf => \timers:0:channel|ALT_INV_process_0~1_combout\,
	combout => \timers:0:channel|process_0~2_combout\);

-- Location: FF_X22_Y67_N2
\timers:0:channel|duration_r[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \timers:0:channel|duration_r[0]~0_combout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sload => VCC,
	ena => \timers:0:channel|process_0~2_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:0:channel|duration_r\(0));

-- Location: LABCELL_X27_Y67_N0
\timers:0:channel|duration_r[0]~_wirecell\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|duration_r[0]~_wirecell_combout\ = ( !\timers:0:channel|duration_r\(0) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111111111111111111111111111111100000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataf => \timers:0:channel|ALT_INV_duration_r\(0),
	combout => \timers:0:channel|duration_r[0]~_wirecell_combout\);

-- Location: LABCELL_X24_Y69_N12
\timers:0:channel|process_0~3\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|process_0~3_combout\ = ( !\IO_ADDR[3]~input_o\ & ( \timers:0:channel|process_0~0_combout\ & ( (!\IO_ADDR[10]~input_o\ & (!\IO_ADDR[2]~input_o\ & (\Equal0~0_combout\ & \IO_WRITE~input_o\))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000010000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_IO_ADDR[10]~input_o\,
	datab => \ALT_INV_IO_ADDR[2]~input_o\,
	datac => \ALT_INV_Equal0~0_combout\,
	datad => \ALT_INV_IO_WRITE~input_o\,
	datae => \ALT_INV_IO_ADDR[3]~input_o\,
	dataf => \timers:0:channel|ALT_INV_process_0~0_combout\,
	combout => \timers:0:channel|process_0~3_combout\);

-- Location: FF_X24_Y69_N14
\timers:0:channel|mode_r[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \IO_DATA[1]~input_o\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sload => VCC,
	ena => \timers:0:channel|process_0~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:0:channel|mode_r\(1));

-- Location: LABCELL_X24_Y69_N33
\timers:0:channel|mode_r[0]~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|mode_r[0]~0_combout\ = !\IO_DATA[0]~input_o\

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1010101010101010101010101010101010101010101010101010101010101010",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_IO_DATA[0]~input_o\,
	combout => \timers:0:channel|mode_r[0]~0_combout\);

-- Location: FF_X24_Y69_N35
\timers:0:channel|mode_r[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:0:channel|mode_r[0]~0_combout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	ena => \timers:0:channel|process_0~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:0:channel|mode_r\(0));

-- Location: LABCELL_X23_Y70_N15
\write_hit[0]\ : cyclonev_lcell_comb
-- Equation(s):
-- write_hit(0) = ( !\IO_ADDR[2]~input_o\ & ( (!\IO_ADDR[3]~input_o\ & (\Equal0~0_combout\ & (\IO_WRITE~input_o\ & !\IO_ADDR[10]~input_o\))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000001000000000000000100000000000000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_IO_ADDR[3]~input_o\,
	datab => \ALT_INV_Equal0~0_combout\,
	datac => \ALT_INV_IO_WRITE~input_o\,
	datad => \ALT_INV_IO_ADDR[10]~input_o\,
	dataf => \ALT_INV_IO_ADDR[2]~input_o\,
	combout => write_hit(0));

-- Location: MLABCELL_X25_Y71_N6
\timers:0:channel|clear_prescale~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|clear_prescale~0_combout\ = ( write_hit(0) & ( (!\timers:0:channel|periods_r~0_combout\ & ((\timers:3:channel|process_0~2_combout\))) # (\timers:0:channel|periods_r~0_combout\ & (!\timers:0:channel|running_r~q\)) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000001111101010100000111110101010",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:0:channel|ALT_INV_running_r~q\,
	datac => \timers:3:channel|ALT_INV_process_0~2_combout\,
	datad => \timers:0:channel|ALT_INV_periods_r~0_combout\,
	dataf => ALT_INV_write_hit(0),
	combout => \timers:0:channel|clear_prescale~0_combout\);

-- Location: FF_X25_Y71_N8
\timers:0:channel|clear_prescale\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:0:channel|clear_prescale~0_combout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:0:channel|clear_prescale~q\);

-- Location: MLABCELL_X21_Y70_N0
\timers:0:channel|process_0~4\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|process_0~4_combout\ = ( \IO_WRITE~input_o\ & ( \timers:3:channel|process_0~2_combout\ & ( (!\IO_ADDR[10]~input_o\ & (!\IO_ADDR[2]~input_o\ & (!\IO_ADDR[3]~input_o\ & \Equal0~0_combout\))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000000000000010000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_IO_ADDR[10]~input_o\,
	datab => \ALT_INV_IO_ADDR[2]~input_o\,
	datac => \ALT_INV_IO_ADDR[3]~input_o\,
	datad => \ALT_INV_Equal0~0_combout\,
	datae => \ALT_INV_IO_WRITE~input_o\,
	dataf => \timers:3:channel|ALT_INV_process_0~2_combout\,
	combout => \timers:0:channel|process_0~4_combout\);

-- Location: FF_X22_Y70_N23
\timers:0:channel|timescale_r[15]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \IO_DATA[15]~input_o\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sload => VCC,
	ena => \timers:0:channel|process_0~4_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:0:channel|timescale_r\(15));

-- Location: FF_X23_Y70_N22
\timers:0:channel|timescale_r[11]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \IO_DATA[11]~input_o\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sload => VCC,
	ena => \timers:0:channel|process_0~4_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:0:channel|timescale_r\(11));

-- Location: MLABCELL_X25_Y71_N42
\timers:0:channel|prescaler|cycle_count[3]~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|prescaler|cycle_count[3]~1_combout\ = ( \timers:0:channel|running_r~q\ & ( \timers:0:channel|clear_prescale~q\ ) ) # ( !\timers:0:channel|running_r~q\ & ( \timers:0:channel|clear_prescale~q\ ) ) # ( \timers:0:channel|running_r~q\ & ( 
-- !\timers:0:channel|clear_prescale~q\ ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111111111111111111111111111111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datae => \timers:0:channel|ALT_INV_running_r~q\,
	dataf => \timers:0:channel|ALT_INV_clear_prescale~q\,
	combout => \timers:0:channel|prescaler|cycle_count[3]~1_combout\);

-- Location: FF_X25_Y71_N58
\timers:0:channel|prescaler|cycle_count[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:0:channel|prescaler|cycle_count~4_combout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	ena => \timers:0:channel|prescaler|cycle_count[3]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:0:channel|prescaler|cycle_count\(0));

-- Location: MLABCELL_X25_Y71_N57
\timers:0:channel|prescaler|cycle_count~4\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|prescaler|cycle_count~4_combout\ = ( !\timers:0:channel|prescaler|LessThan0~0_combout\ & ( (!\timers:0:channel|clear_prescale~q\ & !\timers:0:channel|prescaler|cycle_count\(0)) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111000000000000111100000000000000000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:0:channel|ALT_INV_clear_prescale~q\,
	datad => \timers:0:channel|prescaler|ALT_INV_cycle_count\(0),
	dataf => \timers:0:channel|prescaler|ALT_INV_LessThan0~0_combout\,
	combout => \timers:0:channel|prescaler|cycle_count~4_combout\);

-- Location: FF_X25_Y71_N59
\timers:0:channel|prescaler|cycle_count[0]~DUPLICATE\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:0:channel|prescaler|cycle_count~4_combout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	ena => \timers:0:channel|prescaler|cycle_count[3]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:0:channel|prescaler|cycle_count[0]~DUPLICATE_q\);

-- Location: MLABCELL_X25_Y71_N51
\timers:0:channel|prescaler|cycle_count~3\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|prescaler|cycle_count~3_combout\ = (!\timers:0:channel|prescaler|LessThan0~0_combout\ & (!\timers:0:channel|clear_prescale~q\ & (!\timers:0:channel|prescaler|cycle_count[0]~DUPLICATE_q\ $ (!\timers:0:channel|prescaler|cycle_count\(1)))))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000100010000000000010001000000000001000100000000000100010000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:0:channel|prescaler|ALT_INV_LessThan0~0_combout\,
	datab => \timers:0:channel|ALT_INV_clear_prescale~q\,
	datac => \timers:0:channel|prescaler|ALT_INV_cycle_count[0]~DUPLICATE_q\,
	datad => \timers:0:channel|prescaler|ALT_INV_cycle_count\(1),
	combout => \timers:0:channel|prescaler|cycle_count~3_combout\);

-- Location: FF_X25_Y71_N53
\timers:0:channel|prescaler|cycle_count[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:0:channel|prescaler|cycle_count~3_combout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	ena => \timers:0:channel|prescaler|cycle_count[3]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:0:channel|prescaler|cycle_count\(1));

-- Location: MLABCELL_X25_Y71_N27
\timers:0:channel|prescaler|cycle_count~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|prescaler|cycle_count~0_combout\ = ( \timers:0:channel|prescaler|cycle_count\(1) & ( (\timers:0:channel|prescaler|cycle_count\(2) & (\timers:0:channel|prescaler|cycle_count[0]~DUPLICATE_q\ & (!\timers:0:channel|clear_prescale~q\ & 
-- !\timers:0:channel|prescaler|cycle_count\(3)))) ) ) # ( !\timers:0:channel|prescaler|cycle_count\(1) & ( (!\timers:0:channel|prescaler|cycle_count\(2) & (!\timers:0:channel|prescaler|cycle_count[0]~DUPLICATE_q\ & (!\timers:0:channel|clear_prescale~q\ & 
-- \timers:0:channel|prescaler|cycle_count\(3)))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000010000000000000001000000000010000000000000001000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:0:channel|prescaler|ALT_INV_cycle_count\(2),
	datab => \timers:0:channel|prescaler|ALT_INV_cycle_count[0]~DUPLICATE_q\,
	datac => \timers:0:channel|ALT_INV_clear_prescale~q\,
	datad => \timers:0:channel|prescaler|ALT_INV_cycle_count\(3),
	dataf => \timers:0:channel|prescaler|ALT_INV_cycle_count\(1),
	combout => \timers:0:channel|prescaler|cycle_count~0_combout\);

-- Location: FF_X25_Y71_N28
\timers:0:channel|prescaler|cycle_count[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:0:channel|prescaler|cycle_count~0_combout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	ena => \timers:0:channel|prescaler|cycle_count[3]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:0:channel|prescaler|cycle_count\(3));

-- Location: MLABCELL_X25_Y71_N54
\timers:0:channel|prescaler|cycle_count~2\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|prescaler|cycle_count~2_combout\ = ( !\timers:0:channel|prescaler|cycle_count\(3) & ( (!\timers:0:channel|clear_prescale~q\ & (!\timers:0:channel|prescaler|cycle_count\(2) $ (((!\timers:0:channel|prescaler|cycle_count\(0)) # 
-- (!\timers:0:channel|prescaler|cycle_count\(1)))))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000010011001000000001001100100000000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:0:channel|prescaler|ALT_INV_cycle_count\(0),
	datab => \timers:0:channel|ALT_INV_clear_prescale~q\,
	datac => \timers:0:channel|prescaler|ALT_INV_cycle_count\(1),
	datad => \timers:0:channel|prescaler|ALT_INV_cycle_count\(2),
	dataf => \timers:0:channel|prescaler|ALT_INV_cycle_count\(3),
	combout => \timers:0:channel|prescaler|cycle_count~2_combout\);

-- Location: FF_X25_Y71_N56
\timers:0:channel|prescaler|cycle_count[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:0:channel|prescaler|cycle_count~2_combout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	ena => \timers:0:channel|prescaler|cycle_count[3]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:0:channel|prescaler|cycle_count\(2));

-- Location: MLABCELL_X25_Y71_N24
\timers:0:channel|prescaler|LessThan0~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|prescaler|LessThan0~0_combout\ = ( \timers:0:channel|prescaler|cycle_count\(3) & ( ((\timers:0:channel|prescaler|cycle_count\(2)) # (\timers:0:channel|prescaler|cycle_count\(1))) # 
-- (\timers:0:channel|prescaler|cycle_count[0]~DUPLICATE_q\) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000111111111111110011111111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \timers:0:channel|prescaler|ALT_INV_cycle_count[0]~DUPLICATE_q\,
	datac => \timers:0:channel|prescaler|ALT_INV_cycle_count\(1),
	datad => \timers:0:channel|prescaler|ALT_INV_cycle_count\(2),
	dataf => \timers:0:channel|prescaler|ALT_INV_cycle_count\(3),
	combout => \timers:0:channel|prescaler|LessThan0~0_combout\);

-- Location: MLABCELL_X25_Y71_N9
\timers:0:channel|prescaler|ms_count[0]~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|prescaler|ms_count[0]~1_combout\ = ( \timers:0:channel|prescaler|LessThan0~0_combout\ & ( (\timers:0:channel|running_r~q\) # (\timers:0:channel|clear_prescale~q\) ) ) # ( !\timers:0:channel|prescaler|LessThan0~0_combout\ & ( 
-- \timers:0:channel|clear_prescale~q\ ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000111100001111000011110000111100001111111111110000111111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:0:channel|ALT_INV_clear_prescale~q\,
	datad => \timers:0:channel|ALT_INV_running_r~q\,
	dataf => \timers:0:channel|prescaler|ALT_INV_LessThan0~0_combout\,
	combout => \timers:0:channel|prescaler|ms_count[0]~1_combout\);

-- Location: FF_X22_Y70_N32
\timers:0:channel|prescaler|ms_count[10]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:0:channel|prescaler|Add1~21_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:0:channel|prescaler|ms_count[0]~0_combout\,
	ena => \timers:0:channel|prescaler|ms_count[0]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:0:channel|prescaler|ms_count\(10));

-- Location: LABCELL_X22_Y70_N0
\timers:0:channel|prescaler|Add1~49\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|prescaler|Add1~49_sumout\ = SUM(( \timers:0:channel|prescaler|ms_count\(0) ) + ( VCC ) + ( !VCC ))
-- \timers:0:channel|prescaler|Add1~50\ = CARRY(( \timers:0:channel|prescaler|ms_count\(0) ) + ( VCC ) + ( !VCC ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000000000000011111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datad => \timers:0:channel|prescaler|ALT_INV_ms_count\(0),
	cin => GND,
	sumout => \timers:0:channel|prescaler|Add1~49_sumout\,
	cout => \timers:0:channel|prescaler|Add1~50\);

-- Location: FF_X22_Y70_N2
\timers:0:channel|prescaler|ms_count[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:0:channel|prescaler|Add1~49_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:0:channel|prescaler|ms_count[0]~0_combout\,
	ena => \timers:0:channel|prescaler|ms_count[0]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:0:channel|prescaler|ms_count\(0));

-- Location: LABCELL_X22_Y70_N3
\timers:0:channel|prescaler|Add1~45\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|prescaler|Add1~45_sumout\ = SUM(( \timers:0:channel|prescaler|ms_count\(1) ) + ( GND ) + ( \timers:0:channel|prescaler|Add1~50\ ))
-- \timers:0:channel|prescaler|Add1~46\ = CARRY(( \timers:0:channel|prescaler|ms_count\(1) ) + ( GND ) + ( \timers:0:channel|prescaler|Add1~50\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000000011111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datad => \timers:0:channel|prescaler|ALT_INV_ms_count\(1),
	cin => \timers:0:channel|prescaler|Add1~50\,
	sumout => \timers:0:channel|prescaler|Add1~45_sumout\,
	cout => \timers:0:channel|prescaler|Add1~46\);

-- Location: FF_X22_Y70_N5
\timers:0:channel|prescaler|ms_count[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:0:channel|prescaler|Add1~45_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:0:channel|prescaler|ms_count[0]~0_combout\,
	ena => \timers:0:channel|prescaler|ms_count[0]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:0:channel|prescaler|ms_count\(1));

-- Location: LABCELL_X22_Y70_N6
\timers:0:channel|prescaler|Add1~41\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|prescaler|Add1~41_sumout\ = SUM(( \timers:0:channel|prescaler|ms_count\(2) ) + ( GND ) + ( \timers:0:channel|prescaler|Add1~46\ ))
-- \timers:0:channel|prescaler|Add1~42\ = CARRY(( \timers:0:channel|prescaler|ms_count\(2) ) + ( GND ) + ( \timers:0:channel|prescaler|Add1~46\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \timers:0:channel|prescaler|ALT_INV_ms_count\(2),
	cin => \timers:0:channel|prescaler|Add1~46\,
	sumout => \timers:0:channel|prescaler|Add1~41_sumout\,
	cout => \timers:0:channel|prescaler|Add1~42\);

-- Location: FF_X22_Y70_N8
\timers:0:channel|prescaler|ms_count[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:0:channel|prescaler|Add1~41_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:0:channel|prescaler|ms_count[0]~0_combout\,
	ena => \timers:0:channel|prescaler|ms_count[0]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:0:channel|prescaler|ms_count\(2));

-- Location: LABCELL_X22_Y70_N9
\timers:0:channel|prescaler|Add1~37\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|prescaler|Add1~37_sumout\ = SUM(( \timers:0:channel|prescaler|ms_count\(3) ) + ( GND ) + ( \timers:0:channel|prescaler|Add1~42\ ))
-- \timers:0:channel|prescaler|Add1~38\ = CARRY(( \timers:0:channel|prescaler|ms_count\(3) ) + ( GND ) + ( \timers:0:channel|prescaler|Add1~42\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:0:channel|prescaler|ALT_INV_ms_count\(3),
	cin => \timers:0:channel|prescaler|Add1~42\,
	sumout => \timers:0:channel|prescaler|Add1~37_sumout\,
	cout => \timers:0:channel|prescaler|Add1~38\);

-- Location: FF_X22_Y70_N11
\timers:0:channel|prescaler|ms_count[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:0:channel|prescaler|Add1~37_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:0:channel|prescaler|ms_count[0]~0_combout\,
	ena => \timers:0:channel|prescaler|ms_count[0]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:0:channel|prescaler|ms_count\(3));

-- Location: LABCELL_X22_Y70_N12
\timers:0:channel|prescaler|Add1~33\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|prescaler|Add1~33_sumout\ = SUM(( \timers:0:channel|prescaler|ms_count\(4) ) + ( GND ) + ( \timers:0:channel|prescaler|Add1~38\ ))
-- \timers:0:channel|prescaler|Add1~34\ = CARRY(( \timers:0:channel|prescaler|ms_count\(4) ) + ( GND ) + ( \timers:0:channel|prescaler|Add1~38\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \timers:0:channel|prescaler|ALT_INV_ms_count\(4),
	cin => \timers:0:channel|prescaler|Add1~38\,
	sumout => \timers:0:channel|prescaler|Add1~33_sumout\,
	cout => \timers:0:channel|prescaler|Add1~34\);

-- Location: FF_X22_Y70_N14
\timers:0:channel|prescaler|ms_count[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:0:channel|prescaler|Add1~33_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:0:channel|prescaler|ms_count[0]~0_combout\,
	ena => \timers:0:channel|prescaler|ms_count[0]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:0:channel|prescaler|ms_count\(4));

-- Location: LABCELL_X22_Y70_N15
\timers:0:channel|prescaler|Add1~61\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|prescaler|Add1~61_sumout\ = SUM(( \timers:0:channel|prescaler|ms_count\(5) ) + ( GND ) + ( \timers:0:channel|prescaler|Add1~34\ ))
-- \timers:0:channel|prescaler|Add1~62\ = CARRY(( \timers:0:channel|prescaler|ms_count\(5) ) + ( GND ) + ( \timers:0:channel|prescaler|Add1~34\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:0:channel|prescaler|ALT_INV_ms_count\(5),
	cin => \timers:0:channel|prescaler|Add1~34\,
	sumout => \timers:0:channel|prescaler|Add1~61_sumout\,
	cout => \timers:0:channel|prescaler|Add1~62\);

-- Location: FF_X22_Y70_N59
\timers:0:channel|prescaler|ms_count[5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \timers:0:channel|prescaler|Add1~61_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:0:channel|prescaler|ms_count[0]~0_combout\,
	sload => VCC,
	ena => \timers:0:channel|prescaler|ms_count[0]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:0:channel|prescaler|ms_count\(5));

-- Location: LABCELL_X22_Y70_N18
\timers:0:channel|prescaler|Add1~57\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|prescaler|Add1~57_sumout\ = SUM(( \timers:0:channel|prescaler|ms_count\(6) ) + ( GND ) + ( \timers:0:channel|prescaler|Add1~62\ ))
-- \timers:0:channel|prescaler|Add1~58\ = CARRY(( \timers:0:channel|prescaler|ms_count\(6) ) + ( GND ) + ( \timers:0:channel|prescaler|Add1~62\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000000011111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datad => \timers:0:channel|prescaler|ALT_INV_ms_count\(6),
	cin => \timers:0:channel|prescaler|Add1~62\,
	sumout => \timers:0:channel|prescaler|Add1~57_sumout\,
	cout => \timers:0:channel|prescaler|Add1~58\);

-- Location: FF_X22_Y70_N56
\timers:0:channel|prescaler|ms_count[6]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \timers:0:channel|prescaler|Add1~57_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:0:channel|prescaler|ms_count[0]~0_combout\,
	sload => VCC,
	ena => \timers:0:channel|prescaler|ms_count[0]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:0:channel|prescaler|ms_count\(6));

-- Location: LABCELL_X22_Y70_N21
\timers:0:channel|prescaler|Add1~53\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|prescaler|Add1~53_sumout\ = SUM(( \timers:0:channel|prescaler|ms_count\(7) ) + ( GND ) + ( \timers:0:channel|prescaler|Add1~58\ ))
-- \timers:0:channel|prescaler|Add1~54\ = CARRY(( \timers:0:channel|prescaler|ms_count\(7) ) + ( GND ) + ( \timers:0:channel|prescaler|Add1~58\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000000011111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datad => \timers:0:channel|prescaler|ALT_INV_ms_count\(7),
	cin => \timers:0:channel|prescaler|Add1~58\,
	sumout => \timers:0:channel|prescaler|Add1~53_sumout\,
	cout => \timers:0:channel|prescaler|Add1~54\);

-- Location: FF_X22_Y70_N49
\timers:0:channel|prescaler|ms_count[7]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \timers:0:channel|prescaler|Add1~53_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:0:channel|prescaler|ms_count[0]~0_combout\,
	sload => VCC,
	ena => \timers:0:channel|prescaler|ms_count[0]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:0:channel|prescaler|ms_count\(7));

-- Location: LABCELL_X22_Y70_N24
\timers:0:channel|prescaler|Add1~25\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|prescaler|Add1~25_sumout\ = SUM(( \timers:0:channel|prescaler|ms_count\(8) ) + ( GND ) + ( \timers:0:channel|prescaler|Add1~54\ ))
-- \timers:0:channel|prescaler|Add1~26\ = CARRY(( \timers:0:channel|prescaler|ms_count\(8) ) + ( GND ) + ( \timers:0:channel|prescaler|Add1~54\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:0:channel|prescaler|ALT_INV_ms_count\(8),
	cin => \timers:0:channel|prescaler|Add1~54\,
	sumout => \timers:0:channel|prescaler|Add1~25_sumout\,
	cout => \timers:0:channel|prescaler|Add1~26\);

-- Location: FF_X22_Y70_N53
\timers:0:channel|prescaler|ms_count[8]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \timers:0:channel|prescaler|Add1~25_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:0:channel|prescaler|ms_count[0]~0_combout\,
	sload => VCC,
	ena => \timers:0:channel|prescaler|ms_count[0]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:0:channel|prescaler|ms_count\(8));

-- Location: LABCELL_X22_Y70_N27
\timers:0:channel|prescaler|Add1~29\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|prescaler|Add1~29_sumout\ = SUM(( \timers:0:channel|prescaler|ms_count\(9) ) + ( GND ) + ( \timers:0:channel|prescaler|Add1~26\ ))
-- \timers:0:channel|prescaler|Add1~30\ = CARRY(( \timers:0:channel|prescaler|ms_count\(9) ) + ( GND ) + ( \timers:0:channel|prescaler|Add1~26\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:0:channel|prescaler|ALT_INV_ms_count\(9),
	cin => \timers:0:channel|prescaler|Add1~26\,
	sumout => \timers:0:channel|prescaler|Add1~29_sumout\,
	cout => \timers:0:channel|prescaler|Add1~30\);

-- Location: FF_X22_Y70_N17
\timers:0:channel|prescaler|ms_count[9]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \timers:0:channel|prescaler|Add1~29_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:0:channel|prescaler|ms_count[0]~0_combout\,
	sload => VCC,
	ena => \timers:0:channel|prescaler|ms_count[0]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:0:channel|prescaler|ms_count\(9));

-- Location: LABCELL_X22_Y70_N30
\timers:0:channel|prescaler|Add1~21\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|prescaler|Add1~21_sumout\ = SUM(( \timers:0:channel|prescaler|ms_count\(10) ) + ( GND ) + ( \timers:0:channel|prescaler|Add1~30\ ))
-- \timers:0:channel|prescaler|Add1~22\ = CARRY(( \timers:0:channel|prescaler|ms_count\(10) ) + ( GND ) + ( \timers:0:channel|prescaler|Add1~30\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \timers:0:channel|prescaler|ALT_INV_ms_count\(10),
	cin => \timers:0:channel|prescaler|Add1~30\,
	sumout => \timers:0:channel|prescaler|Add1~21_sumout\,
	cout => \timers:0:channel|prescaler|Add1~22\);

-- Location: FF_X23_Y70_N17
\timers:0:channel|timescale_r[10]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \IO_DATA[10]~input_o\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sload => VCC,
	ena => \timers:0:channel|process_0~4_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:0:channel|timescale_r\(10));

-- Location: FF_X22_Y70_N35
\timers:0:channel|prescaler|ms_count[11]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:0:channel|prescaler|Add1~5_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:0:channel|prescaler|ms_count[0]~0_combout\,
	ena => \timers:0:channel|prescaler|ms_count[0]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:0:channel|prescaler|ms_count\(11));

-- Location: LABCELL_X22_Y70_N33
\timers:0:channel|prescaler|Add1~5\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|prescaler|Add1~5_sumout\ = SUM(( \timers:0:channel|prescaler|ms_count\(11) ) + ( GND ) + ( \timers:0:channel|prescaler|Add1~22\ ))
-- \timers:0:channel|prescaler|Add1~6\ = CARRY(( \timers:0:channel|prescaler|ms_count\(11) ) + ( GND ) + ( \timers:0:channel|prescaler|Add1~22\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000101010101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:0:channel|prescaler|ALT_INV_ms_count\(11),
	cin => \timers:0:channel|prescaler|Add1~22\,
	sumout => \timers:0:channel|prescaler|Add1~5_sumout\,
	cout => \timers:0:channel|prescaler|Add1~6\);

-- Location: FF_X21_Y70_N26
\timers:0:channel|timescale_r[12]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \IO_DATA[12]~input_o\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sload => VCC,
	ena => \timers:0:channel|process_0~4_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:0:channel|timescale_r\(12));

-- Location: FF_X23_Y70_N29
\timers:0:channel|timescale_r[14]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \IO_DATA[14]~input_o\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sload => VCC,
	ena => \timers:0:channel|process_0~4_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:0:channel|timescale_r\(14));

-- Location: FF_X22_Y70_N41
\timers:0:channel|prescaler|ms_count[13]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:0:channel|prescaler|Add1~13_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:0:channel|prescaler|ms_count[0]~0_combout\,
	ena => \timers:0:channel|prescaler|ms_count[0]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:0:channel|prescaler|ms_count\(13));

-- Location: LABCELL_X22_Y70_N36
\timers:0:channel|prescaler|Add1~17\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|prescaler|Add1~17_sumout\ = SUM(( \timers:0:channel|prescaler|ms_count\(12) ) + ( GND ) + ( \timers:0:channel|prescaler|Add1~6\ ))
-- \timers:0:channel|prescaler|Add1~18\ = CARRY(( \timers:0:channel|prescaler|ms_count\(12) ) + ( GND ) + ( \timers:0:channel|prescaler|Add1~6\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000000011111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datad => \timers:0:channel|prescaler|ALT_INV_ms_count\(12),
	cin => \timers:0:channel|prescaler|Add1~6\,
	sumout => \timers:0:channel|prescaler|Add1~17_sumout\,
	cout => \timers:0:channel|prescaler|Add1~18\);

-- Location: FF_X22_Y70_N38
\timers:0:channel|prescaler|ms_count[12]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:0:channel|prescaler|Add1~17_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:0:channel|prescaler|ms_count[0]~0_combout\,
	ena => \timers:0:channel|prescaler|ms_count[0]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:0:channel|prescaler|ms_count\(12));

-- Location: LABCELL_X22_Y70_N39
\timers:0:channel|prescaler|Add1~13\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|prescaler|Add1~13_sumout\ = SUM(( \timers:0:channel|prescaler|ms_count\(13) ) + ( GND ) + ( \timers:0:channel|prescaler|Add1~18\ ))
-- \timers:0:channel|prescaler|Add1~14\ = CARRY(( \timers:0:channel|prescaler|ms_count\(13) ) + ( GND ) + ( \timers:0:channel|prescaler|Add1~18\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:0:channel|prescaler|ALT_INV_ms_count\(13),
	cin => \timers:0:channel|prescaler|Add1~18\,
	sumout => \timers:0:channel|prescaler|Add1~13_sumout\,
	cout => \timers:0:channel|prescaler|Add1~14\);

-- Location: FF_X21_Y70_N20
\timers:0:channel|timescale_r[13]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \IO_DATA[13]~input_o\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sload => VCC,
	ena => \timers:0:channel|process_0~4_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:0:channel|timescale_r\(13));

-- Location: FF_X22_Y70_N44
\timers:0:channel|prescaler|ms_count[14]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:0:channel|prescaler|Add1~9_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:0:channel|prescaler|ms_count[0]~0_combout\,
	ena => \timers:0:channel|prescaler|ms_count[0]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:0:channel|prescaler|ms_count\(14));

-- Location: LABCELL_X22_Y70_N42
\timers:0:channel|prescaler|Add1~9\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|prescaler|Add1~9_sumout\ = SUM(( \timers:0:channel|prescaler|ms_count\(14) ) + ( GND ) + ( \timers:0:channel|prescaler|Add1~14\ ))
-- \timers:0:channel|prescaler|Add1~10\ = CARRY(( \timers:0:channel|prescaler|ms_count\(14) ) + ( GND ) + ( \timers:0:channel|prescaler|Add1~14\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \timers:0:channel|prescaler|ALT_INV_ms_count\(14),
	cin => \timers:0:channel|prescaler|Add1~14\,
	sumout => \timers:0:channel|prescaler|Add1~9_sumout\,
	cout => \timers:0:channel|prescaler|Add1~10\);

-- Location: MLABCELL_X21_Y70_N18
\timers:0:channel|prescaler|LessThan1~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|prescaler|LessThan1~0_combout\ = ( \timers:0:channel|timescale_r\(13) & ( \timers:0:channel|prescaler|Add1~9_sumout\ & ( (\timers:0:channel|timescale_r\(14) & (\timers:0:channel|prescaler|Add1~13_sumout\ & 
-- (!\timers:0:channel|timescale_r\(12) $ (\timers:0:channel|prescaler|Add1~17_sumout\)))) ) ) ) # ( !\timers:0:channel|timescale_r\(13) & ( \timers:0:channel|prescaler|Add1~9_sumout\ & ( (\timers:0:channel|timescale_r\(14) & 
-- (!\timers:0:channel|prescaler|Add1~13_sumout\ & (!\timers:0:channel|timescale_r\(12) $ (\timers:0:channel|prescaler|Add1~17_sumout\)))) ) ) ) # ( \timers:0:channel|timescale_r\(13) & ( !\timers:0:channel|prescaler|Add1~9_sumout\ & ( 
-- (!\timers:0:channel|timescale_r\(14) & (\timers:0:channel|prescaler|Add1~13_sumout\ & (!\timers:0:channel|timescale_r\(12) $ (\timers:0:channel|prescaler|Add1~17_sumout\)))) ) ) ) # ( !\timers:0:channel|timescale_r\(13) & ( 
-- !\timers:0:channel|prescaler|Add1~9_sumout\ & ( (!\timers:0:channel|timescale_r\(14) & (!\timers:0:channel|prescaler|Add1~13_sumout\ & (!\timers:0:channel|timescale_r\(12) $ (\timers:0:channel|prescaler|Add1~17_sumout\)))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1000000001000000000010000000010000100000000100000000001000000001",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:0:channel|ALT_INV_timescale_r\(12),
	datab => \timers:0:channel|ALT_INV_timescale_r\(14),
	datac => \timers:0:channel|prescaler|ALT_INV_Add1~13_sumout\,
	datad => \timers:0:channel|prescaler|ALT_INV_Add1~17_sumout\,
	datae => \timers:0:channel|ALT_INV_timescale_r\(13),
	dataf => \timers:0:channel|prescaler|ALT_INV_Add1~9_sumout\,
	combout => \timers:0:channel|prescaler|LessThan1~0_combout\);

-- Location: MLABCELL_X21_Y70_N24
\timers:0:channel|prescaler|LessThan1~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|prescaler|LessThan1~1_combout\ = ( \timers:0:channel|timescale_r\(12) & ( \timers:0:channel|prescaler|Add1~9_sumout\ & ( (\timers:0:channel|timescale_r\(14) & ((!\timers:0:channel|timescale_r\(13) & 
-- (!\timers:0:channel|prescaler|Add1~13_sumout\ & !\timers:0:channel|prescaler|Add1~17_sumout\)) # (\timers:0:channel|timescale_r\(13) & ((!\timers:0:channel|prescaler|Add1~13_sumout\) # (!\timers:0:channel|prescaler|Add1~17_sumout\))))) ) ) ) # ( 
-- !\timers:0:channel|timescale_r\(12) & ( \timers:0:channel|prescaler|Add1~9_sumout\ & ( (\timers:0:channel|timescale_r\(13) & (\timers:0:channel|timescale_r\(14) & !\timers:0:channel|prescaler|Add1~13_sumout\)) ) ) ) # ( \timers:0:channel|timescale_r\(12) 
-- & ( !\timers:0:channel|prescaler|Add1~9_sumout\ & ( ((!\timers:0:channel|timescale_r\(13) & (!\timers:0:channel|prescaler|Add1~13_sumout\ & !\timers:0:channel|prescaler|Add1~17_sumout\)) # (\timers:0:channel|timescale_r\(13) & 
-- ((!\timers:0:channel|prescaler|Add1~13_sumout\) # (!\timers:0:channel|prescaler|Add1~17_sumout\)))) # (\timers:0:channel|timescale_r\(14)) ) ) ) # ( !\timers:0:channel|timescale_r\(12) & ( !\timers:0:channel|prescaler|Add1~9_sumout\ & ( 
-- ((\timers:0:channel|timescale_r\(13) & !\timers:0:channel|prescaler|Add1~13_sumout\)) # (\timers:0:channel|timescale_r\(14)) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0111001101110011111101110111001100010000000100000011000100010000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:0:channel|ALT_INV_timescale_r\(13),
	datab => \timers:0:channel|ALT_INV_timescale_r\(14),
	datac => \timers:0:channel|prescaler|ALT_INV_Add1~13_sumout\,
	datad => \timers:0:channel|prescaler|ALT_INV_Add1~17_sumout\,
	datae => \timers:0:channel|ALT_INV_timescale_r\(12),
	dataf => \timers:0:channel|prescaler|ALT_INV_Add1~9_sumout\,
	combout => \timers:0:channel|prescaler|LessThan1~1_combout\);

-- Location: MLABCELL_X21_Y70_N42
\timers:0:channel|prescaler|LessThan1~2\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|prescaler|LessThan1~2_combout\ = ( \timers:0:channel|prescaler|LessThan1~0_combout\ & ( !\timers:0:channel|prescaler|LessThan1~1_combout\ & ( (!\timers:0:channel|timescale_r\(11) & (((!\timers:0:channel|timescale_r\(10)) # 
-- (\timers:0:channel|prescaler|Add1~5_sumout\)) # (\timers:0:channel|prescaler|Add1~21_sumout\))) # (\timers:0:channel|timescale_r\(11) & (\timers:0:channel|prescaler|Add1~5_sumout\ & ((!\timers:0:channel|timescale_r\(10)) # 
-- (\timers:0:channel|prescaler|Add1~21_sumout\)))) ) ) ) # ( !\timers:0:channel|prescaler|LessThan1~0_combout\ & ( !\timers:0:channel|prescaler|LessThan1~1_combout\ ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111111111111111101000101111101100000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:0:channel|ALT_INV_timescale_r\(11),
	datab => \timers:0:channel|prescaler|ALT_INV_Add1~21_sumout\,
	datac => \timers:0:channel|ALT_INV_timescale_r\(10),
	datad => \timers:0:channel|prescaler|ALT_INV_Add1~5_sumout\,
	datae => \timers:0:channel|prescaler|ALT_INV_LessThan1~0_combout\,
	dataf => \timers:0:channel|prescaler|ALT_INV_LessThan1~1_combout\,
	combout => \timers:0:channel|prescaler|LessThan1~2_combout\);

-- Location: MLABCELL_X21_Y70_N12
\timers:0:channel|timescale_r[8]~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|timescale_r[8]~0_combout\ = ( !\IO_DATA[8]~input_o\ )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111111111111111111111111111111100000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataf => \ALT_INV_IO_DATA[8]~input_o\,
	combout => \timers:0:channel|timescale_r[8]~0_combout\);

-- Location: FF_X21_Y70_N14
\timers:0:channel|timescale_r[8]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:0:channel|timescale_r[8]~0_combout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	ena => \timers:0:channel|process_0~4_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:0:channel|timescale_r\(8));

-- Location: MLABCELL_X21_Y70_N6
\timers:0:channel|prescaler|LessThan1~14\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|prescaler|LessThan1~14_combout\ = ( !\timers:0:channel|prescaler|Add1~25_sumout\ & ( !\timers:0:channel|timescale_r\(8) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111000011110000111100001111000000000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:0:channel|ALT_INV_timescale_r\(8),
	dataf => \timers:0:channel|prescaler|ALT_INV_Add1~25_sumout\,
	combout => \timers:0:channel|prescaler|LessThan1~14_combout\);

-- Location: LABCELL_X23_Y70_N9
\timers:0:channel|timescale_r[9]~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|timescale_r[9]~1_combout\ = ( !\IO_DATA[9]~input_o\ )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111111111111111111111111111111100000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataf => \ALT_INV_IO_DATA[9]~input_o\,
	combout => \timers:0:channel|timescale_r[9]~1_combout\);

-- Location: FF_X23_Y70_N11
\timers:0:channel|timescale_r[9]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:0:channel|timescale_r[9]~1_combout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	ena => \timers:0:channel|process_0~4_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:0:channel|timescale_r\(9));

-- Location: LABCELL_X23_Y70_N12
\timers:0:channel|prescaler|LessThan1~4\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|prescaler|LessThan1~4_combout\ = !\timers:0:channel|prescaler|Add1~21_sumout\ $ (!\timers:0:channel|timescale_r\(10))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000111111110000000011111111000000001111111100000000111111110000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:0:channel|prescaler|ALT_INV_Add1~21_sumout\,
	datad => \timers:0:channel|ALT_INV_timescale_r\(10),
	combout => \timers:0:channel|prescaler|LessThan1~4_combout\);

-- Location: LABCELL_X23_Y70_N21
\timers:0:channel|prescaler|LessThan1~3\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|prescaler|LessThan1~3_combout\ = !\timers:0:channel|prescaler|Add1~5_sumout\ $ (!\timers:0:channel|timescale_r\(11))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000111111110000000011111111000000001111111100000000111111110000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:0:channel|prescaler|ALT_INV_Add1~5_sumout\,
	datad => \timers:0:channel|ALT_INV_timescale_r\(11),
	combout => \timers:0:channel|prescaler|LessThan1~3_combout\);

-- Location: LABCELL_X22_Y70_N57
\timers:0:channel|prescaler|LessThan1~15\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|prescaler|LessThan1~15_combout\ = ( !\timers:0:channel|prescaler|LessThan1~3_combout\ & ( \timers:0:channel|prescaler|LessThan1~0_combout\ & ( (!\timers:0:channel|prescaler|LessThan1~4_combout\ & 
-- ((!\timers:0:channel|prescaler|LessThan1~14_combout\ & (!\timers:0:channel|timescale_r\(9) & !\timers:0:channel|prescaler|Add1~29_sumout\)) # (\timers:0:channel|prescaler|LessThan1~14_combout\ & ((!\timers:0:channel|timescale_r\(9)) # 
-- (!\timers:0:channel|prescaler|Add1~29_sumout\))))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000011010000010000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:0:channel|prescaler|ALT_INV_LessThan1~14_combout\,
	datab => \timers:0:channel|ALT_INV_timescale_r\(9),
	datac => \timers:0:channel|prescaler|ALT_INV_LessThan1~4_combout\,
	datad => \timers:0:channel|prescaler|ALT_INV_Add1~29_sumout\,
	datae => \timers:0:channel|prescaler|ALT_INV_LessThan1~3_combout\,
	dataf => \timers:0:channel|prescaler|ALT_INV_LessThan1~0_combout\,
	combout => \timers:0:channel|prescaler|LessThan1~15_combout\);

-- Location: LABCELL_X23_Y70_N18
\timers:0:channel|prescaler|LessThan1~5\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|prescaler|LessThan1~5_combout\ = ( \timers:0:channel|prescaler|Add1~25_sumout\ & ( !\timers:0:channel|timescale_r\(8) ) ) # ( !\timers:0:channel|prescaler|Add1~25_sumout\ & ( \timers:0:channel|timescale_r\(8) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000111100001111000011110000111111110000111100001111000011110000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:0:channel|ALT_INV_timescale_r\(8),
	dataf => \timers:0:channel|prescaler|ALT_INV_Add1~25_sumout\,
	combout => \timers:0:channel|prescaler|LessThan1~5_combout\);

-- Location: LABCELL_X23_Y70_N39
\timers:0:channel|prescaler|LessThan1~6\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|prescaler|LessThan1~6_combout\ = ( \timers:0:channel|prescaler|Add1~29_sumout\ & ( !\timers:0:channel|timescale_r\(9) ) ) # ( !\timers:0:channel|prescaler|Add1~29_sumout\ & ( \timers:0:channel|timescale_r\(9) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000111100001111000011110000111111110000111100001111000011110000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:0:channel|ALT_INV_timescale_r\(9),
	dataf => \timers:0:channel|prescaler|ALT_INV_Add1~29_sumout\,
	combout => \timers:0:channel|prescaler|LessThan1~6_combout\);

-- Location: FF_X23_Y70_N5
\timers:0:channel|timescale_r[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \IO_DATA[2]~input_o\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sload => VCC,
	ena => \timers:0:channel|process_0~4_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:0:channel|timescale_r\(2));

-- Location: LABCELL_X19_Y70_N0
\timers:0:channel|timescale_r[0]~feeder\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|timescale_r[0]~feeder_combout\ = ( \IO_DATA[0]~input_o\ )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000011111111111111111111111111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataf => \ALT_INV_IO_DATA[0]~input_o\,
	combout => \timers:0:channel|timescale_r[0]~feeder_combout\);

-- Location: FF_X19_Y70_N1
\timers:0:channel|timescale_r[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:0:channel|timescale_r[0]~feeder_combout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	ena => \timers:0:channel|process_0~4_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:0:channel|timescale_r\(0));

-- Location: FF_X23_Y70_N2
\timers:0:channel|timescale_r[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \IO_DATA[1]~input_o\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sload => VCC,
	ena => \timers:0:channel|process_0~4_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:0:channel|timescale_r\(1));

-- Location: LABCELL_X23_Y70_N0
\timers:0:channel|prescaler|LessThan1~8\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|prescaler|LessThan1~8_combout\ = ( \timers:0:channel|timescale_r\(1) & ( \timers:0:channel|prescaler|Add1~41_sumout\ & ( (\timers:0:channel|timescale_r\(2) & ((!\timers:0:channel|prescaler|Add1~45_sumout\) # 
-- ((!\timers:0:channel|prescaler|Add1~49_sumout\ & \timers:0:channel|timescale_r\(0))))) ) ) ) # ( !\timers:0:channel|timescale_r\(1) & ( \timers:0:channel|prescaler|Add1~41_sumout\ & ( (\timers:0:channel|timescale_r\(2) & 
-- (!\timers:0:channel|prescaler|Add1~49_sumout\ & (\timers:0:channel|timescale_r\(0) & !\timers:0:channel|prescaler|Add1~45_sumout\))) ) ) ) # ( \timers:0:channel|timescale_r\(1) & ( !\timers:0:channel|prescaler|Add1~41_sumout\ & ( 
-- (!\timers:0:channel|timescale_r\(2) & ((!\timers:0:channel|prescaler|Add1~45_sumout\) # ((!\timers:0:channel|prescaler|Add1~49_sumout\ & \timers:0:channel|timescale_r\(0))))) ) ) ) # ( !\timers:0:channel|timescale_r\(1) & ( 
-- !\timers:0:channel|prescaler|Add1~41_sumout\ & ( (!\timers:0:channel|timescale_r\(2) & (!\timers:0:channel|prescaler|Add1~49_sumout\ & (\timers:0:channel|timescale_r\(0) & !\timers:0:channel|prescaler|Add1~45_sumout\))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000100000000000101010100000100000000100000000000101010100000100",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:0:channel|ALT_INV_timescale_r\(2),
	datab => \timers:0:channel|prescaler|ALT_INV_Add1~49_sumout\,
	datac => \timers:0:channel|ALT_INV_timescale_r\(0),
	datad => \timers:0:channel|prescaler|ALT_INV_Add1~45_sumout\,
	datae => \timers:0:channel|ALT_INV_timescale_r\(1),
	dataf => \timers:0:channel|prescaler|ALT_INV_Add1~41_sumout\,
	combout => \timers:0:channel|prescaler|LessThan1~8_combout\);

-- Location: FF_X23_Y70_N25
\timers:0:channel|timescale_r[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \IO_DATA[4]~input_o\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sload => VCC,
	ena => \timers:0:channel|process_0~4_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:0:channel|timescale_r\(4));

-- Location: MLABCELL_X21_Y70_N15
\timers:0:channel|timescale_r[3]~2\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|timescale_r[3]~2_combout\ = !\IO_DATA[3]~input_o\

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1010101010101010101010101010101010101010101010101010101010101010",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_IO_DATA[3]~input_o\,
	combout => \timers:0:channel|timescale_r[3]~2_combout\);

-- Location: FF_X21_Y70_N17
\timers:0:channel|timescale_r[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:0:channel|timescale_r[3]~2_combout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	ena => \timers:0:channel|process_0~4_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:0:channel|timescale_r\(3));

-- Location: LABCELL_X23_Y70_N45
\timers:0:channel|prescaler|LessThan1~7\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|prescaler|LessThan1~7_combout\ = ( \timers:0:channel|prescaler|Add1~37_sumout\ & ( (!\timers:0:channel|timescale_r\(3) & (!\timers:0:channel|timescale_r\(4) $ (\timers:0:channel|prescaler|Add1~33_sumout\))) ) ) # ( 
-- !\timers:0:channel|prescaler|Add1~37_sumout\ & ( (\timers:0:channel|timescale_r\(3) & (!\timers:0:channel|timescale_r\(4) $ (\timers:0:channel|prescaler|Add1~33_sumout\))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000101000000101000010100000010110100000010100001010000001010000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:0:channel|ALT_INV_timescale_r\(4),
	datac => \timers:0:channel|ALT_INV_timescale_r\(3),
	datad => \timers:0:channel|prescaler|ALT_INV_Add1~33_sumout\,
	dataf => \timers:0:channel|prescaler|ALT_INV_Add1~37_sumout\,
	combout => \timers:0:channel|prescaler|LessThan1~7_combout\);

-- Location: LABCELL_X23_Y70_N24
\timers:0:channel|prescaler|LessThan1~9\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|prescaler|LessThan1~9_combout\ = ( \timers:0:channel|timescale_r\(4) & ( \timers:0:channel|prescaler|Add1~41_sumout\ & ( (!\timers:0:channel|prescaler|Add1~33_sumout\) # ((!\timers:0:channel|timescale_r\(3) & 
-- !\timers:0:channel|prescaler|Add1~37_sumout\)) ) ) ) # ( !\timers:0:channel|timescale_r\(4) & ( \timers:0:channel|prescaler|Add1~41_sumout\ & ( (!\timers:0:channel|timescale_r\(3) & (!\timers:0:channel|prescaler|Add1~33_sumout\ & 
-- !\timers:0:channel|prescaler|Add1~37_sumout\)) ) ) ) # ( \timers:0:channel|timescale_r\(4) & ( !\timers:0:channel|prescaler|Add1~41_sumout\ & ( (!\timers:0:channel|prescaler|Add1~33_sumout\) # ((!\timers:0:channel|timescale_r\(2) & 
-- (!\timers:0:channel|timescale_r\(3) & !\timers:0:channel|prescaler|Add1~37_sumout\)) # (\timers:0:channel|timescale_r\(2) & ((!\timers:0:channel|timescale_r\(3)) # (!\timers:0:channel|prescaler|Add1~37_sumout\)))) ) ) ) # ( 
-- !\timers:0:channel|timescale_r\(4) & ( !\timers:0:channel|prescaler|Add1~41_sumout\ & ( (!\timers:0:channel|prescaler|Add1~33_sumout\ & ((!\timers:0:channel|timescale_r\(2) & (!\timers:0:channel|timescale_r\(3) & 
-- !\timers:0:channel|prescaler|Add1~37_sumout\)) # (\timers:0:channel|timescale_r\(2) & ((!\timers:0:channel|timescale_r\(3)) # (!\timers:0:channel|prescaler|Add1~37_sumout\))))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1101000001000000111111011111010011000000000000001111110011110000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:0:channel|ALT_INV_timescale_r\(2),
	datab => \timers:0:channel|ALT_INV_timescale_r\(3),
	datac => \timers:0:channel|prescaler|ALT_INV_Add1~33_sumout\,
	datad => \timers:0:channel|prescaler|ALT_INV_Add1~37_sumout\,
	datae => \timers:0:channel|ALT_INV_timescale_r\(4),
	dataf => \timers:0:channel|prescaler|ALT_INV_Add1~41_sumout\,
	combout => \timers:0:channel|prescaler|LessThan1~9_combout\);

-- Location: MLABCELL_X21_Y70_N39
\timers:0:channel|timescale_r[7]~3\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|timescale_r[7]~3_combout\ = ( !\IO_DATA[7]~input_o\ )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111111111111111111111111111111100000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataf => \ALT_INV_IO_DATA[7]~input_o\,
	combout => \timers:0:channel|timescale_r[7]~3_combout\);

-- Location: FF_X21_Y70_N41
\timers:0:channel|timescale_r[7]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:0:channel|timescale_r[7]~3_combout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	ena => \timers:0:channel|process_0~4_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:0:channel|timescale_r\(7));

-- Location: LABCELL_X23_Y70_N42
\timers:0:channel|timescale_r[6]~4\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|timescale_r[6]~4_combout\ = !\IO_DATA[6]~input_o\

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111000011110000111100001111000011110000111100001111000011110000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \ALT_INV_IO_DATA[6]~input_o\,
	combout => \timers:0:channel|timescale_r[6]~4_combout\);

-- Location: FF_X23_Y70_N44
\timers:0:channel|timescale_r[6]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:0:channel|timescale_r[6]~4_combout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	ena => \timers:0:channel|process_0~4_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:0:channel|timescale_r\(6));

-- Location: LABCELL_X23_Y70_N36
\timers:0:channel|timescale_r[5]~5\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|timescale_r[5]~5_combout\ = !\IO_DATA[5]~input_o\

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111000011110000111100001111000011110000111100001111000011110000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \ALT_INV_IO_DATA[5]~input_o\,
	combout => \timers:0:channel|timescale_r[5]~5_combout\);

-- Location: FF_X23_Y70_N38
\timers:0:channel|timescale_r[5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:0:channel|timescale_r[5]~5_combout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	ena => \timers:0:channel|process_0~4_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:0:channel|timescale_r\(5));

-- Location: LABCELL_X23_Y70_N54
\timers:0:channel|prescaler|LessThan1~10\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|prescaler|LessThan1~10_combout\ = ( \timers:0:channel|prescaler|Add1~53_sumout\ & ( \timers:0:channel|prescaler|Add1~57_sumout\ & ( (!\timers:0:channel|timescale_r\(7) & (!\timers:0:channel|timescale_r\(6) & 
-- (!\timers:0:channel|timescale_r\(5) $ (!\timers:0:channel|prescaler|Add1~61_sumout\)))) ) ) ) # ( !\timers:0:channel|prescaler|Add1~53_sumout\ & ( \timers:0:channel|prescaler|Add1~57_sumout\ & ( (\timers:0:channel|timescale_r\(7) & 
-- (!\timers:0:channel|timescale_r\(6) & (!\timers:0:channel|timescale_r\(5) $ (!\timers:0:channel|prescaler|Add1~61_sumout\)))) ) ) ) # ( \timers:0:channel|prescaler|Add1~53_sumout\ & ( !\timers:0:channel|prescaler|Add1~57_sumout\ & ( 
-- (!\timers:0:channel|timescale_r\(7) & (\timers:0:channel|timescale_r\(6) & (!\timers:0:channel|timescale_r\(5) $ (!\timers:0:channel|prescaler|Add1~61_sumout\)))) ) ) ) # ( !\timers:0:channel|prescaler|Add1~53_sumout\ & ( 
-- !\timers:0:channel|prescaler|Add1~57_sumout\ & ( (\timers:0:channel|timescale_r\(7) & (\timers:0:channel|timescale_r\(6) & (!\timers:0:channel|timescale_r\(5) $ (!\timers:0:channel|prescaler|Add1~61_sumout\)))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000100010000000000100010000000000100010000000000100010000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:0:channel|ALT_INV_timescale_r\(7),
	datab => \timers:0:channel|ALT_INV_timescale_r\(6),
	datac => \timers:0:channel|ALT_INV_timescale_r\(5),
	datad => \timers:0:channel|prescaler|ALT_INV_Add1~61_sumout\,
	datae => \timers:0:channel|prescaler|ALT_INV_Add1~53_sumout\,
	dataf => \timers:0:channel|prescaler|ALT_INV_Add1~57_sumout\,
	combout => \timers:0:channel|prescaler|LessThan1~10_combout\);

-- Location: LABCELL_X23_Y70_N48
\timers:0:channel|prescaler|LessThan1~11\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|prescaler|LessThan1~11_combout\ = ( \timers:0:channel|prescaler|Add1~53_sumout\ & ( \timers:0:channel|prescaler|Add1~57_sumout\ & ( (!\timers:0:channel|timescale_r\(7) & (!\timers:0:channel|timescale_r\(6) & 
-- (!\timers:0:channel|timescale_r\(5) & !\timers:0:channel|prescaler|Add1~61_sumout\))) ) ) ) # ( !\timers:0:channel|prescaler|Add1~53_sumout\ & ( \timers:0:channel|prescaler|Add1~57_sumout\ & ( (!\timers:0:channel|timescale_r\(7)) # 
-- ((!\timers:0:channel|timescale_r\(6) & (!\timers:0:channel|timescale_r\(5) & !\timers:0:channel|prescaler|Add1~61_sumout\))) ) ) ) # ( \timers:0:channel|prescaler|Add1~53_sumout\ & ( !\timers:0:channel|prescaler|Add1~57_sumout\ & ( 
-- (!\timers:0:channel|timescale_r\(7) & ((!\timers:0:channel|timescale_r\(6)) # ((!\timers:0:channel|timescale_r\(5) & !\timers:0:channel|prescaler|Add1~61_sumout\)))) ) ) ) # ( !\timers:0:channel|prescaler|Add1~53_sumout\ & ( 
-- !\timers:0:channel|prescaler|Add1~57_sumout\ & ( (!\timers:0:channel|timescale_r\(7)) # ((!\timers:0:channel|timescale_r\(6)) # ((!\timers:0:channel|timescale_r\(5) & !\timers:0:channel|prescaler|Add1~61_sumout\))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111111011101110101010001000100011101010101010101000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:0:channel|ALT_INV_timescale_r\(7),
	datab => \timers:0:channel|ALT_INV_timescale_r\(6),
	datac => \timers:0:channel|ALT_INV_timescale_r\(5),
	datad => \timers:0:channel|prescaler|ALT_INV_Add1~61_sumout\,
	datae => \timers:0:channel|prescaler|ALT_INV_Add1~53_sumout\,
	dataf => \timers:0:channel|prescaler|ALT_INV_Add1~57_sumout\,
	combout => \timers:0:channel|prescaler|LessThan1~11_combout\);

-- Location: LABCELL_X23_Y70_N6
\timers:0:channel|prescaler|LessThan1~12\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|prescaler|LessThan1~12_combout\ = ( !\timers:0:channel|prescaler|LessThan1~11_combout\ & ( (!\timers:0:channel|prescaler|LessThan1~10_combout\) # ((!\timers:0:channel|prescaler|LessThan1~9_combout\ & 
-- ((!\timers:0:channel|prescaler|LessThan1~8_combout\) # (!\timers:0:channel|prescaler|LessThan1~7_combout\)))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111111111100000111111111110000000000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:0:channel|prescaler|ALT_INV_LessThan1~8_combout\,
	datab => \timers:0:channel|prescaler|ALT_INV_LessThan1~7_combout\,
	datac => \timers:0:channel|prescaler|ALT_INV_LessThan1~9_combout\,
	datad => \timers:0:channel|prescaler|ALT_INV_LessThan1~10_combout\,
	dataf => \timers:0:channel|prescaler|ALT_INV_LessThan1~11_combout\,
	combout => \timers:0:channel|prescaler|LessThan1~12_combout\);

-- Location: LABCELL_X23_Y70_N30
\timers:0:channel|prescaler|LessThan1~13\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|prescaler|LessThan1~13_combout\ = ( \timers:0:channel|prescaler|LessThan1~0_combout\ & ( !\timers:0:channel|prescaler|LessThan1~12_combout\ & ( (\timers:0:channel|prescaler|LessThan1~5_combout\ & 
-- (!\timers:0:channel|prescaler|LessThan1~4_combout\ & (!\timers:0:channel|prescaler|LessThan1~3_combout\ & \timers:0:channel|prescaler|LessThan1~6_combout\))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000100000000000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:0:channel|prescaler|ALT_INV_LessThan1~5_combout\,
	datab => \timers:0:channel|prescaler|ALT_INV_LessThan1~4_combout\,
	datac => \timers:0:channel|prescaler|ALT_INV_LessThan1~3_combout\,
	datad => \timers:0:channel|prescaler|ALT_INV_LessThan1~6_combout\,
	datae => \timers:0:channel|prescaler|ALT_INV_LessThan1~0_combout\,
	dataf => \timers:0:channel|prescaler|ALT_INV_LessThan1~12_combout\,
	combout => \timers:0:channel|prescaler|LessThan1~13_combout\);

-- Location: LABCELL_X22_Y70_N48
\timers:0:channel|prescaler|ms_count[0]~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|prescaler|ms_count[0]~0_combout\ = ( \timers:0:channel|prescaler|LessThan1~15_combout\ & ( \timers:0:channel|prescaler|LessThan1~13_combout\ & ( ((\timers:0:channel|prescaler|Add1~1_sumout\ & !\timers:0:channel|timescale_r\(15))) # 
-- (\timers:0:channel|clear_prescale~q\) ) ) ) # ( !\timers:0:channel|prescaler|LessThan1~15_combout\ & ( \timers:0:channel|prescaler|LessThan1~13_combout\ & ( ((\timers:0:channel|prescaler|Add1~1_sumout\ & !\timers:0:channel|timescale_r\(15))) # 
-- (\timers:0:channel|clear_prescale~q\) ) ) ) # ( \timers:0:channel|prescaler|LessThan1~15_combout\ & ( !\timers:0:channel|prescaler|LessThan1~13_combout\ & ( ((\timers:0:channel|prescaler|Add1~1_sumout\ & !\timers:0:channel|timescale_r\(15))) # 
-- (\timers:0:channel|clear_prescale~q\) ) ) ) # ( !\timers:0:channel|prescaler|LessThan1~15_combout\ & ( !\timers:0:channel|prescaler|LessThan1~13_combout\ & ( ((!\timers:0:channel|prescaler|Add1~1_sumout\ & (!\timers:0:channel|timescale_r\(15) & 
-- \timers:0:channel|prescaler|LessThan1~2_combout\)) # (\timers:0:channel|prescaler|Add1~1_sumout\ & ((!\timers:0:channel|timescale_r\(15)) # (\timers:0:channel|prescaler|LessThan1~2_combout\)))) # (\timers:0:channel|clear_prescale~q\) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0111010111110111011101010111010101110101011101010111010101110101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:0:channel|ALT_INV_clear_prescale~q\,
	datab => \timers:0:channel|prescaler|ALT_INV_Add1~1_sumout\,
	datac => \timers:0:channel|ALT_INV_timescale_r\(15),
	datad => \timers:0:channel|prescaler|ALT_INV_LessThan1~2_combout\,
	datae => \timers:0:channel|prescaler|ALT_INV_LessThan1~15_combout\,
	dataf => \timers:0:channel|prescaler|ALT_INV_LessThan1~13_combout\,
	combout => \timers:0:channel|prescaler|ms_count[0]~0_combout\);

-- Location: FF_X22_Y70_N46
\timers:0:channel|prescaler|ms_count[15]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:0:channel|prescaler|Add1~1_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:0:channel|prescaler|ms_count[0]~0_combout\,
	ena => \timers:0:channel|prescaler|ms_count[0]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:0:channel|prescaler|ms_count\(15));

-- Location: LABCELL_X22_Y70_N45
\timers:0:channel|prescaler|Add1~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|prescaler|Add1~1_sumout\ = SUM(( \timers:0:channel|prescaler|ms_count\(15) ) + ( GND ) + ( \timers:0:channel|prescaler|Add1~10\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:0:channel|prescaler|ALT_INV_ms_count\(15),
	cin => \timers:0:channel|prescaler|Add1~10\,
	sumout => \timers:0:channel|prescaler|Add1~1_sumout\);

-- Location: MLABCELL_X25_Y71_N48
\timers:0:channel|prescaler|TICK~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|prescaler|TICK~0_combout\ = ( \timers:0:channel|prescaler|LessThan0~0_combout\ & ( (!\timers:0:channel|clear_prescale~q\ & \timers:0:channel|running_r~q\) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000001100000011000000110000001100",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \timers:0:channel|ALT_INV_clear_prescale~q\,
	datac => \timers:0:channel|ALT_INV_running_r~q\,
	dataf => \timers:0:channel|prescaler|ALT_INV_LessThan0~0_combout\,
	combout => \timers:0:channel|prescaler|TICK~0_combout\);

-- Location: LABCELL_X22_Y69_N12
\timers:0:channel|prescaler|TICK~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|prescaler|TICK~1_combout\ = ( \timers:0:channel|prescaler|LessThan1~2_combout\ & ( \timers:0:channel|prescaler|LessThan1~15_combout\ & ( (\timers:0:channel|prescaler|Add1~1_sumout\ & (!\timers:0:channel|timescale_r\(15) & 
-- \timers:0:channel|prescaler|TICK~0_combout\)) ) ) ) # ( !\timers:0:channel|prescaler|LessThan1~2_combout\ & ( \timers:0:channel|prescaler|LessThan1~15_combout\ & ( (\timers:0:channel|prescaler|Add1~1_sumout\ & (!\timers:0:channel|timescale_r\(15) & 
-- \timers:0:channel|prescaler|TICK~0_combout\)) ) ) ) # ( \timers:0:channel|prescaler|LessThan1~2_combout\ & ( !\timers:0:channel|prescaler|LessThan1~15_combout\ & ( (\timers:0:channel|prescaler|TICK~0_combout\ & 
-- ((!\timers:0:channel|prescaler|Add1~1_sumout\ & (!\timers:0:channel|timescale_r\(15) & !\timers:0:channel|prescaler|LessThan1~13_combout\)) # (\timers:0:channel|prescaler|Add1~1_sumout\ & ((!\timers:0:channel|timescale_r\(15)) # 
-- (!\timers:0:channel|prescaler|LessThan1~13_combout\))))) ) ) ) # ( !\timers:0:channel|prescaler|LessThan1~2_combout\ & ( !\timers:0:channel|prescaler|LessThan1~15_combout\ & ( (\timers:0:channel|prescaler|Add1~1_sumout\ & 
-- (!\timers:0:channel|timescale_r\(15) & \timers:0:channel|prescaler|TICK~0_combout\)) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000010000000100000011010000010000000100000001000000010000000100",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:0:channel|prescaler|ALT_INV_Add1~1_sumout\,
	datab => \timers:0:channel|ALT_INV_timescale_r\(15),
	datac => \timers:0:channel|prescaler|ALT_INV_TICK~0_combout\,
	datad => \timers:0:channel|prescaler|ALT_INV_LessThan1~13_combout\,
	datae => \timers:0:channel|prescaler|ALT_INV_LessThan1~2_combout\,
	dataf => \timers:0:channel|prescaler|ALT_INV_LessThan1~15_combout\,
	combout => \timers:0:channel|prescaler|TICK~1_combout\);

-- Location: FF_X22_Y69_N13
\timers:0:channel|prescaler|TICK\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:0:channel|prescaler|TICK~1_combout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:0:channel|prescaler|TICK~q\);

-- Location: LABCELL_X24_Y69_N39
\timers:0:channel|running_r~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|running_r~0_combout\ = ( \timers:0:channel|mode_r\(0) & ( (\timers:0:channel|running_r~q\ & (\timers:0:channel|mode_r\(1) & \timers:0:channel|prescaler|TICK~q\)) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000001010000000000000101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:0:channel|ALT_INV_running_r~q\,
	datac => \timers:0:channel|ALT_INV_mode_r\(1),
	datad => \timers:0:channel|prescaler|ALT_INV_TICK~q\,
	dataf => \timers:0:channel|ALT_INV_mode_r\(0),
	combout => \timers:0:channel|running_r~0_combout\);

-- Location: MLABCELL_X25_Y67_N3
\timers:0:channel|Add2~5\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|Add2~5_sumout\ = SUM(( \timers:0:channel|elapsed_r\(1) ) + ( GND ) + ( \timers:0:channel|Add2~2\ ))
-- \timers:0:channel|Add2~6\ = CARRY(( \timers:0:channel|elapsed_r\(1) ) + ( GND ) + ( \timers:0:channel|Add2~2\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000101010101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:0:channel|ALT_INV_elapsed_r\(1),
	cin => \timers:0:channel|Add2~2\,
	sumout => \timers:0:channel|Add2~5_sumout\,
	cout => \timers:0:channel|Add2~6\);

-- Location: FF_X22_Y67_N5
\timers:0:channel|duration_r[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \IO_DATA[1]~input_o\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sload => VCC,
	ena => \timers:0:channel|process_0~2_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:0:channel|duration_r\(1));

-- Location: FF_X22_Y67_N47
\timers:0:channel|duration_r[15]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \IO_DATA[15]~input_o\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sload => VCC,
	ena => \timers:0:channel|process_0~2_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:0:channel|duration_r\(15));

-- Location: FF_X22_Y67_N44
\timers:0:channel|duration_r[14]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \IO_DATA[14]~input_o\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sload => VCC,
	ena => \timers:0:channel|process_0~2_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:0:channel|duration_r\(14));

-- Location: FF_X22_Y67_N41
\timers:0:channel|duration_r[13]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \IO_DATA[13]~input_o\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sload => VCC,
	ena => \timers:0:channel|process_0~2_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:0:channel|duration_r\(13));

-- Location: FF_X22_Y67_N38
\timers:0:channel|duration_r[12]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \IO_DATA[12]~input_o\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sload => VCC,
	ena => \timers:0:channel|process_0~2_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:0:channel|duration_r\(12));

-- Location: FF_X22_Y67_N35
\timers:0:channel|duration_r[11]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \IO_DATA[11]~input_o\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sload => VCC,
	ena => \timers:0:channel|process_0~2_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:0:channel|duration_r\(11));

-- Location: FF_X22_Y67_N32
\timers:0:channel|duration_r[10]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \IO_DATA[10]~input_o\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sload => VCC,
	ena => \timers:0:channel|process_0~2_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:0:channel|duration_r\(10));

-- Location: FF_X22_Y67_N29
\timers:0:channel|duration_r[9]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \IO_DATA[9]~input_o\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sload => VCC,
	ena => \timers:0:channel|process_0~2_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:0:channel|duration_r\(9));

-- Location: FF_X22_Y67_N53
\timers:0:channel|duration_r[8]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \IO_DATA[8]~input_o\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sload => VCC,
	ena => \timers:0:channel|process_0~2_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:0:channel|duration_r\(8));

-- Location: FF_X22_Y67_N50
\timers:0:channel|duration_r[7]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \IO_DATA[7]~input_o\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sload => VCC,
	ena => \timers:0:channel|process_0~2_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:0:channel|duration_r\(7));

-- Location: FF_X22_Y67_N23
\timers:0:channel|duration_r[6]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \IO_DATA[6]~input_o\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sload => VCC,
	ena => \timers:0:channel|process_0~2_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:0:channel|duration_r\(6));

-- Location: FF_X22_Y67_N17
\timers:0:channel|duration_r[5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \IO_DATA[5]~input_o\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sload => VCC,
	ena => \timers:0:channel|process_0~2_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:0:channel|duration_r\(5));

-- Location: FF_X22_Y67_N26
\timers:0:channel|duration_r[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \IO_DATA[4]~input_o\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sload => VCC,
	ena => \timers:0:channel|process_0~2_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:0:channel|duration_r\(4));

-- Location: FF_X22_Y67_N11
\timers:0:channel|duration_r[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \IO_DATA[3]~input_o\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sload => VCC,
	ena => \timers:0:channel|process_0~2_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:0:channel|duration_r\(3));

-- Location: FF_X22_Y67_N8
\timers:0:channel|duration_r[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	asdata => \IO_DATA[2]~input_o\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sload => VCC,
	ena => \timers:0:channel|process_0~2_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:0:channel|duration_r\(2));

-- Location: LABCELL_X22_Y67_N0
\timers:0:channel|Add0~49\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|Add0~49_sumout\ = SUM(( !\timers:0:channel|duration_r\(0) ) + ( VCC ) + ( !VCC ))
-- \timers:0:channel|Add0~50\ = CARRY(( !\timers:0:channel|duration_r\(0) ) + ( VCC ) + ( !VCC ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000001111111100000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datad => \timers:0:channel|ALT_INV_duration_r\(0),
	cin => GND,
	sumout => \timers:0:channel|Add0~49_sumout\,
	cout => \timers:0:channel|Add0~50\);

-- Location: LABCELL_X22_Y67_N3
\timers:0:channel|Add0~45\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|Add0~45_sumout\ = SUM(( \timers:0:channel|duration_r\(1) ) + ( VCC ) + ( \timers:0:channel|Add0~50\ ))
-- \timers:0:channel|Add0~46\ = CARRY(( \timers:0:channel|duration_r\(1) ) + ( VCC ) + ( \timers:0:channel|Add0~50\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000000000000011111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datad => \timers:0:channel|ALT_INV_duration_r\(1),
	cin => \timers:0:channel|Add0~50\,
	sumout => \timers:0:channel|Add0~45_sumout\,
	cout => \timers:0:channel|Add0~46\);

-- Location: LABCELL_X22_Y67_N6
\timers:0:channel|Add0~41\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|Add0~41_sumout\ = SUM(( \timers:0:channel|duration_r\(2) ) + ( VCC ) + ( \timers:0:channel|Add0~46\ ))
-- \timers:0:channel|Add0~42\ = CARRY(( \timers:0:channel|duration_r\(2) ) + ( VCC ) + ( \timers:0:channel|Add0~46\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000000011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \timers:0:channel|ALT_INV_duration_r\(2),
	cin => \timers:0:channel|Add0~46\,
	sumout => \timers:0:channel|Add0~41_sumout\,
	cout => \timers:0:channel|Add0~42\);

-- Location: LABCELL_X22_Y67_N9
\timers:0:channel|Add0~37\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|Add0~37_sumout\ = SUM(( \timers:0:channel|duration_r\(3) ) + ( VCC ) + ( \timers:0:channel|Add0~42\ ))
-- \timers:0:channel|Add0~38\ = CARRY(( \timers:0:channel|duration_r\(3) ) + ( VCC ) + ( \timers:0:channel|Add0~42\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:0:channel|ALT_INV_duration_r\(3),
	cin => \timers:0:channel|Add0~42\,
	sumout => \timers:0:channel|Add0~37_sumout\,
	cout => \timers:0:channel|Add0~38\);

-- Location: LABCELL_X22_Y67_N12
\timers:0:channel|Add0~33\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|Add0~33_sumout\ = SUM(( \timers:0:channel|duration_r\(4) ) + ( VCC ) + ( \timers:0:channel|Add0~38\ ))
-- \timers:0:channel|Add0~34\ = CARRY(( \timers:0:channel|duration_r\(4) ) + ( VCC ) + ( \timers:0:channel|Add0~38\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:0:channel|ALT_INV_duration_r\(4),
	cin => \timers:0:channel|Add0~38\,
	sumout => \timers:0:channel|Add0~33_sumout\,
	cout => \timers:0:channel|Add0~34\);

-- Location: LABCELL_X22_Y67_N15
\timers:0:channel|Add0~61\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|Add0~61_sumout\ = SUM(( \timers:0:channel|duration_r\(5) ) + ( VCC ) + ( \timers:0:channel|Add0~34\ ))
-- \timers:0:channel|Add0~62\ = CARRY(( \timers:0:channel|duration_r\(5) ) + ( VCC ) + ( \timers:0:channel|Add0~34\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:0:channel|ALT_INV_duration_r\(5),
	cin => \timers:0:channel|Add0~34\,
	sumout => \timers:0:channel|Add0~61_sumout\,
	cout => \timers:0:channel|Add0~62\);

-- Location: LABCELL_X22_Y67_N18
\timers:0:channel|Add0~57\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|Add0~57_sumout\ = SUM(( \timers:0:channel|duration_r\(6) ) + ( VCC ) + ( \timers:0:channel|Add0~62\ ))
-- \timers:0:channel|Add0~58\ = CARRY(( \timers:0:channel|duration_r\(6) ) + ( VCC ) + ( \timers:0:channel|Add0~62\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000000000000011111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datad => \timers:0:channel|ALT_INV_duration_r\(6),
	cin => \timers:0:channel|Add0~62\,
	sumout => \timers:0:channel|Add0~57_sumout\,
	cout => \timers:0:channel|Add0~58\);

-- Location: LABCELL_X22_Y67_N21
\timers:0:channel|Add0~53\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|Add0~53_sumout\ = SUM(( \timers:0:channel|duration_r\(7) ) + ( VCC ) + ( \timers:0:channel|Add0~58\ ))
-- \timers:0:channel|Add0~54\ = CARRY(( \timers:0:channel|duration_r\(7) ) + ( VCC ) + ( \timers:0:channel|Add0~58\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000000101010101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:0:channel|ALT_INV_duration_r\(7),
	cin => \timers:0:channel|Add0~58\,
	sumout => \timers:0:channel|Add0~53_sumout\,
	cout => \timers:0:channel|Add0~54\);

-- Location: LABCELL_X22_Y67_N24
\timers:0:channel|Add0~29\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|Add0~29_sumout\ = SUM(( \timers:0:channel|duration_r\(8) ) + ( VCC ) + ( \timers:0:channel|Add0~54\ ))
-- \timers:0:channel|Add0~30\ = CARRY(( \timers:0:channel|duration_r\(8) ) + ( VCC ) + ( \timers:0:channel|Add0~54\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:0:channel|ALT_INV_duration_r\(8),
	cin => \timers:0:channel|Add0~54\,
	sumout => \timers:0:channel|Add0~29_sumout\,
	cout => \timers:0:channel|Add0~30\);

-- Location: LABCELL_X22_Y67_N27
\timers:0:channel|Add0~25\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|Add0~25_sumout\ = SUM(( \timers:0:channel|duration_r\(9) ) + ( VCC ) + ( \timers:0:channel|Add0~30\ ))
-- \timers:0:channel|Add0~26\ = CARRY(( \timers:0:channel|duration_r\(9) ) + ( VCC ) + ( \timers:0:channel|Add0~30\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000000000000011111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datad => \timers:0:channel|ALT_INV_duration_r\(9),
	cin => \timers:0:channel|Add0~30\,
	sumout => \timers:0:channel|Add0~25_sumout\,
	cout => \timers:0:channel|Add0~26\);

-- Location: LABCELL_X22_Y67_N30
\timers:0:channel|Add0~21\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|Add0~21_sumout\ = SUM(( \timers:0:channel|duration_r\(10) ) + ( VCC ) + ( \timers:0:channel|Add0~26\ ))
-- \timers:0:channel|Add0~22\ = CARRY(( \timers:0:channel|duration_r\(10) ) + ( VCC ) + ( \timers:0:channel|Add0~26\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000000011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \timers:0:channel|ALT_INV_duration_r\(10),
	cin => \timers:0:channel|Add0~26\,
	sumout => \timers:0:channel|Add0~21_sumout\,
	cout => \timers:0:channel|Add0~22\);

-- Location: LABCELL_X22_Y67_N33
\timers:0:channel|Add0~17\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|Add0~17_sumout\ = SUM(( \timers:0:channel|duration_r\(11) ) + ( VCC ) + ( \timers:0:channel|Add0~22\ ))
-- \timers:0:channel|Add0~18\ = CARRY(( \timers:0:channel|duration_r\(11) ) + ( VCC ) + ( \timers:0:channel|Add0~22\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000000101010101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:0:channel|ALT_INV_duration_r\(11),
	cin => \timers:0:channel|Add0~22\,
	sumout => \timers:0:channel|Add0~17_sumout\,
	cout => \timers:0:channel|Add0~18\);

-- Location: LABCELL_X22_Y67_N36
\timers:0:channel|Add0~13\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|Add0~13_sumout\ = SUM(( \timers:0:channel|duration_r\(12) ) + ( VCC ) + ( \timers:0:channel|Add0~18\ ))
-- \timers:0:channel|Add0~14\ = CARRY(( \timers:0:channel|duration_r\(12) ) + ( VCC ) + ( \timers:0:channel|Add0~18\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000000000000011111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datad => \timers:0:channel|ALT_INV_duration_r\(12),
	cin => \timers:0:channel|Add0~18\,
	sumout => \timers:0:channel|Add0~13_sumout\,
	cout => \timers:0:channel|Add0~14\);

-- Location: LABCELL_X22_Y67_N39
\timers:0:channel|Add0~9\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|Add0~9_sumout\ = SUM(( \timers:0:channel|duration_r\(13) ) + ( VCC ) + ( \timers:0:channel|Add0~14\ ))
-- \timers:0:channel|Add0~10\ = CARRY(( \timers:0:channel|duration_r\(13) ) + ( VCC ) + ( \timers:0:channel|Add0~14\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:0:channel|ALT_INV_duration_r\(13),
	cin => \timers:0:channel|Add0~14\,
	sumout => \timers:0:channel|Add0~9_sumout\,
	cout => \timers:0:channel|Add0~10\);

-- Location: LABCELL_X22_Y67_N42
\timers:0:channel|Add0~5\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|Add0~5_sumout\ = SUM(( \timers:0:channel|duration_r\(14) ) + ( VCC ) + ( \timers:0:channel|Add0~10\ ))
-- \timers:0:channel|Add0~6\ = CARRY(( \timers:0:channel|duration_r\(14) ) + ( VCC ) + ( \timers:0:channel|Add0~10\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000000011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \timers:0:channel|ALT_INV_duration_r\(14),
	cin => \timers:0:channel|Add0~10\,
	sumout => \timers:0:channel|Add0~5_sumout\,
	cout => \timers:0:channel|Add0~6\);

-- Location: LABCELL_X22_Y67_N45
\timers:0:channel|Add0~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|Add0~1_sumout\ = SUM(( \timers:0:channel|duration_r\(15) ) + ( VCC ) + ( \timers:0:channel|Add0~6\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:0:channel|ALT_INV_duration_r\(15),
	cin => \timers:0:channel|Add0~6\,
	sumout => \timers:0:channel|Add0~1_sumout\);

-- Location: LABCELL_X23_Y67_N45
\timers:0:channel|LessThan0~14\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|LessThan0~14_combout\ = ( \timers:0:channel|Add0~29_sumout\ & ( !\timers:0:channel|elapsed_r\(8) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000010101010101010101010101010101010",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:0:channel|ALT_INV_elapsed_r\(8),
	dataf => \timers:0:channel|ALT_INV_Add0~29_sumout\,
	combout => \timers:0:channel|LessThan0~14_combout\);

-- Location: LABCELL_X24_Y67_N45
\timers:0:channel|LessThan0~2\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|LessThan0~2_combout\ = ( \timers:0:channel|Add0~21_sumout\ & ( !\timers:0:channel|elapsed_r\(10) ) ) # ( !\timers:0:channel|Add0~21_sumout\ & ( \timers:0:channel|elapsed_r\(10) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000111100001111000011110000111111110000111100001111000011110000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:0:channel|ALT_INV_elapsed_r\(10),
	dataf => \timers:0:channel|ALT_INV_Add0~21_sumout\,
	combout => \timers:0:channel|LessThan0~2_combout\);

-- Location: LABCELL_X23_Y67_N21
\timers:0:channel|LessThan0~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|LessThan0~1_combout\ = ( \timers:0:channel|elapsed_r\(11) & ( !\timers:0:channel|Add0~17_sumout\ ) ) # ( !\timers:0:channel|elapsed_r\(11) & ( \timers:0:channel|Add0~17_sumout\ ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000011111111000000001111111111111111000000001111111100000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datad => \timers:0:channel|ALT_INV_Add0~17_sumout\,
	dataf => \timers:0:channel|ALT_INV_elapsed_r\(11),
	combout => \timers:0:channel|LessThan0~1_combout\);

-- Location: LABCELL_X23_Y67_N24
\timers:0:channel|LessThan0~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|LessThan0~0_combout\ = ( \timers:0:channel|Add0~5_sumout\ & ( \timers:0:channel|Add0~9_sumout\ & ( (\timers:0:channel|elapsed_r\(13) & (\timers:0:channel|elapsed_r\(14) & (!\timers:0:channel|Add0~13_sumout\ $ 
-- (\timers:0:channel|elapsed_r\(12))))) ) ) ) # ( !\timers:0:channel|Add0~5_sumout\ & ( \timers:0:channel|Add0~9_sumout\ & ( (\timers:0:channel|elapsed_r\(13) & (!\timers:0:channel|elapsed_r\(14) & (!\timers:0:channel|Add0~13_sumout\ $ 
-- (\timers:0:channel|elapsed_r\(12))))) ) ) ) # ( \timers:0:channel|Add0~5_sumout\ & ( !\timers:0:channel|Add0~9_sumout\ & ( (!\timers:0:channel|elapsed_r\(13) & (\timers:0:channel|elapsed_r\(14) & (!\timers:0:channel|Add0~13_sumout\ $ 
-- (\timers:0:channel|elapsed_r\(12))))) ) ) ) # ( !\timers:0:channel|Add0~5_sumout\ & ( !\timers:0:channel|Add0~9_sumout\ & ( (!\timers:0:channel|elapsed_r\(13) & (!\timers:0:channel|elapsed_r\(14) & (!\timers:0:channel|Add0~13_sumout\ $ 
-- (\timers:0:channel|elapsed_r\(12))))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1000000000001000001000000000001001000000000001000001000000000001",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:0:channel|ALT_INV_elapsed_r\(13),
	datab => \timers:0:channel|ALT_INV_elapsed_r\(14),
	datac => \timers:0:channel|ALT_INV_Add0~13_sumout\,
	datad => \timers:0:channel|ALT_INV_elapsed_r\(12),
	datae => \timers:0:channel|ALT_INV_Add0~5_sumout\,
	dataf => \timers:0:channel|ALT_INV_Add0~9_sumout\,
	combout => \timers:0:channel|LessThan0~0_combout\);

-- Location: LABCELL_X24_Y67_N24
\timers:0:channel|LessThan0~15\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|LessThan0~15_combout\ = ( !\timers:0:channel|LessThan0~1_combout\ & ( \timers:0:channel|LessThan0~0_combout\ & ( (!\timers:0:channel|LessThan0~2_combout\ & ((!\timers:0:channel|elapsed_r\(9) & ((\timers:0:channel|LessThan0~14_combout\) # 
-- (\timers:0:channel|Add0~25_sumout\))) # (\timers:0:channel|elapsed_r\(9) & (\timers:0:channel|Add0~25_sumout\ & \timers:0:channel|LessThan0~14_combout\)))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000101011000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:0:channel|ALT_INV_elapsed_r\(9),
	datab => \timers:0:channel|ALT_INV_Add0~25_sumout\,
	datac => \timers:0:channel|ALT_INV_LessThan0~14_combout\,
	datad => \timers:0:channel|ALT_INV_LessThan0~2_combout\,
	datae => \timers:0:channel|ALT_INV_LessThan0~1_combout\,
	dataf => \timers:0:channel|ALT_INV_LessThan0~0_combout\,
	combout => \timers:0:channel|LessThan0~15_combout\);

-- Location: LABCELL_X23_Y67_N39
\timers:0:channel|LessThan0~7\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|LessThan0~7_combout\ = ( \timers:0:channel|Add0~29_sumout\ & ( !\timers:0:channel|elapsed_r\(8) ) ) # ( !\timers:0:channel|Add0~29_sumout\ & ( \timers:0:channel|elapsed_r\(8) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000011111111000000001111111111111111000000001111111100000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datad => \timers:0:channel|ALT_INV_elapsed_r\(8),
	dataf => \timers:0:channel|ALT_INV_Add0~29_sumout\,
	combout => \timers:0:channel|LessThan0~7_combout\);

-- Location: LABCELL_X23_Y67_N30
\timers:0:channel|LessThan0~3\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|LessThan0~3_combout\ = ( !\timers:0:channel|elapsed_r\(9) & ( \timers:0:channel|Add0~25_sumout\ ) ) # ( \timers:0:channel|elapsed_r\(9) & ( !\timers:0:channel|Add0~25_sumout\ ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111111111111111111110000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datae => \timers:0:channel|ALT_INV_elapsed_r\(9),
	dataf => \timers:0:channel|ALT_INV_Add0~25_sumout\,
	combout => \timers:0:channel|LessThan0~3_combout\);

-- Location: LABCELL_X23_Y67_N12
\timers:0:channel|LessThan0~10\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|LessThan0~10_combout\ = ( \timers:0:channel|Add0~33_sumout\ & ( \timers:0:channel|Add0~37_sumout\ & ( (!\timers:0:channel|elapsed_r\(3)) # ((!\timers:0:channel|elapsed_r\(4)) # ((!\timers:0:channel|elapsed_r\(2) & 
-- \timers:0:channel|Add0~41_sumout\))) ) ) ) # ( !\timers:0:channel|Add0~33_sumout\ & ( \timers:0:channel|Add0~37_sumout\ & ( (!\timers:0:channel|elapsed_r\(4) & ((!\timers:0:channel|elapsed_r\(3)) # ((!\timers:0:channel|elapsed_r\(2) & 
-- \timers:0:channel|Add0~41_sumout\)))) ) ) ) # ( \timers:0:channel|Add0~33_sumout\ & ( !\timers:0:channel|Add0~37_sumout\ & ( (!\timers:0:channel|elapsed_r\(4)) # ((!\timers:0:channel|elapsed_r\(2) & (!\timers:0:channel|elapsed_r\(3) & 
-- \timers:0:channel|Add0~41_sumout\))) ) ) ) # ( !\timers:0:channel|Add0~33_sumout\ & ( !\timers:0:channel|Add0~37_sumout\ & ( (!\timers:0:channel|elapsed_r\(2) & (!\timers:0:channel|elapsed_r\(3) & (\timers:0:channel|Add0~41_sumout\ & 
-- !\timers:0:channel|elapsed_r\(4)))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000100000000000111111110000100011001110000000001111111111001110",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:0:channel|ALT_INV_elapsed_r\(2),
	datab => \timers:0:channel|ALT_INV_elapsed_r\(3),
	datac => \timers:0:channel|ALT_INV_Add0~41_sumout\,
	datad => \timers:0:channel|ALT_INV_elapsed_r\(4),
	datae => \timers:0:channel|ALT_INV_Add0~33_sumout\,
	dataf => \timers:0:channel|ALT_INV_Add0~37_sumout\,
	combout => \timers:0:channel|LessThan0~10_combout\);

-- Location: LABCELL_X23_Y67_N9
\timers:0:channel|LessThan0~8\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|LessThan0~8_combout\ = ( \timers:0:channel|Add0~33_sumout\ & ( \timers:0:channel|Add0~37_sumout\ & ( (\timers:0:channel|elapsed_r\(3) & \timers:0:channel|elapsed_r\(4)) ) ) ) # ( !\timers:0:channel|Add0~33_sumout\ & ( 
-- \timers:0:channel|Add0~37_sumout\ & ( (\timers:0:channel|elapsed_r\(3) & !\timers:0:channel|elapsed_r\(4)) ) ) ) # ( \timers:0:channel|Add0~33_sumout\ & ( !\timers:0:channel|Add0~37_sumout\ & ( (!\timers:0:channel|elapsed_r\(3) & 
-- \timers:0:channel|elapsed_r\(4)) ) ) ) # ( !\timers:0:channel|Add0~33_sumout\ & ( !\timers:0:channel|Add0~37_sumout\ & ( (!\timers:0:channel|elapsed_r\(3) & !\timers:0:channel|elapsed_r\(4)) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1100000011000000000011000000110000110000001100000000001100000011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \timers:0:channel|ALT_INV_elapsed_r\(3),
	datac => \timers:0:channel|ALT_INV_elapsed_r\(4),
	datae => \timers:0:channel|ALT_INV_Add0~33_sumout\,
	dataf => \timers:0:channel|ALT_INV_Add0~37_sumout\,
	combout => \timers:0:channel|LessThan0~8_combout\);

-- Location: LABCELL_X24_Y67_N18
\timers:0:channel|LessThan0~11\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|LessThan0~11_combout\ = ( \timers:0:channel|Add0~61_sumout\ & ( \timers:0:channel|Add0~53_sumout\ & ( (\timers:0:channel|elapsed_r\(5) & (\timers:0:channel|elapsed_r\(7) & (!\timers:0:channel|elapsed_r\(6) $ 
-- (\timers:0:channel|Add0~57_sumout\)))) ) ) ) # ( !\timers:0:channel|Add0~61_sumout\ & ( \timers:0:channel|Add0~53_sumout\ & ( (!\timers:0:channel|elapsed_r\(5) & (\timers:0:channel|elapsed_r\(7) & (!\timers:0:channel|elapsed_r\(6) $ 
-- (\timers:0:channel|Add0~57_sumout\)))) ) ) ) # ( \timers:0:channel|Add0~61_sumout\ & ( !\timers:0:channel|Add0~53_sumout\ & ( (\timers:0:channel|elapsed_r\(5) & (!\timers:0:channel|elapsed_r\(7) & (!\timers:0:channel|elapsed_r\(6) $ 
-- (\timers:0:channel|Add0~57_sumout\)))) ) ) ) # ( !\timers:0:channel|Add0~61_sumout\ & ( !\timers:0:channel|Add0~53_sumout\ & ( (!\timers:0:channel|elapsed_r\(5) & (!\timers:0:channel|elapsed_r\(7) & (!\timers:0:channel|elapsed_r\(6) $ 
-- (\timers:0:channel|Add0~57_sumout\)))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1000001000000000010000010000000000000000100000100000000001000001",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:0:channel|ALT_INV_elapsed_r\(5),
	datab => \timers:0:channel|ALT_INV_elapsed_r\(6),
	datac => \timers:0:channel|ALT_INV_Add0~57_sumout\,
	datad => \timers:0:channel|ALT_INV_elapsed_r\(7),
	datae => \timers:0:channel|ALT_INV_Add0~61_sumout\,
	dataf => \timers:0:channel|ALT_INV_Add0~53_sumout\,
	combout => \timers:0:channel|LessThan0~11_combout\);

-- Location: MLABCELL_X21_Y67_N42
\timers:0:channel|LessThan0~9\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|LessThan0~9_combout\ = ( \timers:0:channel|Add0~45_sumout\ & ( \timers:0:channel|Add0~41_sumout\ & ( (\timers:0:channel|elapsed_r\(2) & ((!\timers:0:channel|elapsed_r\(1)) # ((\timers:0:channel|Add0~49_sumout\ & 
-- !\timers:0:channel|elapsed_r\(0))))) ) ) ) # ( !\timers:0:channel|Add0~45_sumout\ & ( \timers:0:channel|Add0~41_sumout\ & ( (!\timers:0:channel|elapsed_r\(1) & (\timers:0:channel|Add0~49_sumout\ & (\timers:0:channel|elapsed_r\(2) & 
-- !\timers:0:channel|elapsed_r\(0)))) ) ) ) # ( \timers:0:channel|Add0~45_sumout\ & ( !\timers:0:channel|Add0~41_sumout\ & ( (!\timers:0:channel|elapsed_r\(2) & ((!\timers:0:channel|elapsed_r\(1)) # ((\timers:0:channel|Add0~49_sumout\ & 
-- !\timers:0:channel|elapsed_r\(0))))) ) ) ) # ( !\timers:0:channel|Add0~45_sumout\ & ( !\timers:0:channel|Add0~41_sumout\ & ( (!\timers:0:channel|elapsed_r\(1) & (\timers:0:channel|Add0~49_sumout\ & (!\timers:0:channel|elapsed_r\(2) & 
-- !\timers:0:channel|elapsed_r\(0)))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0010000000000000101100001010000000000010000000000000101100001010",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:0:channel|ALT_INV_elapsed_r\(1),
	datab => \timers:0:channel|ALT_INV_Add0~49_sumout\,
	datac => \timers:0:channel|ALT_INV_elapsed_r\(2),
	datad => \timers:0:channel|ALT_INV_elapsed_r\(0),
	datae => \timers:0:channel|ALT_INV_Add0~45_sumout\,
	dataf => \timers:0:channel|ALT_INV_Add0~41_sumout\,
	combout => \timers:0:channel|LessThan0~9_combout\);

-- Location: LABCELL_X24_Y67_N48
\timers:0:channel|LessThan0~12\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|LessThan0~12_combout\ = ( \timers:0:channel|Add0~53_sumout\ & ( \timers:0:channel|Add0~57_sumout\ & ( (!\timers:0:channel|elapsed_r\(6)) # ((!\timers:0:channel|elapsed_r\(7)) # ((!\timers:0:channel|elapsed_r\(5) & 
-- \timers:0:channel|Add0~61_sumout\))) ) ) ) # ( !\timers:0:channel|Add0~53_sumout\ & ( \timers:0:channel|Add0~57_sumout\ & ( (!\timers:0:channel|elapsed_r\(7) & ((!\timers:0:channel|elapsed_r\(6)) # ((!\timers:0:channel|elapsed_r\(5) & 
-- \timers:0:channel|Add0~61_sumout\)))) ) ) ) # ( \timers:0:channel|Add0~53_sumout\ & ( !\timers:0:channel|Add0~57_sumout\ & ( (!\timers:0:channel|elapsed_r\(7)) # ((!\timers:0:channel|elapsed_r\(5) & (!\timers:0:channel|elapsed_r\(6) & 
-- \timers:0:channel|Add0~61_sumout\))) ) ) ) # ( !\timers:0:channel|Add0~53_sumout\ & ( !\timers:0:channel|Add0~57_sumout\ & ( (!\timers:0:channel|elapsed_r\(5) & (!\timers:0:channel|elapsed_r\(6) & (\timers:0:channel|Add0~61_sumout\ & 
-- !\timers:0:channel|elapsed_r\(7)))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000100000000000111111110000100011001110000000001111111111001110",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:0:channel|ALT_INV_elapsed_r\(5),
	datab => \timers:0:channel|ALT_INV_elapsed_r\(6),
	datac => \timers:0:channel|ALT_INV_Add0~61_sumout\,
	datad => \timers:0:channel|ALT_INV_elapsed_r\(7),
	datae => \timers:0:channel|ALT_INV_Add0~53_sumout\,
	dataf => \timers:0:channel|ALT_INV_Add0~57_sumout\,
	combout => \timers:0:channel|LessThan0~12_combout\);

-- Location: LABCELL_X24_Y67_N42
\timers:0:channel|LessThan0~17\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|LessThan0~17_combout\ = ( !\timers:0:channel|LessThan0~12_combout\ & ( (!\timers:0:channel|LessThan0~11_combout\) # ((!\timers:0:channel|LessThan0~10_combout\ & ((!\timers:0:channel|LessThan0~8_combout\) # 
-- (!\timers:0:channel|LessThan0~9_combout\)))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111101011111000111110101111100000000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:0:channel|ALT_INV_LessThan0~10_combout\,
	datab => \timers:0:channel|ALT_INV_LessThan0~8_combout\,
	datac => \timers:0:channel|ALT_INV_LessThan0~11_combout\,
	datad => \timers:0:channel|ALT_INV_LessThan0~9_combout\,
	dataf => \timers:0:channel|ALT_INV_LessThan0~12_combout\,
	combout => \timers:0:channel|LessThan0~17_combout\);

-- Location: LABCELL_X24_Y67_N12
\timers:0:channel|LessThan0~18\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|LessThan0~18_combout\ = ( !\timers:0:channel|LessThan0~2_combout\ & ( !\timers:0:channel|LessThan0~17_combout\ & ( (!\timers:0:channel|LessThan0~1_combout\ & (!\timers:0:channel|LessThan0~7_combout\ & 
-- (!\timers:0:channel|LessThan0~3_combout\ & \timers:0:channel|LessThan0~0_combout\))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000010000000000000000000000000000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:0:channel|ALT_INV_LessThan0~1_combout\,
	datab => \timers:0:channel|ALT_INV_LessThan0~7_combout\,
	datac => \timers:0:channel|ALT_INV_LessThan0~3_combout\,
	datad => \timers:0:channel|ALT_INV_LessThan0~0_combout\,
	datae => \timers:0:channel|ALT_INV_LessThan0~2_combout\,
	dataf => \timers:0:channel|ALT_INV_LessThan0~17_combout\,
	combout => \timers:0:channel|LessThan0~18_combout\);

-- Location: LABCELL_X23_Y67_N54
\timers:0:channel|LessThan0~5\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|LessThan0~5_combout\ = ( \timers:0:channel|Add0~5_sumout\ & ( \timers:0:channel|Add0~13_sumout\ & ( (!\timers:0:channel|elapsed_r\(14)) # ((!\timers:0:channel|elapsed_r\(13) & ((!\timers:0:channel|elapsed_r\(12)) # 
-- (\timers:0:channel|Add0~9_sumout\))) # (\timers:0:channel|elapsed_r\(13) & (\timers:0:channel|Add0~9_sumout\ & !\timers:0:channel|elapsed_r\(12)))) ) ) ) # ( !\timers:0:channel|Add0~5_sumout\ & ( \timers:0:channel|Add0~13_sumout\ & ( 
-- (!\timers:0:channel|elapsed_r\(14) & ((!\timers:0:channel|elapsed_r\(13) & ((!\timers:0:channel|elapsed_r\(12)) # (\timers:0:channel|Add0~9_sumout\))) # (\timers:0:channel|elapsed_r\(13) & (\timers:0:channel|Add0~9_sumout\ & 
-- !\timers:0:channel|elapsed_r\(12))))) ) ) ) # ( \timers:0:channel|Add0~5_sumout\ & ( !\timers:0:channel|Add0~13_sumout\ & ( (!\timers:0:channel|elapsed_r\(14)) # ((!\timers:0:channel|elapsed_r\(13) & \timers:0:channel|Add0~9_sumout\)) ) ) ) # ( 
-- !\timers:0:channel|Add0~5_sumout\ & ( !\timers:0:channel|Add0~13_sumout\ & ( (!\timers:0:channel|elapsed_r\(13) & (!\timers:0:channel|elapsed_r\(14) & \timers:0:channel|Add0~9_sumout\)) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000100000001000110011101100111010001100000010001110111111001110",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:0:channel|ALT_INV_elapsed_r\(13),
	datab => \timers:0:channel|ALT_INV_elapsed_r\(14),
	datac => \timers:0:channel|ALT_INV_Add0~9_sumout\,
	datad => \timers:0:channel|ALT_INV_elapsed_r\(12),
	datae => \timers:0:channel|ALT_INV_Add0~5_sumout\,
	dataf => \timers:0:channel|ALT_INV_Add0~13_sumout\,
	combout => \timers:0:channel|LessThan0~5_combout\);

-- Location: LABCELL_X24_Y67_N6
\timers:0:channel|LessThan0~6\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|LessThan0~6_combout\ = ( \timers:0:channel|Add0~21_sumout\ & ( !\timers:0:channel|LessThan0~5_combout\ & ( (!\timers:0:channel|LessThan0~0_combout\) # ((!\timers:0:channel|Add0~17_sumout\ & ((\timers:0:channel|elapsed_r\(11)) # 
-- (\timers:0:channel|elapsed_r\(10)))) # (\timers:0:channel|Add0~17_sumout\ & (\timers:0:channel|elapsed_r\(10) & \timers:0:channel|elapsed_r\(11)))) ) ) ) # ( !\timers:0:channel|Add0~21_sumout\ & ( !\timers:0:channel|LessThan0~5_combout\ & ( 
-- (!\timers:0:channel|Add0~17_sumout\) # ((!\timers:0:channel|LessThan0~0_combout\) # (\timers:0:channel|elapsed_r\(11))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111111110101111111111110010101100000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:0:channel|ALT_INV_Add0~17_sumout\,
	datab => \timers:0:channel|ALT_INV_elapsed_r\(10),
	datac => \timers:0:channel|ALT_INV_elapsed_r\(11),
	datad => \timers:0:channel|ALT_INV_LessThan0~0_combout\,
	datae => \timers:0:channel|ALT_INV_Add0~21_sumout\,
	dataf => \timers:0:channel|ALT_INV_LessThan0~5_combout\,
	combout => \timers:0:channel|LessThan0~6_combout\);

-- Location: MLABCELL_X25_Y67_N54
\timers:0:channel|elapsed_r[2]~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|elapsed_r[2]~1_combout\ = ( \timers:0:channel|LessThan0~18_combout\ & ( \timers:0:channel|LessThan0~6_combout\ & ( (\timers:0:channel|mode_r\(1) & (\timers:0:channel|elapsed_r\(15) & !\timers:0:channel|Add0~1_sumout\)) ) ) ) # ( 
-- !\timers:0:channel|LessThan0~18_combout\ & ( \timers:0:channel|LessThan0~6_combout\ & ( (\timers:0:channel|mode_r\(1) & ((!\timers:0:channel|elapsed_r\(15) & (!\timers:0:channel|Add0~1_sumout\ & !\timers:0:channel|LessThan0~15_combout\)) # 
-- (\timers:0:channel|elapsed_r\(15) & ((!\timers:0:channel|Add0~1_sumout\) # (!\timers:0:channel|LessThan0~15_combout\))))) ) ) ) # ( \timers:0:channel|LessThan0~18_combout\ & ( !\timers:0:channel|LessThan0~6_combout\ & ( (\timers:0:channel|mode_r\(1) & 
-- (\timers:0:channel|elapsed_r\(15) & !\timers:0:channel|Add0~1_sumout\)) ) ) ) # ( !\timers:0:channel|LessThan0~18_combout\ & ( !\timers:0:channel|LessThan0~6_combout\ & ( (\timers:0:channel|mode_r\(1) & (\timers:0:channel|elapsed_r\(15) & 
-- !\timers:0:channel|Add0~1_sumout\)) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0001000000010000000100000001000001010001000100000001000000010000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:0:channel|ALT_INV_mode_r\(1),
	datab => \timers:0:channel|ALT_INV_elapsed_r\(15),
	datac => \timers:0:channel|ALT_INV_Add0~1_sumout\,
	datad => \timers:0:channel|ALT_INV_LessThan0~15_combout\,
	datae => \timers:0:channel|ALT_INV_LessThan0~18_combout\,
	dataf => \timers:0:channel|ALT_INV_LessThan0~6_combout\,
	combout => \timers:0:channel|elapsed_r[2]~1_combout\);

-- Location: LABCELL_X24_Y69_N30
\timers:0:channel|elapsed_r[2]~2\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|elapsed_r[2]~2_combout\ = ( \timers:0:channel|mode_r\(1) & ( \timers:0:channel|prescaler|TICK~q\ ) ) # ( !\timers:0:channel|mode_r\(1) & ( (!\timers:0:channel|mode_r\(0) & \timers:0:channel|prescaler|TICK~q\) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000011110000000000001111000000000000111111110000000011111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:0:channel|ALT_INV_mode_r\(0),
	datad => \timers:0:channel|prescaler|ALT_INV_TICK~q\,
	dataf => \timers:0:channel|ALT_INV_mode_r\(1),
	combout => \timers:0:channel|elapsed_r[2]~2_combout\);

-- Location: MLABCELL_X25_Y69_N48
\timers:0:channel|elapsed_r[2]~3\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|elapsed_r[2]~3_combout\ = ( \IO_DATA[1]~input_o\ & ( \timers:0:channel|running_r~q\ & ( \timers:0:channel|elapsed_r[2]~2_combout\ ) ) ) # ( !\IO_DATA[1]~input_o\ & ( \timers:0:channel|running_r~q\ & ( 
-- \timers:0:channel|elapsed_r[2]~2_combout\ ) ) ) # ( \IO_DATA[1]~input_o\ & ( !\timers:0:channel|running_r~q\ & ( (write_hit(0) & (\timers:0:channel|periods_r~1_combout\ & \IO_DATA[0]~input_o\)) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000001101010101010101010101010101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:0:channel|ALT_INV_elapsed_r[2]~2_combout\,
	datab => ALT_INV_write_hit(0),
	datac => \timers:0:channel|ALT_INV_periods_r~1_combout\,
	datad => \ALT_INV_IO_DATA[0]~input_o\,
	datae => \ALT_INV_IO_DATA[1]~input_o\,
	dataf => \timers:0:channel|ALT_INV_running_r~q\,
	combout => \timers:0:channel|elapsed_r[2]~3_combout\);

-- Location: FF_X25_Y67_N5
\timers:0:channel|elapsed_r[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:0:channel|Add2~5_sumout\,
	asdata => \timers:0:channel|duration_r\(1),
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:0:channel|elapsed_r[2]~0_combout\,
	sload => \timers:0:channel|elapsed_r[2]~1_combout\,
	ena => \timers:0:channel|elapsed_r[2]~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:0:channel|elapsed_r\(1));

-- Location: MLABCELL_X25_Y67_N6
\timers:0:channel|Add2~9\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|Add2~9_sumout\ = SUM(( \timers:0:channel|elapsed_r\(2) ) + ( GND ) + ( \timers:0:channel|Add2~6\ ))
-- \timers:0:channel|Add2~10\ = CARRY(( \timers:0:channel|elapsed_r\(2) ) + ( GND ) + ( \timers:0:channel|Add2~6\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \timers:0:channel|ALT_INV_elapsed_r\(2),
	cin => \timers:0:channel|Add2~6\,
	sumout => \timers:0:channel|Add2~9_sumout\,
	cout => \timers:0:channel|Add2~10\);

-- Location: FF_X25_Y67_N8
\timers:0:channel|elapsed_r[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:0:channel|Add2~9_sumout\,
	asdata => \timers:0:channel|duration_r\(2),
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:0:channel|elapsed_r[2]~0_combout\,
	sload => \timers:0:channel|elapsed_r[2]~1_combout\,
	ena => \timers:0:channel|elapsed_r[2]~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:0:channel|elapsed_r\(2));

-- Location: MLABCELL_X25_Y67_N9
\timers:0:channel|Add2~13\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|Add2~13_sumout\ = SUM(( \timers:0:channel|elapsed_r\(3) ) + ( GND ) + ( \timers:0:channel|Add2~10\ ))
-- \timers:0:channel|Add2~14\ = CARRY(( \timers:0:channel|elapsed_r\(3) ) + ( GND ) + ( \timers:0:channel|Add2~10\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:0:channel|ALT_INV_elapsed_r\(3),
	cin => \timers:0:channel|Add2~10\,
	sumout => \timers:0:channel|Add2~13_sumout\,
	cout => \timers:0:channel|Add2~14\);

-- Location: FF_X25_Y67_N11
\timers:0:channel|elapsed_r[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:0:channel|Add2~13_sumout\,
	asdata => \timers:0:channel|duration_r\(3),
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:0:channel|elapsed_r[2]~0_combout\,
	sload => \timers:0:channel|elapsed_r[2]~1_combout\,
	ena => \timers:0:channel|elapsed_r[2]~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:0:channel|elapsed_r\(3));

-- Location: MLABCELL_X25_Y67_N12
\timers:0:channel|Add2~17\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|Add2~17_sumout\ = SUM(( \timers:0:channel|elapsed_r\(4) ) + ( GND ) + ( \timers:0:channel|Add2~14\ ))
-- \timers:0:channel|Add2~18\ = CARRY(( \timers:0:channel|elapsed_r\(4) ) + ( GND ) + ( \timers:0:channel|Add2~14\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \timers:0:channel|ALT_INV_elapsed_r\(4),
	cin => \timers:0:channel|Add2~14\,
	sumout => \timers:0:channel|Add2~17_sumout\,
	cout => \timers:0:channel|Add2~18\);

-- Location: FF_X25_Y67_N14
\timers:0:channel|elapsed_r[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:0:channel|Add2~17_sumout\,
	asdata => \timers:0:channel|duration_r\(4),
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:0:channel|elapsed_r[2]~0_combout\,
	sload => \timers:0:channel|elapsed_r[2]~1_combout\,
	ena => \timers:0:channel|elapsed_r[2]~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:0:channel|elapsed_r\(4));

-- Location: MLABCELL_X25_Y67_N15
\timers:0:channel|Add2~21\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|Add2~21_sumout\ = SUM(( \timers:0:channel|elapsed_r\(5) ) + ( GND ) + ( \timers:0:channel|Add2~18\ ))
-- \timers:0:channel|Add2~22\ = CARRY(( \timers:0:channel|elapsed_r\(5) ) + ( GND ) + ( \timers:0:channel|Add2~18\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:0:channel|ALT_INV_elapsed_r\(5),
	cin => \timers:0:channel|Add2~18\,
	sumout => \timers:0:channel|Add2~21_sumout\,
	cout => \timers:0:channel|Add2~22\);

-- Location: FF_X25_Y67_N17
\timers:0:channel|elapsed_r[5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:0:channel|Add2~21_sumout\,
	asdata => \timers:0:channel|duration_r\(5),
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:0:channel|elapsed_r[2]~0_combout\,
	sload => \timers:0:channel|elapsed_r[2]~1_combout\,
	ena => \timers:0:channel|elapsed_r[2]~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:0:channel|elapsed_r\(5));

-- Location: MLABCELL_X25_Y67_N18
\timers:0:channel|Add2~25\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|Add2~25_sumout\ = SUM(( \timers:0:channel|elapsed_r\(6) ) + ( GND ) + ( \timers:0:channel|Add2~22\ ))
-- \timers:0:channel|Add2~26\ = CARRY(( \timers:0:channel|elapsed_r\(6) ) + ( GND ) + ( \timers:0:channel|Add2~22\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:0:channel|ALT_INV_elapsed_r\(6),
	cin => \timers:0:channel|Add2~22\,
	sumout => \timers:0:channel|Add2~25_sumout\,
	cout => \timers:0:channel|Add2~26\);

-- Location: FF_X25_Y67_N20
\timers:0:channel|elapsed_r[6]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:0:channel|Add2~25_sumout\,
	asdata => \timers:0:channel|duration_r\(6),
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:0:channel|elapsed_r[2]~0_combout\,
	sload => \timers:0:channel|elapsed_r[2]~1_combout\,
	ena => \timers:0:channel|elapsed_r[2]~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:0:channel|elapsed_r\(6));

-- Location: MLABCELL_X25_Y67_N21
\timers:0:channel|Add2~29\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|Add2~29_sumout\ = SUM(( \timers:0:channel|elapsed_r\(7) ) + ( GND ) + ( \timers:0:channel|Add2~26\ ))
-- \timers:0:channel|Add2~30\ = CARRY(( \timers:0:channel|elapsed_r\(7) ) + ( GND ) + ( \timers:0:channel|Add2~26\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000101010101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:0:channel|ALT_INV_elapsed_r\(7),
	cin => \timers:0:channel|Add2~26\,
	sumout => \timers:0:channel|Add2~29_sumout\,
	cout => \timers:0:channel|Add2~30\);

-- Location: FF_X25_Y67_N23
\timers:0:channel|elapsed_r[7]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:0:channel|Add2~29_sumout\,
	asdata => \timers:0:channel|duration_r\(7),
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:0:channel|elapsed_r[2]~0_combout\,
	sload => \timers:0:channel|elapsed_r[2]~1_combout\,
	ena => \timers:0:channel|elapsed_r[2]~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:0:channel|elapsed_r\(7));

-- Location: MLABCELL_X25_Y67_N24
\timers:0:channel|Add2~33\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|Add2~33_sumout\ = SUM(( \timers:0:channel|elapsed_r\(8) ) + ( GND ) + ( \timers:0:channel|Add2~30\ ))
-- \timers:0:channel|Add2~34\ = CARRY(( \timers:0:channel|elapsed_r\(8) ) + ( GND ) + ( \timers:0:channel|Add2~30\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:0:channel|ALT_INV_elapsed_r\(8),
	cin => \timers:0:channel|Add2~30\,
	sumout => \timers:0:channel|Add2~33_sumout\,
	cout => \timers:0:channel|Add2~34\);

-- Location: FF_X25_Y67_N26
\timers:0:channel|elapsed_r[8]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:0:channel|Add2~33_sumout\,
	asdata => \timers:0:channel|duration_r\(8),
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:0:channel|elapsed_r[2]~0_combout\,
	sload => \timers:0:channel|elapsed_r[2]~1_combout\,
	ena => \timers:0:channel|elapsed_r[2]~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:0:channel|elapsed_r\(8));

-- Location: MLABCELL_X25_Y67_N27
\timers:0:channel|Add2~37\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|Add2~37_sumout\ = SUM(( \timers:0:channel|elapsed_r\(9) ) + ( GND ) + ( \timers:0:channel|Add2~34\ ))
-- \timers:0:channel|Add2~38\ = CARRY(( \timers:0:channel|elapsed_r\(9) ) + ( GND ) + ( \timers:0:channel|Add2~34\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000101010101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:0:channel|ALT_INV_elapsed_r\(9),
	cin => \timers:0:channel|Add2~34\,
	sumout => \timers:0:channel|Add2~37_sumout\,
	cout => \timers:0:channel|Add2~38\);

-- Location: FF_X25_Y67_N29
\timers:0:channel|elapsed_r[9]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:0:channel|Add2~37_sumout\,
	asdata => \timers:0:channel|duration_r\(9),
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:0:channel|elapsed_r[2]~0_combout\,
	sload => \timers:0:channel|elapsed_r[2]~1_combout\,
	ena => \timers:0:channel|elapsed_r[2]~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:0:channel|elapsed_r\(9));

-- Location: MLABCELL_X25_Y67_N30
\timers:0:channel|Add2~41\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|Add2~41_sumout\ = SUM(( \timers:0:channel|elapsed_r\(10) ) + ( GND ) + ( \timers:0:channel|Add2~38\ ))
-- \timers:0:channel|Add2~42\ = CARRY(( \timers:0:channel|elapsed_r\(10) ) + ( GND ) + ( \timers:0:channel|Add2~38\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \timers:0:channel|ALT_INV_elapsed_r\(10),
	cin => \timers:0:channel|Add2~38\,
	sumout => \timers:0:channel|Add2~41_sumout\,
	cout => \timers:0:channel|Add2~42\);

-- Location: FF_X25_Y67_N32
\timers:0:channel|elapsed_r[10]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:0:channel|Add2~41_sumout\,
	asdata => \timers:0:channel|duration_r\(10),
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:0:channel|elapsed_r[2]~0_combout\,
	sload => \timers:0:channel|elapsed_r[2]~1_combout\,
	ena => \timers:0:channel|elapsed_r[2]~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:0:channel|elapsed_r\(10));

-- Location: MLABCELL_X25_Y67_N33
\timers:0:channel|Add2~45\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|Add2~45_sumout\ = SUM(( \timers:0:channel|elapsed_r\(11) ) + ( GND ) + ( \timers:0:channel|Add2~42\ ))
-- \timers:0:channel|Add2~46\ = CARRY(( \timers:0:channel|elapsed_r\(11) ) + ( GND ) + ( \timers:0:channel|Add2~42\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000101010101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:0:channel|ALT_INV_elapsed_r\(11),
	cin => \timers:0:channel|Add2~42\,
	sumout => \timers:0:channel|Add2~45_sumout\,
	cout => \timers:0:channel|Add2~46\);

-- Location: FF_X25_Y67_N35
\timers:0:channel|elapsed_r[11]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:0:channel|Add2~45_sumout\,
	asdata => \timers:0:channel|duration_r\(11),
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:0:channel|elapsed_r[2]~0_combout\,
	sload => \timers:0:channel|elapsed_r[2]~1_combout\,
	ena => \timers:0:channel|elapsed_r[2]~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:0:channel|elapsed_r\(11));

-- Location: MLABCELL_X25_Y67_N36
\timers:0:channel|Add2~49\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|Add2~49_sumout\ = SUM(( \timers:0:channel|elapsed_r\(12) ) + ( GND ) + ( \timers:0:channel|Add2~46\ ))
-- \timers:0:channel|Add2~50\ = CARRY(( \timers:0:channel|elapsed_r\(12) ) + ( GND ) + ( \timers:0:channel|Add2~46\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:0:channel|ALT_INV_elapsed_r\(12),
	cin => \timers:0:channel|Add2~46\,
	sumout => \timers:0:channel|Add2~49_sumout\,
	cout => \timers:0:channel|Add2~50\);

-- Location: FF_X25_Y67_N38
\timers:0:channel|elapsed_r[12]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:0:channel|Add2~49_sumout\,
	asdata => \timers:0:channel|duration_r\(12),
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:0:channel|elapsed_r[2]~0_combout\,
	sload => \timers:0:channel|elapsed_r[2]~1_combout\,
	ena => \timers:0:channel|elapsed_r[2]~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:0:channel|elapsed_r\(12));

-- Location: MLABCELL_X25_Y67_N39
\timers:0:channel|Add2~53\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|Add2~53_sumout\ = SUM(( \timers:0:channel|elapsed_r\(13) ) + ( GND ) + ( \timers:0:channel|Add2~50\ ))
-- \timers:0:channel|Add2~54\ = CARRY(( \timers:0:channel|elapsed_r\(13) ) + ( GND ) + ( \timers:0:channel|Add2~50\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:0:channel|ALT_INV_elapsed_r\(13),
	cin => \timers:0:channel|Add2~50\,
	sumout => \timers:0:channel|Add2~53_sumout\,
	cout => \timers:0:channel|Add2~54\);

-- Location: FF_X25_Y67_N41
\timers:0:channel|elapsed_r[13]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:0:channel|Add2~53_sumout\,
	asdata => \timers:0:channel|duration_r\(13),
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:0:channel|elapsed_r[2]~0_combout\,
	sload => \timers:0:channel|elapsed_r[2]~1_combout\,
	ena => \timers:0:channel|elapsed_r[2]~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:0:channel|elapsed_r\(13));

-- Location: MLABCELL_X25_Y67_N42
\timers:0:channel|Add2~57\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|Add2~57_sumout\ = SUM(( \timers:0:channel|elapsed_r\(14) ) + ( GND ) + ( \timers:0:channel|Add2~54\ ))
-- \timers:0:channel|Add2~58\ = CARRY(( \timers:0:channel|elapsed_r\(14) ) + ( GND ) + ( \timers:0:channel|Add2~54\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \timers:0:channel|ALT_INV_elapsed_r\(14),
	cin => \timers:0:channel|Add2~54\,
	sumout => \timers:0:channel|Add2~57_sumout\,
	cout => \timers:0:channel|Add2~58\);

-- Location: FF_X25_Y67_N44
\timers:0:channel|elapsed_r[14]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:0:channel|Add2~57_sumout\,
	asdata => \timers:0:channel|duration_r\(14),
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:0:channel|elapsed_r[2]~0_combout\,
	sload => \timers:0:channel|elapsed_r[2]~1_combout\,
	ena => \timers:0:channel|elapsed_r[2]~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:0:channel|elapsed_r\(14));

-- Location: MLABCELL_X25_Y67_N45
\timers:0:channel|Add2~61\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|Add2~61_sumout\ = SUM(( \timers:0:channel|elapsed_r\(15) ) + ( GND ) + ( \timers:0:channel|Add2~58\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:0:channel|ALT_INV_elapsed_r\(15),
	cin => \timers:0:channel|Add2~58\,
	sumout => \timers:0:channel|Add2~61_sumout\);

-- Location: FF_X25_Y67_N47
\timers:0:channel|elapsed_r[15]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:0:channel|Add2~61_sumout\,
	asdata => \timers:0:channel|duration_r\(15),
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:0:channel|elapsed_r[2]~0_combout\,
	sload => \timers:0:channel|elapsed_r[2]~1_combout\,
	ena => \timers:0:channel|elapsed_r[2]~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:0:channel|elapsed_r\(15));

-- Location: LABCELL_X24_Y67_N36
\timers:0:channel|LessThan0~13\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|LessThan0~13_combout\ = ( \timers:0:channel|LessThan0~10_combout\ & ( \timers:0:channel|LessThan0~12_combout\ & ( !\timers:0:channel|LessThan0~7_combout\ ) ) ) # ( !\timers:0:channel|LessThan0~10_combout\ & ( 
-- \timers:0:channel|LessThan0~12_combout\ & ( !\timers:0:channel|LessThan0~7_combout\ ) ) ) # ( \timers:0:channel|LessThan0~10_combout\ & ( !\timers:0:channel|LessThan0~12_combout\ & ( (!\timers:0:channel|LessThan0~7_combout\ & 
-- \timers:0:channel|LessThan0~11_combout\) ) ) ) # ( !\timers:0:channel|LessThan0~10_combout\ & ( !\timers:0:channel|LessThan0~12_combout\ & ( (!\timers:0:channel|LessThan0~7_combout\ & (\timers:0:channel|LessThan0~8_combout\ & 
-- (\timers:0:channel|LessThan0~11_combout\ & \timers:0:channel|LessThan0~9_combout\))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000010000010100000101010101010101010101010101010101010",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:0:channel|ALT_INV_LessThan0~7_combout\,
	datab => \timers:0:channel|ALT_INV_LessThan0~8_combout\,
	datac => \timers:0:channel|ALT_INV_LessThan0~11_combout\,
	datad => \timers:0:channel|ALT_INV_LessThan0~9_combout\,
	datae => \timers:0:channel|ALT_INV_LessThan0~10_combout\,
	dataf => \timers:0:channel|ALT_INV_LessThan0~12_combout\,
	combout => \timers:0:channel|LessThan0~13_combout\);

-- Location: LABCELL_X24_Y67_N54
\timers:0:channel|LessThan0~4\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|LessThan0~4_combout\ = ( \timers:0:channel|LessThan0~0_combout\ & ( (!\timers:0:channel|LessThan0~2_combout\ & (!\timers:0:channel|LessThan0~3_combout\ & !\timers:0:channel|LessThan0~1_combout\)) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000011000000000000001100000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \timers:0:channel|ALT_INV_LessThan0~2_combout\,
	datac => \timers:0:channel|ALT_INV_LessThan0~3_combout\,
	datad => \timers:0:channel|ALT_INV_LessThan0~1_combout\,
	dataf => \timers:0:channel|ALT_INV_LessThan0~0_combout\,
	combout => \timers:0:channel|LessThan0~4_combout\);

-- Location: LABCELL_X24_Y67_N0
\timers:0:channel|LessThan0~16\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|LessThan0~16_combout\ = ( \timers:0:channel|LessThan0~4_combout\ & ( \timers:0:channel|LessThan0~15_combout\ & ( (\timers:0:channel|elapsed_r\(15) & !\timers:0:channel|Add0~1_sumout\) ) ) ) # ( !\timers:0:channel|LessThan0~4_combout\ & ( 
-- \timers:0:channel|LessThan0~15_combout\ & ( (\timers:0:channel|elapsed_r\(15) & !\timers:0:channel|Add0~1_sumout\) ) ) ) # ( \timers:0:channel|LessThan0~4_combout\ & ( !\timers:0:channel|LessThan0~15_combout\ & ( (!\timers:0:channel|elapsed_r\(15) & 
-- (!\timers:0:channel|Add0~1_sumout\ & (!\timers:0:channel|LessThan0~13_combout\ & \timers:0:channel|LessThan0~6_combout\))) # (\timers:0:channel|elapsed_r\(15) & ((!\timers:0:channel|Add0~1_sumout\) # ((!\timers:0:channel|LessThan0~13_combout\ & 
-- \timers:0:channel|LessThan0~6_combout\)))) ) ) ) # ( !\timers:0:channel|LessThan0~4_combout\ & ( !\timers:0:channel|LessThan0~15_combout\ & ( (!\timers:0:channel|elapsed_r\(15) & (!\timers:0:channel|Add0~1_sumout\ & 
-- \timers:0:channel|LessThan0~6_combout\)) # (\timers:0:channel|elapsed_r\(15) & ((!\timers:0:channel|Add0~1_sumout\) # (\timers:0:channel|LessThan0~6_combout\))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0100010011011101010001001101010001000100010001000100010001000100",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:0:channel|ALT_INV_elapsed_r\(15),
	datab => \timers:0:channel|ALT_INV_Add0~1_sumout\,
	datac => \timers:0:channel|ALT_INV_LessThan0~13_combout\,
	datad => \timers:0:channel|ALT_INV_LessThan0~6_combout\,
	datae => \timers:0:channel|ALT_INV_LessThan0~4_combout\,
	dataf => \timers:0:channel|ALT_INV_LessThan0~15_combout\,
	combout => \timers:0:channel|LessThan0~16_combout\);

-- Location: LABCELL_X24_Y69_N0
\timers:0:channel|Mux33~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|Mux33~1_combout\ = ( \timers:0:channel|running_r~q\ & ( \timers:0:channel|LessThan0~16_combout\ & ( (!write_hit(0) & (((!\timers:0:channel|running_r~0_combout\)))) # (write_hit(0) & ((!\timers:0:channel|Mux33~0_combout\ & 
-- ((!\timers:0:channel|running_r~0_combout\))) # (\timers:0:channel|Mux33~0_combout\ & (!\IO_DATA[1]~input_o\)))) ) ) ) # ( !\timers:0:channel|running_r~q\ & ( \timers:0:channel|LessThan0~16_combout\ & ( (write_hit(0) & (!\IO_DATA[1]~input_o\ & 
-- \timers:0:channel|Mux33~0_combout\)) ) ) ) # ( \timers:0:channel|running_r~q\ & ( !\timers:0:channel|LessThan0~16_combout\ & ( (!write_hit(0)) # ((!\IO_DATA[1]~input_o\) # (!\timers:0:channel|Mux33~0_combout\)) ) ) ) # ( !\timers:0:channel|running_r~q\ & 
-- ( !\timers:0:channel|LessThan0~16_combout\ & ( (!write_hit(0) & (((\timers:0:channel|running_r~0_combout\)))) # (write_hit(0) & ((!\timers:0:channel|Mux33~0_combout\ & ((\timers:0:channel|running_r~0_combout\))) # (\timers:0:channel|Mux33~0_combout\ & 
-- (!\IO_DATA[1]~input_o\)))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000010011111110111111101111111000000100000001001111111000000100",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => ALT_INV_write_hit(0),
	datab => \ALT_INV_IO_DATA[1]~input_o\,
	datac => \timers:0:channel|ALT_INV_Mux33~0_combout\,
	datad => \timers:0:channel|ALT_INV_running_r~0_combout\,
	datae => \timers:0:channel|ALT_INV_running_r~q\,
	dataf => \timers:0:channel|ALT_INV_LessThan0~16_combout\,
	combout => \timers:0:channel|Mux33~1_combout\);

-- Location: FF_X24_Y69_N2
\timers:0:channel|running_r\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:0:channel|Mux33~1_combout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:0:channel|running_r~q\);

-- Location: MLABCELL_X25_Y67_N48
\timers:0:channel|elapsed_r[2]~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|elapsed_r[2]~0_combout\ = ( write_hit(0) & ( \timers:0:channel|LessThan0~16_combout\ & ( (!\timers:0:channel|mode_r\(1) & (\timers:0:channel|periods_r~0_combout\ & ((!\timers:0:channel|running_r~q\)))) # (\timers:0:channel|mode_r\(1) & 
-- ((!\timers:0:channel|mode_r\(0)) # ((\timers:0:channel|periods_r~0_combout\ & !\timers:0:channel|running_r~q\)))) ) ) ) # ( !write_hit(0) & ( \timers:0:channel|LessThan0~16_combout\ & ( (\timers:0:channel|mode_r\(1) & !\timers:0:channel|mode_r\(0)) ) ) ) 
-- # ( write_hit(0) & ( !\timers:0:channel|LessThan0~16_combout\ & ( (\timers:0:channel|periods_r~0_combout\ & !\timers:0:channel|running_r~q\) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000001100110000000001010000010100000111001101010000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:0:channel|ALT_INV_mode_r\(1),
	datab => \timers:0:channel|ALT_INV_periods_r~0_combout\,
	datac => \timers:0:channel|ALT_INV_mode_r\(0),
	datad => \timers:0:channel|ALT_INV_running_r~q\,
	datae => ALT_INV_write_hit(0),
	dataf => \timers:0:channel|ALT_INV_LessThan0~16_combout\,
	combout => \timers:0:channel|elapsed_r[2]~0_combout\);

-- Location: FF_X25_Y67_N2
\timers:0:channel|elapsed_r[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:0:channel|Add2~1_sumout\,
	asdata => \timers:0:channel|duration_r[0]~_wirecell_combout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:0:channel|elapsed_r[2]~0_combout\,
	sload => \timers:0:channel|elapsed_r[2]~1_combout\,
	ena => \timers:0:channel|elapsed_r[2]~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:0:channel|elapsed_r\(0));

-- Location: MLABCELL_X21_Y67_N24
\read_value[0]~2\ : cyclonev_lcell_comb
-- Equation(s):
-- \read_value[0]~2_combout\ = ( \IO_ADDR[3]~input_o\ & ( \timers:0:channel|elapsed_r\(0) & ( (!\IO_ADDR[2]~input_o\ & ((\timers:2:channel|elapsed_r\(0)))) # (\IO_ADDR[2]~input_o\ & (\timers:3:channel|elapsed_r\(0))) ) ) ) # ( !\IO_ADDR[3]~input_o\ & ( 
-- \timers:0:channel|elapsed_r\(0) & ( (!\IO_ADDR[2]~input_o\) # (\timers:1:channel|elapsed_r\(0)) ) ) ) # ( \IO_ADDR[3]~input_o\ & ( !\timers:0:channel|elapsed_r\(0) & ( (!\IO_ADDR[2]~input_o\ & ((\timers:2:channel|elapsed_r\(0)))) # (\IO_ADDR[2]~input_o\ & 
-- (\timers:3:channel|elapsed_r\(0))) ) ) ) # ( !\IO_ADDR[3]~input_o\ & ( !\timers:0:channel|elapsed_r\(0) & ( (\IO_ADDR[2]~input_o\ & \timers:1:channel|elapsed_r\(0)) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000001111001101010011010111110000111111110011010100110101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:3:channel|ALT_INV_elapsed_r\(0),
	datab => \timers:2:channel|ALT_INV_elapsed_r\(0),
	datac => \ALT_INV_IO_ADDR[2]~input_o\,
	datad => \timers:1:channel|ALT_INV_elapsed_r\(0),
	datae => \ALT_INV_IO_ADDR[3]~input_o\,
	dataf => \timers:0:channel|ALT_INV_elapsed_r\(0),
	combout => \read_value[0]~2_combout\);

-- Location: MLABCELL_X25_Y68_N0
\timers:1:channel|Add1~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|Add1~1_sumout\ = SUM(( \timers:1:channel|periods_r\(0) ) + ( VCC ) + ( !VCC ))
-- \timers:1:channel|Add1~2\ = CARRY(( \timers:1:channel|periods_r\(0) ) + ( VCC ) + ( !VCC ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:1:channel|ALT_INV_periods_r\(0),
	cin => GND,
	sumout => \timers:1:channel|Add1~1_sumout\,
	cout => \timers:1:channel|Add1~2\);

-- Location: MLABCELL_X25_Y69_N45
\timers:1:channel|elapsed_r[14]~4\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|elapsed_r[14]~4_combout\ = ( \IO_DATA[1]~input_o\ & ( !\timers:1:channel|running_r~q\ & ( (\timers:0:channel|periods_r~1_combout\ & (\Equal11~2_combout\ & \IO_DATA[0]~input_o\)) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000010000000100000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:0:channel|ALT_INV_periods_r~1_combout\,
	datab => \ALT_INV_Equal11~2_combout\,
	datac => \ALT_INV_IO_DATA[0]~input_o\,
	datae => \ALT_INV_IO_DATA[1]~input_o\,
	dataf => \timers:1:channel|ALT_INV_running_r~q\,
	combout => \timers:1:channel|elapsed_r[14]~4_combout\);

-- Location: MLABCELL_X25_Y68_N54
\timers:1:channel|periods_r[14]~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|periods_r[14]~0_combout\ = ( \timers:1:channel|prescaler|TICK~q\ & ( \timers:1:channel|LessThan0~16_combout\ & ( (!\timers:1:channel|running_r~q\ & (((\Equal11~2_combout\ & \timers:0:channel|periods_r~0_combout\)))) # 
-- (\timers:1:channel|running_r~q\ & (\timers:1:channel|mode_r\(1))) ) ) ) # ( !\timers:1:channel|prescaler|TICK~q\ & ( \timers:1:channel|LessThan0~16_combout\ & ( (\Equal11~2_combout\ & (\timers:0:channel|periods_r~0_combout\ & 
-- !\timers:1:channel|running_r~q\)) ) ) ) # ( \timers:1:channel|prescaler|TICK~q\ & ( !\timers:1:channel|LessThan0~16_combout\ & ( (\Equal11~2_combout\ & (\timers:0:channel|periods_r~0_combout\ & !\timers:1:channel|running_r~q\)) ) ) ) # ( 
-- !\timers:1:channel|prescaler|TICK~q\ & ( !\timers:1:channel|LessThan0~16_combout\ & ( (\Equal11~2_combout\ & (\timers:0:channel|periods_r~0_combout\ & !\timers:1:channel|running_r~q\)) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000001100000000000000110000000000000011000000000000001101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:1:channel|ALT_INV_mode_r\(1),
	datab => \ALT_INV_Equal11~2_combout\,
	datac => \timers:0:channel|ALT_INV_periods_r~0_combout\,
	datad => \timers:1:channel|ALT_INV_running_r~q\,
	datae => \timers:1:channel|prescaler|ALT_INV_TICK~q\,
	dataf => \timers:1:channel|ALT_INV_LessThan0~16_combout\,
	combout => \timers:1:channel|periods_r[14]~0_combout\);

-- Location: FF_X25_Y68_N2
\timers:1:channel|periods_r[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:1:channel|Add1~1_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:1:channel|elapsed_r[14]~4_combout\,
	ena => \timers:1:channel|periods_r[14]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:1:channel|periods_r\(0));

-- Location: LABCELL_X23_Y69_N0
\timers:0:channel|Add1~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|Add1~1_sumout\ = SUM(( \timers:0:channel|periods_r\(0) ) + ( VCC ) + ( !VCC ))
-- \timers:0:channel|Add1~2\ = CARRY(( \timers:0:channel|periods_r\(0) ) + ( VCC ) + ( !VCC ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:0:channel|ALT_INV_periods_r\(0),
	cin => GND,
	sumout => \timers:0:channel|Add1~1_sumout\,
	cout => \timers:0:channel|Add1~2\);

-- Location: LABCELL_X24_Y69_N36
\timers:0:channel|elapsed_r[2]~4\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|elapsed_r[2]~4_combout\ = ( \IO_DATA[1]~input_o\ & ( (!\timers:0:channel|running_r~q\ & (\timers:0:channel|periods_r~1_combout\ & (write_hit(0) & \IO_DATA[0]~input_o\))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000100000000000000010",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:0:channel|ALT_INV_running_r~q\,
	datab => \timers:0:channel|ALT_INV_periods_r~1_combout\,
	datac => ALT_INV_write_hit(0),
	datad => \ALT_INV_IO_DATA[0]~input_o\,
	dataf => \ALT_INV_IO_DATA[1]~input_o\,
	combout => \timers:0:channel|elapsed_r[2]~4_combout\);

-- Location: LABCELL_X23_Y69_N54
\timers:0:channel|periods_r[7]~2\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|periods_r[7]~2_combout\ = ( \timers:0:channel|running_r~q\ & ( \timers:0:channel|LessThan0~16_combout\ & ( (\timers:0:channel|prescaler|TICK~q\ & \timers:0:channel|mode_r\(1)) ) ) ) # ( !\timers:0:channel|running_r~q\ & ( 
-- \timers:0:channel|LessThan0~16_combout\ & ( (\timers:0:channel|periods_r~0_combout\ & write_hit(0)) ) ) ) # ( !\timers:0:channel|running_r~q\ & ( !\timers:0:channel|LessThan0~16_combout\ & ( (\timers:0:channel|periods_r~0_combout\ & write_hit(0)) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0001000100010001000000000000000000010001000100010000000000001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:0:channel|ALT_INV_periods_r~0_combout\,
	datab => ALT_INV_write_hit(0),
	datac => \timers:0:channel|prescaler|ALT_INV_TICK~q\,
	datad => \timers:0:channel|ALT_INV_mode_r\(1),
	datae => \timers:0:channel|ALT_INV_running_r~q\,
	dataf => \timers:0:channel|ALT_INV_LessThan0~16_combout\,
	combout => \timers:0:channel|periods_r[7]~2_combout\);

-- Location: FF_X23_Y69_N2
\timers:0:channel|periods_r[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:0:channel|Add1~1_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:0:channel|elapsed_r[2]~4_combout\,
	ena => \timers:0:channel|periods_r[7]~2_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:0:channel|periods_r\(0));

-- Location: LABCELL_X22_Y64_N0
\timers:3:channel|Add1~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|Add1~1_sumout\ = SUM(( \timers:3:channel|periods_r\(0) ) + ( VCC ) + ( !VCC ))
-- \timers:3:channel|Add1~2\ = CARRY(( \timers:3:channel|periods_r\(0) ) + ( VCC ) + ( !VCC ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:3:channel|ALT_INV_periods_r\(0),
	cin => GND,
	sumout => \timers:3:channel|Add1~1_sumout\,
	cout => \timers:3:channel|Add1~2\);

-- Location: LABCELL_X22_Y65_N6
\timers:3:channel|elapsed_r[9]~4\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|elapsed_r[9]~4_combout\ = ( \Equal11~3_combout\ & ( !\timers:3:channel|running_r~q\ & ( (\timers:0:channel|periods_r~0_combout\ & (\Equal0~0_combout\ & (!\IO_ADDR[10]~input_o\ & \IO_WRITE~input_o\))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000001000000000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:0:channel|ALT_INV_periods_r~0_combout\,
	datab => \ALT_INV_Equal0~0_combout\,
	datac => \ALT_INV_IO_ADDR[10]~input_o\,
	datad => \ALT_INV_IO_WRITE~input_o\,
	datae => \ALT_INV_Equal11~3_combout\,
	dataf => \timers:3:channel|ALT_INV_running_r~q\,
	combout => \timers:3:channel|elapsed_r[9]~4_combout\);

-- Location: LABCELL_X22_Y64_N54
\timers:3:channel|periods_r[13]~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|periods_r[13]~0_combout\ = ( \timers:0:channel|periods_r~0_combout\ & ( \timers:3:channel|LessThan0~16_combout\ & ( (!\timers:3:channel|running_r~q\ & (((\Equal11~4_combout\)))) # (\timers:3:channel|running_r~q\ & 
-- (\timers:3:channel|mode_r\(1) & (\timers:3:channel|prescaler|TICK~q\))) ) ) ) # ( !\timers:0:channel|periods_r~0_combout\ & ( \timers:3:channel|LessThan0~16_combout\ & ( (\timers:3:channel|mode_r\(1) & (\timers:3:channel|prescaler|TICK~q\ & 
-- \timers:3:channel|running_r~q\)) ) ) ) # ( \timers:0:channel|periods_r~0_combout\ & ( !\timers:3:channel|LessThan0~16_combout\ & ( (!\timers:3:channel|running_r~q\ & \Equal11~4_combout\) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000001111000000000001000000010000000111110001",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:3:channel|ALT_INV_mode_r\(1),
	datab => \timers:3:channel|prescaler|ALT_INV_TICK~q\,
	datac => \timers:3:channel|ALT_INV_running_r~q\,
	datad => \ALT_INV_Equal11~4_combout\,
	datae => \timers:0:channel|ALT_INV_periods_r~0_combout\,
	dataf => \timers:3:channel|ALT_INV_LessThan0~16_combout\,
	combout => \timers:3:channel|periods_r[13]~0_combout\);

-- Location: FF_X22_Y64_N2
\timers:3:channel|periods_r[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:3:channel|Add1~1_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:3:channel|elapsed_r[9]~4_combout\,
	ena => \timers:3:channel|periods_r[13]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:3:channel|periods_r\(0));

-- Location: MLABCELL_X21_Y67_N21
\read_value[0]~3\ : cyclonev_lcell_comb
-- Equation(s):
-- \read_value[0]~3_combout\ = ( \IO_ADDR[3]~input_o\ & ( \timers:3:channel|periods_r\(0) ) ) # ( !\IO_ADDR[3]~input_o\ & ( \timers:3:channel|periods_r\(0) & ( (!\IO_ADDR[2]~input_o\ & ((\timers:0:channel|periods_r\(0)))) # (\IO_ADDR[2]~input_o\ & 
-- (\timers:1:channel|periods_r\(0))) ) ) ) # ( !\IO_ADDR[3]~input_o\ & ( !\timers:3:channel|periods_r\(0) & ( (!\IO_ADDR[2]~input_o\ & ((\timers:0:channel|periods_r\(0)))) # (\IO_ADDR[2]~input_o\ & (\timers:1:channel|periods_r\(0))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000111100110011000000000000000000001111001100111111111111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \timers:1:channel|ALT_INV_periods_r\(0),
	datac => \timers:0:channel|ALT_INV_periods_r\(0),
	datad => \ALT_INV_IO_ADDR[2]~input_o\,
	datae => \ALT_INV_IO_ADDR[3]~input_o\,
	dataf => \timers:3:channel|ALT_INV_periods_r\(0),
	combout => \read_value[0]~3_combout\);

-- Location: MLABCELL_X21_Y68_N0
\timers:2:channel|Add1~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|Add1~1_sumout\ = SUM(( \timers:2:channel|periods_r\(0) ) + ( VCC ) + ( !VCC ))
-- \timers:2:channel|Add1~2\ = CARRY(( \timers:2:channel|periods_r\(0) ) + ( VCC ) + ( !VCC ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:2:channel|ALT_INV_periods_r\(0),
	cin => GND,
	sumout => \timers:2:channel|Add1~1_sumout\,
	cout => \timers:2:channel|Add1~2\);

-- Location: MLABCELL_X21_Y70_N48
\timers:2:channel|elapsed_r[6]~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|elapsed_r[6]~0_combout\ = ( \IO_WRITE~input_o\ & ( !\timers:2:channel|running_r~q\ & ( (\timers:0:channel|periods_r~0_combout\ & (\Equal11~0_combout\ & (!\IO_ADDR[10]~input_o\ & \Equal0~0_combout\))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000001000000000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:0:channel|ALT_INV_periods_r~0_combout\,
	datab => \ALT_INV_Equal11~0_combout\,
	datac => \ALT_INV_IO_ADDR[10]~input_o\,
	datad => \ALT_INV_Equal0~0_combout\,
	datae => \ALT_INV_IO_WRITE~input_o\,
	dataf => \timers:2:channel|ALT_INV_running_r~q\,
	combout => \timers:2:channel|elapsed_r[6]~0_combout\);

-- Location: FF_X22_Y71_N43
\timers:2:channel|prescaler|TICK\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:2:channel|prescaler|TICK~1_combout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:2:channel|prescaler|TICK~q\);

-- Location: MLABCELL_X21_Y68_N54
\timers:2:channel|periods_r[5]~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|periods_r[5]~0_combout\ = ( \timers:2:channel|prescaler|TICK~q\ & ( \timers:2:channel|LessThan0~16_combout\ & ( (!\timers:2:channel|running_r~q\ & (\timers:0:channel|periods_r~0_combout\ & ((\Equal11~1_combout\)))) # 
-- (\timers:2:channel|running_r~q\ & (((\timers:2:channel|mode_r\(1))))) ) ) ) # ( !\timers:2:channel|prescaler|TICK~q\ & ( \timers:2:channel|LessThan0~16_combout\ & ( (!\timers:2:channel|running_r~q\ & (\timers:0:channel|periods_r~0_combout\ & 
-- \Equal11~1_combout\)) ) ) ) # ( \timers:2:channel|prescaler|TICK~q\ & ( !\timers:2:channel|LessThan0~16_combout\ & ( (!\timers:2:channel|running_r~q\ & (\timers:0:channel|periods_r~0_combout\ & \Equal11~1_combout\)) ) ) ) # ( 
-- !\timers:2:channel|prescaler|TICK~q\ & ( !\timers:2:channel|LessThan0~16_combout\ & ( (!\timers:2:channel|running_r~q\ & (\timers:0:channel|periods_r~0_combout\ & \Equal11~1_combout\)) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000100010000000000010001000000000001000100000010100100111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:2:channel|ALT_INV_running_r~q\,
	datab => \timers:0:channel|ALT_INV_periods_r~0_combout\,
	datac => \timers:2:channel|ALT_INV_mode_r\(1),
	datad => \ALT_INV_Equal11~1_combout\,
	datae => \timers:2:channel|prescaler|ALT_INV_TICK~q\,
	dataf => \timers:2:channel|ALT_INV_LessThan0~16_combout\,
	combout => \timers:2:channel|periods_r[5]~0_combout\);

-- Location: FF_X21_Y68_N2
\timers:2:channel|periods_r[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:2:channel|Add1~1_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:2:channel|elapsed_r[6]~0_combout\,
	ena => \timers:2:channel|periods_r[5]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:2:channel|periods_r\(0));

-- Location: MLABCELL_X21_Y67_N39
\read_value[0]~4\ : cyclonev_lcell_comb
-- Equation(s):
-- \read_value[0]~4_combout\ = ( \timers:2:channel|periods_r\(0) & ( (!\read_value[0]~0_combout\ & (\read_value[0]~1_combout\ & ((\read_value[0]~3_combout\)))) # (\read_value[0]~0_combout\ & ((!\read_value[0]~1_combout\) # ((\read_value[0]~2_combout\)))) ) ) 
-- # ( !\timers:2:channel|periods_r\(0) & ( (\read_value[0]~1_combout\ & ((!\read_value[0]~0_combout\ & ((\read_value[0]~3_combout\))) # (\read_value[0]~0_combout\ & (\read_value[0]~2_combout\)))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000100100011000000010010001101000101011001110100010101100111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_read_value[0]~0_combout\,
	datab => \ALT_INV_read_value[0]~1_combout\,
	datac => \ALT_INV_read_value[0]~2_combout\,
	datad => \ALT_INV_read_value[0]~3_combout\,
	dataf => \timers:2:channel|ALT_INV_periods_r\(0),
	combout => \read_value[0]~4_combout\);

-- Location: IOIBUF_X14_Y81_N18
\IO_READ~input\ : cyclonev_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_IO_READ,
	o => \IO_READ~input_o\);

-- Location: LABCELL_X22_Y77_N9
drive_en : cyclonev_lcell_comb
-- Equation(s):
-- \drive_en~combout\ = ( !\IO_ADDR[10]~input_o\ & ( \IO_READ~input_o\ & ( \Equal0~0_combout\ ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000001010101010101010000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_Equal0~0_combout\,
	datae => \ALT_INV_IO_ADDR[10]~input_o\,
	dataf => \ALT_INV_IO_READ~input_o\,
	combout => \drive_en~combout\);

-- Location: MLABCELL_X21_Y68_N3
\timers:2:channel|Add1~5\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|Add1~5_sumout\ = SUM(( \timers:2:channel|periods_r\(1) ) + ( GND ) + ( \timers:2:channel|Add1~2\ ))
-- \timers:2:channel|Add1~6\ = CARRY(( \timers:2:channel|periods_r\(1) ) + ( GND ) + ( \timers:2:channel|Add1~2\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000000011111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datad => \timers:2:channel|ALT_INV_periods_r\(1),
	cin => \timers:2:channel|Add1~2\,
	sumout => \timers:2:channel|Add1~5_sumout\,
	cout => \timers:2:channel|Add1~6\);

-- Location: FF_X21_Y68_N5
\timers:2:channel|periods_r[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:2:channel|Add1~5_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:2:channel|elapsed_r[6]~0_combout\,
	ena => \timers:2:channel|periods_r[5]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:2:channel|periods_r\(1));

-- Location: LABCELL_X22_Y64_N3
\timers:3:channel|Add1~5\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|Add1~5_sumout\ = SUM(( \timers:3:channel|periods_r\(1) ) + ( GND ) + ( \timers:3:channel|Add1~2\ ))
-- \timers:3:channel|Add1~6\ = CARRY(( \timers:3:channel|periods_r\(1) ) + ( GND ) + ( \timers:3:channel|Add1~2\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000000011111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datad => \timers:3:channel|ALT_INV_periods_r\(1),
	cin => \timers:3:channel|Add1~2\,
	sumout => \timers:3:channel|Add1~5_sumout\,
	cout => \timers:3:channel|Add1~6\);

-- Location: FF_X22_Y64_N5
\timers:3:channel|periods_r[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:3:channel|Add1~5_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:3:channel|elapsed_r[9]~4_combout\,
	ena => \timers:3:channel|periods_r[13]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:3:channel|periods_r\(1));

-- Location: MLABCELL_X25_Y68_N3
\timers:1:channel|Add1~5\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|Add1~5_sumout\ = SUM(( \timers:1:channel|periods_r\(1) ) + ( GND ) + ( \timers:1:channel|Add1~2\ ))
-- \timers:1:channel|Add1~6\ = CARRY(( \timers:1:channel|periods_r\(1) ) + ( GND ) + ( \timers:1:channel|Add1~2\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000000011111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datad => \timers:1:channel|ALT_INV_periods_r\(1),
	cin => \timers:1:channel|Add1~2\,
	sumout => \timers:1:channel|Add1~5_sumout\,
	cout => \timers:1:channel|Add1~6\);

-- Location: FF_X25_Y68_N5
\timers:1:channel|periods_r[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:1:channel|Add1~5_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:1:channel|elapsed_r[14]~4_combout\,
	ena => \timers:1:channel|periods_r[14]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:1:channel|periods_r\(1));

-- Location: LABCELL_X23_Y69_N3
\timers:0:channel|Add1~5\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|Add1~5_sumout\ = SUM(( \timers:0:channel|periods_r\(1) ) + ( GND ) + ( \timers:0:channel|Add1~2\ ))
-- \timers:0:channel|Add1~6\ = CARRY(( \timers:0:channel|periods_r\(1) ) + ( GND ) + ( \timers:0:channel|Add1~2\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000000011111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datad => \timers:0:channel|ALT_INV_periods_r\(1),
	cin => \timers:0:channel|Add1~2\,
	sumout => \timers:0:channel|Add1~5_sumout\,
	cout => \timers:0:channel|Add1~6\);

-- Location: FF_X23_Y69_N5
\timers:0:channel|periods_r[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:0:channel|Add1~5_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:0:channel|elapsed_r[2]~4_combout\,
	ena => \timers:0:channel|periods_r[7]~2_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:0:channel|periods_r\(1));

-- Location: LABCELL_X23_Y64_N30
\read_value[1]~6\ : cyclonev_lcell_comb
-- Equation(s):
-- \read_value[1]~6_combout\ = ( \IO_ADDR[2]~input_o\ & ( (!\IO_ADDR[3]~input_o\ & ((\timers:1:channel|periods_r\(1)))) # (\IO_ADDR[3]~input_o\ & (\timers:3:channel|periods_r\(1))) ) ) # ( !\IO_ADDR[2]~input_o\ & ( (!\IO_ADDR[3]~input_o\ & 
-- ((\timers:0:channel|periods_r\(1)))) # (\IO_ADDR[3]~input_o\ & (\timers:3:channel|periods_r\(1))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000111101010101000011110101010100110011010101010011001101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:3:channel|ALT_INV_periods_r\(1),
	datab => \timers:1:channel|ALT_INV_periods_r\(1),
	datac => \timers:0:channel|ALT_INV_periods_r\(1),
	datad => \ALT_INV_IO_ADDR[3]~input_o\,
	dataf => \ALT_INV_IO_ADDR[2]~input_o\,
	combout => \read_value[1]~6_combout\);

-- Location: LABCELL_X24_Y65_N39
\read_value[1]~5\ : cyclonev_lcell_comb
-- Equation(s):
-- \read_value[1]~5_combout\ = ( \IO_ADDR[3]~input_o\ & ( \IO_ADDR[2]~input_o\ & ( \timers:3:channel|elapsed_r\(1) ) ) ) # ( !\IO_ADDR[3]~input_o\ & ( \IO_ADDR[2]~input_o\ & ( \timers:1:channel|elapsed_r\(1) ) ) ) # ( \IO_ADDR[3]~input_o\ & ( 
-- !\IO_ADDR[2]~input_o\ & ( \timers:2:channel|elapsed_r\(1) ) ) ) # ( !\IO_ADDR[3]~input_o\ & ( !\IO_ADDR[2]~input_o\ & ( \timers:0:channel|elapsed_r\(1) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0101010101010101000011110000111100000000111111110011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:0:channel|ALT_INV_elapsed_r\(1),
	datab => \timers:3:channel|ALT_INV_elapsed_r\(1),
	datac => \timers:2:channel|ALT_INV_elapsed_r\(1),
	datad => \timers:1:channel|ALT_INV_elapsed_r\(1),
	datae => \ALT_INV_IO_ADDR[3]~input_o\,
	dataf => \ALT_INV_IO_ADDR[2]~input_o\,
	combout => \read_value[1]~5_combout\);

-- Location: LABCELL_X23_Y65_N12
\read_value[1]~7\ : cyclonev_lcell_comb
-- Equation(s):
-- \read_value[1]~7_combout\ = ( \read_value[0]~0_combout\ & ( \read_value[1]~5_combout\ & ( (\read_value[0]~1_combout\) # (\timers:2:channel|periods_r\(1)) ) ) ) # ( !\read_value[0]~0_combout\ & ( \read_value[1]~5_combout\ & ( (\read_value[1]~6_combout\ & 
-- \read_value[0]~1_combout\) ) ) ) # ( \read_value[0]~0_combout\ & ( !\read_value[1]~5_combout\ & ( (\timers:2:channel|periods_r\(1) & !\read_value[0]~1_combout\) ) ) ) # ( !\read_value[0]~0_combout\ & ( !\read_value[1]~5_combout\ & ( 
-- (\read_value[1]~6_combout\ & \read_value[0]~1_combout\) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000001111001100110000000000000000000011110011001111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \timers:2:channel|ALT_INV_periods_r\(1),
	datac => \ALT_INV_read_value[1]~6_combout\,
	datad => \ALT_INV_read_value[0]~1_combout\,
	datae => \ALT_INV_read_value[0]~0_combout\,
	dataf => \ALT_INV_read_value[1]~5_combout\,
	combout => \read_value[1]~7_combout\);

-- Location: MLABCELL_X21_Y68_N6
\timers:2:channel|Add1~9\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|Add1~9_sumout\ = SUM(( \timers:2:channel|periods_r\(2) ) + ( GND ) + ( \timers:2:channel|Add1~6\ ))
-- \timers:2:channel|Add1~10\ = CARRY(( \timers:2:channel|periods_r\(2) ) + ( GND ) + ( \timers:2:channel|Add1~6\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \timers:2:channel|ALT_INV_periods_r\(2),
	cin => \timers:2:channel|Add1~6\,
	sumout => \timers:2:channel|Add1~9_sumout\,
	cout => \timers:2:channel|Add1~10\);

-- Location: FF_X21_Y68_N8
\timers:2:channel|periods_r[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:2:channel|Add1~9_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:2:channel|elapsed_r[6]~0_combout\,
	ena => \timers:2:channel|periods_r[5]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:2:channel|periods_r\(2));

-- Location: MLABCELL_X25_Y68_N6
\timers:1:channel|Add1~9\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|Add1~9_sumout\ = SUM(( \timers:1:channel|periods_r\(2) ) + ( GND ) + ( \timers:1:channel|Add1~6\ ))
-- \timers:1:channel|Add1~10\ = CARRY(( \timers:1:channel|periods_r\(2) ) + ( GND ) + ( \timers:1:channel|Add1~6\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \timers:1:channel|ALT_INV_periods_r\(2),
	cin => \timers:1:channel|Add1~6\,
	sumout => \timers:1:channel|Add1~9_sumout\,
	cout => \timers:1:channel|Add1~10\);

-- Location: FF_X25_Y68_N8
\timers:1:channel|periods_r[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:1:channel|Add1~9_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:1:channel|elapsed_r[14]~4_combout\,
	ena => \timers:1:channel|periods_r[14]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:1:channel|periods_r\(2));

-- Location: LABCELL_X22_Y64_N6
\timers:3:channel|Add1~9\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|Add1~9_sumout\ = SUM(( \timers:3:channel|periods_r\(2) ) + ( GND ) + ( \timers:3:channel|Add1~6\ ))
-- \timers:3:channel|Add1~10\ = CARRY(( \timers:3:channel|periods_r\(2) ) + ( GND ) + ( \timers:3:channel|Add1~6\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \timers:3:channel|ALT_INV_periods_r\(2),
	cin => \timers:3:channel|Add1~6\,
	sumout => \timers:3:channel|Add1~9_sumout\,
	cout => \timers:3:channel|Add1~10\);

-- Location: FF_X22_Y64_N8
\timers:3:channel|periods_r[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:3:channel|Add1~9_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:3:channel|elapsed_r[9]~4_combout\,
	ena => \timers:3:channel|periods_r[13]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:3:channel|periods_r\(2));

-- Location: LABCELL_X23_Y69_N6
\timers:0:channel|Add1~9\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|Add1~9_sumout\ = SUM(( \timers:0:channel|periods_r\(2) ) + ( GND ) + ( \timers:0:channel|Add1~6\ ))
-- \timers:0:channel|Add1~10\ = CARRY(( \timers:0:channel|periods_r\(2) ) + ( GND ) + ( \timers:0:channel|Add1~6\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \timers:0:channel|ALT_INV_periods_r\(2),
	cin => \timers:0:channel|Add1~6\,
	sumout => \timers:0:channel|Add1~9_sumout\,
	cout => \timers:0:channel|Add1~10\);

-- Location: FF_X23_Y69_N8
\timers:0:channel|periods_r[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:0:channel|Add1~9_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:0:channel|elapsed_r[2]~4_combout\,
	ena => \timers:0:channel|periods_r[7]~2_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:0:channel|periods_r\(2));

-- Location: LABCELL_X23_Y65_N21
\read_value[2]~9\ : cyclonev_lcell_comb
-- Equation(s):
-- \read_value[2]~9_combout\ = ( \timers:0:channel|periods_r\(2) & ( (!\IO_ADDR[3]~input_o\ & (((!\IO_ADDR[2]~input_o\)) # (\timers:1:channel|periods_r\(2)))) # (\IO_ADDR[3]~input_o\ & (((\timers:3:channel|periods_r\(2))))) ) ) # ( 
-- !\timers:0:channel|periods_r\(2) & ( (!\IO_ADDR[3]~input_o\ & (\timers:1:channel|periods_r\(2) & (\IO_ADDR[2]~input_o\))) # (\IO_ADDR[3]~input_o\ & (((\timers:3:channel|periods_r\(2))))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000001001010111101000101111011100000010010101111010001011110111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_IO_ADDR[3]~input_o\,
	datab => \timers:1:channel|ALT_INV_periods_r\(2),
	datac => \ALT_INV_IO_ADDR[2]~input_o\,
	datad => \timers:3:channel|ALT_INV_periods_r\(2),
	datae => \timers:0:channel|ALT_INV_periods_r\(2),
	combout => \read_value[2]~9_combout\);

-- Location: LABCELL_X23_Y64_N51
\read_value[2]~8\ : cyclonev_lcell_comb
-- Equation(s):
-- \read_value[2]~8_combout\ = ( \timers:1:channel|elapsed_r\(2) & ( \timers:3:channel|elapsed_r\(2) & ( ((!\IO_ADDR[3]~input_o\ & (\timers:0:channel|elapsed_r\(2))) # (\IO_ADDR[3]~input_o\ & ((\timers:2:channel|elapsed_r\(2))))) # (\IO_ADDR[2]~input_o\) ) ) 
-- ) # ( !\timers:1:channel|elapsed_r\(2) & ( \timers:3:channel|elapsed_r\(2) & ( (!\IO_ADDR[2]~input_o\ & ((!\IO_ADDR[3]~input_o\ & (\timers:0:channel|elapsed_r\(2))) # (\IO_ADDR[3]~input_o\ & ((\timers:2:channel|elapsed_r\(2)))))) # (\IO_ADDR[2]~input_o\ & 
-- (((\IO_ADDR[3]~input_o\)))) ) ) ) # ( \timers:1:channel|elapsed_r\(2) & ( !\timers:3:channel|elapsed_r\(2) & ( (!\IO_ADDR[2]~input_o\ & ((!\IO_ADDR[3]~input_o\ & (\timers:0:channel|elapsed_r\(2))) # (\IO_ADDR[3]~input_o\ & 
-- ((\timers:2:channel|elapsed_r\(2)))))) # (\IO_ADDR[2]~input_o\ & (((!\IO_ADDR[3]~input_o\)))) ) ) ) # ( !\timers:1:channel|elapsed_r\(2) & ( !\timers:3:channel|elapsed_r\(2) & ( (!\IO_ADDR[2]~input_o\ & ((!\IO_ADDR[3]~input_o\ & 
-- (\timers:0:channel|elapsed_r\(2))) # (\IO_ADDR[3]~input_o\ & ((\timers:2:channel|elapsed_r\(2)))))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0100000001001100011100000111110001000011010011110111001101111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:0:channel|ALT_INV_elapsed_r\(2),
	datab => \ALT_INV_IO_ADDR[2]~input_o\,
	datac => \ALT_INV_IO_ADDR[3]~input_o\,
	datad => \timers:2:channel|ALT_INV_elapsed_r\(2),
	datae => \timers:1:channel|ALT_INV_elapsed_r\(2),
	dataf => \timers:3:channel|ALT_INV_elapsed_r\(2),
	combout => \read_value[2]~8_combout\);

-- Location: LABCELL_X23_Y65_N33
\read_value[2]~10\ : cyclonev_lcell_comb
-- Equation(s):
-- \read_value[2]~10_combout\ = ( \read_value[2]~9_combout\ & ( \read_value[2]~8_combout\ & ( ((\read_value[0]~0_combout\ & \timers:2:channel|periods_r\(2))) # (\read_value[0]~1_combout\) ) ) ) # ( !\read_value[2]~9_combout\ & ( \read_value[2]~8_combout\ & ( 
-- (\read_value[0]~0_combout\ & ((\read_value[0]~1_combout\) # (\timers:2:channel|periods_r\(2)))) ) ) ) # ( \read_value[2]~9_combout\ & ( !\read_value[2]~8_combout\ & ( (!\read_value[0]~0_combout\ & ((\read_value[0]~1_combout\))) # 
-- (\read_value[0]~0_combout\ & (\timers:2:channel|periods_r\(2) & !\read_value[0]~1_combout\)) ) ) ) # ( !\read_value[2]~9_combout\ & ( !\read_value[2]~8_combout\ & ( (\read_value[0]~0_combout\ & (\timers:2:channel|periods_r\(2) & 
-- !\read_value[0]~1_combout\)) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0001000000010000000110100001101000010101000101010001111100011111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_read_value[0]~0_combout\,
	datab => \timers:2:channel|ALT_INV_periods_r\(2),
	datac => \ALT_INV_read_value[0]~1_combout\,
	datae => \ALT_INV_read_value[2]~9_combout\,
	dataf => \ALT_INV_read_value[2]~8_combout\,
	combout => \read_value[2]~10_combout\);

-- Location: MLABCELL_X21_Y68_N9
\timers:2:channel|Add1~13\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|Add1~13_sumout\ = SUM(( \timers:2:channel|periods_r\(3) ) + ( GND ) + ( \timers:2:channel|Add1~10\ ))
-- \timers:2:channel|Add1~14\ = CARRY(( \timers:2:channel|periods_r\(3) ) + ( GND ) + ( \timers:2:channel|Add1~10\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:2:channel|ALT_INV_periods_r\(3),
	cin => \timers:2:channel|Add1~10\,
	sumout => \timers:2:channel|Add1~13_sumout\,
	cout => \timers:2:channel|Add1~14\);

-- Location: FF_X21_Y68_N11
\timers:2:channel|periods_r[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:2:channel|Add1~13_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:2:channel|elapsed_r[6]~0_combout\,
	ena => \timers:2:channel|periods_r[5]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:2:channel|periods_r\(3));

-- Location: LABCELL_X23_Y64_N42
\read_value[3]~11\ : cyclonev_lcell_comb
-- Equation(s):
-- \read_value[3]~11_combout\ = ( \timers:2:channel|elapsed_r\(3) & ( \IO_ADDR[3]~input_o\ & ( (!\IO_ADDR[2]~input_o\) # (\timers:3:channel|elapsed_r\(3)) ) ) ) # ( !\timers:2:channel|elapsed_r\(3) & ( \IO_ADDR[3]~input_o\ & ( 
-- (\timers:3:channel|elapsed_r\(3) & \IO_ADDR[2]~input_o\) ) ) ) # ( \timers:2:channel|elapsed_r\(3) & ( !\IO_ADDR[3]~input_o\ & ( (!\IO_ADDR[2]~input_o\ & ((\timers:0:channel|elapsed_r\(3)))) # (\IO_ADDR[2]~input_o\ & (\timers:1:channel|elapsed_r\(3))) ) ) 
-- ) # ( !\timers:2:channel|elapsed_r\(3) & ( !\IO_ADDR[3]~input_o\ & ( (!\IO_ADDR[2]~input_o\ & ((\timers:0:channel|elapsed_r\(3)))) # (\IO_ADDR[2]~input_o\ & (\timers:1:channel|elapsed_r\(3))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000111100110011000011110011001100000000010101011111111101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:3:channel|ALT_INV_elapsed_r\(3),
	datab => \timers:1:channel|ALT_INV_elapsed_r\(3),
	datac => \timers:0:channel|ALT_INV_elapsed_r\(3),
	datad => \ALT_INV_IO_ADDR[2]~input_o\,
	datae => \timers:2:channel|ALT_INV_elapsed_r\(3),
	dataf => \ALT_INV_IO_ADDR[3]~input_o\,
	combout => \read_value[3]~11_combout\);

-- Location: LABCELL_X22_Y64_N9
\timers:3:channel|Add1~13\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|Add1~13_sumout\ = SUM(( \timers:3:channel|periods_r\(3) ) + ( GND ) + ( \timers:3:channel|Add1~10\ ))
-- \timers:3:channel|Add1~14\ = CARRY(( \timers:3:channel|periods_r\(3) ) + ( GND ) + ( \timers:3:channel|Add1~10\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:3:channel|ALT_INV_periods_r\(3),
	cin => \timers:3:channel|Add1~10\,
	sumout => \timers:3:channel|Add1~13_sumout\,
	cout => \timers:3:channel|Add1~14\);

-- Location: FF_X22_Y64_N11
\timers:3:channel|periods_r[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:3:channel|Add1~13_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:3:channel|elapsed_r[9]~4_combout\,
	ena => \timers:3:channel|periods_r[13]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:3:channel|periods_r\(3));

-- Location: LABCELL_X23_Y69_N9
\timers:0:channel|Add1~13\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|Add1~13_sumout\ = SUM(( \timers:0:channel|periods_r\(3) ) + ( GND ) + ( \timers:0:channel|Add1~10\ ))
-- \timers:0:channel|Add1~14\ = CARRY(( \timers:0:channel|periods_r\(3) ) + ( GND ) + ( \timers:0:channel|Add1~10\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:0:channel|ALT_INV_periods_r\(3),
	cin => \timers:0:channel|Add1~10\,
	sumout => \timers:0:channel|Add1~13_sumout\,
	cout => \timers:0:channel|Add1~14\);

-- Location: FF_X23_Y69_N11
\timers:0:channel|periods_r[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:0:channel|Add1~13_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:0:channel|elapsed_r[2]~4_combout\,
	ena => \timers:0:channel|periods_r[7]~2_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:0:channel|periods_r\(3));

-- Location: MLABCELL_X25_Y68_N9
\timers:1:channel|Add1~13\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|Add1~13_sumout\ = SUM(( \timers:1:channel|periods_r\(3) ) + ( GND ) + ( \timers:1:channel|Add1~10\ ))
-- \timers:1:channel|Add1~14\ = CARRY(( \timers:1:channel|periods_r\(3) ) + ( GND ) + ( \timers:1:channel|Add1~10\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:1:channel|ALT_INV_periods_r\(3),
	cin => \timers:1:channel|Add1~10\,
	sumout => \timers:1:channel|Add1~13_sumout\,
	cout => \timers:1:channel|Add1~14\);

-- Location: FF_X25_Y68_N11
\timers:1:channel|periods_r[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:1:channel|Add1~13_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:1:channel|elapsed_r[14]~4_combout\,
	ena => \timers:1:channel|periods_r[14]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:1:channel|periods_r\(3));

-- Location: MLABCELL_X25_Y68_N51
\read_value[3]~12\ : cyclonev_lcell_comb
-- Equation(s):
-- \read_value[3]~12_combout\ = ( \timers:1:channel|periods_r\(3) & ( (!\IO_ADDR[3]~input_o\ & (((\timers:0:channel|periods_r\(3))) # (\IO_ADDR[2]~input_o\))) # (\IO_ADDR[3]~input_o\ & (((\timers:3:channel|periods_r\(3))))) ) ) # ( 
-- !\timers:1:channel|periods_r\(3) & ( (!\IO_ADDR[3]~input_o\ & (!\IO_ADDR[2]~input_o\ & ((\timers:0:channel|periods_r\(3))))) # (\IO_ADDR[3]~input_o\ & (((\timers:3:channel|periods_r\(3))))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000010110001101000001011000110100100111101011110010011110101111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_IO_ADDR[3]~input_o\,
	datab => \ALT_INV_IO_ADDR[2]~input_o\,
	datac => \timers:3:channel|ALT_INV_periods_r\(3),
	datad => \timers:0:channel|ALT_INV_periods_r\(3),
	dataf => \timers:1:channel|ALT_INV_periods_r\(3),
	combout => \read_value[3]~12_combout\);

-- Location: MLABCELL_X21_Y68_N51
\read_value[3]~13\ : cyclonev_lcell_comb
-- Equation(s):
-- \read_value[3]~13_combout\ = ( \read_value[3]~12_combout\ & ( (!\read_value[0]~0_combout\ & (\read_value[0]~1_combout\)) # (\read_value[0]~0_combout\ & ((!\read_value[0]~1_combout\ & (\timers:2:channel|periods_r\(3))) # (\read_value[0]~1_combout\ & 
-- ((\read_value[3]~11_combout\))))) ) ) # ( !\read_value[3]~12_combout\ & ( (\read_value[0]~0_combout\ & ((!\read_value[0]~1_combout\ & (\timers:2:channel|periods_r\(3))) # (\read_value[0]~1_combout\ & ((\read_value[3]~11_combout\))))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000010000010101000001000001010100100110001101110010011000110111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_read_value[0]~0_combout\,
	datab => \ALT_INV_read_value[0]~1_combout\,
	datac => \timers:2:channel|ALT_INV_periods_r\(3),
	datad => \ALT_INV_read_value[3]~11_combout\,
	dataf => \ALT_INV_read_value[3]~12_combout\,
	combout => \read_value[3]~13_combout\);

-- Location: LABCELL_X22_Y64_N12
\timers:3:channel|Add1~17\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|Add1~17_sumout\ = SUM(( \timers:3:channel|periods_r\(4) ) + ( GND ) + ( \timers:3:channel|Add1~14\ ))
-- \timers:3:channel|Add1~18\ = CARRY(( \timers:3:channel|periods_r\(4) ) + ( GND ) + ( \timers:3:channel|Add1~14\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \timers:3:channel|ALT_INV_periods_r\(4),
	cin => \timers:3:channel|Add1~14\,
	sumout => \timers:3:channel|Add1~17_sumout\,
	cout => \timers:3:channel|Add1~18\);

-- Location: FF_X22_Y64_N14
\timers:3:channel|periods_r[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:3:channel|Add1~17_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:3:channel|elapsed_r[9]~4_combout\,
	ena => \timers:3:channel|periods_r[13]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:3:channel|periods_r\(4));

-- Location: LABCELL_X23_Y69_N12
\timers:0:channel|Add1~17\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|Add1~17_sumout\ = SUM(( \timers:0:channel|periods_r\(4) ) + ( GND ) + ( \timers:0:channel|Add1~14\ ))
-- \timers:0:channel|Add1~18\ = CARRY(( \timers:0:channel|periods_r\(4) ) + ( GND ) + ( \timers:0:channel|Add1~14\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \timers:0:channel|ALT_INV_periods_r\(4),
	cin => \timers:0:channel|Add1~14\,
	sumout => \timers:0:channel|Add1~17_sumout\,
	cout => \timers:0:channel|Add1~18\);

-- Location: FF_X23_Y69_N14
\timers:0:channel|periods_r[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:0:channel|Add1~17_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:0:channel|elapsed_r[2]~4_combout\,
	ena => \timers:0:channel|periods_r[7]~2_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:0:channel|periods_r\(4));

-- Location: MLABCELL_X25_Y68_N12
\timers:1:channel|Add1~17\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|Add1~17_sumout\ = SUM(( \timers:1:channel|periods_r\(4) ) + ( GND ) + ( \timers:1:channel|Add1~14\ ))
-- \timers:1:channel|Add1~18\ = CARRY(( \timers:1:channel|periods_r\(4) ) + ( GND ) + ( \timers:1:channel|Add1~14\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \timers:1:channel|ALT_INV_periods_r\(4),
	cin => \timers:1:channel|Add1~14\,
	sumout => \timers:1:channel|Add1~17_sumout\,
	cout => \timers:1:channel|Add1~18\);

-- Location: FF_X25_Y68_N14
\timers:1:channel|periods_r[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:1:channel|Add1~17_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:1:channel|elapsed_r[14]~4_combout\,
	ena => \timers:1:channel|periods_r[14]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:1:channel|periods_r\(4));

-- Location: LABCELL_X23_Y64_N27
\read_value[4]~15\ : cyclonev_lcell_comb
-- Equation(s):
-- \read_value[4]~15_combout\ = ( \timers:0:channel|periods_r\(4) & ( \timers:1:channel|periods_r\(4) & ( (!\IO_ADDR[3]~input_o\) # (\timers:3:channel|periods_r\(4)) ) ) ) # ( !\timers:0:channel|periods_r\(4) & ( \timers:1:channel|periods_r\(4) & ( 
-- (!\IO_ADDR[3]~input_o\ & (\IO_ADDR[2]~input_o\)) # (\IO_ADDR[3]~input_o\ & ((\timers:3:channel|periods_r\(4)))) ) ) ) # ( \timers:0:channel|periods_r\(4) & ( !\timers:1:channel|periods_r\(4) & ( (!\IO_ADDR[3]~input_o\ & (!\IO_ADDR[2]~input_o\)) # 
-- (\IO_ADDR[3]~input_o\ & ((\timers:3:channel|periods_r\(4)))) ) ) ) # ( !\timers:0:channel|periods_r\(4) & ( !\timers:1:channel|periods_r\(4) & ( (\IO_ADDR[3]~input_o\ & \timers:3:channel|periods_r\(4)) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000110011110000001111001100001100001111111100110011111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \ALT_INV_IO_ADDR[3]~input_o\,
	datac => \ALT_INV_IO_ADDR[2]~input_o\,
	datad => \timers:3:channel|ALT_INV_periods_r\(4),
	datae => \timers:0:channel|ALT_INV_periods_r\(4),
	dataf => \timers:1:channel|ALT_INV_periods_r\(4),
	combout => \read_value[4]~15_combout\);

-- Location: MLABCELL_X21_Y68_N12
\timers:2:channel|Add1~17\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|Add1~17_sumout\ = SUM(( \timers:2:channel|periods_r\(4) ) + ( GND ) + ( \timers:2:channel|Add1~14\ ))
-- \timers:2:channel|Add1~18\ = CARRY(( \timers:2:channel|periods_r\(4) ) + ( GND ) + ( \timers:2:channel|Add1~14\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \timers:2:channel|ALT_INV_periods_r\(4),
	cin => \timers:2:channel|Add1~14\,
	sumout => \timers:2:channel|Add1~17_sumout\,
	cout => \timers:2:channel|Add1~18\);

-- Location: FF_X21_Y68_N14
\timers:2:channel|periods_r[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:2:channel|Add1~17_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:2:channel|elapsed_r[6]~0_combout\,
	ena => \timers:2:channel|periods_r[5]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:2:channel|periods_r\(4));

-- Location: LABCELL_X23_Y64_N54
\read_value[4]~14\ : cyclonev_lcell_comb
-- Equation(s):
-- \read_value[4]~14_combout\ = ( \IO_ADDR[3]~input_o\ & ( \IO_ADDR[2]~input_o\ & ( \timers:3:channel|elapsed_r\(4) ) ) ) # ( !\IO_ADDR[3]~input_o\ & ( \IO_ADDR[2]~input_o\ & ( \timers:1:channel|elapsed_r\(4) ) ) ) # ( \IO_ADDR[3]~input_o\ & ( 
-- !\IO_ADDR[2]~input_o\ & ( \timers:2:channel|elapsed_r\(4) ) ) ) # ( !\IO_ADDR[3]~input_o\ & ( !\IO_ADDR[2]~input_o\ & ( \timers:0:channel|elapsed_r\(4) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000011111111010101010101010100001111000011110011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:2:channel|ALT_INV_elapsed_r\(4),
	datab => \timers:3:channel|ALT_INV_elapsed_r\(4),
	datac => \timers:1:channel|ALT_INV_elapsed_r\(4),
	datad => \timers:0:channel|ALT_INV_elapsed_r\(4),
	datae => \ALT_INV_IO_ADDR[3]~input_o\,
	dataf => \ALT_INV_IO_ADDR[2]~input_o\,
	combout => \read_value[4]~14_combout\);

-- Location: LABCELL_X23_Y64_N36
\read_value[4]~16\ : cyclonev_lcell_comb
-- Equation(s):
-- \read_value[4]~16_combout\ = ( \read_value[4]~14_combout\ & ( \read_value[0]~1_combout\ & ( (\read_value[0]~0_combout\) # (\read_value[4]~15_combout\) ) ) ) # ( !\read_value[4]~14_combout\ & ( \read_value[0]~1_combout\ & ( (\read_value[4]~15_combout\ & 
-- !\read_value[0]~0_combout\) ) ) ) # ( \read_value[4]~14_combout\ & ( !\read_value[0]~1_combout\ & ( (\read_value[0]~0_combout\ & \timers:2:channel|periods_r\(4)) ) ) ) # ( !\read_value[4]~14_combout\ & ( !\read_value[0]~1_combout\ & ( 
-- (\read_value[0]~0_combout\ & \timers:2:channel|periods_r\(4)) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000001100000011000000110000001101000100010001000111011101110111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_read_value[4]~15_combout\,
	datab => \ALT_INV_read_value[0]~0_combout\,
	datac => \timers:2:channel|ALT_INV_periods_r\(4),
	datae => \ALT_INV_read_value[4]~14_combout\,
	dataf => \ALT_INV_read_value[0]~1_combout\,
	combout => \read_value[4]~16_combout\);

-- Location: LABCELL_X22_Y77_N24
\read_value[5]~17\ : cyclonev_lcell_comb
-- Equation(s):
-- \read_value[5]~17_combout\ = ( \IO_ADDR[3]~input_o\ & ( \timers:0:channel|elapsed_r\(5) & ( (!\IO_ADDR[2]~input_o\ & ((\timers:2:channel|elapsed_r\(5)))) # (\IO_ADDR[2]~input_o\ & (\timers:3:channel|elapsed_r\(5))) ) ) ) # ( !\IO_ADDR[3]~input_o\ & ( 
-- \timers:0:channel|elapsed_r\(5) & ( (!\IO_ADDR[2]~input_o\) # (\timers:1:channel|elapsed_r\(5)) ) ) ) # ( \IO_ADDR[3]~input_o\ & ( !\timers:0:channel|elapsed_r\(5) & ( (!\IO_ADDR[2]~input_o\ & ((\timers:2:channel|elapsed_r\(5)))) # (\IO_ADDR[2]~input_o\ & 
-- (\timers:3:channel|elapsed_r\(5))) ) ) ) # ( !\IO_ADDR[3]~input_o\ & ( !\timers:0:channel|elapsed_r\(5) & ( (\timers:1:channel|elapsed_r\(5) & \IO_ADDR[2]~input_o\) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0001000100010001000000111100111111011101110111010000001111001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:1:channel|ALT_INV_elapsed_r\(5),
	datab => \ALT_INV_IO_ADDR[2]~input_o\,
	datac => \timers:3:channel|ALT_INV_elapsed_r\(5),
	datad => \timers:2:channel|ALT_INV_elapsed_r\(5),
	datae => \ALT_INV_IO_ADDR[3]~input_o\,
	dataf => \timers:0:channel|ALT_INV_elapsed_r\(5),
	combout => \read_value[5]~17_combout\);

-- Location: LABCELL_X23_Y69_N15
\timers:0:channel|Add1~21\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|Add1~21_sumout\ = SUM(( \timers:0:channel|periods_r\(5) ) + ( GND ) + ( \timers:0:channel|Add1~18\ ))
-- \timers:0:channel|Add1~22\ = CARRY(( \timers:0:channel|periods_r\(5) ) + ( GND ) + ( \timers:0:channel|Add1~18\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:0:channel|ALT_INV_periods_r\(5),
	cin => \timers:0:channel|Add1~18\,
	sumout => \timers:0:channel|Add1~21_sumout\,
	cout => \timers:0:channel|Add1~22\);

-- Location: FF_X23_Y69_N17
\timers:0:channel|periods_r[5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:0:channel|Add1~21_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:0:channel|elapsed_r[2]~4_combout\,
	ena => \timers:0:channel|periods_r[7]~2_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:0:channel|periods_r\(5));

-- Location: MLABCELL_X25_Y68_N15
\timers:1:channel|Add1~21\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|Add1~21_sumout\ = SUM(( \timers:1:channel|periods_r\(5) ) + ( GND ) + ( \timers:1:channel|Add1~18\ ))
-- \timers:1:channel|Add1~22\ = CARRY(( \timers:1:channel|periods_r\(5) ) + ( GND ) + ( \timers:1:channel|Add1~18\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:1:channel|ALT_INV_periods_r\(5),
	cin => \timers:1:channel|Add1~18\,
	sumout => \timers:1:channel|Add1~21_sumout\,
	cout => \timers:1:channel|Add1~22\);

-- Location: FF_X25_Y68_N17
\timers:1:channel|periods_r[5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:1:channel|Add1~21_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:1:channel|elapsed_r[14]~4_combout\,
	ena => \timers:1:channel|periods_r[14]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:1:channel|periods_r\(5));

-- Location: LABCELL_X22_Y64_N15
\timers:3:channel|Add1~21\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|Add1~21_sumout\ = SUM(( \timers:3:channel|periods_r\(5) ) + ( GND ) + ( \timers:3:channel|Add1~18\ ))
-- \timers:3:channel|Add1~22\ = CARRY(( \timers:3:channel|periods_r\(5) ) + ( GND ) + ( \timers:3:channel|Add1~18\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:3:channel|ALT_INV_periods_r\(5),
	cin => \timers:3:channel|Add1~18\,
	sumout => \timers:3:channel|Add1~21_sumout\,
	cout => \timers:3:channel|Add1~22\);

-- Location: FF_X22_Y64_N17
\timers:3:channel|periods_r[5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:3:channel|Add1~21_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:3:channel|elapsed_r[9]~4_combout\,
	ena => \timers:3:channel|periods_r[13]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:3:channel|periods_r\(5));

-- Location: LABCELL_X22_Y68_N48
\read_value[5]~18\ : cyclonev_lcell_comb
-- Equation(s):
-- \read_value[5]~18_combout\ = ( \timers:3:channel|periods_r\(5) & ( \IO_ADDR[3]~input_o\ ) ) # ( \timers:3:channel|periods_r\(5) & ( !\IO_ADDR[3]~input_o\ & ( (!\IO_ADDR[2]~input_o\ & (\timers:0:channel|periods_r\(5))) # (\IO_ADDR[2]~input_o\ & 
-- ((\timers:1:channel|periods_r\(5)))) ) ) ) # ( !\timers:3:channel|periods_r\(5) & ( !\IO_ADDR[3]~input_o\ & ( (!\IO_ADDR[2]~input_o\ & (\timers:0:channel|periods_r\(5))) # (\IO_ADDR[2]~input_o\ & ((\timers:1:channel|periods_r\(5)))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0100011101000111010001110100011100000000000000001111111111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:0:channel|ALT_INV_periods_r\(5),
	datab => \ALT_INV_IO_ADDR[2]~input_o\,
	datac => \timers:1:channel|ALT_INV_periods_r\(5),
	datae => \timers:3:channel|ALT_INV_periods_r\(5),
	dataf => \ALT_INV_IO_ADDR[3]~input_o\,
	combout => \read_value[5]~18_combout\);

-- Location: MLABCELL_X21_Y68_N15
\timers:2:channel|Add1~21\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|Add1~21_sumout\ = SUM(( \timers:2:channel|periods_r\(5) ) + ( GND ) + ( \timers:2:channel|Add1~18\ ))
-- \timers:2:channel|Add1~22\ = CARRY(( \timers:2:channel|periods_r\(5) ) + ( GND ) + ( \timers:2:channel|Add1~18\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:2:channel|ALT_INV_periods_r\(5),
	cin => \timers:2:channel|Add1~18\,
	sumout => \timers:2:channel|Add1~21_sumout\,
	cout => \timers:2:channel|Add1~22\);

-- Location: FF_X21_Y68_N17
\timers:2:channel|periods_r[5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:2:channel|Add1~21_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:2:channel|elapsed_r[6]~0_combout\,
	ena => \timers:2:channel|periods_r[5]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:2:channel|periods_r\(5));

-- Location: MLABCELL_X21_Y68_N48
\read_value[5]~19\ : cyclonev_lcell_comb
-- Equation(s):
-- \read_value[5]~19_combout\ = ( \timers:2:channel|periods_r\(5) & ( (!\read_value[0]~0_combout\ & (\read_value[0]~1_combout\ & ((\read_value[5]~18_combout\)))) # (\read_value[0]~0_combout\ & ((!\read_value[0]~1_combout\) # ((\read_value[5]~17_combout\)))) 
-- ) ) # ( !\timers:2:channel|periods_r\(5) & ( (\read_value[0]~1_combout\ & ((!\read_value[0]~0_combout\ & ((\read_value[5]~18_combout\))) # (\read_value[0]~0_combout\ & (\read_value[5]~17_combout\)))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000100100011000000010010001101000101011001110100010101100111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_read_value[0]~0_combout\,
	datab => \ALT_INV_read_value[0]~1_combout\,
	datac => \ALT_INV_read_value[5]~17_combout\,
	datad => \ALT_INV_read_value[5]~18_combout\,
	dataf => \timers:2:channel|ALT_INV_periods_r\(5),
	combout => \read_value[5]~19_combout\);

-- Location: LABCELL_X23_Y69_N18
\timers:0:channel|Add1~25\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|Add1~25_sumout\ = SUM(( \timers:0:channel|periods_r\(6) ) + ( GND ) + ( \timers:0:channel|Add1~22\ ))
-- \timers:0:channel|Add1~26\ = CARRY(( \timers:0:channel|periods_r\(6) ) + ( GND ) + ( \timers:0:channel|Add1~22\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:0:channel|ALT_INV_periods_r\(6),
	cin => \timers:0:channel|Add1~22\,
	sumout => \timers:0:channel|Add1~25_sumout\,
	cout => \timers:0:channel|Add1~26\);

-- Location: FF_X23_Y69_N20
\timers:0:channel|periods_r[6]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:0:channel|Add1~25_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:0:channel|elapsed_r[2]~4_combout\,
	ena => \timers:0:channel|periods_r[7]~2_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:0:channel|periods_r\(6));

-- Location: LABCELL_X22_Y64_N18
\timers:3:channel|Add1~25\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|Add1~25_sumout\ = SUM(( \timers:3:channel|periods_r\(6) ) + ( GND ) + ( \timers:3:channel|Add1~22\ ))
-- \timers:3:channel|Add1~26\ = CARRY(( \timers:3:channel|periods_r\(6) ) + ( GND ) + ( \timers:3:channel|Add1~22\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:3:channel|ALT_INV_periods_r\(6),
	cin => \timers:3:channel|Add1~22\,
	sumout => \timers:3:channel|Add1~25_sumout\,
	cout => \timers:3:channel|Add1~26\);

-- Location: FF_X22_Y64_N20
\timers:3:channel|periods_r[6]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:3:channel|Add1~25_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:3:channel|elapsed_r[9]~4_combout\,
	ena => \timers:3:channel|periods_r[13]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:3:channel|periods_r\(6));

-- Location: MLABCELL_X25_Y68_N18
\timers:1:channel|Add1~25\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|Add1~25_sumout\ = SUM(( \timers:1:channel|periods_r\(6) ) + ( GND ) + ( \timers:1:channel|Add1~22\ ))
-- \timers:1:channel|Add1~26\ = CARRY(( \timers:1:channel|periods_r\(6) ) + ( GND ) + ( \timers:1:channel|Add1~22\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:1:channel|ALT_INV_periods_r\(6),
	cin => \timers:1:channel|Add1~22\,
	sumout => \timers:1:channel|Add1~25_sumout\,
	cout => \timers:1:channel|Add1~26\);

-- Location: FF_X25_Y68_N20
\timers:1:channel|periods_r[6]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:1:channel|Add1~25_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:1:channel|elapsed_r[14]~4_combout\,
	ena => \timers:1:channel|periods_r[14]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:1:channel|periods_r\(6));

-- Location: MLABCELL_X25_Y68_N48
\read_value[6]~21\ : cyclonev_lcell_comb
-- Equation(s):
-- \read_value[6]~21_combout\ = ( \timers:1:channel|periods_r\(6) & ( (!\IO_ADDR[3]~input_o\ & (((\timers:0:channel|periods_r\(6))) # (\IO_ADDR[2]~input_o\))) # (\IO_ADDR[3]~input_o\ & (((\timers:3:channel|periods_r\(6))))) ) ) # ( 
-- !\timers:1:channel|periods_r\(6) & ( (!\IO_ADDR[3]~input_o\ & (!\IO_ADDR[2]~input_o\ & (\timers:0:channel|periods_r\(6)))) # (\IO_ADDR[3]~input_o\ & (((\timers:3:channel|periods_r\(6))))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000100001011101000010000101110100101010011111110010101001111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_IO_ADDR[3]~input_o\,
	datab => \ALT_INV_IO_ADDR[2]~input_o\,
	datac => \timers:0:channel|ALT_INV_periods_r\(6),
	datad => \timers:3:channel|ALT_INV_periods_r\(6),
	dataf => \timers:1:channel|ALT_INV_periods_r\(6),
	combout => \read_value[6]~21_combout\);

-- Location: MLABCELL_X21_Y68_N18
\timers:2:channel|Add1~25\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|Add1~25_sumout\ = SUM(( \timers:2:channel|periods_r\(6) ) + ( GND ) + ( \timers:2:channel|Add1~22\ ))
-- \timers:2:channel|Add1~26\ = CARRY(( \timers:2:channel|periods_r\(6) ) + ( GND ) + ( \timers:2:channel|Add1~22\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:2:channel|ALT_INV_periods_r\(6),
	cin => \timers:2:channel|Add1~22\,
	sumout => \timers:2:channel|Add1~25_sumout\,
	cout => \timers:2:channel|Add1~26\);

-- Location: FF_X21_Y68_N20
\timers:2:channel|periods_r[6]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:2:channel|Add1~25_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:2:channel|elapsed_r[6]~0_combout\,
	ena => \timers:2:channel|periods_r[5]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:2:channel|periods_r\(6));

-- Location: LABCELL_X24_Y67_N33
\read_value[6]~20\ : cyclonev_lcell_comb
-- Equation(s):
-- \read_value[6]~20_combout\ = ( \timers:1:channel|elapsed_r\(6) & ( \timers:0:channel|elapsed_r\(6) & ( (!\IO_ADDR[3]~input_o\) # ((!\IO_ADDR[2]~input_o\ & (\timers:2:channel|elapsed_r\(6))) # (\IO_ADDR[2]~input_o\ & ((\timers:3:channel|elapsed_r\(6))))) ) 
-- ) ) # ( !\timers:1:channel|elapsed_r\(6) & ( \timers:0:channel|elapsed_r\(6) & ( (!\IO_ADDR[2]~input_o\ & (((!\IO_ADDR[3]~input_o\)) # (\timers:2:channel|elapsed_r\(6)))) # (\IO_ADDR[2]~input_o\ & (((\IO_ADDR[3]~input_o\ & 
-- \timers:3:channel|elapsed_r\(6))))) ) ) ) # ( \timers:1:channel|elapsed_r\(6) & ( !\timers:0:channel|elapsed_r\(6) & ( (!\IO_ADDR[2]~input_o\ & (\timers:2:channel|elapsed_r\(6) & (\IO_ADDR[3]~input_o\))) # (\IO_ADDR[2]~input_o\ & (((!\IO_ADDR[3]~input_o\) 
-- # (\timers:3:channel|elapsed_r\(6))))) ) ) ) # ( !\timers:1:channel|elapsed_r\(6) & ( !\timers:0:channel|elapsed_r\(6) & ( (\IO_ADDR[3]~input_o\ & ((!\IO_ADDR[2]~input_o\ & (\timers:2:channel|elapsed_r\(6))) # (\IO_ADDR[2]~input_o\ & 
-- ((\timers:3:channel|elapsed_r\(6)))))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000010000000111001101000011011111000100110001111111010011110111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:2:channel|ALT_INV_elapsed_r\(6),
	datab => \ALT_INV_IO_ADDR[2]~input_o\,
	datac => \ALT_INV_IO_ADDR[3]~input_o\,
	datad => \timers:3:channel|ALT_INV_elapsed_r\(6),
	datae => \timers:1:channel|ALT_INV_elapsed_r\(6),
	dataf => \timers:0:channel|ALT_INV_elapsed_r\(6),
	combout => \read_value[6]~20_combout\);

-- Location: LABCELL_X22_Y68_N45
\read_value[6]~22\ : cyclonev_lcell_comb
-- Equation(s):
-- \read_value[6]~22_combout\ = ( \read_value[6]~20_combout\ & ( (!\read_value[0]~1_combout\ & (((\timers:2:channel|periods_r\(6) & \read_value[0]~0_combout\)))) # (\read_value[0]~1_combout\ & (((\read_value[0]~0_combout\)) # (\read_value[6]~21_combout\))) ) 
-- ) # ( !\read_value[6]~20_combout\ & ( (!\read_value[0]~1_combout\ & (((\timers:2:channel|periods_r\(6) & \read_value[0]~0_combout\)))) # (\read_value[0]~1_combout\ & (\read_value[6]~21_combout\ & ((!\read_value[0]~0_combout\)))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0001000100001100000100010000110000010001001111110001000100111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_read_value[6]~21_combout\,
	datab => \ALT_INV_read_value[0]~1_combout\,
	datac => \timers:2:channel|ALT_INV_periods_r\(6),
	datad => \ALT_INV_read_value[0]~0_combout\,
	dataf => \ALT_INV_read_value[6]~20_combout\,
	combout => \read_value[6]~22_combout\);

-- Location: LABCELL_X22_Y68_N24
\read_value[7]~23\ : cyclonev_lcell_comb
-- Equation(s):
-- \read_value[7]~23_combout\ = ( \IO_ADDR[2]~input_o\ & ( \IO_ADDR[3]~input_o\ & ( \timers:3:channel|elapsed_r\(7) ) ) ) # ( !\IO_ADDR[2]~input_o\ & ( \IO_ADDR[3]~input_o\ & ( \timers:2:channel|elapsed_r\(7) ) ) ) # ( \IO_ADDR[2]~input_o\ & ( 
-- !\IO_ADDR[3]~input_o\ & ( \timers:1:channel|elapsed_r\(7) ) ) ) # ( !\IO_ADDR[2]~input_o\ & ( !\IO_ADDR[3]~input_o\ & ( \timers:0:channel|elapsed_r\(7) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000111100001111010101010101010100110011001100110000000011111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:1:channel|ALT_INV_elapsed_r\(7),
	datab => \timers:2:channel|ALT_INV_elapsed_r\(7),
	datac => \timers:0:channel|ALT_INV_elapsed_r\(7),
	datad => \timers:3:channel|ALT_INV_elapsed_r\(7),
	datae => \ALT_INV_IO_ADDR[2]~input_o\,
	dataf => \ALT_INV_IO_ADDR[3]~input_o\,
	combout => \read_value[7]~23_combout\);

-- Location: MLABCELL_X21_Y68_N21
\timers:2:channel|Add1~29\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|Add1~29_sumout\ = SUM(( \timers:2:channel|periods_r\(7) ) + ( GND ) + ( \timers:2:channel|Add1~26\ ))
-- \timers:2:channel|Add1~30\ = CARRY(( \timers:2:channel|periods_r\(7) ) + ( GND ) + ( \timers:2:channel|Add1~26\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000101010101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:2:channel|ALT_INV_periods_r\(7),
	cin => \timers:2:channel|Add1~26\,
	sumout => \timers:2:channel|Add1~29_sumout\,
	cout => \timers:2:channel|Add1~30\);

-- Location: FF_X21_Y68_N23
\timers:2:channel|periods_r[7]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:2:channel|Add1~29_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:2:channel|elapsed_r[6]~0_combout\,
	ena => \timers:2:channel|periods_r[5]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:2:channel|periods_r\(7));

-- Location: LABCELL_X23_Y69_N21
\timers:0:channel|Add1~29\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|Add1~29_sumout\ = SUM(( \timers:0:channel|periods_r\(7) ) + ( GND ) + ( \timers:0:channel|Add1~26\ ))
-- \timers:0:channel|Add1~30\ = CARRY(( \timers:0:channel|periods_r\(7) ) + ( GND ) + ( \timers:0:channel|Add1~26\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000101010101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:0:channel|ALT_INV_periods_r\(7),
	cin => \timers:0:channel|Add1~26\,
	sumout => \timers:0:channel|Add1~29_sumout\,
	cout => \timers:0:channel|Add1~30\);

-- Location: FF_X23_Y69_N23
\timers:0:channel|periods_r[7]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:0:channel|Add1~29_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:0:channel|elapsed_r[2]~4_combout\,
	ena => \timers:0:channel|periods_r[7]~2_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:0:channel|periods_r\(7));

-- Location: LABCELL_X22_Y64_N21
\timers:3:channel|Add1~29\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|Add1~29_sumout\ = SUM(( \timers:3:channel|periods_r\(7) ) + ( GND ) + ( \timers:3:channel|Add1~26\ ))
-- \timers:3:channel|Add1~30\ = CARRY(( \timers:3:channel|periods_r\(7) ) + ( GND ) + ( \timers:3:channel|Add1~26\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000101010101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:3:channel|ALT_INV_periods_r\(7),
	cin => \timers:3:channel|Add1~26\,
	sumout => \timers:3:channel|Add1~29_sumout\,
	cout => \timers:3:channel|Add1~30\);

-- Location: FF_X22_Y64_N23
\timers:3:channel|periods_r[7]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:3:channel|Add1~29_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:3:channel|elapsed_r[9]~4_combout\,
	ena => \timers:3:channel|periods_r[13]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:3:channel|periods_r\(7));

-- Location: MLABCELL_X25_Y68_N21
\timers:1:channel|Add1~29\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|Add1~29_sumout\ = SUM(( \timers:1:channel|periods_r\(7) ) + ( GND ) + ( \timers:1:channel|Add1~26\ ))
-- \timers:1:channel|Add1~30\ = CARRY(( \timers:1:channel|periods_r\(7) ) + ( GND ) + ( \timers:1:channel|Add1~26\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000101010101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:1:channel|ALT_INV_periods_r\(7),
	cin => \timers:1:channel|Add1~26\,
	sumout => \timers:1:channel|Add1~29_sumout\,
	cout => \timers:1:channel|Add1~30\);

-- Location: FF_X25_Y68_N23
\timers:1:channel|periods_r[7]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:1:channel|Add1~29_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:1:channel|elapsed_r[14]~4_combout\,
	ena => \timers:1:channel|periods_r[14]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:1:channel|periods_r\(7));

-- Location: LABCELL_X22_Y68_N6
\read_value[7]~24\ : cyclonev_lcell_comb
-- Equation(s):
-- \read_value[7]~24_combout\ = ( \timers:3:channel|periods_r\(7) & ( \timers:1:channel|periods_r\(7) & ( ((\IO_ADDR[2]~input_o\) # (\timers:0:channel|periods_r\(7))) # (\IO_ADDR[3]~input_o\) ) ) ) # ( !\timers:3:channel|periods_r\(7) & ( 
-- \timers:1:channel|periods_r\(7) & ( (!\IO_ADDR[3]~input_o\ & ((\IO_ADDR[2]~input_o\) # (\timers:0:channel|periods_r\(7)))) ) ) ) # ( \timers:3:channel|periods_r\(7) & ( !\timers:1:channel|periods_r\(7) & ( ((\timers:0:channel|periods_r\(7) & 
-- !\IO_ADDR[2]~input_o\)) # (\IO_ADDR[3]~input_o\) ) ) ) # ( !\timers:3:channel|periods_r\(7) & ( !\timers:1:channel|periods_r\(7) & ( (!\IO_ADDR[3]~input_o\ & (\timers:0:channel|periods_r\(7) & !\IO_ADDR[2]~input_o\)) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0010000000100000011101010111010100101010001010100111111101111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_IO_ADDR[3]~input_o\,
	datab => \timers:0:channel|ALT_INV_periods_r\(7),
	datac => \ALT_INV_IO_ADDR[2]~input_o\,
	datae => \timers:3:channel|ALT_INV_periods_r\(7),
	dataf => \timers:1:channel|ALT_INV_periods_r\(7),
	combout => \read_value[7]~24_combout\);

-- Location: LABCELL_X22_Y68_N36
\read_value[7]~25\ : cyclonev_lcell_comb
-- Equation(s):
-- \read_value[7]~25_combout\ = ( \read_value[7]~24_combout\ & ( (!\read_value[0]~0_combout\ & (\read_value[0]~1_combout\)) # (\read_value[0]~0_combout\ & ((!\read_value[0]~1_combout\ & ((\timers:2:channel|periods_r\(7)))) # (\read_value[0]~1_combout\ & 
-- (\read_value[7]~23_combout\)))) ) ) # ( !\read_value[7]~24_combout\ & ( (\read_value[0]~0_combout\ & ((!\read_value[0]~1_combout\ & ((\timers:2:channel|periods_r\(7)))) # (\read_value[0]~1_combout\ & (\read_value[7]~23_combout\)))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000101000101000000010100010100100011011001110010001101100111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_read_value[0]~0_combout\,
	datab => \ALT_INV_read_value[0]~1_combout\,
	datac => \ALT_INV_read_value[7]~23_combout\,
	datad => \timers:2:channel|ALT_INV_periods_r\(7),
	dataf => \ALT_INV_read_value[7]~24_combout\,
	combout => \read_value[7]~25_combout\);

-- Location: MLABCELL_X21_Y68_N24
\timers:2:channel|Add1~33\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|Add1~33_sumout\ = SUM(( \timers:2:channel|periods_r\(8) ) + ( GND ) + ( \timers:2:channel|Add1~30\ ))
-- \timers:2:channel|Add1~34\ = CARRY(( \timers:2:channel|periods_r\(8) ) + ( GND ) + ( \timers:2:channel|Add1~30\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:2:channel|ALT_INV_periods_r\(8),
	cin => \timers:2:channel|Add1~30\,
	sumout => \timers:2:channel|Add1~33_sumout\,
	cout => \timers:2:channel|Add1~34\);

-- Location: FF_X21_Y68_N26
\timers:2:channel|periods_r[8]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:2:channel|Add1~33_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:2:channel|elapsed_r[6]~0_combout\,
	ena => \timers:2:channel|periods_r[5]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:2:channel|periods_r\(8));

-- Location: LABCELL_X22_Y64_N24
\timers:3:channel|Add1~33\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|Add1~33_sumout\ = SUM(( \timers:3:channel|periods_r\(8) ) + ( GND ) + ( \timers:3:channel|Add1~30\ ))
-- \timers:3:channel|Add1~34\ = CARRY(( \timers:3:channel|periods_r\(8) ) + ( GND ) + ( \timers:3:channel|Add1~30\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:3:channel|ALT_INV_periods_r\(8),
	cin => \timers:3:channel|Add1~30\,
	sumout => \timers:3:channel|Add1~33_sumout\,
	cout => \timers:3:channel|Add1~34\);

-- Location: FF_X22_Y64_N26
\timers:3:channel|periods_r[8]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:3:channel|Add1~33_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:3:channel|elapsed_r[9]~4_combout\,
	ena => \timers:3:channel|periods_r[13]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:3:channel|periods_r\(8));

-- Location: MLABCELL_X25_Y68_N24
\timers:1:channel|Add1~33\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|Add1~33_sumout\ = SUM(( \timers:1:channel|periods_r\(8) ) + ( GND ) + ( \timers:1:channel|Add1~30\ ))
-- \timers:1:channel|Add1~34\ = CARRY(( \timers:1:channel|periods_r\(8) ) + ( GND ) + ( \timers:1:channel|Add1~30\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:1:channel|ALT_INV_periods_r\(8),
	cin => \timers:1:channel|Add1~30\,
	sumout => \timers:1:channel|Add1~33_sumout\,
	cout => \timers:1:channel|Add1~34\);

-- Location: FF_X25_Y68_N26
\timers:1:channel|periods_r[8]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:1:channel|Add1~33_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:1:channel|elapsed_r[14]~4_combout\,
	ena => \timers:1:channel|periods_r[14]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:1:channel|periods_r\(8));

-- Location: LABCELL_X23_Y69_N24
\timers:0:channel|Add1~33\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|Add1~33_sumout\ = SUM(( \timers:0:channel|periods_r\(8) ) + ( GND ) + ( \timers:0:channel|Add1~30\ ))
-- \timers:0:channel|Add1~34\ = CARRY(( \timers:0:channel|periods_r\(8) ) + ( GND ) + ( \timers:0:channel|Add1~30\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:0:channel|ALT_INV_periods_r\(8),
	cin => \timers:0:channel|Add1~30\,
	sumout => \timers:0:channel|Add1~33_sumout\,
	cout => \timers:0:channel|Add1~34\);

-- Location: FF_X23_Y69_N26
\timers:0:channel|periods_r[8]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:0:channel|Add1~33_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:0:channel|elapsed_r[2]~4_combout\,
	ena => \timers:0:channel|periods_r[7]~2_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:0:channel|periods_r\(8));

-- Location: LABCELL_X23_Y65_N51
\read_value[8]~27\ : cyclonev_lcell_comb
-- Equation(s):
-- \read_value[8]~27_combout\ = ( \timers:1:channel|periods_r\(8) & ( \timers:0:channel|periods_r\(8) & ( (!\IO_ADDR[3]~input_o\) # (\timers:3:channel|periods_r\(8)) ) ) ) # ( !\timers:1:channel|periods_r\(8) & ( \timers:0:channel|periods_r\(8) & ( 
-- (!\IO_ADDR[3]~input_o\ & (!\IO_ADDR[2]~input_o\)) # (\IO_ADDR[3]~input_o\ & ((\timers:3:channel|periods_r\(8)))) ) ) ) # ( \timers:1:channel|periods_r\(8) & ( !\timers:0:channel|periods_r\(8) & ( (!\IO_ADDR[3]~input_o\ & (\IO_ADDR[2]~input_o\)) # 
-- (\IO_ADDR[3]~input_o\ & ((\timers:3:channel|periods_r\(8)))) ) ) ) # ( !\timers:1:channel|periods_r\(8) & ( !\timers:0:channel|periods_r\(8) & ( (\IO_ADDR[3]~input_o\ & \timers:3:channel|periods_r\(8)) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000001010101000010100101111110100000111101011010101011111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_IO_ADDR[3]~input_o\,
	datac => \ALT_INV_IO_ADDR[2]~input_o\,
	datad => \timers:3:channel|ALT_INV_periods_r\(8),
	datae => \timers:1:channel|ALT_INV_periods_r\(8),
	dataf => \timers:0:channel|ALT_INV_periods_r\(8),
	combout => \read_value[8]~27_combout\);

-- Location: LABCELL_X23_Y65_N24
\read_value[8]~26\ : cyclonev_lcell_comb
-- Equation(s):
-- \read_value[8]~26_combout\ = ( \IO_ADDR[2]~input_o\ & ( \timers:2:channel|elapsed_r\(8) & ( (!\IO_ADDR[3]~input_o\ & ((\timers:1:channel|elapsed_r\(8)))) # (\IO_ADDR[3]~input_o\ & (\timers:3:channel|elapsed_r\(8))) ) ) ) # ( !\IO_ADDR[2]~input_o\ & ( 
-- \timers:2:channel|elapsed_r\(8) & ( (\timers:0:channel|elapsed_r\(8)) # (\IO_ADDR[3]~input_o\) ) ) ) # ( \IO_ADDR[2]~input_o\ & ( !\timers:2:channel|elapsed_r\(8) & ( (!\IO_ADDR[3]~input_o\ & ((\timers:1:channel|elapsed_r\(8)))) # (\IO_ADDR[3]~input_o\ & 
-- (\timers:3:channel|elapsed_r\(8))) ) ) ) # ( !\IO_ADDR[2]~input_o\ & ( !\timers:2:channel|elapsed_r\(8) & ( (!\IO_ADDR[3]~input_o\ & \timers:0:channel|elapsed_r\(8)) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000011110000001101010011010100001111111111110011010100110101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:3:channel|ALT_INV_elapsed_r\(8),
	datab => \timers:1:channel|ALT_INV_elapsed_r\(8),
	datac => \ALT_INV_IO_ADDR[3]~input_o\,
	datad => \timers:0:channel|ALT_INV_elapsed_r\(8),
	datae => \ALT_INV_IO_ADDR[2]~input_o\,
	dataf => \timers:2:channel|ALT_INV_elapsed_r\(8),
	combout => \read_value[8]~26_combout\);

-- Location: LABCELL_X23_Y65_N42
\read_value[8]~28\ : cyclonev_lcell_comb
-- Equation(s):
-- \read_value[8]~28_combout\ = ( \read_value[0]~0_combout\ & ( \read_value[8]~26_combout\ & ( (\read_value[0]~1_combout\) # (\timers:2:channel|periods_r\(8)) ) ) ) # ( !\read_value[0]~0_combout\ & ( \read_value[8]~26_combout\ & ( (\read_value[8]~27_combout\ 
-- & \read_value[0]~1_combout\) ) ) ) # ( \read_value[0]~0_combout\ & ( !\read_value[8]~26_combout\ & ( (\timers:2:channel|periods_r\(8) & !\read_value[0]~1_combout\) ) ) ) # ( !\read_value[0]~0_combout\ & ( !\read_value[8]~26_combout\ & ( 
-- (\read_value[8]~27_combout\ & \read_value[0]~1_combout\) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000001111010101010000000000000000000011110101010111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:2:channel|ALT_INV_periods_r\(8),
	datac => \ALT_INV_read_value[8]~27_combout\,
	datad => \ALT_INV_read_value[0]~1_combout\,
	datae => \ALT_INV_read_value[0]~0_combout\,
	dataf => \ALT_INV_read_value[8]~26_combout\,
	combout => \read_value[8]~28_combout\);

-- Location: MLABCELL_X21_Y67_N54
\read_value[9]~29\ : cyclonev_lcell_comb
-- Equation(s):
-- \read_value[9]~29_combout\ = ( \IO_ADDR[2]~input_o\ & ( \timers:2:channel|elapsed_r\(9) & ( (!\IO_ADDR[3]~input_o\ & ((\timers:1:channel|elapsed_r\(9)))) # (\IO_ADDR[3]~input_o\ & (\timers:3:channel|elapsed_r\(9))) ) ) ) # ( !\IO_ADDR[2]~input_o\ & ( 
-- \timers:2:channel|elapsed_r\(9) & ( (\IO_ADDR[3]~input_o\) # (\timers:0:channel|elapsed_r\(9)) ) ) ) # ( \IO_ADDR[2]~input_o\ & ( !\timers:2:channel|elapsed_r\(9) & ( (!\IO_ADDR[3]~input_o\ & ((\timers:1:channel|elapsed_r\(9)))) # (\IO_ADDR[3]~input_o\ & 
-- (\timers:3:channel|elapsed_r\(9))) ) ) ) # ( !\IO_ADDR[2]~input_o\ & ( !\timers:2:channel|elapsed_r\(9) & ( (\timers:0:channel|elapsed_r\(9) & !\IO_ADDR[3]~input_o\) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000111100000000001100110101010100001111111111110011001101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:3:channel|ALT_INV_elapsed_r\(9),
	datab => \timers:1:channel|ALT_INV_elapsed_r\(9),
	datac => \timers:0:channel|ALT_INV_elapsed_r\(9),
	datad => \ALT_INV_IO_ADDR[3]~input_o\,
	datae => \ALT_INV_IO_ADDR[2]~input_o\,
	dataf => \timers:2:channel|ALT_INV_elapsed_r\(9),
	combout => \read_value[9]~29_combout\);

-- Location: MLABCELL_X21_Y68_N27
\timers:2:channel|Add1~37\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|Add1~37_sumout\ = SUM(( \timers:2:channel|periods_r\(9) ) + ( GND ) + ( \timers:2:channel|Add1~34\ ))
-- \timers:2:channel|Add1~38\ = CARRY(( \timers:2:channel|periods_r\(9) ) + ( GND ) + ( \timers:2:channel|Add1~34\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000101010101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:2:channel|ALT_INV_periods_r\(9),
	cin => \timers:2:channel|Add1~34\,
	sumout => \timers:2:channel|Add1~37_sumout\,
	cout => \timers:2:channel|Add1~38\);

-- Location: FF_X21_Y68_N29
\timers:2:channel|periods_r[9]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:2:channel|Add1~37_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:2:channel|elapsed_r[6]~0_combout\,
	ena => \timers:2:channel|periods_r[5]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:2:channel|periods_r\(9));

-- Location: LABCELL_X22_Y64_N27
\timers:3:channel|Add1~37\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|Add1~37_sumout\ = SUM(( \timers:3:channel|periods_r\(9) ) + ( GND ) + ( \timers:3:channel|Add1~34\ ))
-- \timers:3:channel|Add1~38\ = CARRY(( \timers:3:channel|periods_r\(9) ) + ( GND ) + ( \timers:3:channel|Add1~34\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000101010101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:3:channel|ALT_INV_periods_r\(9),
	cin => \timers:3:channel|Add1~34\,
	sumout => \timers:3:channel|Add1~37_sumout\,
	cout => \timers:3:channel|Add1~38\);

-- Location: FF_X22_Y64_N29
\timers:3:channel|periods_r[9]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:3:channel|Add1~37_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:3:channel|elapsed_r[9]~4_combout\,
	ena => \timers:3:channel|periods_r[13]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:3:channel|periods_r\(9));

-- Location: LABCELL_X23_Y69_N27
\timers:0:channel|Add1~37\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|Add1~37_sumout\ = SUM(( \timers:0:channel|periods_r\(9) ) + ( GND ) + ( \timers:0:channel|Add1~34\ ))
-- \timers:0:channel|Add1~38\ = CARRY(( \timers:0:channel|periods_r\(9) ) + ( GND ) + ( \timers:0:channel|Add1~34\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000101010101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:0:channel|ALT_INV_periods_r\(9),
	cin => \timers:0:channel|Add1~34\,
	sumout => \timers:0:channel|Add1~37_sumout\,
	cout => \timers:0:channel|Add1~38\);

-- Location: FF_X23_Y69_N29
\timers:0:channel|periods_r[9]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:0:channel|Add1~37_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:0:channel|elapsed_r[2]~4_combout\,
	ena => \timers:0:channel|periods_r[7]~2_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:0:channel|periods_r\(9));

-- Location: MLABCELL_X25_Y68_N27
\timers:1:channel|Add1~37\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|Add1~37_sumout\ = SUM(( \timers:1:channel|periods_r\(9) ) + ( GND ) + ( \timers:1:channel|Add1~34\ ))
-- \timers:1:channel|Add1~38\ = CARRY(( \timers:1:channel|periods_r\(9) ) + ( GND ) + ( \timers:1:channel|Add1~34\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000101010101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:1:channel|ALT_INV_periods_r\(9),
	cin => \timers:1:channel|Add1~34\,
	sumout => \timers:1:channel|Add1~37_sumout\,
	cout => \timers:1:channel|Add1~38\);

-- Location: FF_X25_Y68_N29
\timers:1:channel|periods_r[9]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:1:channel|Add1~37_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:1:channel|elapsed_r[14]~4_combout\,
	ena => \timers:1:channel|periods_r[14]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:1:channel|periods_r\(9));

-- Location: MLABCELL_X21_Y67_N48
\read_value[9]~30\ : cyclonev_lcell_comb
-- Equation(s):
-- \read_value[9]~30_combout\ = ( \timers:0:channel|periods_r\(9) & ( \timers:1:channel|periods_r\(9) & ( (!\IO_ADDR[3]~input_o\) # (\timers:3:channel|periods_r\(9)) ) ) ) # ( !\timers:0:channel|periods_r\(9) & ( \timers:1:channel|periods_r\(9) & ( 
-- (!\IO_ADDR[3]~input_o\ & ((\IO_ADDR[2]~input_o\))) # (\IO_ADDR[3]~input_o\ & (\timers:3:channel|periods_r\(9))) ) ) ) # ( \timers:0:channel|periods_r\(9) & ( !\timers:1:channel|periods_r\(9) & ( (!\IO_ADDR[3]~input_o\ & ((!\IO_ADDR[2]~input_o\))) # 
-- (\IO_ADDR[3]~input_o\ & (\timers:3:channel|periods_r\(9))) ) ) ) # ( !\timers:0:channel|periods_r\(9) & ( !\timers:1:channel|periods_r\(9) & ( (\timers:3:channel|periods_r\(9) & \IO_ADDR[3]~input_o\) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0001000100010001110100011101000100011101000111011101110111011101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:3:channel|ALT_INV_periods_r\(9),
	datab => \ALT_INV_IO_ADDR[3]~input_o\,
	datac => \ALT_INV_IO_ADDR[2]~input_o\,
	datae => \timers:0:channel|ALT_INV_periods_r\(9),
	dataf => \timers:1:channel|ALT_INV_periods_r\(9),
	combout => \read_value[9]~30_combout\);

-- Location: MLABCELL_X21_Y67_N36
\read_value[9]~31\ : cyclonev_lcell_comb
-- Equation(s):
-- \read_value[9]~31_combout\ = ( \read_value[9]~30_combout\ & ( (!\read_value[0]~0_combout\ & (\read_value[0]~1_combout\)) # (\read_value[0]~0_combout\ & ((!\read_value[0]~1_combout\ & ((\timers:2:channel|periods_r\(9)))) # (\read_value[0]~1_combout\ & 
-- (\read_value[9]~29_combout\)))) ) ) # ( !\read_value[9]~30_combout\ & ( (\read_value[0]~0_combout\ & ((!\read_value[0]~1_combout\ & ((\timers:2:channel|periods_r\(9)))) # (\read_value[0]~1_combout\ & (\read_value[9]~29_combout\)))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000101000101000000010100010100100011011001110010001101100111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_read_value[0]~0_combout\,
	datab => \ALT_INV_read_value[0]~1_combout\,
	datac => \ALT_INV_read_value[9]~29_combout\,
	datad => \timers:2:channel|ALT_INV_periods_r\(9),
	dataf => \ALT_INV_read_value[9]~30_combout\,
	combout => \read_value[9]~31_combout\);

-- Location: MLABCELL_X21_Y68_N30
\timers:2:channel|Add1~41\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|Add1~41_sumout\ = SUM(( \timers:2:channel|periods_r\(10) ) + ( GND ) + ( \timers:2:channel|Add1~38\ ))
-- \timers:2:channel|Add1~42\ = CARRY(( \timers:2:channel|periods_r\(10) ) + ( GND ) + ( \timers:2:channel|Add1~38\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \timers:2:channel|ALT_INV_periods_r\(10),
	cin => \timers:2:channel|Add1~38\,
	sumout => \timers:2:channel|Add1~41_sumout\,
	cout => \timers:2:channel|Add1~42\);

-- Location: FF_X21_Y68_N32
\timers:2:channel|periods_r[10]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:2:channel|Add1~41_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:2:channel|elapsed_r[6]~0_combout\,
	ena => \timers:2:channel|periods_r[5]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:2:channel|periods_r\(10));

-- Location: LABCELL_X22_Y64_N30
\timers:3:channel|Add1~41\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|Add1~41_sumout\ = SUM(( \timers:3:channel|periods_r\(10) ) + ( GND ) + ( \timers:3:channel|Add1~38\ ))
-- \timers:3:channel|Add1~42\ = CARRY(( \timers:3:channel|periods_r\(10) ) + ( GND ) + ( \timers:3:channel|Add1~38\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \timers:3:channel|ALT_INV_periods_r\(10),
	cin => \timers:3:channel|Add1~38\,
	sumout => \timers:3:channel|Add1~41_sumout\,
	cout => \timers:3:channel|Add1~42\);

-- Location: FF_X22_Y64_N32
\timers:3:channel|periods_r[10]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:3:channel|Add1~41_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:3:channel|elapsed_r[9]~4_combout\,
	ena => \timers:3:channel|periods_r[13]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:3:channel|periods_r\(10));

-- Location: LABCELL_X23_Y69_N30
\timers:0:channel|Add1~41\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|Add1~41_sumout\ = SUM(( \timers:0:channel|periods_r\(10) ) + ( GND ) + ( \timers:0:channel|Add1~38\ ))
-- \timers:0:channel|Add1~42\ = CARRY(( \timers:0:channel|periods_r\(10) ) + ( GND ) + ( \timers:0:channel|Add1~38\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \timers:0:channel|ALT_INV_periods_r\(10),
	cin => \timers:0:channel|Add1~38\,
	sumout => \timers:0:channel|Add1~41_sumout\,
	cout => \timers:0:channel|Add1~42\);

-- Location: FF_X23_Y69_N32
\timers:0:channel|periods_r[10]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:0:channel|Add1~41_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:0:channel|elapsed_r[2]~4_combout\,
	ena => \timers:0:channel|periods_r[7]~2_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:0:channel|periods_r\(10));

-- Location: MLABCELL_X25_Y68_N30
\timers:1:channel|Add1~41\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|Add1~41_sumout\ = SUM(( \timers:1:channel|periods_r\(10) ) + ( GND ) + ( \timers:1:channel|Add1~38\ ))
-- \timers:1:channel|Add1~42\ = CARRY(( \timers:1:channel|periods_r\(10) ) + ( GND ) + ( \timers:1:channel|Add1~38\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \timers:1:channel|ALT_INV_periods_r\(10),
	cin => \timers:1:channel|Add1~38\,
	sumout => \timers:1:channel|Add1~41_sumout\,
	cout => \timers:1:channel|Add1~42\);

-- Location: FF_X25_Y68_N32
\timers:1:channel|periods_r[10]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:1:channel|Add1~41_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:1:channel|elapsed_r[14]~4_combout\,
	ena => \timers:1:channel|periods_r[14]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:1:channel|periods_r\(10));

-- Location: LABCELL_X22_Y64_N51
\read_value[10]~33\ : cyclonev_lcell_comb
-- Equation(s):
-- \read_value[10]~33_combout\ = ( \timers:1:channel|periods_r\(10) & ( (!\IO_ADDR[3]~input_o\ & (((\timers:0:channel|periods_r\(10))) # (\IO_ADDR[2]~input_o\))) # (\IO_ADDR[3]~input_o\ & (((\timers:3:channel|periods_r\(10))))) ) ) # ( 
-- !\timers:1:channel|periods_r\(10) & ( (!\IO_ADDR[3]~input_o\ & (!\IO_ADDR[2]~input_o\ & ((\timers:0:channel|periods_r\(10))))) # (\IO_ADDR[3]~input_o\ & (((\timers:3:channel|periods_r\(10))))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000010110001101000001011000110100100111101011110010011110101111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_IO_ADDR[3]~input_o\,
	datab => \ALT_INV_IO_ADDR[2]~input_o\,
	datac => \timers:3:channel|ALT_INV_periods_r\(10),
	datad => \timers:0:channel|ALT_INV_periods_r\(10),
	dataf => \timers:1:channel|ALT_INV_periods_r\(10),
	combout => \read_value[10]~33_combout\);

-- Location: MLABCELL_X21_Y67_N6
\read_value[10]~32\ : cyclonev_lcell_comb
-- Equation(s):
-- \read_value[10]~32_combout\ = ( \IO_ADDR[2]~input_o\ & ( \timers:0:channel|elapsed_r\(10) & ( (!\IO_ADDR[3]~input_o\ & ((\timers:1:channel|elapsed_r\(10)))) # (\IO_ADDR[3]~input_o\ & (\timers:3:channel|elapsed_r\(10))) ) ) ) # ( !\IO_ADDR[2]~input_o\ & ( 
-- \timers:0:channel|elapsed_r\(10) & ( (!\IO_ADDR[3]~input_o\) # (\timers:2:channel|elapsed_r\(10)) ) ) ) # ( \IO_ADDR[2]~input_o\ & ( !\timers:0:channel|elapsed_r\(10) & ( (!\IO_ADDR[3]~input_o\ & ((\timers:1:channel|elapsed_r\(10)))) # 
-- (\IO_ADDR[3]~input_o\ & (\timers:3:channel|elapsed_r\(10))) ) ) ) # ( !\IO_ADDR[2]~input_o\ & ( !\timers:0:channel|elapsed_r\(10) & ( (\timers:2:channel|elapsed_r\(10) & \IO_ADDR[3]~input_o\) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000001111001100110101010111111111000011110011001101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:3:channel|ALT_INV_elapsed_r\(10),
	datab => \timers:1:channel|ALT_INV_elapsed_r\(10),
	datac => \timers:2:channel|ALT_INV_elapsed_r\(10),
	datad => \ALT_INV_IO_ADDR[3]~input_o\,
	datae => \ALT_INV_IO_ADDR[2]~input_o\,
	dataf => \timers:0:channel|ALT_INV_elapsed_r\(10),
	combout => \read_value[10]~32_combout\);

-- Location: MLABCELL_X21_Y67_N12
\read_value[10]~34\ : cyclonev_lcell_comb
-- Equation(s):
-- \read_value[10]~34_combout\ = ( \read_value[10]~32_combout\ & ( (!\read_value[0]~0_combout\ & (\read_value[0]~1_combout\ & ((\read_value[10]~33_combout\)))) # (\read_value[0]~0_combout\ & (((\timers:2:channel|periods_r\(10))) # 
-- (\read_value[0]~1_combout\))) ) ) # ( !\read_value[10]~32_combout\ & ( (!\read_value[0]~0_combout\ & (\read_value[0]~1_combout\ & ((\read_value[10]~33_combout\)))) # (\read_value[0]~0_combout\ & (!\read_value[0]~1_combout\ & 
-- (\timers:2:channel|periods_r\(10)))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000010000100110000001000010011000010101001101110001010100110111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_read_value[0]~0_combout\,
	datab => \ALT_INV_read_value[0]~1_combout\,
	datac => \timers:2:channel|ALT_INV_periods_r\(10),
	datad => \ALT_INV_read_value[10]~33_combout\,
	dataf => \ALT_INV_read_value[10]~32_combout\,
	combout => \read_value[10]~34_combout\);

-- Location: LABCELL_X23_Y67_N0
\read_value[11]~35\ : cyclonev_lcell_comb
-- Equation(s):
-- \read_value[11]~35_combout\ = ( \IO_ADDR[2]~input_o\ & ( \timers:0:channel|elapsed_r\(11) & ( (!\IO_ADDR[3]~input_o\ & ((\timers:1:channel|elapsed_r\(11)))) # (\IO_ADDR[3]~input_o\ & (\timers:3:channel|elapsed_r\(11))) ) ) ) # ( !\IO_ADDR[2]~input_o\ & ( 
-- \timers:0:channel|elapsed_r\(11) & ( (!\IO_ADDR[3]~input_o\) # (\timers:2:channel|elapsed_r\(11)) ) ) ) # ( \IO_ADDR[2]~input_o\ & ( !\timers:0:channel|elapsed_r\(11) & ( (!\IO_ADDR[3]~input_o\ & ((\timers:1:channel|elapsed_r\(11)))) # 
-- (\IO_ADDR[3]~input_o\ & (\timers:3:channel|elapsed_r\(11))) ) ) ) # ( !\IO_ADDR[2]~input_o\ & ( !\timers:0:channel|elapsed_r\(11) & ( (\timers:2:channel|elapsed_r\(11) & \IO_ADDR[3]~input_o\) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000001010101000011110011001111111111010101010000111100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:2:channel|ALT_INV_elapsed_r\(11),
	datab => \timers:3:channel|ALT_INV_elapsed_r\(11),
	datac => \timers:1:channel|ALT_INV_elapsed_r\(11),
	datad => \ALT_INV_IO_ADDR[3]~input_o\,
	datae => \ALT_INV_IO_ADDR[2]~input_o\,
	dataf => \timers:0:channel|ALT_INV_elapsed_r\(11),
	combout => \read_value[11]~35_combout\);

-- Location: MLABCELL_X21_Y68_N33
\timers:2:channel|Add1~45\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|Add1~45_sumout\ = SUM(( \timers:2:channel|periods_r\(11) ) + ( GND ) + ( \timers:2:channel|Add1~42\ ))
-- \timers:2:channel|Add1~46\ = CARRY(( \timers:2:channel|periods_r\(11) ) + ( GND ) + ( \timers:2:channel|Add1~42\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000101010101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:2:channel|ALT_INV_periods_r\(11),
	cin => \timers:2:channel|Add1~42\,
	sumout => \timers:2:channel|Add1~45_sumout\,
	cout => \timers:2:channel|Add1~46\);

-- Location: FF_X21_Y68_N35
\timers:2:channel|periods_r[11]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:2:channel|Add1~45_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:2:channel|elapsed_r[6]~0_combout\,
	ena => \timers:2:channel|periods_r[5]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:2:channel|periods_r\(11));

-- Location: LABCELL_X23_Y69_N33
\timers:0:channel|Add1~45\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|Add1~45_sumout\ = SUM(( \timers:0:channel|periods_r\(11) ) + ( GND ) + ( \timers:0:channel|Add1~42\ ))
-- \timers:0:channel|Add1~46\ = CARRY(( \timers:0:channel|periods_r\(11) ) + ( GND ) + ( \timers:0:channel|Add1~42\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000101010101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:0:channel|ALT_INV_periods_r\(11),
	cin => \timers:0:channel|Add1~42\,
	sumout => \timers:0:channel|Add1~45_sumout\,
	cout => \timers:0:channel|Add1~46\);

-- Location: FF_X23_Y69_N35
\timers:0:channel|periods_r[11]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:0:channel|Add1~45_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:0:channel|elapsed_r[2]~4_combout\,
	ena => \timers:0:channel|periods_r[7]~2_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:0:channel|periods_r\(11));

-- Location: MLABCELL_X25_Y68_N33
\timers:1:channel|Add1~45\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|Add1~45_sumout\ = SUM(( \timers:1:channel|periods_r\(11) ) + ( GND ) + ( \timers:1:channel|Add1~42\ ))
-- \timers:1:channel|Add1~46\ = CARRY(( \timers:1:channel|periods_r\(11) ) + ( GND ) + ( \timers:1:channel|Add1~42\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000101010101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:1:channel|ALT_INV_periods_r\(11),
	cin => \timers:1:channel|Add1~42\,
	sumout => \timers:1:channel|Add1~45_sumout\,
	cout => \timers:1:channel|Add1~46\);

-- Location: FF_X25_Y68_N35
\timers:1:channel|periods_r[11]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:1:channel|Add1~45_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:1:channel|elapsed_r[14]~4_combout\,
	ena => \timers:1:channel|periods_r[14]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:1:channel|periods_r\(11));

-- Location: LABCELL_X22_Y64_N33
\timers:3:channel|Add1~45\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|Add1~45_sumout\ = SUM(( \timers:3:channel|periods_r\(11) ) + ( GND ) + ( \timers:3:channel|Add1~42\ ))
-- \timers:3:channel|Add1~46\ = CARRY(( \timers:3:channel|periods_r\(11) ) + ( GND ) + ( \timers:3:channel|Add1~42\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000101010101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:3:channel|ALT_INV_periods_r\(11),
	cin => \timers:3:channel|Add1~42\,
	sumout => \timers:3:channel|Add1~45_sumout\,
	cout => \timers:3:channel|Add1~46\);

-- Location: FF_X22_Y64_N35
\timers:3:channel|periods_r[11]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:3:channel|Add1~45_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:3:channel|elapsed_r[9]~4_combout\,
	ena => \timers:3:channel|periods_r[13]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:3:channel|periods_r\(11));

-- Location: MLABCELL_X21_Y67_N30
\read_value[11]~36\ : cyclonev_lcell_comb
-- Equation(s):
-- \read_value[11]~36_combout\ = ( \timers:3:channel|periods_r\(11) & ( ((!\IO_ADDR[2]~input_o\ & (\timers:0:channel|periods_r\(11))) # (\IO_ADDR[2]~input_o\ & ((\timers:1:channel|periods_r\(11))))) # (\IO_ADDR[3]~input_o\) ) ) # ( 
-- !\timers:3:channel|periods_r\(11) & ( (!\IO_ADDR[3]~input_o\ & ((!\IO_ADDR[2]~input_o\ & (\timers:0:channel|periods_r\(11))) # (\IO_ADDR[2]~input_o\ & ((\timers:1:channel|periods_r\(11)))))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000100001001100000010000100110000111011011111110011101101111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_IO_ADDR[2]~input_o\,
	datab => \ALT_INV_IO_ADDR[3]~input_o\,
	datac => \timers:0:channel|ALT_INV_periods_r\(11),
	datad => \timers:1:channel|ALT_INV_periods_r\(11),
	dataf => \timers:3:channel|ALT_INV_periods_r\(11),
	combout => \read_value[11]~36_combout\);

-- Location: MLABCELL_X21_Y67_N15
\read_value[11]~37\ : cyclonev_lcell_comb
-- Equation(s):
-- \read_value[11]~37_combout\ = ( \read_value[11]~36_combout\ & ( (!\read_value[0]~0_combout\ & (\read_value[0]~1_combout\)) # (\read_value[0]~0_combout\ & ((!\read_value[0]~1_combout\ & ((\timers:2:channel|periods_r\(11)))) # (\read_value[0]~1_combout\ & 
-- (\read_value[11]~35_combout\)))) ) ) # ( !\read_value[11]~36_combout\ & ( (\read_value[0]~0_combout\ & ((!\read_value[0]~1_combout\ & ((\timers:2:channel|periods_r\(11)))) # (\read_value[0]~1_combout\ & (\read_value[11]~35_combout\)))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000101000101000000010100010100100011011001110010001101100111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_read_value[0]~0_combout\,
	datab => \ALT_INV_read_value[0]~1_combout\,
	datac => \ALT_INV_read_value[11]~35_combout\,
	datad => \timers:2:channel|ALT_INV_periods_r\(11),
	dataf => \ALT_INV_read_value[11]~36_combout\,
	combout => \read_value[11]~37_combout\);

-- Location: MLABCELL_X21_Y68_N36
\timers:2:channel|Add1~49\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|Add1~49_sumout\ = SUM(( \timers:2:channel|periods_r\(12) ) + ( GND ) + ( \timers:2:channel|Add1~46\ ))
-- \timers:2:channel|Add1~50\ = CARRY(( \timers:2:channel|periods_r\(12) ) + ( GND ) + ( \timers:2:channel|Add1~46\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:2:channel|ALT_INV_periods_r\(12),
	cin => \timers:2:channel|Add1~46\,
	sumout => \timers:2:channel|Add1~49_sumout\,
	cout => \timers:2:channel|Add1~50\);

-- Location: FF_X21_Y68_N38
\timers:2:channel|periods_r[12]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:2:channel|Add1~49_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:2:channel|elapsed_r[6]~0_combout\,
	ena => \timers:2:channel|periods_r[5]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:2:channel|periods_r\(12));

-- Location: LABCELL_X23_Y69_N36
\timers:0:channel|Add1~49\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|Add1~49_sumout\ = SUM(( \timers:0:channel|periods_r\(12) ) + ( GND ) + ( \timers:0:channel|Add1~46\ ))
-- \timers:0:channel|Add1~50\ = CARRY(( \timers:0:channel|periods_r\(12) ) + ( GND ) + ( \timers:0:channel|Add1~46\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:0:channel|ALT_INV_periods_r\(12),
	cin => \timers:0:channel|Add1~46\,
	sumout => \timers:0:channel|Add1~49_sumout\,
	cout => \timers:0:channel|Add1~50\);

-- Location: FF_X23_Y69_N38
\timers:0:channel|periods_r[12]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:0:channel|Add1~49_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:0:channel|elapsed_r[2]~4_combout\,
	ena => \timers:0:channel|periods_r[7]~2_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:0:channel|periods_r\(12));

-- Location: LABCELL_X22_Y64_N36
\timers:3:channel|Add1~49\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|Add1~49_sumout\ = SUM(( \timers:3:channel|periods_r\(12) ) + ( GND ) + ( \timers:3:channel|Add1~46\ ))
-- \timers:3:channel|Add1~50\ = CARRY(( \timers:3:channel|periods_r\(12) ) + ( GND ) + ( \timers:3:channel|Add1~46\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:3:channel|ALT_INV_periods_r\(12),
	cin => \timers:3:channel|Add1~46\,
	sumout => \timers:3:channel|Add1~49_sumout\,
	cout => \timers:3:channel|Add1~50\);

-- Location: FF_X22_Y64_N38
\timers:3:channel|periods_r[12]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:3:channel|Add1~49_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:3:channel|elapsed_r[9]~4_combout\,
	ena => \timers:3:channel|periods_r[13]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:3:channel|periods_r\(12));

-- Location: MLABCELL_X25_Y68_N36
\timers:1:channel|Add1~49\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|Add1~49_sumout\ = SUM(( \timers:1:channel|periods_r\(12) ) + ( GND ) + ( \timers:1:channel|Add1~46\ ))
-- \timers:1:channel|Add1~50\ = CARRY(( \timers:1:channel|periods_r\(12) ) + ( GND ) + ( \timers:1:channel|Add1~46\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:1:channel|ALT_INV_periods_r\(12),
	cin => \timers:1:channel|Add1~46\,
	sumout => \timers:1:channel|Add1~49_sumout\,
	cout => \timers:1:channel|Add1~50\);

-- Location: FF_X25_Y68_N38
\timers:1:channel|periods_r[12]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:1:channel|Add1~49_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:1:channel|elapsed_r[14]~4_combout\,
	ena => \timers:1:channel|periods_r[14]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:1:channel|periods_r\(12));

-- Location: LABCELL_X22_Y68_N33
\read_value[12]~39\ : cyclonev_lcell_comb
-- Equation(s):
-- \read_value[12]~39_combout\ = ( \timers:1:channel|periods_r\(12) & ( (!\IO_ADDR[3]~input_o\ & (((\timers:0:channel|periods_r\(12))) # (\IO_ADDR[2]~input_o\))) # (\IO_ADDR[3]~input_o\ & (((\timers:3:channel|periods_r\(12))))) ) ) # ( 
-- !\timers:1:channel|periods_r\(12) & ( (!\IO_ADDR[3]~input_o\ & (!\IO_ADDR[2]~input_o\ & (\timers:0:channel|periods_r\(12)))) # (\IO_ADDR[3]~input_o\ & (((\timers:3:channel|periods_r\(12))))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000100001011101000010000101110100101010011111110010101001111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_IO_ADDR[3]~input_o\,
	datab => \ALT_INV_IO_ADDR[2]~input_o\,
	datac => \timers:0:channel|ALT_INV_periods_r\(12),
	datad => \timers:3:channel|ALT_INV_periods_r\(12),
	dataf => \timers:1:channel|ALT_INV_periods_r\(12),
	combout => \read_value[12]~39_combout\);

-- Location: LABCELL_X22_Y69_N3
\read_value[12]~38\ : cyclonev_lcell_comb
-- Equation(s):
-- \read_value[12]~38_combout\ = ( \IO_ADDR[2]~input_o\ & ( \timers:0:channel|elapsed_r\(12) & ( (!\IO_ADDR[3]~input_o\ & (\timers:1:channel|elapsed_r\(12))) # (\IO_ADDR[3]~input_o\ & ((\timers:3:channel|elapsed_r\(12)))) ) ) ) # ( !\IO_ADDR[2]~input_o\ & ( 
-- \timers:0:channel|elapsed_r\(12) & ( (!\IO_ADDR[3]~input_o\) # (\timers:2:channel|elapsed_r\(12)) ) ) ) # ( \IO_ADDR[2]~input_o\ & ( !\timers:0:channel|elapsed_r\(12) & ( (!\IO_ADDR[3]~input_o\ & (\timers:1:channel|elapsed_r\(12))) # (\IO_ADDR[3]~input_o\ 
-- & ((\timers:3:channel|elapsed_r\(12)))) ) ) ) # ( !\IO_ADDR[2]~input_o\ & ( !\timers:0:channel|elapsed_r\(12) & ( (\IO_ADDR[3]~input_o\ & \timers:2:channel|elapsed_r\(12)) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000001010101001001110010011110101010111111110010011100100111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_IO_ADDR[3]~input_o\,
	datab => \timers:1:channel|ALT_INV_elapsed_r\(12),
	datac => \timers:3:channel|ALT_INV_elapsed_r\(12),
	datad => \timers:2:channel|ALT_INV_elapsed_r\(12),
	datae => \ALT_INV_IO_ADDR[2]~input_o\,
	dataf => \timers:0:channel|ALT_INV_elapsed_r\(12),
	combout => \read_value[12]~38_combout\);

-- Location: LABCELL_X22_Y68_N39
\read_value[12]~40\ : cyclonev_lcell_comb
-- Equation(s):
-- \read_value[12]~40_combout\ = ( \read_value[12]~38_combout\ & ( (!\read_value[0]~0_combout\ & (\read_value[0]~1_combout\ & ((\read_value[12]~39_combout\)))) # (\read_value[0]~0_combout\ & (((\timers:2:channel|periods_r\(12))) # 
-- (\read_value[0]~1_combout\))) ) ) # ( !\read_value[12]~38_combout\ & ( (!\read_value[0]~0_combout\ & (\read_value[0]~1_combout\ & ((\read_value[12]~39_combout\)))) # (\read_value[0]~0_combout\ & (!\read_value[0]~1_combout\ & 
-- (\timers:2:channel|periods_r\(12)))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000010000100110000001000010011000010101001101110001010100110111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_read_value[0]~0_combout\,
	datab => \ALT_INV_read_value[0]~1_combout\,
	datac => \timers:2:channel|ALT_INV_periods_r\(12),
	datad => \ALT_INV_read_value[12]~39_combout\,
	dataf => \ALT_INV_read_value[12]~38_combout\,
	combout => \read_value[12]~40_combout\);

-- Location: MLABCELL_X21_Y68_N39
\timers:2:channel|Add1~53\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|Add1~53_sumout\ = SUM(( \timers:2:channel|periods_r\(13) ) + ( GND ) + ( \timers:2:channel|Add1~50\ ))
-- \timers:2:channel|Add1~54\ = CARRY(( \timers:2:channel|periods_r\(13) ) + ( GND ) + ( \timers:2:channel|Add1~50\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:2:channel|ALT_INV_periods_r\(13),
	cin => \timers:2:channel|Add1~50\,
	sumout => \timers:2:channel|Add1~53_sumout\,
	cout => \timers:2:channel|Add1~54\);

-- Location: FF_X21_Y68_N41
\timers:2:channel|periods_r[13]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:2:channel|Add1~53_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:2:channel|elapsed_r[6]~0_combout\,
	ena => \timers:2:channel|periods_r[5]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:2:channel|periods_r\(13));

-- Location: MLABCELL_X25_Y68_N39
\timers:1:channel|Add1~53\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|Add1~53_sumout\ = SUM(( \timers:1:channel|periods_r\(13) ) + ( GND ) + ( \timers:1:channel|Add1~50\ ))
-- \timers:1:channel|Add1~54\ = CARRY(( \timers:1:channel|periods_r\(13) ) + ( GND ) + ( \timers:1:channel|Add1~50\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:1:channel|ALT_INV_periods_r\(13),
	cin => \timers:1:channel|Add1~50\,
	sumout => \timers:1:channel|Add1~53_sumout\,
	cout => \timers:1:channel|Add1~54\);

-- Location: FF_X25_Y68_N41
\timers:1:channel|periods_r[13]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:1:channel|Add1~53_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:1:channel|elapsed_r[14]~4_combout\,
	ena => \timers:1:channel|periods_r[14]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:1:channel|periods_r\(13));

-- Location: LABCELL_X22_Y64_N39
\timers:3:channel|Add1~53\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|Add1~53_sumout\ = SUM(( \timers:3:channel|periods_r\(13) ) + ( GND ) + ( \timers:3:channel|Add1~50\ ))
-- \timers:3:channel|Add1~54\ = CARRY(( \timers:3:channel|periods_r\(13) ) + ( GND ) + ( \timers:3:channel|Add1~50\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:3:channel|ALT_INV_periods_r\(13),
	cin => \timers:3:channel|Add1~50\,
	sumout => \timers:3:channel|Add1~53_sumout\,
	cout => \timers:3:channel|Add1~54\);

-- Location: FF_X22_Y64_N41
\timers:3:channel|periods_r[13]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:3:channel|Add1~53_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:3:channel|elapsed_r[9]~4_combout\,
	ena => \timers:3:channel|periods_r[13]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:3:channel|periods_r\(13));

-- Location: LABCELL_X23_Y69_N39
\timers:0:channel|Add1~53\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|Add1~53_sumout\ = SUM(( \timers:0:channel|periods_r\(13) ) + ( GND ) + ( \timers:0:channel|Add1~50\ ))
-- \timers:0:channel|Add1~54\ = CARRY(( \timers:0:channel|periods_r\(13) ) + ( GND ) + ( \timers:0:channel|Add1~50\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:0:channel|ALT_INV_periods_r\(13),
	cin => \timers:0:channel|Add1~50\,
	sumout => \timers:0:channel|Add1~53_sumout\,
	cout => \timers:0:channel|Add1~54\);

-- Location: FF_X23_Y69_N41
\timers:0:channel|periods_r[13]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:0:channel|Add1~53_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:0:channel|elapsed_r[2]~4_combout\,
	ena => \timers:0:channel|periods_r[7]~2_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:0:channel|periods_r\(13));

-- Location: LABCELL_X22_Y68_N0
\read_value[13]~42\ : cyclonev_lcell_comb
-- Equation(s):
-- \read_value[13]~42_combout\ = ( \timers:0:channel|periods_r\(13) & ( \IO_ADDR[3]~input_o\ & ( \timers:3:channel|periods_r\(13) ) ) ) # ( !\timers:0:channel|periods_r\(13) & ( \IO_ADDR[3]~input_o\ & ( \timers:3:channel|periods_r\(13) ) ) ) # ( 
-- \timers:0:channel|periods_r\(13) & ( !\IO_ADDR[3]~input_o\ & ( (!\IO_ADDR[2]~input_o\) # (\timers:1:channel|periods_r\(13)) ) ) ) # ( !\timers:0:channel|periods_r\(13) & ( !\IO_ADDR[3]~input_o\ & ( (\timers:1:channel|periods_r\(13) & \IO_ADDR[2]~input_o\) 
-- ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000010100000101111101011111010100110011001100110011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:1:channel|ALT_INV_periods_r\(13),
	datab => \timers:3:channel|ALT_INV_periods_r\(13),
	datac => \ALT_INV_IO_ADDR[2]~input_o\,
	datae => \timers:0:channel|ALT_INV_periods_r\(13),
	dataf => \ALT_INV_IO_ADDR[3]~input_o\,
	combout => \read_value[13]~42_combout\);

-- Location: LABCELL_X23_Y67_N48
\read_value[13]~41\ : cyclonev_lcell_comb
-- Equation(s):
-- \read_value[13]~41_combout\ = ( \IO_ADDR[3]~input_o\ & ( \timers:0:channel|elapsed_r\(13) & ( (!\IO_ADDR[2]~input_o\ & (\timers:2:channel|elapsed_r\(13))) # (\IO_ADDR[2]~input_o\ & ((\timers:3:channel|elapsed_r\(13)))) ) ) ) # ( !\IO_ADDR[3]~input_o\ & ( 
-- \timers:0:channel|elapsed_r\(13) & ( (!\IO_ADDR[2]~input_o\) # (\timers:1:channel|elapsed_r\(13)) ) ) ) # ( \IO_ADDR[3]~input_o\ & ( !\timers:0:channel|elapsed_r\(13) & ( (!\IO_ADDR[2]~input_o\ & (\timers:2:channel|elapsed_r\(13))) # (\IO_ADDR[2]~input_o\ 
-- & ((\timers:3:channel|elapsed_r\(13)))) ) ) ) # ( !\IO_ADDR[3]~input_o\ & ( !\timers:0:channel|elapsed_r\(13) & ( (\IO_ADDR[2]~input_o\ & \timers:1:channel|elapsed_r\(13)) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000001010101001001110010011110101010111111110010011100100111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_IO_ADDR[2]~input_o\,
	datab => \timers:2:channel|ALT_INV_elapsed_r\(13),
	datac => \timers:3:channel|ALT_INV_elapsed_r\(13),
	datad => \timers:1:channel|ALT_INV_elapsed_r\(13),
	datae => \ALT_INV_IO_ADDR[3]~input_o\,
	dataf => \timers:0:channel|ALT_INV_elapsed_r\(13),
	combout => \read_value[13]~41_combout\);

-- Location: LABCELL_X23_Y67_N36
\read_value[13]~43\ : cyclonev_lcell_comb
-- Equation(s):
-- \read_value[13]~43_combout\ = ( \read_value[13]~41_combout\ & ( (!\read_value[0]~0_combout\ & (\read_value[0]~1_combout\ & ((\read_value[13]~42_combout\)))) # (\read_value[0]~0_combout\ & (((\timers:2:channel|periods_r\(13))) # 
-- (\read_value[0]~1_combout\))) ) ) # ( !\read_value[13]~41_combout\ & ( (!\read_value[0]~0_combout\ & (\read_value[0]~1_combout\ & ((\read_value[13]~42_combout\)))) # (\read_value[0]~0_combout\ & (!\read_value[0]~1_combout\ & 
-- (\timers:2:channel|periods_r\(13)))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000010000100110000001000010011000010101001101110001010100110111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_read_value[0]~0_combout\,
	datab => \ALT_INV_read_value[0]~1_combout\,
	datac => \timers:2:channel|ALT_INV_periods_r\(13),
	datad => \ALT_INV_read_value[13]~42_combout\,
	dataf => \ALT_INV_read_value[13]~41_combout\,
	combout => \read_value[13]~43_combout\);

-- Location: LABCELL_X22_Y64_N42
\timers:3:channel|Add1~57\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|Add1~57_sumout\ = SUM(( \timers:3:channel|periods_r\(14) ) + ( GND ) + ( \timers:3:channel|Add1~54\ ))
-- \timers:3:channel|Add1~58\ = CARRY(( \timers:3:channel|periods_r\(14) ) + ( GND ) + ( \timers:3:channel|Add1~54\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \timers:3:channel|ALT_INV_periods_r\(14),
	cin => \timers:3:channel|Add1~54\,
	sumout => \timers:3:channel|Add1~57_sumout\,
	cout => \timers:3:channel|Add1~58\);

-- Location: FF_X22_Y64_N44
\timers:3:channel|periods_r[14]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:3:channel|Add1~57_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:3:channel|elapsed_r[9]~4_combout\,
	ena => \timers:3:channel|periods_r[13]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:3:channel|periods_r\(14));

-- Location: LABCELL_X23_Y69_N42
\timers:0:channel|Add1~57\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|Add1~57_sumout\ = SUM(( \timers:0:channel|periods_r\(14) ) + ( GND ) + ( \timers:0:channel|Add1~54\ ))
-- \timers:0:channel|Add1~58\ = CARRY(( \timers:0:channel|periods_r\(14) ) + ( GND ) + ( \timers:0:channel|Add1~54\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \timers:0:channel|ALT_INV_periods_r\(14),
	cin => \timers:0:channel|Add1~54\,
	sumout => \timers:0:channel|Add1~57_sumout\,
	cout => \timers:0:channel|Add1~58\);

-- Location: FF_X23_Y69_N44
\timers:0:channel|periods_r[14]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:0:channel|Add1~57_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:0:channel|elapsed_r[2]~4_combout\,
	ena => \timers:0:channel|periods_r[7]~2_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:0:channel|periods_r\(14));

-- Location: MLABCELL_X25_Y68_N42
\timers:1:channel|Add1~57\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|Add1~57_sumout\ = SUM(( \timers:1:channel|periods_r\(14) ) + ( GND ) + ( \timers:1:channel|Add1~54\ ))
-- \timers:1:channel|Add1~58\ = CARRY(( \timers:1:channel|periods_r\(14) ) + ( GND ) + ( \timers:1:channel|Add1~54\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \timers:1:channel|ALT_INV_periods_r\(14),
	cin => \timers:1:channel|Add1~54\,
	sumout => \timers:1:channel|Add1~57_sumout\,
	cout => \timers:1:channel|Add1~58\);

-- Location: FF_X25_Y68_N44
\timers:1:channel|periods_r[14]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:1:channel|Add1~57_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:1:channel|elapsed_r[14]~4_combout\,
	ena => \timers:1:channel|periods_r[14]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:1:channel|periods_r\(14));

-- Location: LABCELL_X23_Y65_N3
\read_value[14]~45\ : cyclonev_lcell_comb
-- Equation(s):
-- \read_value[14]~45_combout\ = ( \timers:0:channel|periods_r\(14) & ( \timers:1:channel|periods_r\(14) & ( (!\IO_ADDR[3]~input_o\) # (\timers:3:channel|periods_r\(14)) ) ) ) # ( !\timers:0:channel|periods_r\(14) & ( \timers:1:channel|periods_r\(14) & ( 
-- (!\IO_ADDR[3]~input_o\ & ((\IO_ADDR[2]~input_o\))) # (\IO_ADDR[3]~input_o\ & (\timers:3:channel|periods_r\(14))) ) ) ) # ( \timers:0:channel|periods_r\(14) & ( !\timers:1:channel|periods_r\(14) & ( (!\IO_ADDR[3]~input_o\ & ((!\IO_ADDR[2]~input_o\))) # 
-- (\IO_ADDR[3]~input_o\ & (\timers:3:channel|periods_r\(14))) ) ) ) # ( !\timers:0:channel|periods_r\(14) & ( !\timers:1:channel|periods_r\(14) & ( (\IO_ADDR[3]~input_o\ & \timers:3:channel|periods_r\(14)) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0001000100010001101100011011000100011011000110111011101110111011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_IO_ADDR[3]~input_o\,
	datab => \timers:3:channel|ALT_INV_periods_r\(14),
	datac => \ALT_INV_IO_ADDR[2]~input_o\,
	datae => \timers:0:channel|ALT_INV_periods_r\(14),
	dataf => \timers:1:channel|ALT_INV_periods_r\(14),
	combout => \read_value[14]~45_combout\);

-- Location: MLABCELL_X21_Y68_N42
\timers:2:channel|Add1~57\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|Add1~57_sumout\ = SUM(( \timers:2:channel|periods_r\(14) ) + ( GND ) + ( \timers:2:channel|Add1~54\ ))
-- \timers:2:channel|Add1~58\ = CARRY(( \timers:2:channel|periods_r\(14) ) + ( GND ) + ( \timers:2:channel|Add1~54\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \timers:2:channel|ALT_INV_periods_r\(14),
	cin => \timers:2:channel|Add1~54\,
	sumout => \timers:2:channel|Add1~57_sumout\,
	cout => \timers:2:channel|Add1~58\);

-- Location: FF_X21_Y68_N44
\timers:2:channel|periods_r[14]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:2:channel|Add1~57_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:2:channel|elapsed_r[6]~0_combout\,
	ena => \timers:2:channel|periods_r[5]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:2:channel|periods_r\(14));

-- Location: MLABCELL_X25_Y66_N18
\read_value[14]~44\ : cyclonev_lcell_comb
-- Equation(s):
-- \read_value[14]~44_combout\ = ( \timers:3:channel|elapsed_r\(14) & ( \timers:1:channel|elapsed_r\(14) & ( ((!\IO_ADDR[3]~input_o\ & (\timers:0:channel|elapsed_r\(14))) # (\IO_ADDR[3]~input_o\ & ((\timers:2:channel|elapsed_r\(14))))) # 
-- (\IO_ADDR[2]~input_o\) ) ) ) # ( !\timers:3:channel|elapsed_r\(14) & ( \timers:1:channel|elapsed_r\(14) & ( (!\IO_ADDR[3]~input_o\ & (((\IO_ADDR[2]~input_o\)) # (\timers:0:channel|elapsed_r\(14)))) # (\IO_ADDR[3]~input_o\ & (((!\IO_ADDR[2]~input_o\ & 
-- \timers:2:channel|elapsed_r\(14))))) ) ) ) # ( \timers:3:channel|elapsed_r\(14) & ( !\timers:1:channel|elapsed_r\(14) & ( (!\IO_ADDR[3]~input_o\ & (\timers:0:channel|elapsed_r\(14) & (!\IO_ADDR[2]~input_o\))) # (\IO_ADDR[3]~input_o\ & 
-- (((\timers:2:channel|elapsed_r\(14)) # (\IO_ADDR[2]~input_o\)))) ) ) ) # ( !\timers:3:channel|elapsed_r\(14) & ( !\timers:1:channel|elapsed_r\(14) & ( (!\IO_ADDR[2]~input_o\ & ((!\IO_ADDR[3]~input_o\ & (\timers:0:channel|elapsed_r\(14))) # 
-- (\IO_ADDR[3]~input_o\ & ((\timers:2:channel|elapsed_r\(14)))))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0010000001110000001001010111010100101010011110100010111101111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_IO_ADDR[3]~input_o\,
	datab => \timers:0:channel|ALT_INV_elapsed_r\(14),
	datac => \ALT_INV_IO_ADDR[2]~input_o\,
	datad => \timers:2:channel|ALT_INV_elapsed_r\(14),
	datae => \timers:3:channel|ALT_INV_elapsed_r\(14),
	dataf => \timers:1:channel|ALT_INV_elapsed_r\(14),
	combout => \read_value[14]~44_combout\);

-- Location: LABCELL_X23_Y67_N18
\read_value[14]~46\ : cyclonev_lcell_comb
-- Equation(s):
-- \read_value[14]~46_combout\ = ( \read_value[0]~1_combout\ & ( (!\read_value[0]~0_combout\ & (\read_value[14]~45_combout\)) # (\read_value[0]~0_combout\ & ((\read_value[14]~44_combout\))) ) ) # ( !\read_value[0]~1_combout\ & ( (\read_value[0]~0_combout\ & 
-- \timers:2:channel|periods_r\(14)) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000010100000101000001010000010100100010011101110010001001110111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_read_value[0]~0_combout\,
	datab => \ALT_INV_read_value[14]~45_combout\,
	datac => \timers:2:channel|ALT_INV_periods_r\(14),
	datad => \ALT_INV_read_value[14]~44_combout\,
	dataf => \ALT_INV_read_value[0]~1_combout\,
	combout => \read_value[14]~46_combout\);

-- Location: MLABCELL_X21_Y68_N45
\timers:2:channel|Add1~61\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:2:channel|Add1~61_sumout\ = SUM(( \timers:2:channel|periods_r\(15) ) + ( GND ) + ( \timers:2:channel|Add1~58\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:2:channel|ALT_INV_periods_r\(15),
	cin => \timers:2:channel|Add1~58\,
	sumout => \timers:2:channel|Add1~61_sumout\);

-- Location: FF_X21_Y68_N47
\timers:2:channel|periods_r[15]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:2:channel|Add1~61_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:2:channel|elapsed_r[6]~0_combout\,
	ena => \timers:2:channel|periods_r[5]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:2:channel|periods_r\(15));

-- Location: LABCELL_X22_Y68_N54
\read_value[15]~47\ : cyclonev_lcell_comb
-- Equation(s):
-- \read_value[15]~47_combout\ = ( \IO_ADDR[2]~input_o\ & ( \IO_ADDR[3]~input_o\ & ( \timers:3:channel|elapsed_r\(15) ) ) ) # ( !\IO_ADDR[2]~input_o\ & ( \IO_ADDR[3]~input_o\ & ( \timers:2:channel|elapsed_r\(15) ) ) ) # ( \IO_ADDR[2]~input_o\ & ( 
-- !\IO_ADDR[3]~input_o\ & ( \timers:1:channel|elapsed_r\(15) ) ) ) # ( !\IO_ADDR[2]~input_o\ & ( !\IO_ADDR[3]~input_o\ & ( \timers:0:channel|elapsed_r\(15) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0011001100110011000011110000111101010101010101010000000011111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \timers:2:channel|ALT_INV_elapsed_r\(15),
	datab => \timers:0:channel|ALT_INV_elapsed_r\(15),
	datac => \timers:1:channel|ALT_INV_elapsed_r\(15),
	datad => \timers:3:channel|ALT_INV_elapsed_r\(15),
	datae => \ALT_INV_IO_ADDR[2]~input_o\,
	dataf => \ALT_INV_IO_ADDR[3]~input_o\,
	combout => \read_value[15]~47_combout\);

-- Location: LABCELL_X23_Y69_N45
\timers:0:channel|Add1~61\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:0:channel|Add1~61_sumout\ = SUM(( \timers:0:channel|periods_r\(15) ) + ( GND ) + ( \timers:0:channel|Add1~58\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:0:channel|ALT_INV_periods_r\(15),
	cin => \timers:0:channel|Add1~58\,
	sumout => \timers:0:channel|Add1~61_sumout\);

-- Location: FF_X23_Y69_N47
\timers:0:channel|periods_r[15]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:0:channel|Add1~61_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:0:channel|elapsed_r[2]~4_combout\,
	ena => \timers:0:channel|periods_r[7]~2_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:0:channel|periods_r\(15));

-- Location: MLABCELL_X25_Y68_N45
\timers:1:channel|Add1~61\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:1:channel|Add1~61_sumout\ = SUM(( \timers:1:channel|periods_r\(15) ) + ( GND ) + ( \timers:1:channel|Add1~58\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:1:channel|ALT_INV_periods_r\(15),
	cin => \timers:1:channel|Add1~58\,
	sumout => \timers:1:channel|Add1~61_sumout\);

-- Location: FF_X25_Y68_N47
\timers:1:channel|periods_r[15]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:1:channel|Add1~61_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:1:channel|elapsed_r[14]~4_combout\,
	ena => \timers:1:channel|periods_r[14]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:1:channel|periods_r\(15));

-- Location: LABCELL_X22_Y64_N45
\timers:3:channel|Add1~61\ : cyclonev_lcell_comb
-- Equation(s):
-- \timers:3:channel|Add1~61_sumout\ = SUM(( \timers:3:channel|periods_r\(15) ) + ( GND ) + ( \timers:3:channel|Add1~58\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \timers:3:channel|ALT_INV_periods_r\(15),
	cin => \timers:3:channel|Add1~58\,
	sumout => \timers:3:channel|Add1~61_sumout\);

-- Location: FF_X22_Y64_N47
\timers:3:channel|periods_r[15]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK~inputCLKENA0_outclk\,
	d => \timers:3:channel|Add1~61_sumout\,
	clrn => \RESETN~inputCLKENA0_outclk\,
	sclr => \timers:3:channel|elapsed_r[9]~4_combout\,
	ena => \timers:3:channel|periods_r[13]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \timers:3:channel|periods_r\(15));

-- Location: LABCELL_X22_Y68_N30
\read_value[15]~48\ : cyclonev_lcell_comb
-- Equation(s):
-- \read_value[15]~48_combout\ = ( \timers:3:channel|periods_r\(15) & ( ((!\IO_ADDR[2]~input_o\ & (\timers:0:channel|periods_r\(15))) # (\IO_ADDR[2]~input_o\ & ((\timers:1:channel|periods_r\(15))))) # (\IO_ADDR[3]~input_o\) ) ) # ( 
-- !\timers:3:channel|periods_r\(15) & ( (!\IO_ADDR[3]~input_o\ & ((!\IO_ADDR[2]~input_o\ & (\timers:0:channel|periods_r\(15))) # (\IO_ADDR[2]~input_o\ & ((\timers:1:channel|periods_r\(15)))))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000100000101010000010000010101001011101011111110101110101111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_IO_ADDR[3]~input_o\,
	datab => \ALT_INV_IO_ADDR[2]~input_o\,
	datac => \timers:0:channel|ALT_INV_periods_r\(15),
	datad => \timers:1:channel|ALT_INV_periods_r\(15),
	dataf => \timers:3:channel|ALT_INV_periods_r\(15),
	combout => \read_value[15]~48_combout\);

-- Location: LABCELL_X22_Y68_N12
\read_value[15]~49\ : cyclonev_lcell_comb
-- Equation(s):
-- \read_value[15]~49_combout\ = ( \read_value[15]~47_combout\ & ( \read_value[15]~48_combout\ & ( ((\timers:2:channel|periods_r\(15) & \read_value[0]~0_combout\)) # (\read_value[0]~1_combout\) ) ) ) # ( !\read_value[15]~47_combout\ & ( 
-- \read_value[15]~48_combout\ & ( (!\read_value[0]~1_combout\ & (\timers:2:channel|periods_r\(15) & \read_value[0]~0_combout\)) # (\read_value[0]~1_combout\ & ((!\read_value[0]~0_combout\))) ) ) ) # ( \read_value[15]~47_combout\ & ( 
-- !\read_value[15]~48_combout\ & ( (\read_value[0]~0_combout\ & ((\timers:2:channel|periods_r\(15)) # (\read_value[0]~1_combout\))) ) ) ) # ( !\read_value[15]~47_combout\ & ( !\read_value[15]~48_combout\ & ( (!\read_value[0]~1_combout\ & 
-- (\timers:2:channel|periods_r\(15) & \read_value[0]~0_combout\)) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000001000000010000001110000011101010010010100100101011101010111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_read_value[0]~1_combout\,
	datab => \timers:2:channel|ALT_INV_periods_r\(15),
	datac => \ALT_INV_read_value[0]~0_combout\,
	datae => \ALT_INV_read_value[15]~47_combout\,
	dataf => \ALT_INV_read_value[15]~48_combout\,
	combout => \read_value[15]~49_combout\);

-- Location: LABCELL_X1_Y35_N3
\~QUARTUS_CREATED_GND~I\ : cyclonev_lcell_comb
-- Equation(s):

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
;
END structure;


