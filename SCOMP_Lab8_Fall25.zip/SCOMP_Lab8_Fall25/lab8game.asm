; lab8game.asm
; Produces a random 4 digits hex
; Hex is then display 

ORG 0

	; Get and store the switch values
Init:
	LOADI  0
	STORE  Rand
    STORE  Score
    OUT    Hex1
	IN     Switches
    JNZ    Init
	
RandGen:
	LOAD   Rand
	ADDI   1
	STORE  Rand
	IN 	   Switches
	SUB	   Bit9
	JNZ    RandGen
	
	
	LOAD   Rand
	OUT    Hex0
    
	LOAD Rand 
	AND BitSW0
	STORE SW0value
    
	LOAD Rand 
	AND BitSW1
    SHIFT -4
	STORE SW1value
    
	LOAD Rand 
	AND BitSW2
    SHIFT -8
	STORE SW2value
    
	LOAD Rand 
	AND BitSW3
    SHIFT -12
	STORE SW3value
	
MAXFUNCTION:
    LOAD Rand
    STORE Remaining
    AND Mask
    STORE Max
    LOADI 3
    STORE Count
    CALL Next
    CALL CheckMax
    CALL Next
    CALL CheckMax
    CALL Next
    CALL CheckMax
    CALL Next
	
GETINPUT:
	LOAD Rand
	JZERO RandGen
	
	IN Switches
	AND    Bit0
    ADDI   -1
	JZERO  SW0CHECKING
	
SWT1:
	IN Switches
	AND    Bit1
    ADDI   -2
	JZERO  SW1CHECKING
	
SWT2:
	IN Switches
	AND    Bit2
    ADDI   -4
	JZERO  SW2CHECKING
	
SWT3:
	IN Switches
	AND    Bit3
    ADDI   -8
	JZERO  SW3CHECKING
	
	JUMP GETINPUT
	

Finish:
	JUMP  Finish
	
SW0CHECKING:
	LOAD  Rand
	AND   BitSW0
	JZERO SWT1
	LOAD SW0value
	SUB  Max
	JZERO AddPointSW0
	JUMP Finish
	
SW1CHECKING:
	LOAD  Rand
	AND   BitSW1
	JZERO SWT2
	LOAD SW1value
	SUB  Max
	JZERO AddPointSW1
	JUMP Finish
	
SW2CHECKING:
	LOAD  Rand
	AND   BitSW2
	JZERO SWT3
	LOAD SW2value
	SUB  Max
	JZERO AddPointSW2
	JUMP Finish

SW3CHECKING:
	LOAD  Rand
	AND   BitSW3
	JZERO GETINPUT
	LOAD SW3value
	SUB  Max
	JZERO AddPointSW3
	JUMP Finish
	
AddPointSW0:
	LOAD Score
	ADDI 1
	store Score
	OUT   Hex1
	LOAD  Rand
	AND   MaskSetZeroSW0
	store Rand
	OUT   Hex0
	JUMP GETINPUT

AddPointSW1:
	LOAD Score
	ADDI 1
	store Score
	OUT   Hex1
	LOAD  Rand
	AND   MaskSetZeroSW1
	store Rand
	OUT   Hex0
	JUMP GETINPUT
	
AddPointSW2:
	LOAD Score
	ADDI 1
	store Score
	OUT   Hex1
	LOAD  Rand
	AND   MaskSetZeroSW2
	store Rand
	OUT   Hex0
	JUMP GETINPUT
	
AddPointSW3:
	LOAD Score
	ADDI 1
	store Score
	OUT   Hex1
	LOAD  Rand
	AND   MaskSetZeroSW3
	store Rand
	OUT   Hex0
	JUMP GETINPUT

Jret:
	RETURN
    
    
CheckMax:
    LOAD Remaining
    AND Mask
    SUB Max
    JNEG SkipUpdate
    ADD Max
    STORE Max
    RETURN

Next:
    LOAD Remaining
    SHIFT -4
    STORE Remaining
    LOAD Count
    ADDI -1
    STORE Count
    RETURN
    
SkipUpdate:
    RETURN
	



; Variables
Pattern:   DW 0
Rand:	   DW 0
Score:	   DW 0
Remaining: DW 0
Max:       DW 0
Count:     DW 0
SW0value:  DW 0
SW1value:  DW 0
SW2value:  DW 0
SW3value:  DW 0

; Useful values
Bit0:      DW &B0000000001
Bit9:      DW &B1000000000
Bit2:	   DW &B0000000100
Bit1:	   DW &B0000000010
Bit3:	   DW &B0000001000
BitSW0:    DW &H000F
BitSW1:    DW &H00F0
BitSW2:    DW &H0F00
BitSW3:    DW &HF000
Mask:      DW &H000F
MaskSetZeroSW0: DW &HFFF0
MaskSetZeroSW1: DW &HFF0F
MaskSetZeroSW2: DW &HF0FF
MaskSetZeroSW3: DW &H0FFF



; IO address constants
Switches:  EQU 000
LEDs:      EQU 001
Timer:     EQU 002
Hex0:      EQU 004
Hex1:      EQU 005
